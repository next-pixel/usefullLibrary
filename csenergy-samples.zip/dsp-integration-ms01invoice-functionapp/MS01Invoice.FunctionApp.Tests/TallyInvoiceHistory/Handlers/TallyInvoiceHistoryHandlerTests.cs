using System.Text.Json;
using Azure.Messaging.ServiceBus;
using Dsp.Int.Library.Common.Models;
using Dsp.Int.Library.Common.Models.Base;
using Dsp.Int.Library.Common.Models.Events;
using Dsp.Int.Library.Common.Models.Exceptions;
using Dsp.Int.Library.Common.Services.DspData;
using Dsp.Int.Library.Common.Services.IntStorageAccount;
using Microsoft.Extensions.Logging;
using Moq;
using MS01Invoice.FunctionApp.TallyInvoiceHistory.Handlers;
using Shouldly;

namespace MS01Invoice.FunctionApp.Tests.TallyInvoiceHistory.Handlers;

public class TallyInvoiceHistoryHandlerTests
{
    private readonly Mock<IDspLandingService> _dspLandingService;
    private readonly Mock<IIntStorageService> _intStorageService;
    private readonly TallyInvoiceHistoryHandler _handler;

    public TallyInvoiceHistoryHandlerTests()
    {
        var logger = new Mock<ILogger<TallyInvoiceHistoryHandler>>();
        _dspLandingService = new Mock<IDspLandingService>();
        _intStorageService = new Mock<IIntStorageService>();

        _handler = new TallyInvoiceHistoryHandler(logger.Object, _dspLandingService.Object, _intStorageService.Object);
    }

    [Fact]
    public async Task ProcessAsync_ValidationError()
    {
        // Arrange
        var message = ServiceBusModelFactory.ServiceBusReceivedMessage(BinaryData.FromString("[]"));

        // Act
        var result = await _handler.ProcessAsync(message, CancellationToken.None);

        // Assert
        result.ShouldBeOfType<FailureResult>();
        result.Exception.ShouldBeOfType<EventValidationException>();
    }

    [Theory]
    [InlineData("e02_lineItems_valid.json", "invoice_lineItems_valid_10.csv", 10)]
    [InlineData("e02_lineItems_valid.json", "invoice_lineItems_valid_0.csv", 0)]
    [InlineData("e02_invoiceDetails_valid.json", "invoices_valid_10.csv", 30)]
    [InlineData("e02_invoiceDetails_valid.json", "invoices_valid_0.csv", 0)]
    public async Task ProcessAsync_Valid(string eventData, string csvContent, int output)
    {
        // Arrange
        var inputE02 = await File.ReadAllTextAsync($"TallyInvoiceHistory/TestData/{eventData}");
        var input = JsonSerializer.Deserialize<BaseEventModel<E02InvoiceHistoryEventModel>>(inputE02);
        var csvContents = await File.ReadAllTextAsync($"TallyInvoiceHistory/TestData/{csvContent}");

        _intStorageService.Setup(x => x.DownloadFile(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(csvContents);

        _dspLandingService.Setup(x => x.UploadFile(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act
        var result = await _handler.ProcessAsync(input, CancellationToken.None);

        // Assert
        result.ShouldBeOfType<Result>();

        _intStorageService.Verify(x => x.DownloadFile(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()),
            Times.Once);

        _dspLandingService.Verify(x => x.UploadFile(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()),
            Times.Exactly(output));
    }

    [Fact]
    public async Task ProcessAsync_Handles_UnRecoverableException_IntegrationStorageAccountService()
    {
        // Arrange
        var inputFile = await File.ReadAllTextAsync("TallyInvoiceHistory/TestData/e02_invoiceDetails_valid.json");
        var input = JsonSerializer.Deserialize<BaseEventModel<E02InvoiceHistoryEventModel>>(inputFile);

        _intStorageService.Setup(x => x.DownloadFile(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new UnRecoverableException("Error"));

        // Act & Assert
        await Should.ThrowAsync<UnRecoverableException>(() => _handler.ProcessAsync(input, CancellationToken.None));

        _dspLandingService.Verify(x => x.UploadFile(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Theory]
    [InlineData("e02_lineItems_valid.json", "invoice_lineItems_valid_10.csv")]
    [InlineData("e02_invoiceDetails_valid.json", "invoices_valid_10.csv")]
    public async Task ProcessAsync_Handles_UnRecoverableException_DspLandingService(string eventData, string csvContent)
    {
        // Arrange
        var inputE02 = await File.ReadAllTextAsync($"TallyInvoiceHistory/TestData/{eventData}");
        var input = JsonSerializer.Deserialize<BaseEventModel<E02InvoiceHistoryEventModel>>(inputE02);
        var csvContents = await File.ReadAllTextAsync($"TallyInvoiceHistory/TestData/{csvContent}");

        _intStorageService.Setup(x => x.DownloadFile(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(csvContents);

        _dspLandingService.Setup(x => x.UploadFile(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new UnRecoverableException("Error"));

        // Act & Assert
        await Should.ThrowAsync<UnRecoverableException>(() => _handler.ProcessAsync(input, CancellationToken.None));
    }
}