using System.Globalization;
using System.Text.Json;
using System.Text.Json.Serialization;
using CsvHelper;
using Dsp.Int.Library.Common.Services.Tally.Dtos;
using MS01Invoice.FunctionApp.TallyInvoiceHistory.Mappers;
using Shouldly;

namespace MS01Invoice.FunctionApp.Tests.TallyInvoiceHistory.Mappers;

public class TallyHistoricToDspMapperTests
{
    private readonly JsonSerializerOptions _jsonSerializerOptions = new()
    {
        DefaultIgnoreCondition = JsonIgnoreCondition.Never,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = true
    };


    [Fact]
    public async Task MapToDspTallyHistoricInvoiceDto_Valid()
    {
        // Arrange
        var csvContents = await File.ReadAllTextAsync("TallyInvoiceHistory/TestData/invoices_valid_2.csv");
        var csvReader = new CsvReader(new StringReader(csvContents), CultureInfo.CurrentCulture);
        var input = csvReader.GetRecords<TallyHistoricInvoiceDto>();

        var invoiceDetailExpected = await File.ReadAllTextAsync("TallyInvoiceHistory/TestData/invoices_valid_2_detail_expected.json");
        var siteAddressExpected = await File.ReadAllTextAsync("TallyInvoiceHistory/TestData/invoices_valid_2_siteAddress_expected.json");
        var billingAddressExpected = await File.ReadAllTextAsync("TallyInvoiceHistory/TestData/invoices_valid_2_billingAddress_expected.json");

        // Act

        var (invoiceDetail, siteAddress, billingAddress) = TallyHistoricToDspMapper.MapToDspTallyInvoiceDetailDto(input);

        var invoiceDetailActual = JsonSerializer.Serialize(invoiceDetail, _jsonSerializerOptions);
        var siteAddressActual = JsonSerializer.Serialize(siteAddress, _jsonSerializerOptions);
        var billingAddressActual = JsonSerializer.Serialize(billingAddress, _jsonSerializerOptions);

        // Assert

        invoiceDetailActual.ShouldBe(invoiceDetailExpected);
        siteAddressActual.ShouldBe(siteAddressExpected);
        billingAddressActual.ShouldBe(billingAddressExpected);
    }

    [Fact]
    public async Task MapToDspTallyHistoricLineItemDto_Valid()
    {
        // Arrange
        var csvContents = await File.ReadAllTextAsync("TallyInvoiceHistory/TestData/invoice_lineItems_valid_2.csv");
        var csvReader = new CsvReader(new StringReader(csvContents), CultureInfo.CurrentCulture);
        var input = csvReader.GetRecords<TallyHistoricLineItemDto>();

        var expected = await File.ReadAllTextAsync("TallyInvoiceHistory/TestData/invoice_lineItems_valid_2_expected.json");

        // Act
        var output = TallyHistoricToDspMapper.MapToDspTallyLineItemsDictionary(input);
        var actual = JsonSerializer.Serialize(output, _jsonSerializerOptions);

        // Assert

        actual.ShouldBe(expected);
    }

    [Fact]
    public void MapToDspTallyHistoricInvoiceDtoInvalid()
    {
        // Act
        var (invoiceDetail, siteAddress, billingAddress) = TallyHistoricToDspMapper.MapToDspTallyInvoiceDetailDto(null);

        // Assert
        invoiceDetail.ShouldBeNull();
        siteAddress.ShouldBeNull();
        billingAddress.ShouldBeNull();
    }

    [Fact]
    public void MapToDspTallyHistoricLineItemDto_Invalid()
    {
        // Act
        var result = TallyHistoricToDspMapper.MapToDspTallyLineItemsDictionary(null);

        // Assert
        result.ShouldNotBeNull();
        result.Count.ShouldBe(0);
    }
}