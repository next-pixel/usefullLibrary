using System.Text.Json;
using Azure.Messaging.ServiceBus;
using Dsp.Int.Library.Common.Models;
using Dsp.Int.Library.Common.Models.Base;
using Dsp.Int.Library.Common.Models.Events;
using Dsp.Int.Library.Common.Models.Exceptions;
using Dsp.Int.Library.Common.Services.DspData;
using Dsp.Int.Library.Common.Services.Tally;
using Dsp.Int.Library.Common.Services.Tally.Dtos;
using Microsoft.Extensions.Logging;
using Moq;
using MS01Invoice.FunctionApp.TallyInvoiceEvent.Handlers;
using Shouldly;

namespace MS01Invoice.FunctionApp.Tests.TallyInvoiceEvent.Handlers;

public class TallyInvoiceEventHandlerTests
{
    private readonly Mock<IDspLandingService> _dspLandingService;
    private readonly Mock<ITallyService> _tallyService;
    private readonly TallyInvoiceEventHandler _handler;

    public TallyInvoiceEventHandlerTests()
    {
        var logger = new Mock<ILogger<TallyInvoiceEventHandler>>();
        _dspLandingService = new Mock<IDspLandingService>();
        _tallyService = new Mock<ITallyService>();

        _handler = new TallyInvoiceEventHandler(logger.Object, _tallyService.Object, _dspLandingService.Object);
    }


    [Fact]
    public async Task ProcessAsync_ValidationError()
    {
        // Arrange
        var message = ServiceBusModelFactory.ServiceBusReceivedMessage(BinaryData.FromString("[]"));

        // Act
        var result = await _handler.ProcessAsync(message, CancellationToken.None);

        // Assert
        result.ShouldBeOfType<FailureResult>();
        result.Exception.ShouldBeOfType<EventValidationException>();
    }

    [Fact]
    public async Task ProcessAsync_ValidationError_NoInvoiceNumber()
    {
        // Arrange
        var inputFile = await File.ReadAllTextAsync("TallyInvoiceEvent/TestData/e01_valid.json");
        var input = JsonSerializer.Deserialize<BaseEventModel<E01InvoiceEventModel>>(inputFile);


        // Act
        var result = await _handler.ProcessAsync(input, CancellationToken.None);

        // Assert
        result.ShouldBeOfType<FailureResult>();
        result.Exception.ShouldBeOfType<EventValidationException>();
    }

    [Fact]
    public async Task ProcessAsync_Valid()
    {
        // Arrange
        var inputFile = await File.ReadAllTextAsync("TallyInvoiceEvent/TestData/e01_valid.json");
        var input = JsonSerializer.Deserialize<BaseEventModel<E01InvoiceEventModel>>(inputFile);
        var invoiceDetailsFile = await File.ReadAllTextAsync("TallyInvoiceEvent/TestData/tally_valid_invoice.json");
        var invoiceDetails = JsonSerializer.Deserialize<TallyInvoiceDetailDto>(invoiceDetailsFile);

        _tallyService.Setup(x => x.GetInvoice(
                It.IsAny<BaseRequestModel<NoRequest>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(invoiceDetails);

        _dspLandingService.Setup(x => x.UploadFile(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act
        var result = await _handler.ProcessAsync(input, CancellationToken.None);

        // Assert
        result.ShouldBeOfType<SuccessResult>();
        _dspLandingService.Verify(x => x.UploadFile(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()),
            Times.Exactly(4));
    }

    [Fact]
    public async Task ProcessAsync_Handles_UnRecoverableException_TallyService()
    {
        // Arrange
        var inputFile = await File.ReadAllTextAsync("TallyInvoiceEvent/TestData/e01_valid.json");
        var input = JsonSerializer.Deserialize<BaseEventModel<E01InvoiceEventModel>>(inputFile);

        _tallyService.Setup(x => x.GetInvoice(
                It.IsAny<BaseRequestModel<NoRequest>>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new UnRecoverableException("Error"));

        // Act
        var result = await _handler.ProcessAsync(input, CancellationToken.None);

        // Assert
        result.ShouldBeOfType<FailureResult>();
        result.Exception.ShouldBeOfType<UnRecoverableException>();
        _dspLandingService.Verify(x => x.UploadFile(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task ProcessAsync_Handles_StandardCommsException_TallyService()
    {
        // Arrange
        var inputFile = await File.ReadAllTextAsync("TallyInvoiceEvent/TestData/e01_valid.json");
        var input = JsonSerializer.Deserialize<BaseEventModel<E01InvoiceEventModel>>(inputFile);

        _tallyService.Setup(x => x.GetInvoice(
                It.IsAny<BaseRequestModel<NoRequest>>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new StandardCommunicationException("Error"));

        // Act
        var result = await _handler.ProcessAsync(input, CancellationToken.None);

        // Assert
        result.ShouldBeOfType<FailureResult>();
        result.Exception.ShouldBeOfType<StandardCommunicationException>();
        _dspLandingService.Verify(x => x.UploadFile(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }
}