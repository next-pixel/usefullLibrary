using System.Text.Json;
using Dsp.Int.Library.Common.Services.Tally.Dtos;
using MS01Invoice.FunctionApp.TallyInvoiceEvent.Mappers;
using Shouldly;

namespace MS01Invoice.FunctionApp.Tests.TallyInvoiceEvent.Mappers;

public class TallyToDspMapperTests
{
    [Fact]
    public void MapToDspTallyInvoiceDetailDto_Valid()
    {
        // Arrange
        var inputFile = File.ReadAllText("TallyInvoiceEvent/TestData/tally_valid_invoice.json");
        var input = JsonSerializer.Deserialize<TallyInvoiceDetailDto>(inputFile);

        // Act
        var result = TallyToDspMapper.MapToDspTallyInvoiceDetailDto(input);

        // Assert

    }

    [Fact]
    public void MapToDspTallyAddressDto_BillingAddress_Valid()
    {
        // Arrange
        var inputFile = File.ReadAllText("TallyInvoiceEvent/TestData/tally_valid_invoice.json");
        var input = JsonSerializer.Deserialize<TallyInvoiceDetailDto>(inputFile);

      // Assert

      
    }

    [Fact]
    public void MapToDspTallyAddressDto_SiteAddress_Valid()
    {
        // Arrange
        var inputFile = File.ReadAllText("TallyInvoiceEvent/TestData/tally_valid_invoice.json");
        var input = JsonSerializer.Deserialize<TallyInvoiceDetailDto>(inputFile);

    
     
    }

    [Fact]
    public void MapToDspTallyLineItems_Valid()
    {
        // Arrange
        var inputFile = File.ReadAllText("TallyInvoiceEvent/TestData/tally_valid_invoice.json");
        var input = JsonSerializer.Deserialize<TallyInvoiceDetailDto>(inputFile);

        // Act
       
       
    }

    [Fact]
    public void MapToDspTallyAddressDto_SiteAddress_Invalid()
    {
        // Act
        var result = TallyToDspMapper.MapToDspTallyAddressDto(null, "sample");

        // Assert
        result.ShouldBeNull();
    }

    [Fact]
    public void MapToDspTallyAddressDto_InvoiceDetails_Invalid()
    {
        // Act
        var result = TallyToDspMapper.MapToDspTallyInvoiceDetailDto(null);

        // Assert
        result.ShouldBeNull();
    }

    [Fact]
    public void MapToDspTallyAddressDto_LineItems_Invalid()
    {
        // Act
        var result = TallyToDspMapper.MapToDspTallyLineItemDto(null, "sample");

        // Assert
        result.ShouldNotBe(null);
        result.Count.ShouldBe(0);
    }
}