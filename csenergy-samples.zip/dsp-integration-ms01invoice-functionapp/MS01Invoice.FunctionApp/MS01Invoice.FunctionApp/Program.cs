using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using MS01Invoice.FunctionApp.Configuration;

var host = new HostBuilder()
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureServices((hostContext, collection) =>
    {
        collection.AddDependencies(hostContext);
        collection.AddApplicationInsightsTelemetryWorkerService();
        collection.ConfigureFunctionsApplicationInsights();
    })
    .ConfigureAppConfiguration((hostContext, config) => { config.AddJsonFile("host.json", true); })
    .ConfigureLogging((hostingContext, logging) =>
    {
        logging.AddApplicationInsights(console => { console.IncludeScopes = true; });

        logging.AddConfiguration(hostingContext.Configuration.GetSection("logging"));
        logging.Services.Configure<LoggerFilterOptions>(options =>
        {
            var defaultRule = options.Rules.FirstOrDefault(rule => rule.ProviderName
                                                                   == "Microsoft.Extensions.Logging.ApplicationInsights.ApplicationInsightsLoggerProvider");
            if (defaultRule is not null)
            {
                options.Rules.Remove(defaultRule);
            }
        });
    })
    .Build();

host.Run();