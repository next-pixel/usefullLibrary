using System.Diagnostics.CodeAnalysis;
using System.Net;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;

namespace MS01Invoice.FunctionApp.Ping;

[ExcludeFromCodeCoverage]
public class PingFunction
{
    private readonly ILogger _logger;

    public PingFunction(ILoggerFactory loggerFactory)
    {
        _logger = loggerFactory.CreateLogger<PingFunction>();
    }

    [Function("PingFunction")]
    public HttpResponseData Run([HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequestData req,
        FunctionContext executionContext)
    {
        _logger.LogInformation("Hello World - Ping Test");

        var response = req.CreateResponse(HttpStatusCode.OK);
        response.Headers.Add("Content-Type", "text/plain; charset=utf-8");

        response.WriteString("Ping Test Successful");

        return response;
    }
}