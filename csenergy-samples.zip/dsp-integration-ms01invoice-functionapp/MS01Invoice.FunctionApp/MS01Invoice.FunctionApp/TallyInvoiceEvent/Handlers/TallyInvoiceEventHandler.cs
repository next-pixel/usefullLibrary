using System.Text.Json;
using Azure.Messaging.ServiceBus;
using Dsp.Int.Library.Common.Handlers;
using Dsp.Int.Library.Common.Helpers;
using Dsp.Int.Library.Common.Models;
using Dsp.Int.Library.Common.Models.Base;
using Dsp.Int.Library.Common.Models.Events;
using Dsp.Int.Library.Common.Models.Exceptions;
using Dsp.Int.Library.Common.Services.DspData;
using Dsp.Int.Library.Common.Services.Tally;
using Microsoft.Extensions.Logging;
using MS01Invoice.FunctionApp.Configuration;
using MS01Invoice.FunctionApp.TallyInvoiceEvent.Mappers;

namespace MS01Invoice.FunctionApp.TallyInvoiceEvent.Handlers;

public interface ITallyInvoiceEventHandler : IBaseMessageHandler
{
    Task<Result> ProcessAsync(BaseEventModel<E01InvoiceEventModel> message, CancellationToken cancellationToken);
}

public class TallyInvoiceEventHandler(ILogger<TallyInvoiceEventHandler> log, ITallyService tallyService, IDspLandingService dspLandingService)
    : ITallyInvoiceEventHandler
{
    /// <summary>
    ///     Processes a ServiceBusReceivedMessage asynchronously by deserializing it into a BaseEventModel and invoking further
    ///     processing.
    /// </summary>
    public async Task<Result> ProcessAsync(ServiceBusReceivedMessage request, CancellationToken cancellationToken)
    {
        // Deserialize the business event
        try
        {
            var message = JsonSerializer.Deserialize<BaseEventModel<E01InvoiceEventModel>>(request.Body.ToString());
            return await ProcessAsync(message, cancellationToken);
        } 
        catch (UnRecoverableException e)
        {
            return new FailureResult(e);
        }
        catch (StandardCommunicationException e)
        {
            return new FailureResult(e);
        }
        catch (Exception ex)
        {
            log.LogError(ex, "Error deserializing message");
            return new FailureResult(new EventValidationException("Error deserializing message"));
        }
    }

    /// <summary>
    ///     Processes an invoice event model asynchronously, performing validation, processing, and uploading resulting CSV
    ///     data.
    /// </summary>
    public async Task<Result> ProcessAsync(BaseEventModel<E01InvoiceEventModel> message, CancellationToken cancellationToken)
    {
        // -- Validate --
        var invoiceNumber = "";
        // var invoiceNumber = ""message.Payload?.InvoiceNumber;
        // if (invoiceNumber == null)
        // {
        //     return new FailureResult(new EventValidationException("InvoiceNumber is not present"));
        // }

        // -- Process --
        log.LogInformation("Processing invoice: {InvoiceNumber}", invoiceNumber);
        try
        {
            var invoiceDetails = await tallyService.GetInvoice(GenerateGetInvoiceRequest(invoiceNumber), CancellationToken.None);

           
            var uploads = new List<Task>
            {

            };

            await Task.WhenAll(uploads);
        }
        catch (Exception ex)
        {
            log.LogError(ex, "Error processing invoice: {InvoiceNumber}", invoiceNumber);
            return new FailureResult(ex);
        }

        // -- Response --
        return new SuccessResult();
    }

    /// <summary>
    ///     Asynchronously uploads a single item as a CSV file to a designated storage location.
    /// </summary>
    private async Task UploadCsvAsync<T>(T data, string category, string invoiceNumber, CancellationToken cancellationToken)
    {
        if (data == null) return;

        var csvData = CsvFormatHelper.ConvertToCsv(data);
        await UploadFile(category, invoiceNumber, csvData, cancellationToken);
    }

    /// <summary>
    ///     Asynchronously uploads a collection of items as a CSV file to a designated storage location.
    /// </summary>
    private async Task UploadListCsvAsync<T>(IReadOnlyCollection<T> data, string category, string invoiceNumber, CancellationToken cancellationToken)
    {
        if (data == null) return;
        var csvData = CsvFormatHelper.ConvertListToCsv(data);
        await UploadFile(category, invoiceNumber, csvData, cancellationToken);
    }

    /// <summary>
    ///     Asynchronously uploads CSV data to a designated storage container and file path.
    /// </summary>
    private async Task UploadFile(string category, string invoiceNumber, string csvData, CancellationToken cancellationToken)
    {
   
    }

    /// <summary>
    ///     Generates a request model for fetching an invoice based on its number.
    /// </summary>
    private BaseRequestModel<NoRequest> GenerateGetInvoiceRequest(string invoiceNumber)
    {
        var req = new BaseRequestModel<NoRequest>
        {
            PathParams = new Dictionary<string, string>
            {
                { Constants.InvoiceNumberParam, invoiceNumber }
            }
        };

        return req;
    }
}