using Dsp.Int.Library.Common.Services.DspData.Dtos.LandingTally;
using Dsp.Int.Library.Common.Services.Tally.Dtos;

namespace MS01Invoice.FunctionApp.TallyInvoiceEvent.Mappers;

public static class TallyToDspMapper
{
    public static DspTallyInvoiceDetailDto MapToDspTallyInvoiceDetailDto(TallyInvoiceDetailDto i)
    {
        if (i == null)
        {
            return null;
        }

        var o = new DspTallyInvoiceDetailDto
        {
            
        };

        return o;
    }

    public static DspTallyAddressDto MapToDspTallyAddressDto(TallyAddressDto i, string invoiceNumber)
    {
        if (i == null)
        {
            return null;
        }

        var o = new DspTallyAddressDto
        {
            
        };

        return o;
    }

    public static List<DspTallyLineItemDto> MapToDspTallyLineItemDto(List<TallyLineItemDto> lineItems, string invoiceNumber)
    {
        var dspLineItems = new List<DspTallyLineItemDto>();
        if (lineItems == null)
        {
            return dspLineItems;
        }

        foreach (var i in lineItems)
        {
            var o = new DspTallyLineItemDto
            {
              
            };
            dspLineItems.Add(o);
        }

        return dspLineItems;
    }
}