using Dsp.Int.Library.Common.Extensions;
using Dsp.Int.Library.Common.Services.DspData.Dtos.LandingTally;
using Dsp.Int.Library.Common.Services.Tally.Dtos;

namespace MS01Invoice.FunctionApp.TallyInvoiceHistory.Mappers;

public static class TallyHistoricToDspMapper
{
    public static (IEnumerable<DspTallyInvoiceDetailDto>, IEnumerable<DspTallyAddressDto>, IEnumerable<DspTallyAddressDto>) MapToDspTallyInvoiceDetailDto(
        IEnumerable<TallyHistoricInvoiceDto> input)
    {
        if (input == null)
        {
            return (null, null, null);
        }

        var invoiceDetailsList = new List<DspTallyInvoiceDetailDto>();
        var siteAddressList = new List<DspTallyAddressDto>();
        var billingAddressList = new List<DspTallyAddressDto>();

        foreach (var i in input)
        {
            var invoiceDetails = new DspTallyInvoiceDetailDto
            {
              
            };
            var siteAddress = new DspTallyAddressDto
            {
                
            };
            var billingAddress = new DspTallyAddressDto
            {

            };
            invoiceDetailsList.Add(invoiceDetails);
            siteAddressList.Add(siteAddress);
            billingAddressList.Add(billingAddress);
        }

        return (invoiceDetailsList, siteAddressList, billingAddressList);
    }

    public static Dictionary<string, List<DspTallyLineItemDto>> MapToDspTallyLineItemsDictionary(IEnumerable<TallyHistoricLineItemDto> lineItems)
    {
        var items = new Dictionary<string, List<DspTallyLineItemDto>>();

        if (lineItems == null)
        {
            return items;
        }

        foreach (var i in lineItems)
        {
            var o = new DspTallyLineItemDto
            {
               
            };
            
            // value.Add(o);
        }

        return items;
    }
}