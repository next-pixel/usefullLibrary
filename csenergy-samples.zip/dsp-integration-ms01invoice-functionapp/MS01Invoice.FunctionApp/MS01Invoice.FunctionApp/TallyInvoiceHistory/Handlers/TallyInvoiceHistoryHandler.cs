using System.Globalization;
using System.Text.Json;
using Azure.Messaging.ServiceBus;
using CsvHelper;
using Dsp.Int.Library.Common.Handlers;
using Dsp.Int.Library.Common.Helpers;
using Dsp.Int.Library.Common.Models;
using Dsp.Int.Library.Common.Models.Base;
using Dsp.Int.Library.Common.Models.Events;
using Dsp.Int.Library.Common.Models.Exceptions;
using Dsp.Int.Library.Common.Services.DspData;
using Dsp.Int.Library.Common.Services.DspData.Dtos.LandingTally;
using Dsp.Int.Library.Common.Services.IntStorageAccount;
using Dsp.Int.Library.Common.Services.Tally.Dtos;
using Microsoft.Extensions.Logging;
using MS01Invoice.FunctionApp.Configuration;
using MS01Invoice.FunctionApp.TallyInvoiceHistory.Mappers;

namespace MS01Invoice.FunctionApp.TallyInvoiceHistory.Handlers;

public interface ITallyInvoiceHistoryHandler : IBaseMessageHandler
{
    Task<Result> ProcessAsync(BaseEventModel<E02InvoiceHistoryEventModel> message, CancellationToken cancellationToken);
}

public class TallyInvoiceHistoryHandler(ILogger<TallyInvoiceHistoryHandler> log, IDspLandingService dspLandingService, IIntStorageService intStorageService)
    : ITallyInvoiceHistoryHandler
{
    /// <summary>
    ///     Processes a ServiceBusReceivedMessage asynchronously by deserializing it into a BaseEventModel and invoking further
    ///     processing.
    /// </summary>
    public async Task<Result> ProcessAsync(ServiceBusReceivedMessage request, CancellationToken cancellationToken)
    {
        // Deserialize the business event
        try
        {
            var message = JsonSerializer.Deserialize<BaseEventModel<E02InvoiceHistoryEventModel>>(request.Body.ToString());
            return await ProcessAsync(message, cancellationToken);
        }
        catch (UnRecoverableException e)
        {
            return new FailureResult(e);
        }
        catch (StandardCommunicationException e)
        {
            return new FailureResult(e);
        }
        catch (Exception ex)
        {
            log.LogError(ex, "Error deserializing message");
            return new FailureResult(new EventValidationException("Error deserializing message"));
        }
    }

    public async Task<Result> ProcessAsync(BaseEventModel<E02InvoiceHistoryEventModel> message, CancellationToken cancellationToken)
    {
      
        return new Result();
    }

    private async Task HandleInvoiceDetails(string input, CancellationToken cancellationToken)
    {
        IEnumerable<DspTallyInvoiceDetailDto> invoiceDetailsList;
        IEnumerable<DspTallyAddressDto> siteAddressList;
        IEnumerable<DspTallyAddressDto> billingAddressList;

        try
        {
            var csvReader = new CsvReader(new StringReader(input), CultureInfo.CurrentCulture);
            var invoiceItems = csvReader.GetRecords<TallyHistoricInvoiceDto>();
            (invoiceDetailsList, siteAddressList, billingAddressList) = TallyHistoricToDspMapper.MapToDspTallyInvoiceDetailDto(invoiceItems);
        }
        catch (Exception e)
        {
            throw new UnRecoverableException("Mapping to Dsp Dto failed.", e);
        }

        var uploadTasks = new List<Task<Result>>();
        

        var results = await Task.WhenAll(uploadTasks);

        var exceptions = results.Where(r => r.State == ResultState.Failure)
            .Select(r => r.Exception)
            .ToList();

        if (exceptions.Count != 0)
        {
            throw new UnRecoverableException("Processing File failed. {Message}", exceptions[0]);
        }
    }

    private async Task HandleLineItems(string input, CancellationToken cancellationToken)
    {
        Dictionary<string, List<DspTallyLineItemDto>> mappedValue;
        try
        {
            var csvReader = new CsvReader(new StringReader(input), CultureInfo.CurrentCulture);
            var lineItems = csvReader.GetRecords<TallyHistoricLineItemDto>();
            mappedValue = TallyHistoricToDspMapper.MapToDspTallyLineItemsDictionary(lineItems);
        }
        catch (Exception e)
        {
            throw new UnRecoverableException("Mapping to Dsp Dto failed.", e);
        }

        log.LogInformation("Unique Invoices in LineItems {Count}", mappedValue.Count);

        var uploadTasks = new List<Task<Result>>();
       
        var results = await Task.WhenAll(uploadTasks);

        var exceptions = results.Where(r => r.State == ResultState.Failure)
            .Select(r => r.Exception)
            .ToList();

        if (exceptions.Count != 0)
        {
            throw new UnRecoverableException("Processing File failed. {Message}", exceptions[0]);
        }
    }

    private async Task<Result> UploadLineItemsFile(IEnumerable<DspTallyLineItemDto> items, string invoiceNumber, CancellationToken cancellationToken)
    {
        throw new NotImplementedException();
    }

    private async Task<Result> UploadCsvFile<T>(T data, string invoiceNumber, string category, CancellationToken cancellationToken)
    {
        throw new NotImplementedException(); 
    }

    /// <summary>
    ///     Asynchronously uploads CSV data to a designated storage container and file path.
    /// </summary>
    private async Task UploadFile(string category, string invoiceNumber, string csvData, CancellationToken cancellationToken)
    {
       
    }
}