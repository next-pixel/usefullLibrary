using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Text.Json;
using Azure.Messaging.ServiceBus;
using Dsp.Int.Library.Common.Events;
using Dsp.Int.Library.Common.Handlers;
using Dsp.Int.Library.Common.Models;
using Dsp.Int.Library.Common.Models.Base;
using Dsp.Int.Library.Common.Models.Events;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using MS01Invoice.FunctionApp.TallyInvoiceHistory.Handlers;

namespace MS01Invoice.FunctionApp.TallyInvoiceHistory;

[ExcludeFromCodeCoverage]
public class TallyInvoiceHistoryFunction(
    IServiceBusMessageHandler<TallyInvoiceHistoryHandler> messageHandler,
    ITallyInvoiceHistoryHandler handler,
    ILogger<TallyInvoiceHistoryFunction> logger)
{
    [Function(nameof(TallyInvoiceHistoryFunction))]
    public async Task RunAsync(
        [ServiceBusTrigger(ServiceBusConstants.Topics.History, ServiceBusConstants.Subscriptions.DspInvoiceHistory, Connection = "ServiceBusConnection", AutoCompleteMessages = false)]
        ServiceBusReceivedMessage message,
        ServiceBusMessageActions messageActions,
        CancellationToken cancellationToken)
    {
        logger.LogInformation("Message ID: {Id}", message.MessageId);
        logger.LogInformation("Message Body: {Body}", message.Body);
        logger.LogInformation("Message Content-Type: {ContentType}", message.ContentType);

        await messageHandler.ProcessAsync(message, messageActions, handler, cancellationToken);

        logger.LogInformation("{FunctionName} processed message: {MessageId}", nameof(TallyInvoiceHistoryFunction), message.MessageId);
    }

    /// <summary>
    ///     Helper function to develop locally with an HTTP trigger.
    ///     This function is disabled when deployed to Azure.
    /// </summary>
    [Function("TallyInvoiceHistoryHttpTrigger")]
    public async Task<HttpResponseData> RunHttpAsync([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req,
        FunctionContext executionContext, CancellationToken cancellationToken)
    {
        var body = await new StreamReader(req.Body).ReadToEndAsync(cancellationToken);

        var message = JsonSerializer.Deserialize<BaseEventModel<E02InvoiceHistoryEventModel>>(body);

        var result = await handler.ProcessAsync(message, cancellationToken);
        var response = req.CreateResponse(HttpStatusCode.OK);
        if (result.State != ResultState.Failure) return response;

        await response.WriteStringAsync(result.Exception.Message, cancellationToken);
        response.StatusCode = HttpStatusCode.BadRequest;
        return response;
    }
}