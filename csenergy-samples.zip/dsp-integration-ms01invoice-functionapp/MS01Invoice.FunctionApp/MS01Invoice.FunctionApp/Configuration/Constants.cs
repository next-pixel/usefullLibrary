namespace MS01Invoice.FunctionApp.Configuration;

public static class Constants
{
    public const string CsvFileFormat = "csv";

    public const string DirectoryLanding = "landing";
    public const string InvoiceNumberParam = "invoiceNumber";
    
    public const string SuffixHistory = "_HIST";

    public const string InvoiceDetailsBase = "invoiceDetails_base";
    public const string InvoiceDetailsSiteAddress = "invoiceDetails_siteAddress";
    public const string InvoiceDetailsBillingAddress = "invoiceDetails_billingAddress";
    public const string InvoiceDetailsLineItems = "invoiceDetails_lineItems";

    public const string DspStorageClient = nameof(DspStorageClient);
    public const string IntStorageClient = nameof(IntStorageClient);
    public const string LineItems = "LineItems";
}