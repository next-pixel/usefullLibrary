using System.Diagnostics.CodeAnalysis;
using Azure.Identity;
using Dsp.Int.Library.Common.Handlers;
using Dsp.Int.Library.Common.Services.DspData;
using Dsp.Int.Library.Common.Services.Http;
using Dsp.Int.Library.Common.Services.IntStorageAccount;
using Dsp.Int.Library.Common.Services.Tally;
using Dsp.Int.Library.Common.Services.Tally.Config;
using Microsoft.Extensions.Azure;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using MS01Invoice.FunctionApp.TallyInvoiceEvent.Handlers;
using MS01Invoice.FunctionApp.TallyInvoiceHistory.Handlers;

namespace MS01Invoice.FunctionApp.Configuration;

[ExcludeFromCodeCoverage]
public static class ServicesContainer
{
    public static IServiceCollection AddDependencies(
        this IServiceCollection serviceCollection, HostBuilderContext hostContext)
    {
        serviceCollection
            .RegisterOptions(hostContext.Configuration)
            .RegisterAzureServices()
            .RegisterServices()
            .RegisterHandlers();

        return serviceCollection;
    }

    private static IServiceCollection RegisterOptions(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<TallyOptions>(configuration.GetSection(TallyConstants.Tally));
        return services;
    }

    private static IServiceCollection RegisterServices(this IServiceCollection services)
    {
        services.AddScoped<ITallyService, TallyService>();
        services.AddScoped<IIntStorageService, IntStorageService>();
        services.AddScoped<IDspLandingService, DspLandingService>();

        return services;
    }

    private static IServiceCollection RegisterHandlers(this IServiceCollection services)
    {
        // Common Handler
        services.AddScoped(typeof(IServiceBusMessageHandler<>), typeof(ServiceBusMessageHandler<>));
        services.AddScoped<IHttpClientHelper, HttpClientHelper>();

        // Handlers
        services.AddScoped<ITallyInvoiceEventHandler, TallyInvoiceEventHandler>();
        services.AddScoped<ITallyInvoiceHistoryHandler, TallyInvoiceHistoryHandler>();

        var tallyBaseUrl = GetEnvironmentVariable(TallyConstants.TallyBaseUrl);
        services.AddHttpClient(TallyConstants.Tally).ConfigureHttpClient(x => { x.BaseAddress = new Uri(tallyBaseUrl!); });

        return services;
    }

    private static IServiceCollection RegisterAzureServices(this IServiceCollection services)
    {
        var userAssignedClientId = GetEnvironmentVariable("ServiceBusConnection__clientId");
        // "ServiceBusConnection__clientId" contains managedIdentityClientId
        var dspStorageAccount = GetEnvironmentVariable("Dsp_storageAccount");
        var intStorageAccount = GetEnvironmentVariable("Int_storageAccount");

        var credentials = new DefaultAzureCredential(new DefaultAzureCredentialOptions
            { ManagedIdentityClientId = userAssignedClientId });

        services.AddAzureClients(clientBuilder =>
        {
            clientBuilder.AddBlobServiceClient(new Uri($"https://{intStorageAccount}.blob.core.windows.net"))
                .WithCredential(credentials)
                .WithName(Constants.IntStorageClient);

            clientBuilder.AddBlobServiceClient(new Uri($"https://{dspStorageAccount}.blob.core.windows.net"))
                .WithCredential(credentials)
                .WithName(Constants.DspStorageClient);
        });
        return services;
    }

    private static string GetEnvironmentVariable(string name)
    {
        var value = Environment.GetEnvironmentVariable(name, EnvironmentVariableTarget.Process);
        return value!;
    }
}