# Introduction 
This repository is used to store the IaC for DSP. IaC scripts are based on BICEP and deployments in Azure environments are done using Azure DevOps piplines. Service principal and Service connections are set up within microsoft entra Id and Azure devops respectively.
The Repository is orgnaised into consisting of integration, core and analytics  stacks. Each stack consists of individual modules and parameter files

# Getting Started
Guide users through getting your code up and running on their own system. In this section you can talk about:
1.	Confifure the parameter file based on the environment to be provisioned. Add correct values for subscription, resources groups, IPs, resrource names and skus for each environment in a separate parameter file named as "parameter.<env>.ae.jsnoc
2.	Save the code changes and push to remote branch
3.	Choose the correct devops pipleine wihtin azure devops to deploy the infrastructure (Core, Integration, analytics)
4.	Within the pipeline configuration choose the stages to run (Build, dev, test, uat, production)

# Note:
For Subnets and NSGS meant for databricks 
    Comment/ remove the parameters and code for NSGs and subnets specific to Databricks after the subnets have been delgated to databricks. If this is not done, the pipline run will fail after the initial run since Azure would consider this as a change to the delegated subnets which will cause a conflict.

# Deployment Order:
The below indicates the deployment order for each stack. 

## Integration
For integration, the deployment has been split into two as the ADF service disconnects its GIT connection when other services in the integration stack are deployed. For this reason, the deployment should be as follows: 
1. Integration
2. Integration-ADF

# Contribute
Get in touch with the DSP CORE Team. 
