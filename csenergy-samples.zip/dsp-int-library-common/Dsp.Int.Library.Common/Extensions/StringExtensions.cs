using System.Globalization;

namespace Dsp.Int.Library.Common.Extensions;

public static class StringExtensions
{
    const string GeneralDateFormat = "MM/dd/yyyy HH:mm:ss";
    public static bool IsNullOrWhiteSpace(this string value)
    {
        return string.IsNullOrWhiteSpace(value) || string.IsNullOrEmpty(value);
    }
    
    public static DateTime ToDateTimeInvariant(this string value)
    {
        return DateTime.ParseExact(value, GeneralDateFormat, CultureInfo.InvariantCulture);
    }
    
    public static DateTime? ToDateTimeOrNull(this string value)
    {
        if (value.IsNullOrWhiteSpace())
        {
            return null;
        }
        
        var r = DateTime.ParseExact(value, GeneralDateFormat, CultureInfo.InvariantCulture);
        return r;
    }
}