using System.Text.Json.Serialization;

namespace Dsp.Int.Library.Common.Services.Tally.Config;

public class TallyOptions
{
    public const string ConfigurationSectionName = nameof(TallyOptions);
    [JsonPropertyName("apiKey")] public string ApiKey { get; set; }
    [JsonPropertyName("orgId")] public string OrgId { get; set; }
}