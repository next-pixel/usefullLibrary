namespace Dsp.Int.Library.Common.Services.Tally.Config;

public static class TallyConstants
{
    public const string AuthorisationHeader = "Ocp-Apim-Subscription-Key";
    public const string OrgIdHeader = "Tally-OrgId";
    public const string Tally = nameof(Tally);
    public const string TallyBaseUrl = "Tally__baseUrl";

    public static class Paths
    {
        public const string GetInvoice = "finance/invoices/{invoiceNumber}";
    }
}