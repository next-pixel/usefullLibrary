using System.Text.Json.Serialization;

namespace Dsp.Int.Library.Common.Services.Tally.Dtos;

public class TallyHistoricLineItemDto
{
   
}