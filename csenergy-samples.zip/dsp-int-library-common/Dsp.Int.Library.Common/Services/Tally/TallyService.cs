using System.Net;
using Dsp.Int.Library.Common.Helpers;
using Dsp.Int.Library.Common.Models.Base;
using Dsp.Int.Library.Common.Models.Exceptions;
using Dsp.Int.Library.Common.Services.Http;
using Dsp.Int.Library.Common.Services.Tally.Config;
using Dsp.Int.Library.Common.Services.Tally.Dtos;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Dsp.Int.Library.Common.Services.Tally;

public interface ITallyService
{
    Task<TallyInvoiceDetailDto> GetInvoice(BaseRequestModel<NoRequest> req, CancellationToken cancellationToken);
}

public class TallyService(IHttpClientHelper httpClientHelper, IOptions<TallyOptions> options, ILogger<TallyService> log)
    : ITallyService
{
    private readonly TallyOptions _options = options.Value;

    public async Task<TallyInvoiceDetailDto> GetInvoice(BaseRequestModel<NoRequest> req, CancellationToken cancellationToken)
    {
        return await SendRequestToTally<NoRequest, TallyInvoiceDetailDto>(req, TallyConstants.Paths.GetInvoice, HttpMethod.Get, cancellationToken);
    }

    private async Task<TResponse> SendRequestToTally<TRequest, TResponse>(BaseRequestModel<TRequest> req, string path, HttpMethod method,
        CancellationToken cancellationToken)
    {
        var queryParams = HttpHelper.GetQueryString(req);
        var url = HttpHelper.GetFinalUrl(path, req);
        url = $"{url}{queryParams}";

        if (req.Headers == null)
        {
            req.Headers = new Dictionary<string, string>();
        }
        else
        {
            req.Headers.Remove(TallyConstants.AuthorisationHeader);
        }

        req.Headers.Add(TallyConstants.AuthorisationHeader, _options.ApiKey);
        req.Headers.Add(TallyConstants.OrgIdHeader, _options.OrgId);

        var httpReqMessage = HttpHelper.GenerateHttpRequest(req, method, url, log);

        var response = await httpClientHelper.SendAsync(TallyConstants.Tally, url, httpReqMessage, cancellationToken);

        switch (response.StatusCode)
        {
            case HttpStatusCode.OK:
            {
                var parsedResponse = await HttpHelper.ParseSuccessResponse<TResponse>(TallyConstants.Tally, response, cancellationToken);
                return parsedResponse;
            }
            case HttpStatusCode.BadRequest:
            {
                log.LogError("Connection to Tally failed with status code {ResponseStatusCode}", response.StatusCode);
                var content = await response.Content?.ReadAsStringAsync(cancellationToken);
                log.LogError("Error Response {Content}", content);
                log.LogError("UnRecoverableException - Message marked for dead-lettering");
                throw new UnRecoverableException($"Connection to Tally failed with status code {response.StatusCode}", content);
            }
            case HttpStatusCode.RequestTimeout:
            case HttpStatusCode.TooManyRequests:
            case HttpStatusCode.BadGateway:
            case HttpStatusCode.ServiceUnavailable:
            case HttpStatusCode.InternalServerError:
            {
                log.LogError("Connection to Tally failed with status code {ResponseStatusCode}", response.StatusCode);
                log.LogError("StandardCommunicationException - Message marked for retry");
                throw new StandardCommunicationException($"Connection to Tally failed with status code {response.StatusCode}.");
            }
            default:
                log.LogError("UnRecoverableException - Message marked for dead-lettering");
                log.LogError("Connection to Tally failed with status code {ResponseStatusCode}", response.StatusCode);
                throw new UnRecoverableException($"Connection to Tally failed with status code {response.StatusCode}");
        }
    }
}