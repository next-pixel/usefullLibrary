using System.Collections.Concurrent;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Extensions.Logging;

namespace Dsp.Int.Library.Common.Services.Http;

public interface IHttpClientHelper
{
    Task<HttpResponseMessage> SendAsync(
        string httpClientName,
        string uri,
        HttpRequestMessage httpRequestMessage,
        CancellationToken cancellationToken,
        JsonSerializerOptions serializerSettings = null);
}

public class HttpClientHelper : IHttpClientHelper
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ConcurrentDictionary<string, HttpClient> _clientCache = new();
    private readonly ILogger<HttpClientHelper> _logger;
    private readonly JsonSerializerOptions _serializerOptions;

    public HttpClientHelper(
        IHttpClientFactory httpClientFactory,
        ILogger<HttpClientHelper> logger)
    {
        _httpClientFactory = httpClientFactory ?? throw new ArgumentNullException(nameof(httpClientFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _serializerOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };
    }

    /// <summary>
    ///     SendAsync that takes a typed request TRequest and returns  the HTTP Response message.
    /// </summary>
    public async Task<HttpResponseMessage> SendAsync(
        string httpClientName,
        string uri,
        HttpRequestMessage httpRequestMessage,
        CancellationToken cancellationToken,
        JsonSerializerOptions serializerSettings = null)
    {
        try
        {
            var httpClient = _clientCache.GetOrAdd(httpClientName, _httpClientFactory.CreateClient(httpClientName));
            _logger.LogInformation("Executing: {BaseAddress}{Uri}", httpClient.BaseAddress, uri);

            var response = await httpClient.SendAsync(httpRequestMessage, cancellationToken);

            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError("An error occurred: {Error}", ex.Message);
            throw;
        }
    }
}