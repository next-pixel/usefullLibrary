namespace Dsp.Int.Library.Common.Services.DspData;

public static class DspConstants
{
    public const string ContainerTally = "tally";
    public const string DspStorageClient = nameof(DspStorageClient);
}