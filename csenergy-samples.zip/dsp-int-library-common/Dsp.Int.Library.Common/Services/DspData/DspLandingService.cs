using System.Text;
using Azure.Storage;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Dsp.Int.Library.Common.Models.Exceptions;
using Dsp.Int.Library.Common.Services.IntStorageAccount;
using Microsoft.Extensions.Azure;
using Microsoft.Extensions.Logging;

namespace Dsp.Int.Library.Common.Services.DspData;

public interface IDspLandingService
{
    Task UploadFile(string containerName, string fileName, string fileContents, CancellationToken cancellationToken);
}

    
    public class DspLandingService : IDspLandingService
    {
        private readonly BlobServiceClient _blobServiceClient;
        private readonly ILogger<DspLandingService> _log;
    
        public DspLandingService(IAzureClientFactory<BlobServiceClient> clientFactory, ILogger<DspLandingService> log)
        {
            _blobServiceClient = clientFactory.CreateClient(DspConstants.DspStorageClient);
            _log = log;
        }
    
    public async Task UploadFile(string containerName, string fileName, string fileContents, CancellationToken cancellationToken)
    {
        try
        {
            _log.LogInformation("Uploading file {Name} to container {Container}", fileName, containerName);
            var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);

            var blobClient = containerClient.GetBlobClient(fileName);

            using var stream = new MemoryStream(Encoding.UTF8.GetBytes(fileContents));

            // Specify the StorageTransferOptions
            var options = new BlobUploadOptions
            {
                TransferOptions = new StorageTransferOptions
                {
                    // Set the maximum number of workers that 
                    // may be used in a parallel transfer.
                    MaximumConcurrency = 40,

                    // Set the maximum length of a transfer to 50MB.
                    MaximumTransferSize = 10 * 1024 * 1024
                }
            };

            await blobClient.UploadAsync(stream, options, cancellationToken);
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Exception in UploadFile {Name}", fileName);
            throw new UnRecoverableException("File upload failed. {Message}", ex.Message);
        }
    }
}