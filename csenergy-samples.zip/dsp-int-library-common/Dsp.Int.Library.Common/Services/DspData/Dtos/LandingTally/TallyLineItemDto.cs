using System.Text.Json.Serialization;

namespace Dsp.Int.Library.Common.Services.DspData.Dtos.LandingTally;

public record DspTallyLineItemDto
{

}