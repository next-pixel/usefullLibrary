using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Dsp.Int.Library.Common.Models.Exceptions;
using Microsoft.Extensions.Azure;
using Microsoft.Extensions.Logging;

namespace Dsp.Int.Library.Common.Services.IntStorageAccount;

public interface IIntStorageService
{
    Task<string> DownloadFile(string containerName, string filePath,  CancellationToken cancellationToken);
}

public class IntStorageService : IIntStorageService
{
    private readonly BlobServiceClient _blobServiceClient;
    private readonly ILogger<IntStorageService> _log;
    
    public IntStorageService(IAzureClientFactory<BlobServiceClient> clientFactory, ILogger<IntStorageService> log)
    {
        _blobServiceClient = clientFactory.CreateClient(IntStorageConstants.IntStorageClient);
        _log = log;
    }
    
    public async Task<string> DownloadFile(string containerName, string filePath, CancellationToken cancellationToken)
    {
        try
        {
            _log.LogInformation("Downloading file {Name} from container {Container}", filePath, containerName);
            var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);

            var blobClient = containerClient.GetBlobClient(filePath);
            
            BlobDownloadResult result = await blobClient.DownloadContentAsync(cancellationToken);
            var blobContents = result.Content.ToString();
            
            return blobContents;
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Exception in DownloadFile {Name}", filePath);
            throw new UnRecoverableException("File download failed. {Message}", ex.Message);
        }
    }
}