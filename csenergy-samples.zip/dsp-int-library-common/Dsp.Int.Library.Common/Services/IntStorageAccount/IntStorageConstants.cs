namespace Dsp.Int.Library.Common.Services.IntStorageAccount;

public static class IntStorageConstants
{
    public const string IntStorageClient = nameof(IntStorageClient);
    public const string ContainerTallyHistory = "tally-history";
}