using FluentValidation;

namespace Dsp.Int.Library.Common.Helpers;

public static class Guarantee
{
    public static void NotNull(object value, string name)
    {
        if (value == null)
        {
            throw new ValidationException($"{name} should not be null");
        }
    }
}