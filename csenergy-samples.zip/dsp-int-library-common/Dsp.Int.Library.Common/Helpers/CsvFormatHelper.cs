using System.Reflection;
using System.Text;

namespace Dsp.Int.Library.Common.Helpers;

public class CsvFormatHelper
{
    public static string ConvertListToCsv<T>(IEnumerable<T> records)
    {
        var csvBuilder = new StringBuilder();
        var properties = typeof(T).GetProperties();

        // Header
        csvBuilder.AppendLine(CreateCsvRow(properties.Select(p => p.Name)));

        // Rows
        foreach (var record in records)
        {
            var values = properties.Select(p => GetValue(p, record));
            csvBuilder.AppendLine(CreateCsvRow(values));
        }

        return csvBuilder.ToString();
    }

    public static string ConvertToCsv<T>(T record)
    {
        var csvBuilder = new StringBuilder();
        var properties = typeof(T).GetProperties();

        // Header
        csvBuilder.AppendLine(CreateCsvRow(properties.Select(p => p.Name)));

        // Row
        var values = properties.Select(p => GetValue(p, record));
        csvBuilder.AppendLine(CreateCsvRow(values));

        return csvBuilder.ToString();
    }

    private static string CreateCsvRow(IEnumerable<string> values)
    {
        return string.Join(",", values.Select(value =>
            value.Contains(',') ? $"\"{value}\"" : value));
    }

    private static string GetValue<T>(PropertyInfo property, T record)
    {
        var value = property.GetValue(record, null)?.ToString() ?? "";
        return value;
    }
}