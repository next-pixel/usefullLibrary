using System.Net;
using System.Net.Mime;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Dsp.Int.Library.Common.Models.Base;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.Extensions.Logging;

namespace Dsp.Int.Library.Common.Helpers;

public static class HttpHelper
{
    public static QueryString GetQueryString<T>(BaseRequestModel<T> req)
    {
        var queryParamsList = new QueryBuilder();
        if (req.QueryParams != null)
        {
            foreach (var key in req.QueryParams.Keys)
            {
                queryParamsList.Add(key, req.QueryParams[key]);
            }
        }

        var queryParams = queryParamsList.ToQueryString();
        return queryParams;
    }

    public static string GetFinalUrl<T>(string url, BaseRequestModel<T> req)
    {
        if (req?.PathParams != null)
        {
            foreach (var keyValue in req.PathParams)
            {
                url = url.Replace("{" + keyValue.Key + "}", keyValue.Value);
            }
        }

        return url;
    }

    public static JsonSerializerOptions GetIgnoreNullPolicy()
    {
        return new JsonSerializerOptions
        {
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };
    }

    public static JsonSerializerOptions GetIgnoreNullPolicyAndCamelCaseAndEnum()
    {
        return new JsonSerializerOptions
        {
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            Converters =
            {
                new JsonStringEnumConverter()
            }
        };
    }

    public static HttpRequestMessage GenerateHttpRequest<T>(BaseRequestModel<T> req, HttpMethod method, string url, ILogger log)
    {
        StringContent stringContent = null;
        if (method == HttpMethod.Post || method == HttpMethod.Put || method == HttpMethod.Patch)
        {
            var requestJson = JsonSerializer.Serialize(req.Payload, GetIgnoreNullPolicy());
            log.LogInformation("Request Body : {0}", requestJson);
            stringContent = new StringContent(requestJson, Encoding.UTF8, MediaTypeNames.Application.Json);
        }

        var httpReqMessage = new HttpRequestMessage
        {
            Method = method,
            RequestUri = new Uri(url, UriKind.RelativeOrAbsolute),
            Content = stringContent
        };

        req.Headers?.ToList().ForEach(kv =>
        {
            var (key, value) = kv;
            if (!string.IsNullOrEmpty(value))
                httpReqMessage.Headers.Add(key, value);
        });

        return httpReqMessage;
    }

    public static async Task<T> ParseSuccessResponse<T>(string client, HttpResponseMessage response, CancellationToken cancellationToken)
    {
        try
        {
            if (response.StatusCode == HttpStatusCode.OK)
            {
                var content = await response.Content.ReadAsStringAsync(cancellationToken);
                var resp = JsonSerializer.Deserialize<T>(content, GetIgnoreNullPolicyAndCamelCaseAndEnum());
                return resp;
            }
        }
        catch (Exception)
        {
            return default;
        }

        return default;
    }
}