using Azure.Messaging.ServiceBus;
using Dsp.Int.Library.Common.ErrorHandling;
using Dsp.Int.Library.Common.Models;
using Dsp.Int.Library.Common.Models.Exceptions;
using FluentValidation;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace Dsp.Int.Library.Common.Handlers;

public interface IBaseMessageHandler
{
    public Task<Result> ProcessAsync(ServiceBusReceivedMessage request, CancellationToken cancellationToken);
}

public interface IServiceBusMessageHandler<T> where T : class
{
    public Task ProcessAsync(ServiceBusReceivedMessage message,
        ServiceBusMessageActions messageActions, IBaseMessageHandler baseHandler, CancellationToken cancellationToken);
}

public class ServiceBusMessageHandler<T> : IServiceBusMessageHandler<T> where T : class
{
    private readonly ILogger<ServiceBusMessageHandler<T>> _logger;

    public ServiceBusMessageHandler(ILogger<ServiceBusMessageHandler<T>> logger)
    {
        _logger = logger;
    }

    public async Task ProcessAsync(ServiceBusReceivedMessage message, ServiceBusMessageActions messageActions, IBaseMessageHandler baseHandler, CancellationToken cancellationToken)
    {
        try
        {
            _logger.LogInformation("Message Body: {Content}", message.Body.ToString());

            var result = await baseHandler.ProcessAsync(message, cancellationToken);
            _logger.LogInformation("Handler has finished processing with result state: {Result}", Enum.GetName(result.State));

            if (result.State == ResultState.Failure)
            {
                _logger.LogError(result.Exception, "A {ErrorType} error occurred: {Error}", result.Exception?.GetType().ToString(), result.Exception?.Message);

                switch (result.Exception)
                {
                    case EventValidationException: // Failed event message validation
                        _logger.LogInformation("Function will deadletter message");
                        _logger.LogInformation("Message Body: {Content}", message.Body.ToString());
                        await messageActions.DeadLetterMessageAsync(message, null, ErrorMessageConstants.InvalidDataErrorCode,
                            ErrorMessageConstants.InvalidDataErrorMessageText, cancellationToken);
                        break;
                    case StandardCommunicationException: // Connectivity/5xx errors returned from downstream providers
                        // Do nothing and let the PeekLock expire to force the retry of the message.
                        _logger.LogInformation("Function will abandon message for retry");
                        break;
                    case ValidationException: // Invalid data returned from downstream providers
                        _logger.LogInformation("Function will deadletter message");
                        await messageActions.DeadLetterMessageAsync(message, null, ErrorMessageConstants.InvalidDataErrorCode,
                            ErrorMessageConstants.InvalidDataErrorMessageText, cancellationToken);
                        break;
                    case InvalidMessageException: // Bad/Invalid request
                        _logger.LogInformation("Function will deadletter message");
                        await messageActions.DeadLetterMessageAsync(message, null, ErrorMessageConstants.BadInputDataErrorCode,
                            ErrorMessageConstants.BadInputDataErrorMessageText, cancellationToken);
                        break;
                    case MappingException: // Error mapping 
                        _logger.LogInformation("Function will deadletter message");
                        await messageActions.DeadLetterMessageAsync(message, null, ErrorMessageConstants.BadMappingErrorCode,
                            ErrorMessageConstants.BadMappingErrorMessageText, cancellationToken);
                        break;
                    case HttpRequestException: // Unrecoverable downstream HTTP exceptions
                        _logger.LogInformation("Function will deadletter message due to HttpRequestException");
                        await messageActions.DeadLetterMessageAsync(message, null, ErrorMessageConstants.UnexpectedErrorCode,
                            ErrorMessageConstants.UnexpectedErrorUserMessageText, cancellationToken);
                        break;
                    case UnRecoverableException: // Unrecoverable  exceptions
                        _logger.LogInformation("Function will deadletter message due to UnRecoverableException");
                        await messageActions.DeadLetterMessageAsync(message, null, ErrorMessageConstants.UnexpectedErrorCode,
                            result.Exception.Message, cancellationToken);
                        break;
                    default:
                        _logger.LogInformation("Function will deadletter message");
                        await messageActions.DeadLetterMessageAsync(message, null, ErrorMessageConstants.UnexpectedErrorCode,
                            ErrorMessageConstants.UnexpectedErrorUserMessageText, cancellationToken);
                        break;
                }
            }
            else
            {
                await messageActions.CompleteMessageAsync(message);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError("An unhandled {ErrorType} error occurred: {Error}", ex.GetType().ToString(), ex.Message);
            _logger.LogInformation("Function will deadletter message");
            await messageActions.DeadLetterMessageAsync(message, null, ErrorMessageConstants.UnexpectedErrorCode, ErrorMessageConstants.UnexpectedErrorUserMessageText);
        }
    }
}