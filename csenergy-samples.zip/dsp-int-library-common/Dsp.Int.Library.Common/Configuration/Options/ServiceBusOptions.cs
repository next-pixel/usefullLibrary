namespace Dsp.Int.Library.Common.Configuration.Options;

public class ServiceBusOptions
{
    public const string ConfigurationSectionName = nameof(ServiceBusOptions);
}