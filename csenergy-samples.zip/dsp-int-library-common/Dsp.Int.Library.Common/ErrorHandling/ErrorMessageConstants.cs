namespace Dsp.Int.Library.Common.ErrorHandling;

public static class ErrorMessageConstants
{
    public const string UnexpectedErrorCode = "DSPGEN9999";
    public const int UnexpectedErrorEventId = 9999;
    public const string UnexpectedErrorUserMessageText = "An unexpected error occurred";

    public const string UnspecifiedErrorCode = "DSPGEN0000";

    public const int
        UnspecifiedErrorEventId =
            0; // This aligns with the default value of zero used in the Microsoft.Extensions.Logging (https://github.com/aspnet/Logging/blob/e8e3e707f5131e22d7d27fce6bfcefdda1dbb817/src/Microsoft.Extensions.Logging.Abstractions/LoggerExtensions.cs#L368)

    public const string UnspecifiedEventName = "Unspecified";

    public const string BadVersionErrorCode = "DSPVAL0001";
    public const int BadVersionEventId = 10001;

    public const string BadInputDataErrorCode = "DSPVAL0002";
    public const int BadInputDataEventId = 10002;
    public const string BadInputDataErrorMessageText = "Invalid request received";

    public const string BadMappingErrorCode = "DSPVAL0003";
    public const int BadMappingEventId = 10003;
    public const string BadMappingErrorMessageText = "A mapping error occurred";

    public const string InvalidDataErrorCode = "DSPVAL0004";
    public const int InvalidDataErrorId = 10004;
    public const string InvalidDataErrorMessageText = "Invalid data was retrieved from the downstream provider";

    public const string BadMappingFromDownstreamErrorCode = "DSPVAL0005";
    public const int BadMappingFromDownstreamEventId = 10005;
    public const string BadMappingFromDownstreamMessageTemplate = "A mapping error occurred when attempting to map from {DownstreamProvider} to Response. Error Message: {Reason}";

    public const string FailedAuthenticationErrorCode = "DSPSEC0001";
    public const int FailedAuthenticationEventId = 10100;

    public const string CommunicationsErrorCode = "DSPCOM9999";
    public const int CommunicationsErrorEventId = 9999;
    public const string CommunicationsErrorUserMessageText = UnexpectedErrorUserMessageText;
    public const string CommunicationsErrorSupportMessageTemplate = "An unexpected error occurred while attempting to communicate with {0}";

    public const string AuthorisationScopeErrorCode = "DSPSEC0001";
    public const int AuthorisationScopeErrorEventId = 10100;
    public const string AuthorisationScopeErrorUserMessageText = "Authorisation failed";
    public const string AuthorisationScopeErrorSupportMessageTemplate = "Authorisation Error: Scope {scope} was not found in the security token";

    public const string AuthorisationRoleErrorCode = "DSPSEC0002";
    public const int AuthorisationRoleErrorEventId = 10200;
    public const string AuthorisationRoleErrorUserMessageText = "Authorisation failed";

    public const string AuthorisationRoleErrorSupportMessageTemplate =
        "Authorisation Error: At least one of the Function-Level Permissions {FunctionLevelPermissions} are required in security token";

    public const string CommunicationsErrorNotFoundUserMessageText = "Error occurred while attempting to communicate with {0} system. Check if the input parameters are valid";
}