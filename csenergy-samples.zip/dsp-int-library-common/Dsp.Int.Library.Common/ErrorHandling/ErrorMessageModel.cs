using System.Text.Json.Serialization;

namespace Dsp.Int.Library.Common.ErrorHandling;

public class ErrorMessageModel
{
    /// <summary>
    ///     The enumerated code representing the error or error category.
    /// </summary>
    [JsonPropertyName("code")]
    public string MessageCode { get; set; }

    /// <summary>
    ///     Error message text to be returned to the caller.
    /// </summary>
    [JsonPropertyName("message")]
    public string UserMessageText { get; set; }

    /// <summary>
    ///     The UTC date and time that the error message was created.
    /// </summary>
    [JsonPropertyName("timestamp")]
    public DateTimeOffset Timestamp { get; set; } = DateTimeOffset.UtcNow;

    /// <summary>
    ///     Error message to be logged to the logging target. This will not be
    ///     returned to the caller.
    /// </summary>
    [JsonPropertyName("supportMessageText")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string SupportMessageText { get; set; }
}