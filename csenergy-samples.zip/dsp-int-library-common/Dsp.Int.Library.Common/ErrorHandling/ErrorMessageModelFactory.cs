using System.Diagnostics.CodeAnalysis;

namespace Dsp.Int.Library.Common.ErrorHandling;

[ExcludeFromCodeCoverage]
public static class ErrorMessageModelFactory
{
    public static ErrorMessageModel CreateErrorMessageModel(string messageCode,
        string messageText,
        string supportMessageText = null)
    {
        return new ErrorMessageModel
        {
            MessageCode = messageCode,
            UserMessageText = messageText,
            SupportMessageText = supportMessageText
        };
    }
}