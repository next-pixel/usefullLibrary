using System.Text.Json.Serialization;

namespace Dsp.Int.Library.Common.Models.Base;

public class BaseEventModel<T>
{
    [JsonPropertyName("payload")] public T Payload { get; set; }
    [JsonPropertyName("metadata")] public EventMetadata Metadata { get; set; }
}

public class EventMetadata
{
    [JsonPropertyName("requestId")] public string RequestId { get; set; }
    [JsonPropertyName("sendingSystemId")] public string SendingSystemId { get; set; }

    [JsonPropertyName("initiatingSystemId")]
    public string InitiatingSystemId { get; set; }
}