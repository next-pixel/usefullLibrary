namespace Dsp.Int.Library.Common.Models.Base;

public class NoResponse
{
}