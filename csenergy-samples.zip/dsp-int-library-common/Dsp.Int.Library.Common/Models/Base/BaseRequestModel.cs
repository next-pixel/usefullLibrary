namespace Dsp.Int.Library.Common.Models.Base;

public class BaseRequestModel<T>
{
    public T Payload { get; set; }
    public Dictionary<string, string> PathParams { get; set; }
    public Dictionary<string, string> QueryParams { get; set; }
    public Dictionary<string, string> Headers { get; set; }
}