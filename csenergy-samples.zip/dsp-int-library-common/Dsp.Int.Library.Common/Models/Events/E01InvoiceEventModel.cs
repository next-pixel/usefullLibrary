using System.Text.Json.Serialization;

namespace Dsp.Int.Library.Common.Models.Events;

public class E01InvoiceEventModel
{

}

public class BillingAddress
{

}