using System.Diagnostics.CodeAnalysis;

namespace Dsp.Int.Library.Common.Models;

[ExcludeFromCodeCoverage]
public class Result
{
    public ResultState State { get; protected set; }
    public Exception Exception { get; protected set; }
}

public class Result<T>
{
    public ResultState State { get; protected set; }
    public Exception Exception { get; protected set; }
    public T Value { get; protected set; }
}

public class SuccessResult : Result
{
    public SuccessResult()
    {
        State = ResultState.Success;
        Exception = null;
    }
}

public class SuccessResult<T> : Result<T>
{
    public SuccessResult(T value)
    {
        State = ResultState.Success;
        Exception = null;
        Value = value;
    }
}

public class FailureResult : Result
{
    public FailureResult(Exception ex)
    {
        State = ResultState.Failure;
        Exception = ex;
    }
}

public class FailureResult<T> : Result<T>
{
    public FailureResult(Exception ex)
    {
        State = ResultState.Failure;
        Exception = ex;
        Value = default!;
    }
}

public enum ResultState
{
    Success,
    Failure
}