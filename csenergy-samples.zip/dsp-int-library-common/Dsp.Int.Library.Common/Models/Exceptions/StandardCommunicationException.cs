using System.Diagnostics.CodeAnalysis;

namespace Dsp.Int.Library.Common.Models.Exceptions;

[ExcludeFromCodeCoverage]
public class StandardCommunicationException : Exception
{
    public StandardCommunicationException()
    {
    }

    public StandardCommunicationException(string message)
        : base(message)
    {
    }

    public StandardCommunicationException(string message, Exception inner)
        : base(message, inner)
    {
    }
}