namespace Dsp.Int.Library.Common.Models.Exceptions;

public class UnRecoverableException : Exception
{
    public UnRecoverableException(string message) : base(message)
    {
    }

    public UnRecoverableException(string message, object error) : base(message)
    {
    }

    public UnRecoverableException(string message, Exception inner)
        : base(message, inner)
    {
    }
}