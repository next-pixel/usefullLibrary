using System.Runtime.Serialization;
using FluentValidation;
using FluentValidation.Results;

namespace Dsp.Int.Library.Common.Models.Exceptions;

public class EventValidationException : ValidationException
{
    public EventValidationException(string message) : base(message)
    {
    }

    public EventValidationException(string message, IEnumerable<ValidationFailure> errors) : base(message, errors)
    {
    }

    public EventValidationException(string message, IEnumerable<ValidationFailure> errors, bool appendDefaultMessage) : base(message, errors, appendDefaultMessage)
    {
    }

    public EventValidationException(IEnumerable<ValidationFailure> errors) : base(errors)
    {
    }

    public EventValidationException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}