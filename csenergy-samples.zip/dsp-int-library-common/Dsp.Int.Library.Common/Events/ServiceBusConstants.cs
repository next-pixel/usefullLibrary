namespace Dsp.Int.Library.Common.Events;

public static class ServiceBusConstants
{
    public static class Topics
    {
        public const string Invoice = "invoice.topic";
        public const string History = "invoice-history.topic";
    }

    public static class Subscriptions
    {
        public const string DspInvoice = "dsp.invoice.subscription";
        public const string DspInvoiceHistory = "dsp.invoice.subscription";
    }
}