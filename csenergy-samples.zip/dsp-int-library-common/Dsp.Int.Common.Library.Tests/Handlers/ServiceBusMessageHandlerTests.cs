using Azure.Messaging.ServiceBus;
using Dsp.Int.Library.Common.Handlers;
using Dsp.Int.Library.Common.Models;
using Dsp.Int.Library.Common.Models.Exceptions;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Moq;

namespace Dsp.Int.Common.Library.Tests.Handlers;

public class ServiceBusMessageHandlerTests
{
    private readonly ServiceBusReceivedMessage _serviceBusReceivedMessage;
    private readonly Mock<ServiceBusMessageActions> _messageActions;
    private readonly Mock<IBaseMessageHandler> _handler;
    private readonly Mock<ILogger<ServiceBusMessageHandler<TestHandler>>> _logger;

    public ServiceBusMessageHandlerTests()
    {
        _serviceBusReceivedMessage = ServiceBusModelFactory.ServiceBusReceivedMessage();
        _messageActions = new Mock<ServiceBusMessageActions>();
        _handler = new Mock<IBaseMessageHandler>();
        _logger = new Mock<ILogger<ServiceBusMessageHandler<TestHandler>>>();
    }

    [Fact]
    public async Task ServiceBusMessageHandler_SuccessfulHandler()
    {
        // Arrange
        _handler.Setup(x => x.ProcessAsync(It.IsAny<ServiceBusReceivedMessage>(), It.IsAny<CancellationToken>())).ReturnsAsync(new SuccessResult());
        var serviceBusMessageHandler = new ServiceBusMessageHandler<TestHandler>(_logger.Object);

        // Act
        await serviceBusMessageHandler.ProcessAsync(_serviceBusReceivedMessage, _messageActions.Object, _handler.Object, CancellationToken.None);

        // Assert
        _messageActions.Verify(x => x.CompleteMessageAsync(It.IsAny<ServiceBusReceivedMessage>(), It.IsAny<CancellationToken>()));
    }

    [Fact]
    public async Task ServiceBusMessageHandler_FailedHandler_EventValidationException()
    {
        // Arrange
        _handler.Setup(x => x.ProcessAsync(It.IsAny<ServiceBusReceivedMessage>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new FailureResult(new EventValidationException(new List<ValidationFailure>())));
        var serviceBusMessageHandler = new ServiceBusMessageHandler<TestHandler>(_logger.Object);

        // Act
        await serviceBusMessageHandler.ProcessAsync(_serviceBusReceivedMessage, _messageActions.Object, _handler.Object, CancellationToken.None);

        // Assert
        VerifyLog(_logger, LogLevel.Information, "Function will complete message");
        VerifyLog(_logger, LogLevel.Information, "Message Body: ");
        _messageActions.Verify(x => x.AbandonMessageAsync(It.IsAny<ServiceBusReceivedMessage>(),
            null,
            It.IsAny<CancellationToken>()), Times.Never);
        _messageActions.Verify(x => x.DeadLetterMessageAsync(It.IsAny<ServiceBusReceivedMessage>(),
            It.IsAny<Dictionary<string, object>>(),
            It.IsAny<string>(),
            It.IsAny<string>(),
            It.IsAny<CancellationToken>()), Times.Never);
        _messageActions.Verify(x => x.CompleteMessageAsync(It.IsAny<ServiceBusReceivedMessage>(),
            It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task ServiceBusMessageHandler_FailedHandler_ThrowsException()
    {
        // Arrange
        _handler.Setup(x => x.ProcessAsync(It.IsAny<ServiceBusReceivedMessage>(), It.IsAny<CancellationToken>())).ThrowsAsync(new Exception());
        var serviceBusMessageHandler = new ServiceBusMessageHandler<TestHandler>(_logger.Object);

        // Act
        await serviceBusMessageHandler.ProcessAsync(_serviceBusReceivedMessage, _messageActions.Object, _handler.Object, CancellationToken.None);

        // Assert
        VerifyLog(_logger, LogLevel.Information, "Function will deadletter message");
        _messageActions.Verify(x => x.DeadLetterMessageAsync(It.IsAny<ServiceBusReceivedMessage>(),
            It.IsAny<Dictionary<string, object>>(),
            It.IsAny<string>(),
            It.IsAny<string>(),
            It.IsAny<CancellationToken>()));
    }

    [Fact]
    public async Task ServiceBusMessageHandler_FailedHandler_StandardCommsException()
    {
        // Arrange
        _handler.Setup(x => x.ProcessAsync(It.IsAny<ServiceBusReceivedMessage>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new FailureResult(new StandardCommunicationException()));
        var serviceBusMessageHandler = new ServiceBusMessageHandler<TestHandler>(_logger.Object);

        // Act
        await serviceBusMessageHandler.ProcessAsync(_serviceBusReceivedMessage, _messageActions.Object, _handler.Object, CancellationToken.None);

        // Assert
        VerifyLog(_logger, LogLevel.Information, "Function will abandon message for retry");
        _messageActions.Verify(x => x.AbandonMessageAsync(It.IsAny<ServiceBusReceivedMessage>(),
            null,
            It.IsAny<CancellationToken>()), Times.Never);
        _messageActions.Verify(x => x.DeadLetterMessageAsync(It.IsAny<ServiceBusReceivedMessage>(),
            It.IsAny<Dictionary<string, object>>(),
            It.IsAny<string>(),
            It.IsAny<string>(),
            It.IsAny<CancellationToken>()), Times.Never);
        _messageActions.Verify(x => x.CompleteMessageAsync(It.IsAny<ServiceBusReceivedMessage>(),
            It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task ServiceBusMessageHandler_FailedHandler_HttpRequestException()
    {
        // Arrange
        _handler.Setup(x => x.ProcessAsync(It.IsAny<ServiceBusReceivedMessage>(), It.IsAny<CancellationToken>())).ReturnsAsync(new FailureResult(new HttpRequestException()));
        var serviceBusMessageHandler = new ServiceBusMessageHandler<TestHandler>(_logger.Object);

        // Act
        await serviceBusMessageHandler.ProcessAsync(_serviceBusReceivedMessage, _messageActions.Object, _handler.Object, CancellationToken.None);

        // Assert
        VerifyLog(_logger, LogLevel.Information, "Function will deadletter message");
        _messageActions.Verify(x => x.DeadLetterMessageAsync(It.IsAny<ServiceBusReceivedMessage>(),
            It.IsAny<Dictionary<string, object>>(),
            It.IsAny<string>(),
            It.IsAny<string>(),
            It.IsAny<CancellationToken>()));
    }

    [Fact]
    public async Task ServiceBusMessageHandler_FailedHandler_InvalidMessageException()
    {
        // Arrange
        _handler.Setup(x => x.ProcessAsync(It.IsAny<ServiceBusReceivedMessage>(), It.IsAny<CancellationToken>())).ReturnsAsync(new FailureResult(new InvalidMessageException()));
        var serviceBusMessageHandler = new ServiceBusMessageHandler<TestHandler>(_logger.Object);

        // Act
        await serviceBusMessageHandler.ProcessAsync(_serviceBusReceivedMessage, _messageActions.Object, _handler.Object, CancellationToken.None);

        // Assert
        VerifyLog(_logger, LogLevel.Information, "Function will deadletter message");
        _messageActions.Verify(x => x.DeadLetterMessageAsync(It.IsAny<ServiceBusReceivedMessage>(),
            It.IsAny<Dictionary<string, object>>(),
            It.IsAny<string>(),
            It.IsAny<string>(),
            It.IsAny<CancellationToken>()));
    }

    [Fact]
    public async Task ServiceBusMessageHandler_FailedHandler_ValidationException()
    {
        // Arrange
        _handler.Setup(x => x.ProcessAsync(It.IsAny<ServiceBusReceivedMessage>(), It.IsAny<CancellationToken>())).ReturnsAsync(new FailureResult(new ValidationException("test")));
        var serviceBusMessageHandler = new ServiceBusMessageHandler<TestHandler>(_logger.Object);

        // Act
        await serviceBusMessageHandler.ProcessAsync(_serviceBusReceivedMessage, _messageActions.Object, _handler.Object, CancellationToken.None);

        // Assert
        VerifyLog(_logger, LogLevel.Information, "Function will deadletter message");
        _messageActions.Verify(x => x.DeadLetterMessageAsync(It.IsAny<ServiceBusReceivedMessage>(),
            It.IsAny<Dictionary<string, object>>(),
            It.IsAny<string>(),
            It.IsAny<string>(),
            It.IsAny<CancellationToken>()));
    }

    [Fact]
    public async Task ServiceBusMessageHandler_FailedHandler_MappingException()
    {
        // Arrange
        _handler.Setup(x => x.ProcessAsync(It.IsAny<ServiceBusReceivedMessage>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new FailureResult(new MappingException("A mapping exception")));
        var serviceBusMessageHandler = new ServiceBusMessageHandler<TestHandler>(_logger.Object);

        // Act
        await serviceBusMessageHandler.ProcessAsync(_serviceBusReceivedMessage, _messageActions.Object, _handler.Object, CancellationToken.None);

        // Assert
        VerifyLog(_logger, LogLevel.Information, "Function will deadletter message");
        _messageActions.Verify(x => x.DeadLetterMessageAsync(It.IsAny<ServiceBusReceivedMessage>(),
            It.IsAny<Dictionary<string, object>>(),
            It.IsAny<string>(),
            It.IsAny<string>(),
            It.IsAny<CancellationToken>()));
        _messageActions.Verify(x => x.CompleteMessageAsync(It.IsAny<ServiceBusReceivedMessage>(),
            It.IsAny<CancellationToken>()), Times.Never);
    }


    [Fact]
    public async Task ServiceBusMessageHandler_FailedHandler_DefaultException()
    {
        // Arrange
        _handler.Setup(x => x.ProcessAsync(It.IsAny<ServiceBusReceivedMessage>(), It.IsAny<CancellationToken>())).ReturnsAsync(new FailureResult(new Exception()));
        var serviceBusMessageHandler = new ServiceBusMessageHandler<TestHandler>(_logger.Object);

        // Act
        await serviceBusMessageHandler.ProcessAsync(_serviceBusReceivedMessage, _messageActions.Object, _handler.Object, CancellationToken.None);

        // Assert
        VerifyLog(_logger, LogLevel.Information, "Function will deadletter message");
        _messageActions.Verify(x => x.DeadLetterMessageAsync(It.IsAny<ServiceBusReceivedMessage>(),
            It.IsAny<Dictionary<string, object>>(),
            It.IsAny<string>(),
            It.IsAny<string>(),
            It.IsAny<CancellationToken>()));
    }

    private static void VerifyLog<T>(Mock<ILogger<T>> logger, LogLevel level, string message, string failMessage = null)
    {
        logger.Verify(l => l.Log(level, It.IsAny<EventId>(),
            It.Is<It.IsAnyType>((o, _) => o.ToString().Contains(message)), It.IsAny<Exception>(),
            It.Is<Func<It.IsAnyType, Exception, string>>((v, t) => true)), failMessage!);
    }

    public class TestHandler : IBaseMessageHandler
    {
        public Task<Result> ProcessAsync(ServiceBusReceivedMessage request, CancellationToken cancellationToken)
        {
            return Task.FromResult<Result>(new SuccessResult());
        }
    }
}