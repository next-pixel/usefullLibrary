using System.Net;
using Dsp.Int.Library.Common.Models.Base;
using Dsp.Int.Library.Common.Models.Exceptions;
using Dsp.Int.Library.Common.Services.Http;
using Dsp.Int.Library.Common.Services.Tally;
using Dsp.Int.Library.Common.Services.Tally.Config;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using Shouldly;

namespace Dsp.Int.Common.Library.Tests.Services;

public class TallyServiceTests
{
    private readonly Mock<IHttpClientHelper> _httpClientHelperMock;
    private readonly TallyService _tallyService;

    public TallyServiceTests()
    {
        _httpClientHelperMock = new Mock<IHttpClientHelper>();
        var optionsMock = new Mock<IOptions<TallyOptions>>();
        var loggerMock = new Mock<ILogger<TallyService>>();

        var tallyOptions = new TallyOptions { ApiKey = "YourApiKey", OrgId = "YourOrgId" };
        optionsMock.Setup(opt => opt.Value).Returns(tallyOptions);

        _tallyService = new TallyService(_httpClientHelperMock.Object, optionsMock.Object, loggerMock.Object);
    }

    [Fact]
    public async Task GetInvoice_Should_Return_Response_For_OK_Status_Code()
    {
        // Arrange
        var baseRequest = new BaseRequestModel<NoRequest>();
        var cancellationToken = new CancellationToken();
        var responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
        {
            Content = new StringContent("OK response content")
        };

        _httpClientHelperMock.Setup(x => x.SendAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<HttpRequestMessage>(), cancellationToken, null))
            .ReturnsAsync(responseMessage);

        // Act
        var result = await _tallyService.GetInvoice(baseRequest, cancellationToken);

        // Assert
        Should.NotThrow(() => result);
        _httpClientHelperMock.Verify(x => x.SendAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<HttpRequestMessage>(), cancellationToken, null), Times.Once);
    }

    [Theory]
    [InlineData(HttpStatusCode.BadRequest, typeof(UnRecoverableException))]
    [InlineData(HttpStatusCode.Unauthorized, typeof(UnRecoverableException))]
    [InlineData(HttpStatusCode.Forbidden, typeof(UnRecoverableException))]
    [InlineData(HttpStatusCode.InternalServerError, typeof(StandardCommunicationException))]
    [InlineData(HttpStatusCode.RequestTimeout, typeof(StandardCommunicationException))]
    [InlineData(HttpStatusCode.TooManyRequests, typeof(StandardCommunicationException))]
    [InlineData(HttpStatusCode.BadGateway, typeof(StandardCommunicationException))]
    [InlineData(HttpStatusCode.ServiceUnavailable, typeof(StandardCommunicationException))]
    public async Task GetInvoice_Should_Throw_Specific_Exceptions_For_Error_Status_Codes(HttpStatusCode statusCode, Type expectedExceptionType)
    {
        // Arrange
        var baseRequest = new BaseRequestModel<NoRequest>();
        var cancellationToken = new CancellationToken();
        var responseMessage = new HttpResponseMessage(statusCode)
        {
            Content = new StringContent($"{statusCode} response content")
        };

        _httpClientHelperMock.Setup(x => x.SendAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<HttpRequestMessage>(), cancellationToken, null))
            .ReturnsAsync(responseMessage);

        // Act & Assert
        var exception = await Should.ThrowAsync<Exception>(() => _tallyService.GetInvoice(baseRequest, cancellationToken));
        exception.ShouldBeOfType(expectedExceptionType);
        _httpClientHelperMock.Verify(x => x.SendAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<HttpRequestMessage>(), cancellationToken, null), Times.Once);
    }
}