using Dsp.Int.Library.Common.Helpers;
using Shouldly;

namespace Dsp.Int.Common.Library.Tests.Helpers;

public class CsvHelperTests
{
    private class TestRecord
    {
        public TestRecord(string name, int age, bool isActive, decimal balance)
        {
            Name = name;
            Age = age;
            IsActive = isActive;
            Balance = balance;
        }

        public string Name { get; set; }
        public int Age { get; set; }
        public bool IsActive { get; set; }
        public decimal Balance { get; set; }
    }


    [Theory]
    [InlineData("John", 10, true, 12.222, "Name,Age,IsActive,Balance\nJohn,10,True,12.222\n")]
    [InlineData("John", 10, true, 0, "Name,Age,IsActive,Balance\nJohn,10,True,0\n")]
    [InlineData("John,Jane", 10, true, 0, "Name,Age,IsActive,Balance\n\"John,Jane\",10,True,0\n")]
    [InlineData(null, 0, false, 0, "Name,Age,IsActive,Balance\n,0,False,0\n")]
    public void TestConvertToCsv(string name, int age, bool isActive, decimal balance, string expected)
    {
        //Arrange
        var record = new TestRecord(name, age, isActive, balance);

        //Act
        var csv = CsvHelper.ConvertToCsv(record);

        //Assert
        csv.ShouldBe(expected);
    }

    [Fact]
    public void TestConvertListToCsv()
    {
        //Arrange
        var records = new List<TestRecord>
        {
            new("John", 10, true, 12.222m),
            new("John", 10, true, 0m),
            new("John,Jane", 10, true, 0m),
            new(null, 0, false, 0m)
        };

        //Act
        var csv = CsvHelper.ConvertListToCsv(records);

        //Assert
        csv.ShouldBe("Name,Age,IsActive,Balance\nJohn,10,True,12.222\nJohn,10,True,0\n\"John,Jane\",10,True,0\n,0,False,0\n");
    }
}