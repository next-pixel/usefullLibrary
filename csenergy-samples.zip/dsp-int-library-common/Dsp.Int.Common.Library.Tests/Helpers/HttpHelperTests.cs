using Dsp.Int.Library.Common.Helpers;
using Dsp.Int.Library.Common.Models.Base;
using Shouldly;

namespace Dsp.Int.Common.Library.Tests.Helpers;

public class HttpHelperTests
{
    [Fact]
    public void GetQueryString_ReturnsCorrectQueryString()
    {
        // Arrange
        var requestModel = new BaseRequestModel<NoRequest>
        {
            QueryParams = new Dictionary<string, string>
            {
                { "param1", "value1" },
                { "param2", "value2" }
            }
        };

        // Act
        var queryString = HttpHelper.GetQueryString(requestModel);

        // Assert
        queryString.Value.ShouldBe("?param1=value1&param2=value2");
    }

    [Fact]
    public void GetFinalUrl_ReplacesPathParamsCorrectly()
    {
        // Arrange
        var urlTemplate = "resource/{id}";
        var requestModel = new BaseRequestModel<NoRequest>
        {
            PathParams = new Dictionary<string, string>
            {
                { "id", "123" }
            }
        };

        // Act
        var finalUrl = HttpHelper.GetFinalUrl(urlTemplate, requestModel);

        // Assert
        finalUrl.ShouldBe("resource/123");
    }
}