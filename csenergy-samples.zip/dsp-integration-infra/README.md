# DSP Integration Infrastructure

This repository contains the infrastructure as code (IaC) components for DSP integration services, leveraging Azure resources. The repository is structured to support multiple environments through Bicep templates and includes pipelines for continuous integration and deployment (CI/CD).

## Repository Structure

- **bicep/**: Contains [Bicep](https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/) templates used to define the Azure resources.
  - **stacks/**: Includes separate directories for each stack with their respective Bicep files and parameters.
    - **parameters/**: Parameter files for each resource stack.
      - **app-insights/**: Parameters for Application Insights resources.
      - **managed-identity/**: Parameters for Managed Identity resources.
      - **servicebus/**: Parameters for Azure Service Bus resources.
- **pipelines/**: YAML pipeline definitions for Azure DevOps.
  - **app-insights/**: CI/CD pipeline for Application Insights integration.
    - **integration-appinsights.pipeline.yaml**: Pipeline definition for Application Insights.
  - **managed-identity/**: CI/CD pipeline for Managed Identity integration.
    - **integration-managedidentity.pipeline.yaml**: Pipeline definition for Managed Identity.
  - **sbus-topics/**: CI/CD pipeline for Service Bus Topics integration.
    - **integration-sbus-topics.pipeline.yaml**: Pipeline definition for Service Bus Topics.
- **.gitignore**: Defines what files and directories to ignore in the repository.
- **README.md**: This file, which provides an overview and documentation for the repository.
