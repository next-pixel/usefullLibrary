# This PowerShell script is used to replace a target file with an environment file in a specified artifact path.
# It takes four parameters:
# - targetFileName: The name of the file to be replaced.
# - environmentFileName: The name of the environment file that will replace the target file.
# - removeFileFilter: A filter for files to be removed after the replacement.
# - artifactPath: The path where the target and environment files are located.
#
# The script first changes the current location to the artifact path.
# If the target file exists, it is removed.
# If the environment file exists, it is renamed to the target file name, effectively replacing the original target file.
# Then, any files matching the removeFileFilter are removed.
# If the environment file does not exist, an exception is thrown.

param(
    [Parameter(Mandatory=$true)][String]$targetFileName,
    [Parameter(Mandatory=$true)][String]$environmentFileName,
    [Parameter(Mandatory=$true)][String]$removeFileFilter,
    [Parameter(Mandatory=$true)][String]$artifactPath
)

Set-Location $artifactPath

if (Test-Path -Path $targetFileName)
{
    Write-Output "Removing existing $targetFileName"
    Remove-Item -Path $targetFileName
}
if (Test-Path -Path $environmentFileName)
{
    Write-Output "Using $environmentFileName as $targetFileName"
    Rename-Item -Path $environmentFileName -NewName $targetFileName
    Write-Output "Removing $removeFileFilter files"
    Remove-Item -Path $removeFileFilter
}
else {
    throw "Could not find $environmentFileName in $artifactPath"
}
