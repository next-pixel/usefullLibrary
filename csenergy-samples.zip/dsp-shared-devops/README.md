# README

This repository serves as a centralized location for all our DevOps infrastructure as code (IaC) components, including Bicep modules, stack definitions, and Azure DevOps pipeline templates.

## Repository Structure

Below is the high-level structure of the repository with descriptions of each directory and its purpose:

- **bicep/**: This directory contains all Bicep files, which are used to define and deploy Azure resources declaratively.

  - **modules/**: Reusable Bicep modules are stored here, categorized by the type of Azure service they provision.
    - **compute/**: Modules related to Azure Compute resources such as Function Apps and Logic Apps.
    - **identity/**: Modules pertaining to identity management like Azure Active Directory configurations.
    - **keyvault/**: Contains modules for provisioning and managing Azure Key Vaults.
    - **networking/**: Networking-related modules, including virtual networks and subnets.
    - **roles/**: Defines roles and permissions for Azure resources.
    - **service-bus/**: Modules for Azure Service Bus resources.
    - **storage/**: Modules for Azure Storage solutions.

  - **stacks/**: Stacks are comprehensive Bicep files that combine multiple modules to provision complete environments.
    - **function-app/**: Stack definition for deploying a function app.
    - **logic-app/**: Stack definition for deploying a logic app.

- **pipelines/**: Contains Azure DevOps pipeline templates for CI/CD processes.

  - **templates/**: Reusable YAML templates for different types of applications.
    - **function-app/**: Templates specific to building and deploying Azure Function Apps.
    - **logic-app/**: Templates for building and deploying Logic Apps.

- **samples/**: Sample applications and code snippets that demonstrate how to use the stacks and modules.

- **scripts/**: Utility scripts to facilitate various DevOps tasks.

## Usage

For using pipeline templates:

1. Reference the required template in your Azure DevOps pipeline YAML file.
2. Customize the parameters as needed for your application.

