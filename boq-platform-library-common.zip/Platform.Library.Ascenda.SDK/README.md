[![Target Framework](https://img.shields.io/badge/Target%20Framework:-net6.0-GREEN.svg?style=plastic&logo=dotnet)](https://shields.io/)
[![Quality Gate Status](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Ascenda.SDK&metric=alert_status&token=sqb_46f0b569d51d84bb82010120efdedb2faaa35d8e)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Ascenda.SDK)
[![Coverage](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Ascenda.SDK&metric=coverage&token=sqb_46f0b569d51d84bb82010120efdedb2faaa35d8e)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Ascenda.SDK)
[![Platform.Library.Ascenda.SDK package in Development feed in Azure Artifacts](https://feeds.dev.azure.com/qdigitalcode/_apis/public/Packaging/Feeds/Development/Packages/d84dc8b9-7134-4920-b1ff-54d2d15893df/Badge)](https://dev.azure.com/qdigitalcode/DenovoBank/_artifacts/feed/Development/NuGet/Platform.Library.Ascenda.SDK?preferRelease=true)

[![Bugs](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Ascenda.SDK&metric=bugs&token=sqb_46f0b569d51d84bb82010120efdedb2faaa35d8e)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Ascenda.SDK)
[![Code Smells](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Ascenda.SDK&metric=code_smells&token=sqb_46f0b569d51d84bb82010120efdedb2faaa35d8e)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Ascenda.SDK)
[![Security Hotspots](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Ascenda.SDK&metric=security_hotspots&token=sqb_46f0b569d51d84bb82010120efdedb2faaa35d8e)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Ascenda.SDK)
[![Vulnerabilities](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Ascenda.SDK&metric=vulnerabilities&token=sqb_46f0b569d51d84bb82010120efdedb2faaa35d8e)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Ascenda.SDK)

# Platform.Library.Ascenda.SDK

## Description
Library that abstracts interactions to Ascenda as an SDK.

## Dependencies
- **Platform Libraries**
  - [Platform.Library.Common](https://dev.azure.com/qdigitalcode/DenovoBank/_git/Platform.Library.Common) [![Platform.Library.Common package in Development feed in Azure Artifacts](https://feeds.dev.azure.com/qdigitalcode/_apis/public/Packaging/Feeds/Development/Packages/67e9c6fb-c794-495f-8f1b-8b015233216a/Badge)](https://dev.azure.com/qdigitalcode/DenovoBank/_artifacts/feed/Development/NuGet/Platform.Library.Common) **(PRIVATE)** - Access common error handling
  - [Platform.Library.Http](https://dev.azure.com/qdigitalcode/DenovoBank/_git/Platform.Library.Http) [![Platform.Library.Http package in Development feed in Azure Artifacts](https://feeds.dev.azure.com/qdigitalcode/_apis/public/Packaging/Feeds/Development/Packages/67e9c6fb-c794-495f-8f1b-8b015233216a/Badge)](https://dev.azure.com/qdigitalcode/DenovoBank/_artifacts/feed/Development/NuGet/Platform.Library.Http) **(PRIVATE)** - Access common Http Client handling

## Consumers
Any API or Function App that needs to communicate with Ascenda

## Registration
```csharp
	services.RegisterAscendaSDK(
#if DEBUG
		true,
#else
		false,
#endif
		"<component_name>"
	);
```