$reportGenVersion = "4.6.1"

Clear-Host

Write-Host "Running Tests and collecting coverage stats"
dotnet test -c Release /p:CollectCoverage=true /p:CoverletOutputFormat=cobertura /p:SkipAutoProps=true

Write-Host "Generating Coverage Report"
Write-Host "This requires the report generator tool: 'dotnet tool install -g dotnet-reportgenerator-globaltool --version $reportGenVersion --ignore-failed-sources'"

reportgenerator -reports:./tests/**/coverage.cobertura.xml -targetdir:.\tests\artifacts -reporttypes:"HtmlInline" -assemblyFilters:"-NServiceBus.*;-xunit.*"

Write-Host "Launching Coverage Report"
Invoke-Item -Path .\tests\artifacts\index.html