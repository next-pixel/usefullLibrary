﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Converts the standard Ascenda Date/Time format
    /// </summary>
    public class AscendaDateTimeConverter : CustomDateTimeConverter
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AscendaDateTimeConverter"/> class.
        /// </summary>
        public AscendaDateTimeConverter() : base(AscendaConstants.DateFormats.DefaultFormat) { }
    }
}
