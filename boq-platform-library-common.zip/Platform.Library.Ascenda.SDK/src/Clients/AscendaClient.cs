using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Platform.Library.Common.Standard.Models.Abstractions;
using Platform.Library.Http;
using Platform.Library.Http.Abstractions;

namespace Platform.Library.Ascenda.SDK
{
    /// <inheritdoc cref="IAscendaClient"/>
    public class AscendaClient : IAscendaClient
    {
        private readonly ILogger<AscendaClient> _logger;
        private readonly IHttpClientHelper _clientHelper;
        private readonly AscendaClientSettings _settings;

        /// <summary>
        /// Initializes a new instance of the <see cref="AscendaClient"/> class.
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="clientHelper"></param>
        /// <param name="settings"></param>
        public AscendaClient(
            ILogger<AscendaClient> logger,
            IHttpClientHelper clientHelper,
            IOptions<AscendaClientSettings> settings)
        {
            _logger = logger.GuardNull(nameof(logger));
            _clientHelper = clientHelper.GuardNull(nameof(clientHelper));
            _settings = settings.GuardNull(nameof(settings));
        }

        /// <inheritdoc cref="IAscendaClient.CreateEventNotificationAsync(AscendaEventRequestDto, string, IDictionary{string, string}, CancellationToken)"/>
        public async Task CreateEventNotificationAsync(
            AscendaEventRequestDto request,
            string id,
            IDictionary<string, string> headers,
            CancellationToken cancellationToken)
        {
            try
            {
                var httpResponseMessage = await _clientHelper.PostAsync(
                   AscendaConstants.HttpClients.Ascenda,
                   _settings.EventsPath.WithPathParameters(id),
                   request,
                   headers,
                   null,
                   cancellationToken);

                if (!httpResponseMessage.ParseResponse(out var exception))
                    throw exception;
            }
            catch (AscendaException aex)
            {
                _logger.LogAscendaException(aex);
                throw;
            }
            catch (Exception ex)
            {
                throw _logger.RaiseAndLogStandardException(ex);
            }
        }

        /// <inheritdoc cref="IAscendaClient.GetPointsBalanceAsync(string, IStandardHeaderModel, CancellationToken)"/>
        public async Task<AscendaPointsBalanceResponse> GetPointsBalanceAsync(string temenosCif,IStandardHeaderModel standardHeaders, CancellationToken cancellationToken)
        {
            try
            {
                var httpResponseMessage = await _clientHelper.GetAsync(
                   AscendaConstants.HttpClients.Ascenda,
                   UriPath.Combine(_settings.AscendaUserPath, _settings.PointsPath, temenosCif),
                   null,
                   standardHeaders,
                   cancellationToken);

                return httpResponseMessage.ParseResponse<AscendaPointsBalanceResponse>(cancellationToken, out var exception)
                    ?? throw exception;
            }
            catch (AscendaException aex)
            {
                _logger.LogAscendaException(aex);
                throw;
            }
            catch (Exception ex)
            {
                throw _logger.RaiseAndLogStandardException(ex);
            }
        }

        /// <inheritdoc cref="IAscendaClient.GetOfferCampaignsAsync(string, int, IStandardHeaderModel, CancellationToken)"/>
        public async Task<AscendaGetOffersCampaignsResponse> GetOfferCampaignsAsync(string temenosCif, int offerNumber, IStandardHeaderModel standardHeaders, CancellationToken cancellationToken)
        {
            try
            {
                var httpResponseMessage = await _clientHelper.GetAsync(
                   AscendaConstants.HttpClients.Ascenda,
                   UriPath.Combine(_settings.AscendaUserPath, _settings.CampaignsPath, temenosCif)
                    .WithQueryParameters(
                       (AscendaConstants.QueryParameters.PageSize   , offerNumber.AsPageSize()),
                       (AscendaConstants.QueryParameters.PageNumber , AscendaConstants.QueryDefaults.Page),
                       (AscendaConstants.QueryParameters.Sort       , AscendaConstants.SortFilters.Campaign)
                    ),
                   null,
                   standardHeaders,
                   cancellationToken);

                return httpResponseMessage.ParseResponse<AscendaGetOffersCampaignsResponse>(cancellationToken, out var exception)
                    ?? throw exception;
            }
            catch (AscendaException aex)
            {
                _logger.LogAscendaException(aex);
                throw;
            }
            catch (Exception ex)
            {
                throw _logger.RaiseAndLogStandardException(ex);
            }
        }

        /// <inheritdoc cref="IAscendaClient.GetPartnerOffersAsync(string, int, IStandardHeaderModel, CancellationToken)"/>
        public async Task<AscendaGetOffersCampaignsResponse> GetPartnerOffersAsync(string cif, int offerNumber, IStandardHeaderModel standardHeaders, CancellationToken cancellationToken)
        {
            try
            {
                var httpResponseMessage = await _clientHelper.GetAsync(
                   AscendaConstants.HttpClients.Ascenda,
                   UriPath.Combine(_settings.AscendaUserPath, _settings.OffersPath, cif)
                    .WithQueryParameters(
                       (AscendaConstants.QueryParameters.PageSize, offerNumber.AsPageSize()),
                       (AscendaConstants.QueryParameters.PageNumber, AscendaConstants.QueryDefaults.Page),
                       (AscendaConstants.QueryParameters.Sort, AscendaConstants.SortFilters.PartnerOffer)
                    ),
                   null,
                   standardHeaders,
                   cancellationToken);

                return httpResponseMessage.ParseResponse<AscendaGetOffersCampaignsResponse>(cancellationToken, out var exception)
                    ?? throw exception;
            }
            catch (AscendaException aex)
            {
                _logger.LogAscendaException(aex);
                throw;
            }
            catch (Exception ex)
            {
                throw _logger.RaiseAndLogStandardException(ex);
            }
        }

        /// <inheritdoc cref="IAscendaClient.PurchaseEraserAsync(AscendaPurchaseEraserRequest, IStandardHeaderModel, string, CancellationToken)"/>
        public async Task<string> PurchaseEraserAsync(AscendaPurchaseEraserRequest request, IStandardHeaderModel standardHeaders, string temenosCif, CancellationToken cancellationToken)
        {
            try
            {
                var httpResponseMessage = await _clientHelper.PostAsync(
                   AscendaConstants.HttpClients.Ascenda,
                   _settings.PurchaseEraserUrl.WithPathParameters((AscendaConstants.PathParameters.BankUserIdentifier, temenosCif)),
                   request,
                   null,
                   standardHeaders,
                cancellationToken);

                var response = httpResponseMessage.ParseResponse<AscendaPurchaseEraserResponse>(cancellationToken, out var exception)
                    ?? throw exception;

                return response.Data.Id;
            }
            catch (AscendaException aex)
            {
                _logger.LogAscendaException(aex);
                throw;
            }
            catch (Exception ex)
            {
                throw _logger.RaiseAndLogStandardException(ex);
            }
        }

        /// <inheritdoc cref="IAscendaClient.PurchaseEraserRefundAsync(AscendaPurchaseEraserRefundRequest, IStandardHeaderModel, string, CancellationToken)"/>
        public async Task PurchaseEraserRefundAsync(AscendaPurchaseEraserRefundRequest request, IStandardHeaderModel standardHeaders, string temenosCif, CancellationToken cancellationToken)
        {
            try
            {
                var httpResponseMessage = await _clientHelper.PostAsync(
                   AscendaConstants.HttpClients.Ascenda,
                   _settings.PurchaseEraserRefundUrl.WithPathParameters((AscendaConstants.PathParameters.BankUserIdentifier, temenosCif)),
                   request,
                   null,
                   standardHeaders,
                   cancellationToken);

                if (!httpResponseMessage.ParseResponse(out var exception))
                    throw exception;
            }
            catch (AscendaException aex)
            {
                _logger.LogAscendaException(aex);
                throw;
            }
            catch (Exception ex)
            {
                throw _logger.RaiseAndLogStandardException(ex);
            }
        }

        /// <inheritdoc cref="IAscendaClient.ValidatePromoCodeAsync(AscendaValidatePromoCodeRequest, IStandardHeaderModel, CancellationToken)"/>
        public async Task<bool> ValidatePromoCodeAsync(AscendaValidatePromoCodeRequest request, IStandardHeaderModel standardHeaders, CancellationToken cancellationToken)
        {
            try
            {
                var httpResponseMessage = await _clientHelper.PostAsync(
                   AscendaConstants.HttpClients.Ascenda,
                   _settings.ValidatePromoUrl,
                   request,
                   null,
                   standardHeaders,
                   cancellationToken);

                var response = httpResponseMessage.ParseResponse<AscendaValidatePromoCodeResponse>(cancellationToken, out var exception)
                    ?? throw exception;

                return response.Data.Attributes.Valid;
            }
            catch (AscendaException aex)
            {
                _logger.LogAscendaException(aex);
                throw;
            }
            catch (Exception ex)
            {
                throw _logger.RaiseAndLogStandardException(ex);
            }
        }

        /// <inheritdoc cref="IAscendaClient.PurchaseEraserCheckEligibilityAsync(AscendaCheckEligibilityRequest, IStandardHeaderModel, string, CancellationToken)"/>
        public async Task<AscendaCheckEligibilityResponse> PurchaseEraserCheckEligibilityAsync(AscendaCheckEligibilityRequest request, IStandardHeaderModel standardHeaders, string temenosCif, CancellationToken cancellationToken)
        {
            try
            {
                var httpResponseMessage = await _clientHelper.PostAsync(
                   AscendaConstants.HttpClients.Ascenda,
                   _settings.CheckEligibilityUrl.WithPathParameters((AscendaConstants.PathParameters.BankUserIdentifier, temenosCif)),
                   request,
                   null,
                   standardHeaders,
                   cancellationToken);

                return httpResponseMessage.ParseResponse<AscendaCheckEligibilityResponse>(cancellationToken, out var exception)
                    ?? throw exception;
            }
            catch (AscendaException aex)
            {
                _logger.LogAscendaException(aex);
                throw;
            }
            catch (Exception ex)
            {
                throw _logger.RaiseAndLogStandardException(ex);
            }
        }

        /// <inheritdoc cref="IAscendaClient.CreateAccountAsync(CreateAscendaCustomerRequest, IStandardHeaderModel, CancellationToken)"/>
        public async Task<AscendaResponse<AscendaCustomerResponse>> CreateAccountAsync(CreateAscendaCustomerRequest createRequest, IStandardHeaderModel standardHeaders, CancellationToken cancellationToken)
        {
            try
            {
                var httpResponseMessage = await _clientHelper.PostAsync<CreateAscendaCustomerRequest>(
                   AscendaConstants.HttpClients.Ascenda,
                   _settings.AscendaUserPath,
                   createRequest,
                   null,
                   standardHeaders,
                   cancellationToken);

                return httpResponseMessage.ParseResponse<AscendaResponse<AscendaCustomerResponse>>(cancellationToken, out var exception)
                    ?? throw exception;
            }
            catch (AscendaException aex)
            {
                _logger.LogAscendaException(aex);
                throw;
            }
            catch (Exception ex)
            {
                throw _logger.RaiseAndLogStandardException(ex);
            }
        }
    }
}