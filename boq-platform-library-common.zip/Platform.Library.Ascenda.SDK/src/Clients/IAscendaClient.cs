using Platform.Library.Common.Standard.Models.Abstractions;

namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Interface for the Ascenda Client
    /// </summary>
    public interface IAscendaClient
    {
        /// <summary>
        /// Create a new Event Notification in the Ascenda system.
        /// </summary>
        /// <param name="request">Request DTO.</param>
        /// <param name="id">Ascenda known ID.</param>
        /// <param name="headers">Dictionary of additional headers. The Ocp-Apim-Subscription-Key header is the only platform-standard header inherited.</param>
        /// <param name="cancellationToken"></param>
        /// <returns>Response DTO returned by the Ascenda system.</returns>
        Task CreateEventNotificationAsync(
            AscendaEventRequestDto request,
            string id, 
            IDictionary<string, string> headers, 
            CancellationToken cancellationToken
        );

        /// <summary>
        /// Get Points Balance
        /// </summary>
        /// <param name="temenosCif"></param>
        /// <param name="standardHeaders"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task<AscendaPointsBalanceResponse> GetPointsBalanceAsync(
            string temenosCif, 
            IStandardHeaderModel standardHeaders,
            CancellationToken cancellationToken
        );

        /// <summary>
        /// Get Offer Campaigns
        /// </summary>
        /// <param name="temenosCif"></param>
        /// <param name="offerNumber"></param>
        /// <param name="standardHeaders"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task<AscendaGetOffersCampaignsResponse> GetOfferCampaignsAsync(
            string temenosCif,
            int offerNumber,
            IStandardHeaderModel standardHeaders,
            CancellationToken cancellationToken
        );

        /// <summary>
        /// Get Partner Offers
        /// </summary>
        /// <param name="temenosCif"></param>
        /// <param name="offerNumber"></param>
        /// <param name="standardHeaders"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task<AscendaGetOffersCampaignsResponse> GetPartnerOffersAsync(
            string temenosCif,
            int offerNumber,
            IStandardHeaderModel standardHeaders,
            CancellationToken cancellationToken
        );

        /// <summary>
        /// Purchase Eraser
        /// </summary>
        /// <param name="request"></param>
        /// <param name="standardHeaders"></param>
        /// <param name="temenosCif"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task<string> PurchaseEraserAsync(
            AscendaPurchaseEraserRequest request, 
            IStandardHeaderModel standardHeaders, 
            string temenosCif, 
            CancellationToken cancellationToken
        );

        /// <summary>
        /// Purchase Eraser Refund
        /// </summary>
        /// <param name="request"></param>
        /// <param name="standardHeaders"></param>
        /// <param name="temenosCif"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task PurchaseEraserRefundAsync(
            AscendaPurchaseEraserRefundRequest request, 
            IStandardHeaderModel standardHeaders, 
            string temenosCif, 
            CancellationToken cancellationToken
        );

        /// <summary>
        /// Validate Promo Code
        /// </summary>
        /// <param name="request"></param>
        /// <param name="standardHeaders"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task<bool> ValidatePromoCodeAsync(
            AscendaValidatePromoCodeRequest request, 
            IStandardHeaderModel standardHeaders, 
            CancellationToken cancellationToken
        );

        /// <summary>
        /// Purchase Eraser Check Eligibility
        /// </summary>
        /// <param name="request"></param>
        /// <param name="standardHeaders"></param>
        /// <param name="temenosCif"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task<AscendaCheckEligibilityResponse> PurchaseEraserCheckEligibilityAsync(
            AscendaCheckEligibilityRequest request, 
            IStandardHeaderModel standardHeaders, 
            string temenosCif,
            CancellationToken cancellationToken
        );

        /// <summary>
        /// Acenda Create Customer
        /// </summary>
        /// <param name="createRequest"></param>
        /// <param name="standardHeaders"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task<AscendaResponse<AscendaCustomerResponse>> CreateAccountAsync(
            CreateAscendaCustomerRequest createRequest,
            IStandardHeaderModel standardHeaders,
            CancellationToken cancellationToken
        );
    }
}
