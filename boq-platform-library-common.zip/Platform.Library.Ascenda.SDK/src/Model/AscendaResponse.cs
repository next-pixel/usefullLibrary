﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Response Wrapper
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class AscendaResponse<T>
        where T : BaseAscendaResponse
    {
        /// <summary>
        /// Gets or sets Response Data
        /// </summary>
        [JsonProperty("data")]
        [JsonPropertyName("data")]
        public T Data { get; set; }
    }
}
