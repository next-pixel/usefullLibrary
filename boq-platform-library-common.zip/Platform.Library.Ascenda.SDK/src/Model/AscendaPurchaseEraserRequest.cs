﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Purchase Eraser Request
    /// </summary>
    public class AscendaPurchaseEraserRequest : CardSpend { }
}
