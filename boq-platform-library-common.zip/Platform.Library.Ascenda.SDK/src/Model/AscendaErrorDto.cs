namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Error Response
    /// </summary>
    public class AscendaErrorDto
    {
        /// <summary>
        /// Gets or sets the Errors collection
        /// </summary>
        [JsonProperty("errors")]
        [JsonPropertyName("errors")]
        public IEnumerable<AscendaError> Errors { get; set; }
    }
}