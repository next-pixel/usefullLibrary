﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Purchase Eraser Response Data
    /// </summary>
    public class PurchaseEraserResponseData
    {
        /// <summary>
        /// Gets or sets ID
        /// </summary>
        [JsonProperty("id")]
        [JsonPropertyName("id")]
        public string Id { get; set; }
    }
}
