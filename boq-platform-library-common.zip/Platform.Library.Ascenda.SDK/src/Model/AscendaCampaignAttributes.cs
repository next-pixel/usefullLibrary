﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Campaign Attributes
    /// </summary>
    public class AscendaCampaignAttributes
    {
        /// <summary>
        /// Gets or sets Campaign Type
        /// </summary>
        [JsonProperty("type")]
        [JsonPropertyName("type")]
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets Brand
        /// </summary>
        [JsonProperty("brand")]
        [JsonPropertyName("brand")]
        public string Brand { get; set; }

        /// <summary>
        /// Gets or sets Title
        /// </summary>
        [JsonProperty("title")]
        [JsonPropertyName("title")]
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets Categories
        /// </summary>
        [JsonProperty("categories")]
        [JsonPropertyName("categories")]
        public IEnumerable<string> Categories { get; set; }

        /// <summary>
        /// Gets or sets Logo
        /// </summary>
        [JsonProperty("logo")]
        [JsonPropertyName("logo")]
        public string LogoUrl { get; set; }

        /// <summary>
        /// Gets or sets Cover Image
        /// </summary>
        [JsonProperty("cover_image")]
        [JsonPropertyName("cover_image")]
        public string CoverImageUrl { get; set; }

        /// <summary>
        /// Gets or sets Main Category Icon
        /// </summary>
        [JsonProperty("main_category_icon")]
        [JsonPropertyName("main_category_icon")]
        public string MainCategoryImageUrl { get; set; }

        /// <summary>
        /// Gets or sets Start Date
        /// </summary>
        [JsonProperty("start_date")]
        [JsonPropertyName("start_date")]
        [MsJson.JsonConverter(typeof(AscendaDateTimeConverter))]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// Gets or sets End Date
        /// </summary>
        [JsonProperty("end_date")]
        [JsonPropertyName("end_date")]
        [MsJson.JsonConverter(typeof(AscendaDateTimeConverter))]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Gets or sets Campaign Code
        /// </summary>
        [JsonProperty("campaign_code")]
        [JsonPropertyName("campaign_code")]
        public string CampaignCode { get; set; }
    }
}
