﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Widget Data
    /// </summary>
    public class AscendaWidgetData
    {
        /// <summary>
        /// Gets or sets Point Balance
        /// </summary>
        [JsonProperty("pointsBalance")]
        [JsonPropertyName("pointsBalance")]
        public int PointsBalance { get; set; }

        /// <summary>
        /// Gets or sets ID
        /// </summary>
        [JsonProperty("id")]
        [JsonPropertyName("id")]
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [JsonProperty("type")]
        [JsonPropertyName("type")]
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets Attributes
        /// </summary>
        [JsonProperty("attributes")]
        [JsonPropertyName("attributes")]
        public AscendaCampaignAttributes Attributes { get; set; }
    }
}
