﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Promo Validation Attributes
    /// </summary>
    public class PromoValidationAttributes
    {
        /// <summary>
        /// Gets or sets the Validity of the Promo Code
        /// </summary>
        [JsonProperty("valid")]
        [JsonPropertyName("valid")]
        public bool Valid { get; set; }
    }
}
