﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Collection Metadata
    /// </summary>
    public class AscendaCollectionMetadata
    {
        /// <summary>
        /// Gets or sets the Merchant Name
        /// </summary>
        [JsonProperty("count")]
        [JsonPropertyName("count")]
        public int Count { get; set; }       
    }
}
