﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Validate Promo Code Response
    /// </summary>
    public class AscendaValidatePromoCodeResponse
    {
        /// <summary>
        /// Gets or sets the Promo Validation Data
        /// </summary>
        [JsonProperty("data")]
        [JsonPropertyName("data")]
        public PromoValidationDetails Data { get; set; }
    }
}
