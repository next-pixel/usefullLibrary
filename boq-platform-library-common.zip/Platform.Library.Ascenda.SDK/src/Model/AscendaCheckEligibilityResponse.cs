﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Check Eligibility Response
    /// </summary>
    public class AscendaCheckEligibilityResponse
    {
        /// <summary>
        /// Gets or sets Eligibility Item Data
        /// </summary>
        [JsonProperty("data")]
        [JsonPropertyName("data")]
        public IEnumerable<EligibilityItem> Data { get; set; }

        /// <summary>
        /// Gets or sets Metadata
        /// </summary>
        [JsonProperty("meta")]
        [JsonPropertyName("meta")]
        public AscendaCollectionMetadata Metadata { get; set; }
    }
}
