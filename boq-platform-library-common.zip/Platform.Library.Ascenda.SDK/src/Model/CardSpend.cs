﻿using Platform.Library.BaseEvent;

namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Card Spend Data
    /// </summary>
    public class CardSpend
    {
        /// <summary>
        /// Gets or sets the Reference Id
        /// </summary>
        [JsonProperty("reference_id")]
        [JsonPropertyName("reference_id")]
        public string ReferenceId { get; set; }

        /// <summary>
        /// Gets or sets the Amount
        /// </summary>
        [JsonProperty("amount")]
        [JsonPropertyName("amount")]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets the Currency
        /// </summary>
        [JsonProperty("currency")]
        [JsonPropertyName("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets the Purchase Type
        /// </summary>
        [JsonProperty("type")]
        [JsonPropertyName("type")]
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets the MCC
        /// </summary>
        [JsonProperty("mcc")]
        [JsonPropertyName("mcc")]
        public string Mcc { get; set; }

        /// <summary>
        /// Gets or sets the Metadata
        /// </summary>
        [JsonProperty("metadata")]
        [JsonPropertyName("metadata")]
        public AscendaMetadata Metadata { get; set; }
    }
}
