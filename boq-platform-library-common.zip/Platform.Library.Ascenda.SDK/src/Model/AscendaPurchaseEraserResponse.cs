﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Purchase Eraser Response
    /// </summary>
    public class AscendaPurchaseEraserResponse
    {
        /// <summary>
        /// Gets or sets response Data
        /// </summary>
        [JsonProperty("data")]
        [JsonPropertyName("data")]
        public PurchaseEraserResponseData Data { get; set; }
    }
}
