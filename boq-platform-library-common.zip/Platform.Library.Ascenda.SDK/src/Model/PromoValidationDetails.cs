﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Promo Code Validation Details
    /// </summary>
    public class PromoValidationDetails
    {
        /// <summary>
        /// Gets or sets the Promo Code Validation Attributes
        /// </summary>
        [JsonProperty("attributes")]
        [JsonPropertyName("attributes")]
        public PromoValidationAttributes Attributes { get; set; }
    }
}
