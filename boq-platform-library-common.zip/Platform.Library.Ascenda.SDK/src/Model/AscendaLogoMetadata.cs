﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Logo Metadata
    /// </summary>
    public class AscendaLogoMetadata
    {
        /// <summary>
        /// Gets or sets Referrer ID
        /// </summary>
        [JsonProperty("logo_url")]
        [JsonPropertyName("logo_url")]
        public string LogoUrl { get; set; }
    }
}
