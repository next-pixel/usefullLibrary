namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Error
    /// </summary>
    public class AscendaError
    {
        /// <summary>
        /// Gets or sets the Error ID
        /// </summary>
        [JsonProperty("id")]
        [JsonPropertyName("id")]
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets the Error Code
        /// </summary>
        [JsonProperty("code")]
        [JsonPropertyName("code")]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the Error Message
        /// </summary>
        [JsonProperty("message")]
        [JsonPropertyName("message")]
        public string Message { get; set; }
    }
}