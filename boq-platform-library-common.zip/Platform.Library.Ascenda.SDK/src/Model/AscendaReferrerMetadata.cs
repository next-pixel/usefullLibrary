﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Referrer Metadata
    /// </summary>
    public class AscendaReferrerMetadata
    {
        /// <summary>
        /// Gets or sets Referrer ID
        /// </summary>
        [JsonProperty("referrer_id")]
        [JsonPropertyName("referrer_id")]
        public string ReferrerId { get; set; }
    }
}
