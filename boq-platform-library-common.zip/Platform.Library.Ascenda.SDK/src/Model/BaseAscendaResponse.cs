﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Base Ascenda Response
    /// </summary>
    public abstract class BaseAscendaResponse
    {
        /// <summary>
        /// Gets or sets the ID
        /// </summary>
        [JsonProperty("id")]
        [JsonPropertyName("id")]
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets the Type
        /// </summary>
        [JsonProperty("type")]
        [JsonPropertyName("type")]
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets the Attributes
        /// </summary>
        [JsonProperty("attributes")]
        [JsonPropertyName("attributes")]
        public CaseInsensitiveDictionary<string> Attributes { get; set; }
    }
}
