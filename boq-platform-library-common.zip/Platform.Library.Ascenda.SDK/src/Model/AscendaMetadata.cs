﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Metadata
    /// </summary>
    public class AscendaMetadata
    {
        /// <summary>
        /// Gets or sets the Merchant Name
        /// </summary>
        [JsonProperty("merchant_name")]
        [JsonPropertyName("merchant_name")]
        public string MerchantName { get; set; }
       
        /// <summary>
        /// Gets or sets the Account Type
        /// </summary>
        [JsonProperty("account_Type")]
        [JsonPropertyName("account_Type")]
        public string AccountType { get; set; }

        /// <summary>
        /// Gets or sets the Card last 4 digits
        /// </summary>
        [JsonProperty("card_Last_4")]
        [JsonPropertyName("card_Last_4")]
        public string CardLast4 { get; set; }
    }
}
