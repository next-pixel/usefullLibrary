﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Check Eligibility Request
    /// </summary>
    public class AscendaCheckEligibilityRequest
    {
        /// <summary>
        /// Gets or sets the Card Spend list
        /// </summary>
        [JsonProperty("card_spend")]
        [JsonPropertyName("card_spend")]
        public CardSpend[] CardSpend { get; set; }
    }
}
