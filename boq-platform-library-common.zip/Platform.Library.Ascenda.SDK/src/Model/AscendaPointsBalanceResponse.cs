﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Points Balance Response
    /// </summary>
    public class AscendaPointsBalanceResponse
    {
        /// <summary>
        /// Gets or sets Ascenda Points Balance Data
        /// </summary>
        [JsonProperty("data")]
        [JsonPropertyName("data")]
        public PointsData Data { get; set; }
    }
}
