﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Get Offers Campaigns Response
    /// </summary>
    public class AscendaGetOffersCampaignsResponse
    {
        /// <summary>
        /// Gets or sets Data
        /// </summary>
        [JsonProperty("data")]
        [JsonPropertyName("data")]
        public IEnumerable<AscendaWidgetData> Data { get; set; }

        /// <summary>
        /// Gets or sets Metadata
        /// </summary>
        [JsonProperty("meta")]
        [JsonPropertyName("meta")]
        public AscendaCollectionMetadata Metadata { get; set; }
    }
}
