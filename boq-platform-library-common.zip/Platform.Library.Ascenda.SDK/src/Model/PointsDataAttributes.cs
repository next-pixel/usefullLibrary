﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Points Data Attributes
    /// </summary>
    public class PointsDataAttributes
    {
        /// <summary>
        /// Gets or sets Points Balance
        /// </summary>
        [JsonProperty("pointsBalance")]
        [JsonPropertyName("pointsBalance")]
        public int PointsBalance { get; set; }

        /// <summary>
        /// Gets or sets Accruals Data
        /// </summary>
        [JsonProperty("accruals")]
        [JsonPropertyName("accruals")]
        public IEnumerable<PointsAccrual> Accruals { get; set; }

        /// <summary>
        /// Gets or sets Tranch Data
        /// </summary>
        [JsonProperty("tranches")]
        [JsonPropertyName("tranches")]
        public IEnumerable<PointsTranch> Tranches { get; set; }
    }
}
