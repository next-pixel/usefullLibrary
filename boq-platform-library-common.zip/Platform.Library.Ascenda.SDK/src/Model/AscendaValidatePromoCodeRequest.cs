﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Validate Promo Code Request
    /// </summary>
    public class AscendaValidatePromoCodeRequest
    {
        /// <summary>
        /// Get or sets the Campaign Code
        /// </summary>
        [JsonProperty("campaign_code")]
        [JsonPropertyName("campaign_code")]
        public string CampaignCode { get; set; }
    }
}
