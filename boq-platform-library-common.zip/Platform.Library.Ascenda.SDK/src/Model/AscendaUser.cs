﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda User Details
    /// </summary>
    public class AscendaUser
    {
        /// <summary>
        /// Gets or sets Partner User ID
        /// </summary>
        [JsonProperty("partner_user_id")]
        [JsonPropertyName("partner_user_id")]
        public string PartnerUserId { get; set; }

        /// <summary>
        /// Gets or sets Ascenda Metadata
        /// </summary>
        [JsonProperty("metadata")]
        [JsonPropertyName("metadata")]
        public AscendaReferrerMetadata Metadata { get; set; }
    }
}
