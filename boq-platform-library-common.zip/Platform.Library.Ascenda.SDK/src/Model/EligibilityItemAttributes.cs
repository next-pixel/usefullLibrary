﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Eligibility Item Attributes
    /// </summary>
    public class EligibilityItemAttributes
    {
        /// <summary>
        /// Gets or sets Reference ID
        /// </summary>
        [JsonProperty("referenceId")]
        public string ReferenceId { get; set; }

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        [JsonProperty("amount")]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets Code/Type
        /// </summary>
        [JsonProperty("code")]
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets Points Required
        /// </summary>
        [JsonProperty("pointsRequired")]
        public int PointsRequired { get; set; }

        /// <summary>
        /// Gets or sets Ascenda Metadata
        /// </summary>
        [JsonProperty("metadata")]
        public AscendaLogoMetadata Metadata { get; set; }
    }
}
