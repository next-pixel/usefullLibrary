﻿using Platform.Library.Extensions.JsonConverters;
using System;
using System.Collections.Generic;
namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Points Accrual
    /// </summary>
    public class PointsAccrual
    {
        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        [JsonProperty("amount")]
        [JsonPropertyName("amount")]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets Transaction Date
        /// </summary>
        [JsonProperty("transactionDate")]
        [JsonPropertyName("transactionDate")]
        [MsJson.JsonConverter(typeof(AscendaDateTimeConverter))]
        public DateTime? TransactionDate { get; set; }
    }
}
