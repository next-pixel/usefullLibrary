﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Purchase Eraser Refund Request
    /// </summary>
    public class AscendaPurchaseEraserRefundRequest
    {
        /// <summary>
        /// Gets or sets the Reference ID
        /// </summary>
        [JsonProperty("reference_id")]
        [JsonPropertyName("reference_id")]
        public string ReferenceId { get; set; }
    }
}
