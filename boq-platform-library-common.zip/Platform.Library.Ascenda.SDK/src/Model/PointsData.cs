﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Points Data
    /// </summary>
    public class PointsData
    {
        /// <summary>
        /// Gets or sets Ascenda Points Data Attributes
        /// </summary>
        [JsonProperty("attributes")]
        [JsonPropertyName("attributes")]
        public PointsDataAttributes Attributes { get; set; }
    }
}
