﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Customer Response
    /// </summary>
    public class AscendaCustomerResponse : BaseAscendaResponse
    {
        /// <summary>
        /// Partner User ID
        /// </summary>
        [NwJson.JsonIgnore]
        [MsJson.JsonIgnore]
        public string PartnerUserId => Attributes[AscendaConstants.Properties.PartnerUserId];
    }
}
