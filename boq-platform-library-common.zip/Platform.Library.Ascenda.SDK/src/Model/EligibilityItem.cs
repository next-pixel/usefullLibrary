﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Eligibility Item
    /// </summary>
    public class EligibilityItem
    {
        /// <summary>
        /// Gets or sets the Item ID
        /// </summary>
        [JsonProperty("id")]
        [JsonPropertyName("id")]
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets the Item Type
        /// </summary>
        [JsonProperty("type")]
        [JsonPropertyName("type")]
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets the Items Attributes
        /// </summary>
        [JsonProperty("attributes")]
        [JsonPropertyName("attributes")]
        public EligibilityItemAttributes Attributes { get; set; }
    }
}
