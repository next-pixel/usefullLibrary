﻿namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Create Customer Request
    /// </summary>
    public class CreateAscendaCustomerRequest
    {
        /// <summary>
        /// Gets or sets the User details
        /// </summary>
        [JsonProperty("user")]
        [JsonPropertyName("user")]
        public AscendaUser User { get; set; }
    }
}
