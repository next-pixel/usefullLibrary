using System.Text.Json.Serialization;
using Newtonsoft.Json;

namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Event Request
    /// </summary>
    public class AscendaEventRequestDto
    {
        /// <summary>
        /// Gets or sets Event ID
        /// </summary>
        [JsonProperty("event_id")]
        [JsonPropertyName("event_id")]
        public string EventId { get; set; }

        /// <summary>
        /// Gets or sets Reference ID
        /// </summary>
        [JsonProperty("reference_id")]
        [JsonPropertyName("reference_id")]
        public string ReferenceId { get; set; }

        /// <summary>
        /// Gets or sets Metadata
        /// </summary>
        [JsonProperty("metadata")]
        [JsonPropertyName("metadata")]
        public AscendaVerificationMetadata Metadata { get; set; }
    }
}