namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Ascenda Verificaiton Metadata template
    /// </summary>
    public class AscendaVerificationMetadata
    {
        /// <summary>
        /// Email Verified
        /// </summary>
        [JsonProperty("emailVerified")]
        [JsonPropertyName("emailVerified")]
        public bool EmailVerified { get; set; }

        /// <summary>
        /// Tfn Provided
        /// </summary>
        [JsonProperty("tfnProvided")]
        [JsonPropertyName("tfnProvided")]
        public bool TfnProvided { get; set; }
    }
}