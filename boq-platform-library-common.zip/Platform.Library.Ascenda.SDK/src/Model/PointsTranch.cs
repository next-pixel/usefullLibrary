﻿using Platform.Library.Extensions.JsonConverters;

namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Points Tranch
    /// </summary>
    public class PointsTranch
    {
        /// <summary>
        /// Gets or sets Balance
        /// </summary>
        [JsonProperty("balance")]
        [JsonPropertyName("balance")]
        public decimal Balance { get; set; }

        /// <summary>
        /// Gets or sets Expiry Date
        /// </summary>
        [JsonProperty("expiryDate")]
        [JsonPropertyName("expiryDate")]
        [MsJson.JsonConverter(typeof(AscendaDateTimeConverter))]
        public DateTime? ExpiryDate { get; set; }
    }
}
