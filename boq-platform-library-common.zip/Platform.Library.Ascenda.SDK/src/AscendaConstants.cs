using System.Diagnostics.CodeAnalysis;

namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Constants for use with the Ascenda SDK
    /// </summary>
    public static class AscendaConstants
    {
        /// <summary>
        /// Date Formats
        /// </summary>
        public static class DateFormats
        {
            /// <summary>
            /// Default Ascenda Date Format
            /// </summary>
            public const string DefaultFormat = "yyyy-MM-ddTHH:mm:ss.FFFZ";
        }

        /// <summary>
        /// Http Clients
        /// </summary>
        public static class HttpClients
        {
            /// <summary>
            /// Ascenda Client
            /// </summary>
            public const string Ascenda = Configuration.Ascenda;
        }

        /// <summary>
        /// Ascenda Payload Properties
        /// </summary>
        public static class Properties
        {
            /// <summary>
            /// Partner User ID Property
            /// </summary>
            public const string PartnerUserId = "partner_user_id";
        }

        internal static class PathParameters
        {
            public const string BankUserIdentifier = "bank_user_identifier";
        }

        internal static class QueryParameters
        {
            public const string PageSize = "page[size]";
            public const string PageNumber = "page[number]";
            public const string Sort = "sort";
        }

        internal static class SortFilters
        {
            public const string Campaign = "-score_by_recommended";
            public const string PartnerOffer = "-score_by_recommended,brand";
        }

        internal static class QueryDefaults
        {
            public const int Page = 1;
        }

        internal static class Configuration
        {
            internal const string Ascenda = nameof(Ascenda);
            internal const string InternalApimSubscriptionKey = nameof(InternalApimSubscriptionKey);
        }

        internal static class ErrorMessages
        {
            /// <summary>
            /// Standard text for logging Ascenda exceptions
            /// </summary>
            /// <remarks>0:Method, 1:ExceptionType, 3: StatusCode, 4:Message</remarks>
            public const string LogAscendaException = "Communication to Ascenda with {Method} failed with {ExceptionType} : {StatusCode} - {Message}";
        }
    }
}