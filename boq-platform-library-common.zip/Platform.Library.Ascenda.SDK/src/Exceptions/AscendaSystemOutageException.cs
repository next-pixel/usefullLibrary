using System.Net;

namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// System Outage response from Ascenda
    /// </summary>
    public class AscendaSystemOutageException : AscendaException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AscendaSystemOutageException"/> class.
        /// </summary>
        /// <param name="responseMessage"></param>
        public AscendaSystemOutageException(HttpResponseMessage responseMessage) : base(responseMessage) { }
    }
}