using System.Net;

namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Already Onboarded response from Ascenda
    /// </summary>
    public class AscendaAlreadyOnboardedException : AscendaException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AscendaAlreadyOnboardedException"/> class.
        /// </summary>
        /// <param name="responseMessage"></param>
        public AscendaAlreadyOnboardedException(HttpResponseMessage responseMessage) : base(responseMessage) { }
    }
}