using System.Net;

namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Unknown response from Ascenda
    /// </summary>
    public class AscendaUnauthorizedException : AscendaException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AscendaUnauthorizedException"/> class.
        /// </summary>
        /// <param name="responseMessage"></param>
        public AscendaUnauthorizedException(HttpResponseMessage responseMessage) : base(responseMessage) { }
    }
}