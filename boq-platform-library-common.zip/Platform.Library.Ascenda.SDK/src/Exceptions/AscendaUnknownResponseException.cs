using System.Net;

namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Unknown response from Ascenda
    /// </summary>
    public class AscendaUnknownResponseException : AscendaException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AscendaUnknownResponseException"/> class.
        /// </summary>
        /// <param name="responseMessage"></param>
        public AscendaUnknownResponseException(HttpResponseMessage responseMessage) : base(responseMessage) { }
    }
}