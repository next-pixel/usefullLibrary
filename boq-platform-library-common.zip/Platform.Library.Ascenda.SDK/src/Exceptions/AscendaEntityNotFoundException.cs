using System.Net;

namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Entity Not Found response from Ascenda
    /// </summary>
    public class AscendaEntityNotFoundException : AscendaException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AscendaEntityNotFoundException"/> class.
        /// </summary>
        /// <param name="responseMessage"></param>
        public AscendaEntityNotFoundException(HttpResponseMessage responseMessage) : base(responseMessage) { }
    }
}