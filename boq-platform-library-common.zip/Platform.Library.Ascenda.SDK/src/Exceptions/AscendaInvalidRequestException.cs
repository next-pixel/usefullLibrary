namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Invalid Request response from Ascenda
    /// </summary>
    public class AscendaInvalidRequestException : AscendaException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AscendaInvalidRequestException"/> class.
        /// </summary>
        /// <param name="responseMessage"></param>
        public AscendaInvalidRequestException(HttpResponseMessage responseMessage) : base(responseMessage) { }
    }
}