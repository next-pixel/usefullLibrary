using System.Net;

namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Exception raised from Ascenda
    /// </summary>
    public abstract class AscendaException : Exception
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AscendaException"/> class.
        /// </summary>
        /// <param name="responseMessage"></param>
        protected AscendaException(HttpResponseMessage responseMessage)
        {
            StatusCode = responseMessage.StatusCode;
            var errorDto = responseMessage.ContentAsResponse<AscendaErrorDto>();
            ErrorCode = errorDto?.Errors?.FirstOrDefault()?.Code ?? "?";
            ErrorMessage = errorDto?.Errors?.FirstOrDefault()?.Message ?? "No Message Provided";
        }

        /// <summary>Gets or sets the Status Code returned from Ascenda</summary>
        public HttpStatusCode StatusCode { get; private set; }

        /// <summary>Gets or sets the Error Code returned from Ascenda</summary>
        public string ErrorCode { get; private set; }

        /// <summary>Gets or sets the Error Message returned from Ascenda</summary>
        public string ErrorMessage { get; private set; }
    }
}