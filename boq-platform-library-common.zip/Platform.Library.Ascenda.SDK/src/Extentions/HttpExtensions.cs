using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Platform.Library.Common.ErrorHandling;
using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.Extensions;
using System.Net;
using System.Runtime.CompilerServices;

namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Extension methods to assist with Http requests/responses to Ascenda
    /// </summary>
    public static class HttpExtensions
    {
        /// <summary>
        /// Parse a <see cref="HttpResponseMessage"/> when no response is expected
        /// </summary>
        /// <param name="httpResponseMessage"></param>
        /// <param name="exception"></param>
        /// <returns></returns>
        internal static bool ParseResponse(this HttpResponseMessage httpResponseMessage, out AscendaException exception)
        {
            if (httpResponseMessage.IsSuccessStatusCode)
            {
                exception = null;
                return true;
            }

            exception = DetermineAscendaException(httpResponseMessage);
            return false;
        }

        /// <summary>
        /// Parse a <see cref="HttpResponseMessage"/> and extract the response or exception
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="httpResponseMessage"></param>
        /// <param name="cancellationToken"></param>
        /// <param name="exception"></param>
        /// <returns></returns>
        internal static T ParseResponse<T>(this HttpResponseMessage httpResponseMessage, CancellationToken cancellationToken, out AscendaException exception)
            where T : class, new()
        {
            if (httpResponseMessage.IsSuccessStatusCode)
            {
                exception = null;
                return httpResponseMessage.ContentAsResponse<T>(cancellationToken);
            }

            exception = DetermineAscendaException(httpResponseMessage);
            return null;
        }

        internal static T ContentAsResponse<T>(this HttpResponseMessage httpResponseMessage, CancellationToken cancellationToken = default)
            where T : class, new()
        {
            var content = httpResponseMessage?.Content.ReadAsStringAsync(cancellationToken).Result;
            if (string.IsNullOrWhiteSpace(content))
                return default(T);

            return content?.Deserialize<T>();
        }

        internal static string WithQueryParameters(this string path, params (string ParamName, object Value)[] queryParams)
        {
            return QueryHelpers.AddQueryString(
                path, 
                queryParams.Select(p => new KeyValuePair<string, StringValues>(p.ParamName, new StringValues(p.Value?.ToString() ?? "")))
            );
        }

        internal static int AsPageSize(this int pageSize)
        {
            return pageSize <= 0 ? 3 : pageSize;
        }

        internal static void LogAscendaException<T>(this ILogger logger, T exception, [CallerMemberName] string memberName = null)
            where T : AscendaException
        {
            logger.LogError(exception, AscendaConstants.ErrorMessages.LogAscendaException, memberName, exception.FormattedTypeName(), exception.StatusCode, exception.Message);
        }

        internal static StandardApiException RaiseAndLogStandardException<T>(this ILogger logger, T exception, [CallerMemberName] string memberName = null)
            where T : Exception
        {
            if (exception.GetType().IsAssignableTo(typeof(StandardApiException)))
                return exception as StandardApiException;

            var stdEx = StandardApiExceptionFactory.CreateStandardCommunicationException(exception);
            logger.LogError(stdEx.ErrorMessage);
            return stdEx;
        }

        internal static string WithPathParameters(this string path, params string[] parameters)
        {
            return string.Format(path, parameters);
        }

        internal static string WithPathParameters(this string path, params (string Token, string Value)[] parameters)
        {
            var result = path;
            if (parameters.AnyNullSafe())
            {
                foreach ( var parameter in parameters)
                    result = result.Replace(parameter.Token, parameter.Value);
            }
            return result;
        }

        private static AscendaException DetermineAscendaException(HttpResponseMessage httpResponseMessage)
        { 
            switch (httpResponseMessage.StatusCode)
            {
                case HttpStatusCode.NotFound:
                    return new AscendaEntityNotFoundException(httpResponseMessage);
                case HttpStatusCode.UnprocessableEntity:
                    return new AscendaAlreadyOnboardedException(httpResponseMessage);
                case HttpStatusCode.Unauthorized:
                case HttpStatusCode.Forbidden:
                    return new AscendaUnauthorizedException(httpResponseMessage);
                case HttpStatusCode.BadRequest:
                case HttpStatusCode.Conflict:
                case HttpStatusCode.Gone:
                case HttpStatusCode.TooManyRequests:
                    return new AscendaInvalidRequestException(httpResponseMessage);
                case HttpStatusCode.InternalServerError:
                case HttpStatusCode.NotImplemented:
                case HttpStatusCode.BadGateway:
                case HttpStatusCode.ServiceUnavailable:
                case HttpStatusCode.GatewayTimeout:
                    return new AscendaSystemOutageException(httpResponseMessage);
                default:
                    return new AscendaUnknownResponseException(httpResponseMessage);
            }
        }
    }
}