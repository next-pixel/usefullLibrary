namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// OBSOLETE Ascenda Events Interface
    /// </summary>
    [Obsolete("Plesae use IAscendaClient", true)]
    public interface IAscendaEvents
    {
        /// <summary>
        /// OBSOLETE Create Event Notification
        /// </summary>
        /// <param name="request"></param>
        /// <param name="id"></param>
        /// <param name="headers"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public Task<HttpResponseMessage> CreateEventNotification(AscendaEventRequestDto request,
            string id, Dictionary<string, string> headers, CancellationToken cancellationToken);
    }
}