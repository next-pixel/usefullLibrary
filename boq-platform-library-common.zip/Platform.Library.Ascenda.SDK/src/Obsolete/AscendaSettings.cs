using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.Configuration;

namespace Platform.Library.Ascenda.SDK
{
    /// <inheritdoc cref="IAscendaSettings"/>
    [Obsolete("Please use AscendaClientSettings", true)]
    [ExcludeFromCodeCoverage]
    public class AscendaSettings : IAscendaSettings
    {
        private IConfiguration Configuration { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="AscendaSettings"/> class.
        /// </summary>
        /// <param name="configuration"></param>
        public AscendaSettings(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        /// <inheritdoc cref="IAscendaSettings.BaseUrl"/>
        public string BaseUrl => GetSetting<string>("Ascenda:BaseUrl");

        /// <inheritdoc cref="IAscendaSettings.InternalApimSubscriptionKey"/>
        public string InternalApimSubscriptionKey => GetSetting<string>("InternalApimSubscriptionKey");

        private T GetSetting<T>(string key) where T : IConvertible
        {
            return Configuration.GetValue<T>(key);
        }
    }
}