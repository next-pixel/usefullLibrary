namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// OBSOLETE Ascenda Settings
    /// </summary>
    [Obsolete("Please use AscendaClientSettings", true)]
    public interface IAscendaSettings
    {
        /// <summary>
        /// OBSOLETE Base Url
        /// </summary>
        public string BaseUrl { get; }
        
        /// <summary>
        /// OBSOLETE Internal Subscription Key
        /// </summary>
        public string InternalApimSubscriptionKey { get; }
    }
}