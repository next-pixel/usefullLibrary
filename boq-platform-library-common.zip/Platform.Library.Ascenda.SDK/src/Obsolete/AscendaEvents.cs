using Platform.Library.Http.Abstractions;
using System.Diagnostics.CodeAnalysis;

namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// OBSOLETE Ascenda Events
    /// </summary>
    [Obsolete("Please use the new AscendaClient",true)]
    [ExcludeFromCodeCoverage]
    public class AscendaEvents : IAscendaEvents
    {
        private readonly IHttpClientHelper _httpClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="AscendaEvents"/> class.
        /// </summary>
        /// <param name="httpClient"></param>
        public AscendaEvents(
            IHttpClientHelper httpClient)
        {
            _httpClient = httpClient;
        }

        /// <summary>
        /// Create a new Event Notification in the Ascenda system.
        /// </summary>
        /// <param name="request">Request DTO.</param>
        /// <param name="id">Ascenda known ID.</param>
        /// <param name="headers">Dictionary of additional headers. The Ocp-Apim-Subscription-Key header is the only platform-standard header inherited.</param>
        /// <param name="cancellationToken"></param>
        /// <returns>Response DTO returned by the Ascenda system.</returns>
        public Task<HttpResponseMessage> CreateEventNotification(AscendaEventRequestDto request,
            string id, Dictionary<string, string> headers, CancellationToken cancellationToken)
        {
            throw new NotImplementedException("Please use the new AscendaClient");
        }
    }
}