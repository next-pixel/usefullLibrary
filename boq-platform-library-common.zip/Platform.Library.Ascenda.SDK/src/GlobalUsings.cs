﻿global using Newtonsoft.Json;
global using System.Text.Json;
global using System.Text.Json.Serialization;

global using NwJson = Newtonsoft.Json;
global using MsJson = System.Text.Json.Serialization;