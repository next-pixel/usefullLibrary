using Autofac;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Platform.Library.Common.AspNetCore.StandardApi.Http;
using Platform.Library.Http;
using Platform.Library.Http.Abstractions;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Net.Http.Headers;

namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Registration extension methods
    /// </summary>
    public static class Container
    {
        /// <summary>
        /// OBSOLETE Old registration method
        /// </summary>
        /// <param name="serviceCollection"></param>
        /// <param name="configuration"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        [Obsolete("Please use the RegisterAscendaSdk extension method instead", true)]
        [ExcludeFromCodeCoverage]
        public static IServiceCollection AddAscendaSDK(this IServiceCollection serviceCollection, IConfiguration configuration)
        {
            throw new NotImplementedException("Please use RegisterAscendaSdk");
        }

        /// <summary>
        /// Register Ascenda SDK using Microsoft Dependency Injection
        /// </summary>
        /// <param name="services"></param>
        /// <param name="inDebug"></param>
        /// <param name="defaultHeaders"></param>
        /// <param name="componentSectionName"></param>
        /// <returns></returns>
        public static IServiceCollection RegisterAscendaSdk(this IServiceCollection services, bool inDebug, IDictionary<string,string> defaultHeaders = null, string componentSectionName = null)
        {
            services.AddSingleton<IAscendaClient, AscendaClient>();
            services.RegisterHttpClient<AscendaClientSettings>(inDebug, componentSectionName, defaultHeaders);

            return services;
        }

        /// <summary>
        /// Register Ascenda SDK using Autofac
        /// </summary>
        /// <param name="services"></param>
        /// <param name="builder"></param>
        /// <param name="configuration"></param>
        /// <param name="inDebug"></param>
        /// <param name="defaultHeaders"></param>
        /// <param name="componentSectionName"></param>
        /// <returns></returns>        
        public static IServiceCollection RegisterAscendaSdk(this IServiceCollection services, ContainerBuilder builder, IConfiguration configuration, bool inDebug, IDictionary<string, string> defaultHeaders = null, string componentSectionName = null)
        {
            builder.RegisterType<AscendaClient>().AsImplementedInterfaces().SingleInstance();
            services.RegisterHttpClient<AscendaClientSettings>(builder, configuration, inDebug, componentSectionName, defaultHeaders);

            return services;
        }
    }
}