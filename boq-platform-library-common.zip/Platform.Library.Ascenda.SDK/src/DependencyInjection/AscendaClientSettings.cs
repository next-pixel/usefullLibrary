﻿using Microsoft.Extensions.DependencyInjection;
using Platform.Library.Common.AspNetCore.StandardApi.Http;
using Platform.Library.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Platform.Library.Ascenda.SDK
{
    /// <summary>
    /// Client Settings for connecting to Ascenda
    /// </summary>
    public class AscendaClientSettings : ClientSettings
    {
        /// <summary>
        /// Configuiration section to map to
        /// </summary>
        public override string ConfigName => AscendaConstants.Configuration.Ascenda;

        /// <summary>
        /// Connection to Ascenda should be through the gateway
        /// </summary>
        public override bool UseGateway => true;

        /// <summary>
        /// Configure the profile to use for Ascenda
        /// </summary>
        protected override HttpClientProfile ClientProfile => HttpClientProfile.Client(
            ClientName,
            (_, clientBuilder) => clientBuilder.ConfigurePrimaryHttpMessageHandler(() =>
                new HttpClientHandler()
                {
                    AutomaticDecompression = DecompressionMethods.Deflate | DecompressionMethods.GZip
                }),
            ConfigHeadersBuilder
                .Include(StandardHeaderConstants.OcpApimSubscriptionKey, AscendaConstants.Configuration.InternalApimSubscriptionKey)
            );

        /// <summary>
        /// Gets or sets the Events path
        /// </summary>
        public string EventsPath { get; set; }

        /// <summary>
        /// Gets or sets the Purchase Eraser path
        /// </summary>
        public string PurchaseEraserUrl { get; set; }

        /// <summary>
        /// Gets or sets the Validate Promo path
        /// </summary>
        public string ValidatePromoUrl { get; set; }

        /// <summary>
        /// Gets or sets the Purchase Eraser Refund path
        /// </summary>
        public string PurchaseEraserRefundUrl { get; set; }

        /// <summary>
        /// Gets or sets the Ascenda User path
        /// </summary>
        public string AscendaUserPath { get; set; }

        /// <summary>
        /// Gets or sets the Check Eligibility path
        /// </summary>
        public string CheckEligibilityUrl { get; set; }

        /// <summary>
        /// Gets or sets the Offers path
        /// </summary>
        public string OffersPath { get; set; }

        /// <summary>
        /// Gets or sets the Campaigns path
        /// </summary>
        public string CampaignsPath { get; set; }

        /// <summary>
        /// Gets or sets the Points path
        /// </summary>
        public string PointsPath { get; set; }

        /// <summary>
        /// Gets or sets the Post Campaign path
        /// </summary>
        public string PostCampaignUrl { get; set; }


        /// <summary>
        /// Gets of sets the Products eligible for rewards
        /// </summary>
        /// <remarks>A list of products separated by ";"</remarks>
        public string ProductsEligibleForRewards { get; set; }

        /// <summary>
        /// Gets or sets the Accounts eligible for refer a friend flag
        /// </summary>
        /// <remarks>A list of account types separated by ";"</remarks>
        public string AccountsEligibleForReferAFriendFlag { get; set; }
    }
}
