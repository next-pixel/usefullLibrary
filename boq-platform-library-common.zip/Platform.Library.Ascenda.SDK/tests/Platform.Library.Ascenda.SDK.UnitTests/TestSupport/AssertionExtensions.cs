﻿using FluentAssertions;
using Platform.Library.Common.Standard.ErrorHandling;
using System.Net;

namespace Platform.Library.Ascenda.SDK.UnitTests
{
    public static class AssertionExtensions
    {
        public static bool TryAssertOnException(this Exception ex, TestResponseEnum testResponse)
        {
            if (testResponse == TestResponseEnum.Success)
            {
                ex.Should().BeNull();
                return false;
            }
            else
            {
                ex.Should().NotBeNull();
                switch (testResponse) 
                { 
                    case TestResponseEnum.BadRequest:
                        ex.Should().BeOfType<AscendaInvalidRequestException>();
                        break;
                    case TestResponseEnum.Unauthorized:
                        ex.Should().BeOfType<AscendaUnauthorizedException>();
                        break;
                    case TestResponseEnum.BadGateway:
                        ex.Should().BeOfType<AscendaSystemOutageException>();
                        break;
                    case TestResponseEnum.NotFound:
                        ex.Should().BeOfType<AscendaEntityNotFoundException>();
                        break;
                    case TestResponseEnum.AlreadyOnboarded:
                        ex.Should().BeOfType<AscendaAlreadyOnboardedException>();
                        break;
                    case TestResponseEnum.StandardApiException:
                    case TestResponseEnum.UnexpectedException:
                        ex.Should().BeOfType<StandardApiException>();
                        break;
                    default:
                        ex.Should().BeOfType<AscendaUnknownResponseException>();
                        break;
                }

                if ( ex is AscendaException aEx )
                {
                    aEx.StatusCode.Should().NotBe(HttpStatusCode.OK);
                    aEx.ErrorCode.Should().NotBeNullOrWhiteSpace();
                    aEx.ErrorMessage.Should().NotBeNullOrWhiteSpace();
                }
                return true;
            }
        }
    }
}
