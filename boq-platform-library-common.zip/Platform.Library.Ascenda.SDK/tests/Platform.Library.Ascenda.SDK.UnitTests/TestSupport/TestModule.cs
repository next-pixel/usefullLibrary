﻿using Autofac;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Platform.Library.Ascenda.SDK.UnitTests
{
    public class TestModule : Module
    {
        public TestModule(IServiceCollection services, IConfiguration configuration)
        {
            Services = services;
            Configuration = configuration.GuardNull();
        }

        public IServiceCollection Services { get; }

        public IConfiguration Configuration { get; }

        protected override void Load(ContainerBuilder builder)
        {
            Services.RegisterAscendaSdk(
                builder,
                Configuration,
                true,
                null,
                "Unit Test"
            );
        }
    }
}
