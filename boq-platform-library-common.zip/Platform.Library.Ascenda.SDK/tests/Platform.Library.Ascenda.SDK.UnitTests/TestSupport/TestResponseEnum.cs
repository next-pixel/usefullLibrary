﻿namespace Platform.Library.Ascenda.SDK.UnitTests
{
    public enum TestResponseEnum
    {
        Success,
        NotFound,
        AlreadyOnboarded,
        Unauthorized,
        BadRequest,
        BadGateway,
        OtherResponse,
        StandardApiException,
        UnexpectedException
    }
}
