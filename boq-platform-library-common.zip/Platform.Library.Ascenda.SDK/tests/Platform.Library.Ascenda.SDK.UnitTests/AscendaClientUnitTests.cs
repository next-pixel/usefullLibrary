﻿using FluentAssertions;
using FluentAssertions.Execution;
using Platform.Library.Common.ErrorHandling;
using Platform.Library.Testing.XUnit;
using System.Net;
using Xunit.Abstractions;

namespace Platform.Library.Ascenda.SDK.UnitTests
{
    [TestType(TestTypeEnum.UnitTest)]
    public class AscendaClientUnitTests : XUnitTestFixture
    {
        public AscendaClientUnitTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture) { }

        protected ContextModule Context => Module<ContextModule>();
        protected ResourceModule Resource => Module<ResourceModule>();

        [ModuleInit(nameof(InitHttpModule))]
        protected HttpModule Http => Module<HttpModule>();

        private void InitHttpModule()
        {
            Http.HandleMockRequestEvent += HttpModule_HandleMockRequestEvent;
        }

        protected override void TestSetup()
        {
            if (PlatformContext.CurrentTestName.Contains(nameof(AscendaClient_CreateAccountAsync_ExpectedBehaviour)) )
            {
                Context.RegisterModule<TestModule>();
            }
            else
            {
                Context.RegisterWithMsDi(services =>
                {
                    services.RegisterAscendaSdk(true, componentSectionName: "UnitTest");
                });
            }
        }

        private Func<TestResponseEnum> ExpectedTestResponse { get; set; } = () => TestResponseEnum.Success;

        private void HttpModule_HandleMockRequestEvent(object sender, HttpRequestEventArgs args)
        {
            switch (args.ClientName)
            {
                case AscendaConstants.HttpClients.Ascenda:

                    var testResponse = ExpectedTestResponse.Invoke();
                    if (testResponse == TestResponseEnum.Success)
                    {
                        if (args.Method == HttpMethod.Post)
                        {
                            if (args.RequestPath.AbsolutePath.Contains("/campaign_events"))
                            {
                                args.SetResponse(HttpStatusCode.OK);
                                return;
                            }
                            else if ( args.RequestPath.AbsolutePath.EndsWithIgnoreCase("/purchase_eraser"))
                            {
                                args.SetResponse(HttpStatusCode.OK, Resource.ExtractManifestResource<AscendaPurchaseEraserResponse>("Valid"), null);
                                return;
                            }
                            else if (args.RequestPath.AbsolutePath.EndsWithIgnoreCase("/purchase_eraser/refund"))
                            {
                                args.SetResponse(HttpStatusCode.OK);
                                return;
                            }
                            else if ( args.RequestPath.AbsolutePath.EndsWithIgnoreCase("/campaigns/validate"))
                            {
                                args.SetResponse(HttpStatusCode.OK, Resource.ExtractManifestResource<AscendaValidatePromoCodeResponse>("Valid"), null);
                                return;
                            }
                            else if (args.RequestPath.AbsolutePath.EndsWithIgnoreCase("/purchase_eraser/eligibility"))
                            {
                                args.SetResponse(HttpStatusCode.OK, Resource.ExtractManifestResource<AscendaCheckEligibilityResponse>("Valid"), null);
                                return;
                            }
                            else if (args.RequestPath.AbsolutePath.EndsWithIgnoreCase("/users"))
                            {
                                args.SetResponse(HttpStatusCode.Created, Resource.ExtractManifestResource<AscendaResponse<AscendaCustomerResponse>>("Valid"), null);
                                return;
                            }
                        }
                        else if ( args.Method ==  HttpMethod.Get ) 
                        {
                            if (args.TryParseAfterRequestPath("/users/points_summary/", out var temenosCif))
                            {
                                args.SetResponse(HttpStatusCode.OK, Resource.ExtractManifestResource<AscendaPointsBalanceResponse>(temenosCif), null);
                                return;
                            }
                            else if (args.TryParseAfterRequestPath("/users/campaigns/", out temenosCif))
                            {
                                args.SetResponse(HttpStatusCode.OK, Resource.ExtractManifestResource<AscendaGetOffersCampaignsResponse>(temenosCif), null);
                                return;
                            }
                            else if (args.TryParseAfterRequestPath("/users/offers/", out temenosCif))
                            {
                                args.SetResponse(HttpStatusCode.OK, Resource.ExtractManifestResource<AscendaGetOffersCampaignsResponse>(temenosCif), null);
                                return;
                            }
                        }
                    }
                    else
                    {
                        switch ( testResponse )
                        {
                            case TestResponseEnum.NotFound:
                                args.SetResponse(HttpStatusCode.NotFound, Resource.ExtractManifestResource<AscendaErrorDto>("NotFound"), null);
                                break;
                            case TestResponseEnum.Unauthorized:
                                args.SetResponse(HttpStatusCode.Unauthorized, Resource.ExtractManifestResource<AscendaErrorDto>("Unauthorized"), null);
                                break;
                            case TestResponseEnum.BadGateway:
                                args.SetResponse(HttpStatusCode.BadGateway);
                                break;
                            case TestResponseEnum.BadRequest:
                                args.SetResponse(HttpStatusCode.BadRequest, Resource.ExtractManifestResource<AscendaErrorDto>("BadRequest"), null);
                                break;
                            case TestResponseEnum.AlreadyOnboarded:
                                args.SetResponse(HttpStatusCode.UnprocessableEntity, Resource.ExtractManifestResource<AscendaErrorDto>("UnprocessableEntity"), null);
                                break;
                            case TestResponseEnum.OtherResponse:
                                args.SetResponse(HttpStatusCode.Unused);
                                break;
                            case TestResponseEnum.StandardApiException:
                                throw StandardApiExceptionFactory.CreateStandardCommunicationException();
                            case TestResponseEnum.UnexpectedException:
                            default:
                                throw new Exception("Test");
                        }

                        return;
                    }
                    break;
            }

            throw new NotSupportedException($"[{args.ClientName}] {args.Method.ToString().ToUpper()}[{args.RequestPath.AbsoluteUri}] Not supported by {nameof(HttpModule_HandleMockRequestEvent)}");
        }

        [Theory]
        [InlineData("Valid", "123", TestResponseEnum.Success)]
        [InlineData("Valid", "123", TestResponseEnum.NotFound)]
        [InlineData("Valid", "123", TestResponseEnum.UnexpectedException)]
        [InlineData("Valid", "123", TestResponseEnum.StandardApiException)]
        public async Task AscendaClient_GetPointsBalanceAsync_ExpectedBehaviour(string scenario, string temenosCif, TestResponseEnum testResponse)
        {
            // Arrange
            var client = Context.Resolve<IAscendaClient>();
            ExpectedTestResponse = () => testResponse;

            // Act
            Exception actualException = null;
            AscendaPointsBalanceResponse actualResponse = null;
            try
            {
                actualResponse = await client.GetPointsBalanceAsync(temenosCif, null, CancellationToken.None);
            }
            catch (Exception ex)
            {
                actualException = ex;
            }

            // Assert
            using (new AssertionScope())
            {
                if ( !actualException.TryAssertOnException(testResponse) )
                {
                    actualResponse.Should().NotBeNull();
                    WriteLine(actualResponse.Serialize());
                }
            }
        }

        [Theory]
        [InlineData("Valid", "123", 1, TestResponseEnum.Success)]
        [InlineData("Valid", "123", 1, TestResponseEnum.NotFound)]
        [InlineData("Valid", "123", 1, TestResponseEnum.UnexpectedException)]
        [InlineData("Valid", "123", 1, TestResponseEnum.StandardApiException)]
        public async Task AscendaClient_GetOfferCampaignsAsync_ExpectedBehaviour(string scenario, string temenosCif, int offerNumber, TestResponseEnum testResponse)
        {
            // Arrange
            var client = Context.Resolve<IAscendaClient>();
            ExpectedTestResponse = () => testResponse;

            // Act
            Exception actualException = null;
            AscendaGetOffersCampaignsResponse actualResponse = null;
            try
            {
                actualResponse = await client.GetOfferCampaignsAsync(temenosCif, offerNumber, null, CancellationToken.None);
            }
            catch (Exception ex)
            {
                actualException = ex;
            }

            // Assert
            using (new AssertionScope())
            {
                if (!actualException.TryAssertOnException(testResponse))
                {
                    actualResponse.Should().NotBeNull();
                    WriteLine(actualResponse.Serialize());
                }
            }
        }

        [Theory]

        [InlineData("Valid", "123", 1, TestResponseEnum.Success)]
        [InlineData("Valid", "123", 1, TestResponseEnum.NotFound)]
        [InlineData("Valid", "123", 1, TestResponseEnum.UnexpectedException)]
        [InlineData("Valid", "123", 1, TestResponseEnum.StandardApiException)]
        public async Task AscendaClient_GetPartnerOffersAsync_ExpectedBehaviour(string scenario, string temenosCif, int offerNumber, TestResponseEnum testResponse)
        {
            // Arrange
            var client = Context.Resolve<IAscendaClient>();
            ExpectedTestResponse = () => testResponse;

            // Act
            Exception actualException = null;
            AscendaGetOffersCampaignsResponse actualResponse = null;
            try
            {
                actualResponse = await client.GetPartnerOffersAsync(temenosCif, offerNumber, null, CancellationToken.None);
            }
            catch (Exception ex)
            {
                actualException = ex;
            }

            // Assert
            using (new AssertionScope())
            {
                if (!actualException.TryAssertOnException(testResponse))
                {
                    actualResponse.Should().NotBeNull();
                    WriteLine(actualResponse.Serialize());
                }
            }
        }

        [Theory]
        [InlineData("Valid", "123", TestResponseEnum.Success)]
        [InlineData("Valid", "123", TestResponseEnum.NotFound)]
        [InlineData("Valid", "123", TestResponseEnum.UnexpectedException)]
        [InlineData("Valid", "123", TestResponseEnum.StandardApiException)]
        public async Task AscendaClient_CreateEventNotificationAsync_ExpectedBehaviour(string scenario, string id, TestResponseEnum testResponse)
        {
            // Arrange
            var client = Context.Resolve<IAscendaClient>();
            var request = Resource.ExtractManifestResource<AscendaEventRequestDto>(scenario);
            ExpectedTestResponse = () => testResponse;

            // Act
            Exception actualException = null;
            try
            {
                await client.CreateEventNotificationAsync(request, id, null, CancellationToken.None);
            }
            catch ( Exception ex )
            {
                actualException = ex;
            }

            // Assert
            using (new AssertionScope())
            {
                actualException.TryAssertOnException(testResponse);
            }
        }

        [Theory]
        [InlineData("Valid", "123", TestResponseEnum.Success, "1111")]
        [InlineData("Valid", "123", TestResponseEnum.NotFound, null)]
        [InlineData("Valid", "123", TestResponseEnum.Unauthorized, null)]
        [InlineData("Valid", "123", TestResponseEnum.BadRequest, null)]
        [InlineData("Valid", "123", TestResponseEnum.UnexpectedException, null)]
        [InlineData("Valid", "123", TestResponseEnum.StandardApiException, null)]
        public async Task AscendaClient_PurchaseEraserAsync_ExpectedBehaviour(string scenario, string temenosCif, TestResponseEnum testResponse, string expectedResponse)
        {
            // Arrange
            var client = Context.Resolve<IAscendaClient>();
            var request = Resource.ExtractManifestResource<AscendaPurchaseEraserRequest>(scenario);
            ExpectedTestResponse = () => testResponse;

            // Act
            Exception actualException = null;
            string actualResponse = null;
            try
            {
                actualResponse = await client.PurchaseEraserAsync(request,null, temenosCif, CancellationToken.None);
            }
            catch (Exception ex)
            {
                actualException = ex;
            }

            // Assert
            using (new AssertionScope())
            {
                if (actualException.TryAssertOnException(testResponse))
                    actualResponse.Should().BeNull();
                else
                    actualResponse.Should().BeEquivalentTo(expectedResponse);
            }
        }


        [Theory]
        [InlineData("Valid", "123", TestResponseEnum.Success)]
        [InlineData("Valid", "123", TestResponseEnum.NotFound)]
        [InlineData("Valid", "123", TestResponseEnum.Unauthorized)]
        [InlineData("Valid", "123", TestResponseEnum.UnexpectedException)]
        [InlineData("Valid", "123", TestResponseEnum.StandardApiException)]
        public async Task AscendaClient_PurchaseEraserRefundAsync_ExpectedBehaviour(string scenario, string temenosCif, TestResponseEnum testResponse)
        {
            // Arrange
            var client = Context.Resolve<IAscendaClient>();
            var request = Resource.ExtractManifestResource<AscendaPurchaseEraserRefundRequest>(scenario);
            ExpectedTestResponse = () => testResponse;

            // Act
            Exception actualException = null;
            try
            {
                await client.PurchaseEraserRefundAsync(request, null, temenosCif, CancellationToken.None);
            }
            catch (Exception ex)
            {
                actualException = ex;
            }

            // Assert
            using (new AssertionScope())
            {
                actualException.TryAssertOnException(testResponse);
            }
        }

        [Theory]
        [InlineData("Valid", TestResponseEnum.Success, true)]
        [InlineData("Valid", TestResponseEnum.BadGateway, null)]
        [InlineData("Valid", TestResponseEnum.UnexpectedException, null)]
        [InlineData("Valid", TestResponseEnum.StandardApiException, null)]
        public async Task AscendaClient_ValidatePromoCodeAsync_ExpectedBehaviour(string scenario, TestResponseEnum testResponse, bool? expectedResponse)
        {
            // Arrange
            var client = Context.Resolve<IAscendaClient>();
            var request = Resource.ExtractManifestResource<AscendaValidatePromoCodeRequest>(scenario);
            ExpectedTestResponse = () => testResponse;

            // Act
            Exception actualException = null;
            bool? actualResponse = null;
            try
            {
                actualResponse = await client.ValidatePromoCodeAsync(request, null, CancellationToken.None);
            }
            catch (Exception ex)
            {
                actualException = ex;
            }

            // Assert
            using (new AssertionScope())
            {
                if (actualException.TryAssertOnException(testResponse))
                    actualResponse.Should().BeNull();
                else
                    actualResponse.Should().Be(expectedResponse);
            }
        }

        [Theory]
        [InlineData("Valid", "123", TestResponseEnum.Success)]
        [InlineData("Valid", "123", TestResponseEnum.NotFound)]
        [InlineData("Valid", "123", TestResponseEnum.Unauthorized)]
        [InlineData("Valid", "123", TestResponseEnum.OtherResponse)]
        [InlineData("Valid", "123", TestResponseEnum.UnexpectedException)]
        [InlineData("Valid", "123", TestResponseEnum.StandardApiException)]
        public async Task AscendaClient_PurchaseEraserCheckEligibilityAsync_ExpectedBehaviour(string scenario, string temenosCif, TestResponseEnum testResponse)
        {
            // Arrange
            var client = Context.Resolve<IAscendaClient>();
            var request = Resource.ExtractManifestResource<AscendaCheckEligibilityRequest>(scenario);
            ExpectedTestResponse = () => testResponse;

            // Act
            Exception actualException = null;
            AscendaCheckEligibilityResponse actualResponse = null;

            try
            {
                actualResponse = await client.PurchaseEraserCheckEligibilityAsync(request, null, temenosCif, CancellationToken.None);
            }
            catch (Exception ex)
            {
                actualException = ex;
            }

            // Assert
            using (new AssertionScope())
            {
                if ( actualException.TryAssertOnException(testResponse) )
                    actualResponse.Should().BeNull();
                else
                {
                    actualResponse.Should().NotBeNull();
                    WriteLine(actualResponse.Serialize());
                }
            }
        }

        /// <summary>
        /// TESTING AUTOFAC REGISTRATION
        /// </summary>
        /// <param name="scenario"></param>
        /// <param name="testResponse"></param>
        /// <returns></returns>
        [Theory]
        [InlineData("Valid", TestResponseEnum.Success)]
        [InlineData("Valid", TestResponseEnum.OtherResponse)]
        [InlineData("Valid", TestResponseEnum.AlreadyOnboarded)]
        [InlineData("Valid", TestResponseEnum.UnexpectedException)]
        [InlineData("Valid", TestResponseEnum.StandardApiException)]
        public async Task AscendaClient_CreateAccountAsync_ExpectedBehaviour(string scenario, TestResponseEnum testResponse)
        {
            // Arrange
            var client = Context.Resolve<IAscendaClient>();
            var request = Resource.ExtractManifestResource<CreateAscendaCustomerRequest>(scenario);
            ExpectedTestResponse = () => testResponse;

            // Act
            Exception actualException = null;
            AscendaResponse<AscendaCustomerResponse> actualResponse = null;
            try
            {
                actualResponse = await client.CreateAccountAsync(request, null, CancellationToken.None);
            }
            catch (Exception ex)
            {
                actualException = ex;
            }

            // Assert
            using (new AssertionScope())
            {
                if (actualException.TryAssertOnException(testResponse))
                    actualResponse.Should().BeNull();
                else
                {
                    actualResponse.Data.PartnerUserId.Should().NotBeNullOrWhiteSpace();
                    WriteLine(actualResponse.Serialize());
                }
            }
        }
    }
}
