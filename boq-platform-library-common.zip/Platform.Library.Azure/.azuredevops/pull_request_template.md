|**Change Type:**|[`New Feature`][`Support`][`Uplift`]|
|-:|:-|
|**Jira Ticket:**|[{Jira Card Title}](https://qdigital.atlassian.net/browse/{Jira_Number})|
|**Confluence:**|[Platform Libraries](https://qdigital.atlassian.net/wiki/spaces/ITSARCH/pages/6137808603)|
|**Repository:**|[Platform.Library.Azure](https://dev.azure.com/qdigitalcode/DenovoBank/_git/Platform.Library.Azure)|

## {Jira} Overview
- {Summarize your changes}

## Additional Information
- {Provide additional information relevant to people reviewing the code}

### Reviewer Notes
- {Add notes for reviewers to pay attention to}

## Checklist
To be completed by the developer raising the PR, and verified by all reviewers:

- [ ] **Is this a BREAKING CHANGE?** - Has the appropriate `semver` tag been added for breaking changes (see [Versioning](https://qdigital.atlassian.net/wiki/spaces/DNMVP/pages/766083225/Versioning))
- [ ] **Unit Tests** - Unit tests have been added for all new functionality
- **Documentation**
  - [ ] **Confluence Updated** - Has the referenced confluence been updated to reflect these changes
  - [ ] **README.md Updated** - Is the repo's README.md up to date 
  
### Commit Messages