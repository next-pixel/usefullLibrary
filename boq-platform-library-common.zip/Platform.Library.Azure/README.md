[![Build Status](https://dev.azure.com/qdigitalcode/DenovoBank/_apis/build/status/Platform.Library.Azure?repoName=Platform.Library.Azure&branchName=master)](https://dev.azure.com/qdigitalcode/DenovoBank/_build/latest?definitionId=1343&repoName=Platform.Library.Azure&branchName=master)
[![Platform.Library.Azure package in Development feed in Azure Artifacts](https://feeds.dev.azure.com/qdigitalcode/_apis/public/Packaging/Feeds/Development/Packages/8b0a8e26-689c-46c6-987b-a73beab597c7/Badge)](https://dev.azure.com/qdigitalcode/DenovoBank/_artifacts/feed/Development/NuGet/Platform.Library.Azure)

# Platform.Library.Azure

## Summary
Provides Base Common functionalities for Service Bus and KeyVault.

Ref -  [Platform Nuget Libraries](https://qdigital.atlassian.net/wiki/spaces/DNMVP/pages/916849358/Platform+Nuget+Packages)

Note: Update Confluence Page with new versions after you release a new version

--- 

# Changelog

### -6/03/2020 

  - New Feature - Updated Common Library to latest version -1.0.25.
---