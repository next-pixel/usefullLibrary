using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace Library.Azure.KeyVault
{
    public class IConfiguationKeyVaultConfiguration : IKeyVaultConfiguration
    {
        private static readonly Regex keyVaultRegex = new Regex(@"^keyvault[\[]{0,1}(?<namedinstance>[a-z,A-Z]+){0,1}[\]]{0,1}_secrets_uri[\d]*\Z", RegexOptions.Compiled | RegexOptions.IgnoreCase);
        private List<KeyVaultUri> _keyVaultSecretsUris;
        private IConfiguration _configuration;

        public IConfiguationKeyVaultConfiguration(IConfiguration configuration)
        {
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        public string KeyVaultClientId
        {
            get
            {
                var setting = _configuration["KeyVault_ClientId"];
                setting.AssertArgumentIsNotNullOrWhiteSpace("KeyVault_ClientId", "Setting KeyVault_ClientId not found in the configuration");
                return setting;
            }
        }

        public string KeyVaultClientSecret
        {
            get
            {
                var setting = _configuration["KeyVault_ClientSecret"];
                setting.AssertArgumentIsNotNullOrWhiteSpace("KeyVault_ClientSecret", "Setting KeyVault_ClientSecret not found in the configuration");
                return setting;
            }
        }

        public List<KeyVaultUri> KeyVaultSecretsUris
        {
            get
            {
                if (_keyVaultSecretsUris == null)
                {
                    _keyVaultSecretsUris = GetKeyVaultUris();
                }

                return _keyVaultSecretsUris;
            }
        }

        public List<KeyVaultUri> GetKeyVaultUris()
        {
            var uris = new List<KeyVaultUri>();

            var allSetting = _configuration.AsEnumerable().ToList();

            foreach (var setting in allSetting)
            {
                var match = keyVaultRegex.Match(setting.Key);

                if (match.Success)
                {
                    uris.Add(new KeyVaultUri
                    {
                        NamedInstance = match.Groups["namedinstance"].Value,
                        Uri = setting.Value
                    });
                }
            }

            return uris;
        }
    }
}