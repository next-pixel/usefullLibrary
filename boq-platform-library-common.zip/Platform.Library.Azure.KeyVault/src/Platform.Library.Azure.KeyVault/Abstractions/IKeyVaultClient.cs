using System.Threading;
using System.Threading.Tasks;

namespace Library.Azure.KeyVault
{
    public interface IKeyVaultClient
    {
        //
        // Summary:
        //     Gets a secret.
        //
        // Parameters:
        //   secretIdentifier:
        //     The URL for the secret.
        //
        //   cancellationToken:
        //     Optional cancellation token
        //
        // Returns:
        //     A response message containing the secret
        Task<string> GetSecretAsync(string secretIdentifier, CancellationToken cancellationToken = default(CancellationToken));


        Task SetSecretAsync(string baseUrl, string secretIdentifier, string value, CancellationToken cancellationToken = default(CancellationToken));

        Task<string> SignAsync(string baseUrl, byte[] digest, string algorithm,
            CancellationToken cancellationToken = default(CancellationToken));
    }
}