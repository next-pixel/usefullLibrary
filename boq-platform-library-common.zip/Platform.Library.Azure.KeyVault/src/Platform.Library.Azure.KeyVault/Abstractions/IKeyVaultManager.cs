using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Library.Azure.KeyVault
{
    public interface IKeyVaultManager
    {
        Task<string> GetKeyVaultSettingAsync(string key, string namedInstance = null);

        Task SetKeyVaultSettingAsync(string key, string value, string namedInstance = null);

        Task<string> KeyVaultJwtSignAsync(string key, List<Claim> claims, string algorithm,
            string namedInstance = null);
    }
}