﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace Platform.Library.Azure.KeyVault
{
    [Obsolete("Copied from Platform.Library.Extensions to break connection as not compatible with net standard 2.1", false)]
    public interface IConfigurationManager
    {
        T GetSetting<T>(string key) where T : IConvertible;

        T GetSetting<T>(string key, T defaultValue) where T : IConvertible;

        T GetConnectionString<T>(string key) where T : IConvertible;

        T GetSetting<T>(string key, IConfiguration configuration) where T : IConvertible;

        T GetSetting<T>(string key, T defaultValue, IConfiguration configuration) where T : IConvertible;
    }
}
