using System.Collections.Generic;

namespace Library.Azure.KeyVault
{
    public interface IKeyVaultConfiguration
    {
        string KeyVaultClientId { get; }
        string KeyVaultClientSecret { get; }
        List<KeyVaultUri> KeyVaultSecretsUris { get; }
    }
}