﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace System
{
    internal static class ArgumentExtensions
    {
        /// <summary>
        /// Raises an <see cref="ArgumentNullException"/> if <paramref name="o"/> is null
        /// </summary>
        /// <param name="o"> Object being checked </param>
        /// <param name="paramName"> Name of argument causing the expcetion. Default is Null </param>
        /// <param name="message"> Exception message. Default is Null </param>
        /// <returns></returns>
        internal static void AssertArgumentIsNotNull(this object o, string paramName = null, string message = null)
        {
            if (o is null)
                throw new ArgumentNullException(message, paramName);
        }
        /// <summary>
        /// Raises an <see cref="ArgumentNullException"/> if <paramref name="o"/> is null or white space
        /// </summary>
        /// <param name="o"> Object being checked </param>
        /// <param name="paramName"> Name of argument. Default is Null </param>
        /// <param name="message"> Exception message. Default is Null </param>
        /// <returns></returns>
        internal static void AssertArgumentIsNotNullOrWhiteSpace(this string o, string paramName = null, string message = null)
        {
            if (string.IsNullOrWhiteSpace(o))
                throw new ArgumentNullException(message, paramName);
        }

        internal static bool AnyNullSafe<T>(this IEnumerable<T> list)
        {
            return list != null ? list.Any() : false;
        }

        internal static IEnumerable<TSource> WhereNullSafe<TSource>(this IEnumerable<TSource> source, Func<TSource, bool> predicate)
        {
            if (source == null)
            {
                return new List<TSource>();
            }

            return source.Where(predicate);
        }

        internal static IEnumerable<TSource> WhereNullSafe<TSource>(this IEnumerable<TSource> source, Func<TSource, int, bool> predicate)
        {
            if (source == null)
            {
                return new List<TSource>();
            }

            return source.Where(predicate);
        }
    }
}
