﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace Platform.Library.Azure.KeyVault
{
    [Obsolete("Copied from Platform.Library.Extensions to break connection as not compatible with net standard 2.1", false)]
    public class SettingsConfigurationManager : IConfigurationManager
    {
        public virtual T GetSetting<T>(string key) where T : IConvertible
        {
            var value = ConfigurationManager.AppSettings[key];

            return Convert<T>(value);
        }

        public virtual T GetSetting<T>(string key, T defaultValue) where T : IConvertible
        {
            var value = ConfigurationManager.AppSettings[key];

            return ConvertOrDefault(value, defaultValue);
        }

        public virtual T GetConnectionString<T>(string key) where T : IConvertible
        {
            var setting = ConfigurationManager.ConnectionStrings[key];

            if (setting != null)
            {
                var value = setting.ConnectionString;

                return Convert<T>(value);
            }

            return default(T);
        }

        public virtual T GetSetting<T>(string key, IConfiguration configuration) where T : IConvertible
        {
            var value = configuration[key];

            return Convert<T>(value);
        }

        public virtual T GetSetting<T>(string key, T defaultValue, IConfiguration configuration) where T : IConvertible
        {
            var value = configuration[key];

            return ConvertOrDefault(value, defaultValue);
        }

        protected T ConvertOrDefault<T>(string value, T defaultValue) where T : IConvertible
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return defaultValue;
            }

            return (T)System.Convert.ChangeType(value, typeof(T));
        }

        protected T Convert<T>(string value) where T : IConvertible
        {
            return (T)System.Convert.ChangeType(value, typeof(T));
        }
    }
}
