﻿namespace Platform.Library.Azure.KeyVault
{
    internal class KeyVaultDetails
    {
        public bool UsesKeyvault { get; set; }
        public string SecretName { get; set; }
        public string NamedInstance { get; set; }
    }
}