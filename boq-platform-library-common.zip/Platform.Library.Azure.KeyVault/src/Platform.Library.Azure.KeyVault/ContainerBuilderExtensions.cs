using System;
using Autofac;
using Microsoft.Extensions.Configuration;

namespace Library.Azure.KeyVault
{
    public static class ContainerBuilderExtensions
    {

        public static void RegisterKeyVaultAsSingleInstance(this ContainerBuilder builder, bool useManagedServiceIdentity, KeyVaultManager keyVaultManager)
        {
            if (keyVaultManager == null) throw new ArgumentNullException(nameof(keyVaultManager));
            keyVaultManager.UseManagedServiceIdentity = useManagedServiceIdentity;
            BuildClient(builder, keyVaultManager);
        }

        public static void RegisterKeyVaultAsSingleInstance(this ContainerBuilder builder, bool useManagedServiceIdentity = false)
        {
            if (useManagedServiceIdentity)
            {
                builder.Register(x =>
                {
                    var config = new KeyVaultConfiguration();
                    var manager = new KeyVaultManager(config.KeyVaultSecretsUris)
                    {
                        UseManagedServiceIdentity = true
                    };
                    BuildClient(builder, manager);
                    return manager;
                }).As<IKeyVaultManager>().SingleInstance();
            }
            else
            {
                builder.Register(x =>
                {
                    var config = new KeyVaultConfiguration();
                    var manager = new KeyVaultManager(config.KeyVaultClientId, config.KeyVaultClientSecret, config.KeyVaultSecretsUris);
                    BuildClient(builder, manager);
                    return manager;
                }).As<IKeyVaultManager>().SingleInstance();
            }
        }

        public static void RegisterKeyVaultAsSingleInstance(this ContainerBuilder builder, IConfiguration configuration, bool useManagedServiceIdentity = false)
        {
            if (useManagedServiceIdentity)
            {
                builder.Register(x =>
                {
                    var config = new IConfiguationKeyVaultConfiguration(configuration);
                    var manager = new KeyVaultManager(config.KeyVaultSecretsUris) 
                    {
                        UseManagedServiceIdentity = true
                    };
                    BuildClient(builder, manager);
                    return manager;
                }).As<IKeyVaultManager>().SingleInstance();
            }
            else
            {
                builder.Register(x =>
                {
                    var config = new IConfiguationKeyVaultConfiguration(configuration);
                    var manager = new KeyVaultManager(config.KeyVaultClientId, config.KeyVaultClientSecret, config.KeyVaultSecretsUris);
                    BuildClient(builder, manager);
                    return manager;
                }).As<IKeyVaultManager>().SingleInstance();
            }
        }

        private static void BuildClient(ContainerBuilder builder, KeyVaultManager manager)
        {
            var azureClient = new Microsoft.Azure.KeyVault.KeyVaultClient(manager.GetAuthenticationManager());
            var client = new KeyVaultClient(azureClient);
            manager.Client = client;
        }
    }
}