using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text.RegularExpressions;

namespace Library.Azure.KeyVault
{
    public class KeyVaultConfiguration : IKeyVaultConfiguration
    {
        private static readonly Regex keyVaultRegex = new Regex(@"^keyvault[\[]{0,1}(?<namedinstance>[a-z,A-Z]+){0,1}[\]]{0,1}_secrets_uri[\d]*\Z", RegexOptions.Compiled | RegexOptions.IgnoreCase);
        private List<KeyVaultUri> _keyVaultSecretsUris;

        public string KeyVaultClientId
        {
            get
            {
                var setting = ConfigurationManager.AppSettings["KeyVault_ClientId"];
                setting.AssertArgumentIsNotNullOrWhiteSpace("KeyVault_ClientId", "Setting KeyVault_ClientId not found in the configuration");
                return setting;
            }
        }

        public string KeyVaultClientSecret
        {
            get
            {
                var setting = ConfigurationManager.AppSettings["KeyVault_ClientSecret"];
                setting.AssertArgumentIsNotNullOrWhiteSpace("KeyVault_ClientSecret", "Setting KeyVault_ClientSecret not found in the configuration");
                return setting;
            }
        }

        public List<KeyVaultUri> KeyVaultSecretsUris
        {
            get
            {
                if (_keyVaultSecretsUris == null)
                {
                    _keyVaultSecretsUris = GetKeyVaultUris();
                }

                return _keyVaultSecretsUris;
            }
        }

        public List<KeyVaultUri> GetKeyVaultUris()
        {
            var uris = new List<KeyVaultUri>();

            var allSettingKeys = ConfigurationManager.AppSettings.AllKeys;

            foreach (var settingKey in allSettingKeys)
            {
                var match = keyVaultRegex.Match(settingKey);

                if (match.Success)
                {
                    uris.Add(new KeyVaultUri
                    {
                        NamedInstance = match.Groups["namedinstance"].Value,
                        Uri = ConfigurationManager.AppSettings[settingKey]
                    });
                }
            }

            return uris;
        }
    }
}