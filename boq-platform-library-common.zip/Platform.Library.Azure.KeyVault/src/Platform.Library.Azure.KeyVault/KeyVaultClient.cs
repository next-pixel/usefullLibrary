using Microsoft.Azure.KeyVault;
using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Tokens;

namespace Library.Azure.KeyVault
{
    public class KeyVaultClient : IKeyVaultClient
    {
        public Microsoft.Azure.KeyVault.IKeyVaultClient Client { get; }

        public KeyVaultClient(Microsoft.Azure.KeyVault.KeyVaultClient client)
        {
            Client = client;
        }

        public async Task<string> GetSecretAsync(string keyUri, CancellationToken cancellationToken = default(CancellationToken))
        {
            var secret = await Client.GetSecretAsync(keyUri, cancellationToken);

            if (secret is null)
            {
                throw new ArgumentException($"The secret {keyUri} does not exist in Azure Key Vault");
            }

            return secret.Value;
        }

        public async Task SetSecretAsync(string baseUrl, string secretIdentifier, string value, CancellationToken cancellationToken = default(CancellationToken))
        {
            await Client.SetSecretAsync(baseUrl, secretIdentifier, value, cancellationToken: cancellationToken);
        }

        public async Task<string> SignAsync(string baseUrl, byte[] digest, string algorithm,
            CancellationToken cancellationToken = default(CancellationToken))
        {

            var signature =
                await Client.SignAsync(baseUrl,
                    algorithm, digest, cancellationToken: cancellationToken);
            return Base64UrlEncoder.Encode(signature.Result);
        }
    }
}