namespace Library.Azure.KeyVault
{
    public class KeyVaultUri
    {
        public string Uri { get; set; }
        public string NamedInstance { get; set; }
    }
}