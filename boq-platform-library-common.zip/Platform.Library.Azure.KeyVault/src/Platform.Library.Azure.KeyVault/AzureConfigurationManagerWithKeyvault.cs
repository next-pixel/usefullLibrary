﻿using Library.Azure.KeyVault;
using Microsoft.Extensions.Configuration;
using System;
using System.Configuration;
using System.Text.RegularExpressions;

namespace Platform.Library.Azure.KeyVault
{
    public class AzureConfigurationManagerWithKeyvault : SettingsConfigurationManager
    {
        private static readonly Regex keyVaultRegex = new Regex(@"^keyvault[\[]{0,1}(?<namedinstance>[a-z,A-Z]+){0,1}[\]]{0,1}:(?<secret>.+)\Z", RegexOptions.Compiled | RegexOptions.IgnoreCase);
        private IKeyVaultManager KeyVaultManager { get; set; }

        public AzureConfigurationManagerWithKeyvault(IKeyVaultManager keyVaultManager)
        {
            keyVaultManager.AssertArgumentIsNotNull(nameof(keyVaultManager));

            KeyVaultManager = keyVaultManager;
        }

        public override T GetSetting<T>(string key)
        {
            var value = ConfigurationManager.AppSettings[key];
            var keyVaultDetails = GetKeyVaultDetails(value);

            if (keyVaultDetails.UsesKeyvault)
            {
                value = AsyncHelper.RunSync(() => KeyVaultManager.GetKeyVaultSettingAsync(keyVaultDetails.SecretName, keyVaultDetails.NamedInstance));
            }

            return Convert<T>(value);
        }

        public override T GetSetting<T>(string key, T defaultValue)
        {
            var value = ConfigurationManager.AppSettings[key];
            var keyVaultDetails = GetKeyVaultDetails(value);

            if (keyVaultDetails.UsesKeyvault)
            {
                value = AsyncHelper.RunSync(() => KeyVaultManager.GetKeyVaultSettingAsync(keyVaultDetails.SecretName, keyVaultDetails.NamedInstance));
            }

            return ConvertOrDefault(value, defaultValue);
        }

        public override T GetConnectionString<T>(string key)
        {
            var value = base.GetConnectionString<string>(key);
            var keyVaultDetails = GetKeyVaultDetails(value);

            if (keyVaultDetails.UsesKeyvault)
            {
                value = AsyncHelper.RunSync(() => KeyVaultManager.GetKeyVaultSettingAsync(keyVaultDetails.SecretName, keyVaultDetails.NamedInstance));
            }

            return Convert<T>(value);
        }

        public override T GetSetting<T>(string key, IConfiguration configuration)
        {
            var value = configuration[key];

            var keyVaultDetails = GetKeyVaultDetails(value);

            if (keyVaultDetails.UsesKeyvault)
            {
                value = AsyncHelper.RunSync(() => KeyVaultManager.GetKeyVaultSettingAsync(keyVaultDetails.SecretName, keyVaultDetails.NamedInstance));
            }

            return Convert<T>(value);
        }

        public override T GetSetting<T>(string key, T defaultValue, IConfiguration configuration)
        {
            var value = configuration[key];

            var keyVaultDetails = GetKeyVaultDetails(value);

            if (keyVaultDetails.UsesKeyvault)
            {
                value = AsyncHelper.RunSync(() => KeyVaultManager.GetKeyVaultSettingAsync(keyVaultDetails.SecretName, keyVaultDetails.NamedInstance));
            }

            return ConvertOrDefault(value, defaultValue);
        }

        private KeyVaultDetails GetKeyVaultDetails(string s)
        {
            var x = new KeyVaultDetails
            {
                UsesKeyvault = false
            };

            if (!string.IsNullOrWhiteSpace(s))
            {
                var match = keyVaultRegex.Match(s);

                x.UsesKeyvault = match.Success;

                if (x.UsesKeyvault)
                {
                    x.SecretName = match.Groups["secret"].Value;
                    x.NamedInstance = match.Groups["namedinstance"].Value;
                }
            }

            return x;
        }
    }
}