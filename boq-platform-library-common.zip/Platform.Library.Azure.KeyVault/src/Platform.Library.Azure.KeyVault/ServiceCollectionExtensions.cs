﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace Library.Azure.KeyVault
{
    public static class ServiceCollectionExtensions
    {
        public static void RegisterKeyVaultAsSingleton(this IServiceCollection services, bool useManagedServiceIdentity, KeyVaultManager keyVaultManager)
        {
            if (keyVaultManager == null) throw new ArgumentNullException(nameof(keyVaultManager));
            keyVaultManager.UseManagedServiceIdentity = useManagedServiceIdentity;
            BuildClient(keyVaultManager);
        }

        public static void RegisterKeyVaultAsSingleton(this IServiceCollection services, bool useManagedServiceIdentity = false)
        {
            if (useManagedServiceIdentity)
            {
                services.AddSingleton<IKeyVaultManager, KeyVaultManager>(provider =>
                {
                    var config = new KeyVaultConfiguration();
                    var manager = new KeyVaultManager(config.KeyVaultSecretsUris)
                    {
                        UseManagedServiceIdentity = true
                    };
                    BuildClient(manager);
                    return manager;
                });
            }
            else
            {
                services.AddSingleton<IKeyVaultManager, KeyVaultManager>(provider =>
                {
                    var config = new KeyVaultConfiguration();
                    var manager = new KeyVaultManager(
                        config.KeyVaultClientId,
                        config.KeyVaultClientSecret,
                        config.KeyVaultSecretsUris
                    );
                    BuildClient(manager);
                    return manager;
                });
            }
        }

        public static void RegisterKeyVaultAsSingleton(this IServiceCollection services, IConfiguration configuration, bool useManagedServiceIdentity = false)
        {
            if (useManagedServiceIdentity)
            {
                services.AddSingleton<IKeyVaultManager, KeyVaultManager>(provider =>
                {
                    var config = new IConfiguationKeyVaultConfiguration(configuration);
                    var manager = new KeyVaultManager(config.KeyVaultSecretsUris)
                    {
                        UseManagedServiceIdentity = true
                    };
                    BuildClient(manager);
                    return manager;
                });
            }
            else
            {
                services.AddSingleton<IKeyVaultManager, KeyVaultManager>(provider =>
                {
                    var config = new IConfiguationKeyVaultConfiguration(configuration);
                    var manager = new KeyVaultManager(config.KeyVaultClientId, config.KeyVaultClientSecret, config.KeyVaultSecretsUris);
                    BuildClient(manager);
                    return manager;
                });
            }
        }

        private static void BuildClient(KeyVaultManager manager)
        {
            var azureClient = new Microsoft.Azure.KeyVault.KeyVaultClient(manager.GetAuthenticationManager());
            var client = new KeyVaultClient(azureClient);
            manager.Client = client;
        }
    }
}