using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using static Microsoft.Azure.KeyVault.KeyVaultClient;

namespace Library.Azure.KeyVault
{
    public class KeyVaultManager : IKeyVaultManager
    {
        private static MemoryCache _memoryCache = new MemoryCache(new MemoryCacheOptions());
        public IKeyVaultClient Client { get; set; }
        private string KeyVaultClientId { get; }
        private string KeyVaultClientSecret { get; }
        private List<KeyVaultUri> KeyVaultSecretsUris { get; }
        public bool UseManagedServiceIdentity { get; set; }

        public KeyVaultManager(string keyVaultClientId, string keyVaultClientSecret, List<KeyVaultUri> keyVaultSecretsUris) :
            this(keyVaultSecretsUris)
        {
            keyVaultClientId.AssertArgumentIsNotNullOrWhiteSpace(nameof(keyVaultClientId));
            keyVaultClientSecret.AssertArgumentIsNotNullOrWhiteSpace(nameof(keyVaultClientSecret));

            KeyVaultClientId = keyVaultClientId;
            KeyVaultClientSecret = keyVaultClientSecret;
        }

        public KeyVaultManager(List<KeyVaultUri> keyVaultSecretsUris)
        {
            keyVaultSecretsUris.AssertArgumentIsNotNull(nameof(keyVaultSecretsUris));
            KeyVaultSecretsUris = keyVaultSecretsUris;
        }

        private string GetFromCache(string key)
        {
            if (_memoryCache.TryGetValue(key, out _))
            {
                return _memoryCache.Get(key) as string;
            }

            return null;
        }

        internal AuthenticationCallback GetAuthenticationManager()
        {
            if (UseManagedServiceIdentity)
            {
                var azureServiceTokenProvider = new AzureServiceTokenProvider();

                return (new AuthenticationCallback(azureServiceTokenProvider.KeyVaultTokenCallback));
            }
            else
            {
                return new AuthenticationCallback(GetToken);
            }
        }

        private void AddToCache(string key, string value, DateTimeOffset? absoluteExpiry = null)
        {
            if (absoluteExpiry == null)
            {
                absoluteExpiry = DateTimeOffset.Now.AddMinutes(30);
            }

            var policy = new MemoryCacheEntryOptions
            {
                Priority = CacheItemPriority.Normal,
                AbsoluteExpiration = absoluteExpiry.Value
            };

            _memoryCache.Set(key, value, policy);
        }

        public async Task<string> GetToken(string authority, string resource, string scope)
        {
            var accessToken = GetFromCache("KeyVault.AutenticationToken");

            if (string.IsNullOrWhiteSpace(accessToken))
            {
                try
                {
                    var authContext = new AuthenticationContext(authority);

                    var clientCred = new ClientCredential(KeyVaultClientId, KeyVaultClientSecret);

                    var result = await authContext.AcquireTokenAsync(resource, clientCred);

                    if (result == null)
                    {
                        throw new InvalidOperationException("Failed to obtain the JWT token");
                    }

                    accessToken = result.AccessToken;

                    AddToCache("KeyVault.AutenticationToken", accessToken, result.ExpiresOn.AddSeconds(-120));
                }
                catch (Exception)
                {
                    throw;
                }
            }

            return accessToken;
        }

        public async Task<string> GetKeyVaultSettingAsync(string key, string namedInstance = null)
        {
            key.AssertArgumentIsNotNullOrWhiteSpace("Key");

            var cacheKey = $"{namedInstance}{(!string.IsNullOrWhiteSpace(namedInstance) ? "-" : "")}{key}";
            var value = GetFromCache(cacheKey);

            if (string.IsNullOrWhiteSpace(value))
            {
                var exceptions = new List<Exception>();

                var baseUris = KeyVaultSecretsUris.WhereNullSafe(x => x.NamedInstance.Equals(namedInstance, StringComparison.OrdinalIgnoreCase));

                foreach (var baseUri in baseUris)
                {
                    var keyUri = !baseUri.Uri.EndsWith("/") ? $"{baseUri.Uri}/{key}" : $"{baseUri.Uri}{key}";

                    try
                    {
                        try
                        {
                            value = await Client.GetSecretAsync(keyUri);

                            AddToCache(cacheKey, value);

                            return value;
                        }
                        catch (Exception)
                        {
                            throw;
                        }
                    }
                    catch (Exception ex)
                    {
                        exceptions.Add(new InvalidOperationException($"An unknown error occurred getting the Secret '{keyUri}' from Azure Key Vault", ex));
                    }
                }

                if (string.IsNullOrWhiteSpace(value) && exceptions.AnyNullSafe())
                {
                    throw new AggregateException(exceptions);
                }
            }

            return value;
        }

        public async Task SetKeyVaultSettingAsync(string key, string value, string namedInstance = null)
        {
            key.AssertArgumentIsNotNullOrWhiteSpace(nameof(key));
            value.AssertArgumentIsNotNullOrWhiteSpace(nameof(value));

            var exceptions = new List<Exception>();

            var baseUris = KeyVaultSecretsUris.WhereNullSafe(x => x.NamedInstance.Equals(namedInstance, StringComparison.OrdinalIgnoreCase)); ;

            foreach (var baseUri in baseUris)
            {
                var keyUri = baseUri.Uri.Replace("secrets/", "");

                try
                {
                    try
                    {
                        await Client.SetSecretAsync(keyUri, key, value);

                        AddToCache(key, value);
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
                catch (Exception ex)
                {
                    exceptions.Add(new InvalidOperationException($"An unknown error occurred getting the Secret '{keyUri}' from Azure Key Vault", ex));
                }
            }

            if (exceptions.AnyNullSafe())
            {
                throw new AggregateException(exceptions);
            }
        }


        public async Task<string> KeyVaultJwtSignAsync(string key, List<Claim> claims, string algorithm, string namedInstance = null)
        {
            key.AssertArgumentIsNotNullOrWhiteSpace("Key");

            var cacheKey = $"{namedInstance}{(!string.IsNullOrWhiteSpace(namedInstance) ? "-" : "")}{key}";

            var value = GetFromCache(cacheKey);

            if (string.IsNullOrWhiteSpace(value))
            {
                var exceptions = new List<Exception>();

                var baseUris = KeyVaultSecretsUris.WhereNullSafe(x => x.NamedInstance.Equals(namedInstance, StringComparison.OrdinalIgnoreCase));

                foreach (var baseUri in baseUris)
                {
                    var keyUri = !baseUri.Uri.EndsWith("/") ? $"{baseUri.Uri}/{key}" : $"{baseUri.Uri}{key}";

                    try
                    {
                        var token = new JwtSecurityToken(
                            new JwtHeader(),
                            new JwtPayload(
                                claims
                            ));

                        var header = Base64UrlEncoder.Encode(JsonConvert.SerializeObject(new Dictionary<string, string>
                        {
                            {JwtHeaderParameterNames.Alg, algorithm}
                        }));


                        var byteData = Encoding.UTF8.GetBytes(header + "." + token.EncodedPayload);
                        var hasher = new SHA256CryptoServiceProvider();
                        var digest = hasher.ComputeHash(byteData);
                        value = $"{header}.{token.EncodedPayload}.{await Client.SignAsync(keyUri, digest, algorithm)}";
                        AddToCache(cacheKey, value);
                        return value;
                    }
                    catch (Exception ex)
                    {
                        exceptions.Add(new InvalidOperationException($"An unknown error occurred while signing the JWT '{keyUri}' from Azure Key Vault", ex));
                    }
                }

                if (string.IsNullOrWhiteSpace(value) && exceptions.AnyNullSafe())
                {
                    throw new AggregateException(exceptions);
                }
            }

            return value;
        }
    }
}