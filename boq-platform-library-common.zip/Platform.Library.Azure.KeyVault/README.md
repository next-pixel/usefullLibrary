[![Build Status](https://dev.azure.com/qdigitalcode/DenovoBank/_apis/build/status/Platform.Library.Azure.KeyVault?repoName=Platform.Library.Azure.KeyVault&branchName=master)](https://dev.azure.com/qdigitalcode/DenovoBank/_build/latest?definitionId=1343&repoName=Platform.Library.Azure.KeyVault&branchName=master)
[![Platform.Library.Azure.KeyVault package in Development feed in Azure Artifacts](https://feeds.dev.azure.com/qdigitalcode/_apis/public/Packaging/Feeds/Development/Packages/8b0a8e26-689c-46c6-987b-a73beab597c7/Badge)](https://dev.azure.com/qdigitalcode/DenovoBank/_artifacts/feed/Development/NuGet/Platform.Library.Azure.KeyVault)

# Platform.Library.Azure.KeyVault
Platform library for performing key vault access and manipulation

## Out of Date
This library is out of date and may not be supported by .net 6 directly and will require re-writing

- [Replacement for Jwt Token dependnency](https://www.nuget.org/packages/Microsoft.AspNetCore.Authentication.JwtBearer/6.0.5)
