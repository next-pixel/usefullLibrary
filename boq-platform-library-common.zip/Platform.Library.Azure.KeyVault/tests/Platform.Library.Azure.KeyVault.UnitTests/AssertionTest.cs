using System;
using Xunit;

namespace Platform.Library.Azure.KeyVault.UnitTests
{
    public class AssertionTest
    {
        [Fact]
        public void Test1()
        {
            // TODO: Simple assertion to flex the unit test library
            Assert.True(true);
        }
    }
}
