# History

Olaf Loogman@Deloitte built these pipelines in 2020.

Stiven Skoklevski@DxC added HLT and PFT env in 2021.

The pipelines are using json ARM templates and there is no what-if jobs.
Some of the resources in these pipelines were decommissioned.
There are resources that are still in use.
These pipelines can not be re-used because it will re-create resources that had been decommissioned.
Without a what-if job, it is difficult to identity the risk of these pipelines.

As part of HLX 2.0 in 2024, Huu Huynh@BOQ needs to add storage account file private endpoint.
New pipeline (platform/mft/azure-pipelines.yml) was created to deploy the private endpoint for storage account file.
It is setup to allow for environment selection.
What-if and Deploy are its own stage to allow what-if to run without Environment approval.

Deleted az-cli-pipeline.yml as it is only used to deploy PE and that is moved into platform/mft/azure-pipelines.yml
Deleted cmd-azure-pipelines.yml as it is only doing curl tests.
Deleted ps-azure-pipelines.yml as it is only add private-endpoint dns-zone-group for sit. It can be moved into platform/mft/azure-pipelines.yml
Deleted test/Get-StorageAccount-Container-Roles.ps1 as it is only used for HLT. HLT is no longer in use.
