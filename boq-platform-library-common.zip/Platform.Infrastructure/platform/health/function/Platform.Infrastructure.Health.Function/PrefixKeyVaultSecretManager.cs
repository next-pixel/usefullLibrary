﻿using Microsoft.Azure.KeyVault.Models;
using Microsoft.Extensions.Configuration.AzureKeyVault;
using System;
using System.Collections.Generic;
using System.Text;

namespace Platform.Infrastructure.Health.Function
{
    public class PrefixKeyVaultSecretManager : IKeyVaultSecretManager
    {
        private readonly string _prefix;

        public PrefixKeyVaultSecretManager(string prefix)
        {
            _prefix = $"{prefix}";
        }

        public bool Load(SecretItem secret)
        {
            return secret.Identifier.Name.StartsWith(_prefix) || secret.Identifier.Name.StartsWith(_prefix.Replace(":", "--"));
        }

        public string GetKey(SecretBundle secret)
        {
            return secret.SecretIdentifier.Name;
        }
    }
}
