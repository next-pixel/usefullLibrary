using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using System.Web.Http;
using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.Azure.KeyVault;
using Microsoft.Extensions.Configuration.AzureKeyVault;
using System.Security.Cryptography.X509Certificates;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;

namespace Platform.Infrastructure.Health.Function
{
    public static class NetworkStatus
    {
        private static IConfiguration Configuration { set; get; }
        //private static string _prefix = "Status:Network";

        static NetworkStatus()
        {

        }

        [FunctionName("NetworkStatus")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "health/status/network/{party}")] HttpRequest req,
            ILogger log, string party)
        {
            log.LogInformation($"C# HTTP trigger function processed a request. Party param: {party}");

            var protocol = Environment.GetEnvironmentVariable($"Status:Network:{party}:Protocol");
            var host = Environment.GetEnvironmentVariable($"Status:Network:{party}:Host");
            var port = Environment.GetEnvironmentVariable($"Status:Network:{party}:Port");
            var url = Environment.GetEnvironmentVariable($"Status:Network:{party}:Url");
            var clientCert = Environment.GetEnvironmentVariable($"Status:Network:{party}:ClientCert");
            var httpAccept = Environment.GetEnvironmentVariable($"Status:Network:{party}:HttpAccept");

            if (
                    (!string.IsNullOrWhiteSpace(host) && !string.IsNullOrWhiteSpace(port)) || 
                    (!string.IsNullOrWhiteSpace(url)))
            {
                if (string.IsNullOrWhiteSpace(protocol))
                {
                    protocol = "http";
                }

                if (protocol.StartsWith("http"))
                {
                    if (string.IsNullOrEmpty(url))
                    {
                        url = $"{protocol}://{host}:{port}";
                    }

                    log.LogInformation($"Executing HTTP GET to {url}");

                    var result = await HttpGet(url, log, clientCert, httpAccept);

                    if (result)
                    {
                        return new JsonResult(new { networkStatus = "OK" });
                    }
                    else
                    {
                        return new InternalServerErrorResult();
                    }
                }
                return new BadRequestObjectResult("Protocol not supported"); 

            }
            else
            {
                return new NotFoundObjectResult($"Configuration for {party} not found");
            }
        }

        public static async Task<bool> HttpGet(string url, ILogger log, string kvCert, string httpAccept)
        {
            HttpClientHandler handler = new HttpClientHandler();
            handler.ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator;
            //handler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };


            if (!string.IsNullOrEmpty(kvCert))
            {
                var azureServiceTokenProvider = new AzureServiceTokenProvider();
                var kv = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(azureServiceTokenProvider.KeyVaultTokenCallback));
                var certificatePrivateKeySecretBundle = await kv.GetSecretAsync(Environment.GetEnvironmentVariable("kvConnectionString"), kvCert);

                byte[] privateKeyBytes = Convert.FromBase64String(certificatePrivateKeySecretBundle.Value);
                X509Certificate2 certificateWithPrivateKey = new X509Certificate2(privateKeyBytes, (string)null, X509KeyStorageFlags.MachineKeySet);

                
                handler.ClientCertificates.Add(certificateWithPrivateKey);
            }

            HttpClient client = new HttpClient(handler);

            try
            {
                log.LogInformation($"Calling {url}");
                var response = await client.GetAsync(url);

                log.LogInformation($"{url} called with response status {response.StatusCode}");

                if (string.IsNullOrWhiteSpace(httpAccept))
                {
                    response.EnsureSuccessStatusCode();
                }
                else
                {
                    // check whether the response HTTP status falls in the accepted range with a regular expression check
                    var status = Enum.Format(typeof(HttpStatusCode), response.StatusCode, "D");

                    return Regex.Match(status, httpAccept).Success;
                }
            }
            catch (Exception ex)
            {
                log.LogError($"Error during calling {url}");
                log.LogError(ex.Message);
                return false;
            }
            return true;
        }

    }
}
