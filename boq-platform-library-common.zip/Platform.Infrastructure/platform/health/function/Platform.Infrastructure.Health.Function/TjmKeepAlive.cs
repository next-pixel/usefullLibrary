﻿using Microsoft.Azure.KeyVault;
using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureKeyVault;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Platform.Infrastructure.Health.Function
{
    public static class TjmKeepAlive
    {
        private static IConfiguration Configuration { set; get; }
        private static string _prefix = "KeepAlive:TJM";

        static TjmKeepAlive()
        {
            var builder = new ConfigurationBuilder();

            var azureServiceTokenProvider = new AzureServiceTokenProvider();
            var keyVaultClient = new KeyVaultClient(
                new KeyVaultClient.AuthenticationCallback(
                    azureServiceTokenProvider.KeyVaultTokenCallback));

            builder.AddAzureKeyVault(
                Environment.GetEnvironmentVariable("kvConnectionString"),
                keyVaultClient,
                new PrefixKeyVaultSecretManager(_prefix));

            Configuration = builder.Build();
        }

        [FunctionName("TjmKeepAlive")]
        public static void Run([TimerTrigger("*/5 * * * * *")]TimerInfo myTimer, ILogger log)
        {
            log.LogInformation($"TjmKeepAlive function executed at: {DateTime.Now}");

            var times = new List<double>();
            var host = Configuration.GetValue<string>("KeepAlive:TJM:Host", Configuration.GetValue<string>("KeepAlive:TJM:Host", string.Empty));
            var port = Configuration.GetValue<string>("KeepAlive:TJM:Port", Configuration.GetValue<string>("KeepAlive:TJM:Port", string.Empty));

            if (!string.IsNullOrWhiteSpace(host) && !string.IsNullOrWhiteSpace(port))
            {
                var portNo = Int32.Parse(port);

                IPAddress ipAddress = IPAddress.Parse(host);
                IPEndPoint endPoint = new IPEndPoint(ipAddress, portNo);

                for (int i = 0; i < 3; i++)
                {
                    using (var sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp))
                    {
                        sock.Blocking = true;

                        var stopwatch = new Stopwatch();

                        // Measure the Connect call only
                        stopwatch.Start();

                        log.LogInformation($"Calling host {host} on port {portNo}");

                        sock.Connect(endPoint);
                        stopwatch.Stop();

                        double t = stopwatch.Elapsed.TotalMilliseconds;
                        Console.WriteLine("{0:0.00}ms", t);
                        times.Add(t);

                        sock.Close();
                    }
                    Thread.Sleep(1000);
                }

                log.LogInformation("{0:0.00} {1:0.00} {2:0.00}", times.Min(), times.Max(), times.Average());
            }
            else
            {
                log.LogWarning("Configuration data not found");
            }
        }
    }
}
