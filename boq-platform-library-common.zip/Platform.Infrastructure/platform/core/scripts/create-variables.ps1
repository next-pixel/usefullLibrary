param (
    [string]
    $variableSuffix
)

$mapToSet=@{ $variableSuffix = ConvertFrom-Json $($env:DeploymentOutputs); }

$mapToSet.GetEnumerator() | ForEach-Object { 
    foreach ($output in $_.Value.PSObject.Properties) {
        $var = "$($_.Key)" + $($output.Name)
        Write-Host "##vso[task.setvariable variable=$($var)]$($output.Value.value)"
    }
}