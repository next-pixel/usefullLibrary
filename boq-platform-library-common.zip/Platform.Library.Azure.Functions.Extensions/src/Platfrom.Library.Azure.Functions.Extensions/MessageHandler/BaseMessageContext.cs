﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Platform.Library.Azure.Functions.Extensions
{
    /// <summary>
    /// Abstract message context class
    /// </summary>
    public abstract class BaseMessageContext
    {
        private readonly object _defaultResult;

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseMessageContext"/> class.
        /// </summary>
        /// <param name="defaultResult"></param>
        protected BaseMessageContext(object defaultResult)
        {
            _defaultResult = defaultResult;
            Result = defaultResult;
        }

        /// <summary>
        /// Result of the current processing
        /// </summary>
        public object Result { get; set; }

        /// <summary>
        /// Error message if an error has occurred
        /// </summary>
        public string ErrorMessage { get; private set; } = "Business error occured. Message will be dead lettered";

        /// <summary>
        /// Error reason if an error has occurred
        /// </summary>
        public string ErrorReason { get; private set; } = string.Empty;

        /// <summary>
        /// Ensure that the result is successful
        /// </summary>
        public void EnsureSuccess()
        {
            if (Result == _defaultResult)
                Result = SuccessStatus;
        }

        /// <summary>
        /// Status to set when successful
        /// </summary>
        protected abstract object SuccessStatus { get; }

        /// <summary>
        /// Status to set when poisoned
        /// </summary>
        protected abstract object PoisonedStatus { get; }

        /// <summary>
        /// Status to set when requiring retry
        /// </summary>
        protected abstract object RequiresRetryStatus { get; }

        /// <summary>
        /// Set the result as poisoned
        /// </summary>
        /// <typeparam name="TEx"></typeparam>
        /// <param name="ex"></param>
        public void Poisoned<TEx>(TEx ex)
            where TEx : UnrecoverableMessageException
        {
            Result = PoisonedStatus;
            ErrorMessage = ex.ErrorMessage;
            ErrorReason = ex.ErrorReason;
        }

        /// <summary>
        /// Set the result as requiring a retry
        /// </summary>
        /// <param name="ex"></param>
        /// <exception cref="ArgumentException"></exception>
        public void RequiresRetry(Exception ex)
        {
            if ( ex is UnrecoverableMessageException )
                throw new ArgumentException(nameof(ex), $"Cannot retry when exception is a type of {nameof(UnrecoverableMessageException)}");

            Result = RequiresRetryStatus;
            ErrorMessage = $"{ex.GetType().Name} has occurred";
            ErrorReason = ex.Message;
        }

        /// <summary>
        /// Indicates if the result is poisoned
        /// </summary>
        public bool IsPoisoned => Result.Equals(PoisonedStatus);

        /// <summary>
        /// Indicates if the result is successful
        /// </summary>
        public bool IsSuccessful => Result.Equals(SuccessStatus);

        /// <summary>
        /// Indicates if a retry is required
        /// </summary>
        public bool IsRetryRequired => Result.Equals(RequiresRetryStatus);
    }
}
