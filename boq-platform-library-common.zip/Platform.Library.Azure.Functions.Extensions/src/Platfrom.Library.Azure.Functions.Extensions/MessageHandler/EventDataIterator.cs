﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Platform.Library.Azure.Functions.Extensions
{
    internal class EventDataIterator<TItem>
    {
        private readonly List<DataItemStatus> _failures = new List<DataItemStatus>();
        
        internal void AddItemStatus(DataItemStatus itemState)
        {
            if (itemState.State != DataItemState.Success)
                _failures.Add(itemState);
        }

        internal IEnumerable<DataItemStatus> AllFailures => _failures;
        internal bool HasFailed => _failures.Count > 0;
        internal int RecoverableFailureCount => _failures.Count(f => f.State == DataItemState.Recoverable);

        internal void UpdateMessageContext(ProcessMessageContext context, int totalItems)
        {
            if (HasFailed)
            {
                if (totalItems == RecoverableFailureCount)
                    context.RequiresRetry(RecoverableFailureException);
                else
                    context.Poisoned(UnrecoverableFailureException);
            }
            else
                context.Result = ProcessMessageResult.SuccessfullyProcessedMessage;
        }

        private UnrecoverableFailuresMessageException UnrecoverableFailureException =>
            new UnrecoverableFailuresMessageException(AllFailures);

        private AggregateException RecoverableFailureException =>
            new AggregateException(
                $"All {TypeExtensions.ReadableTypeName<TItem>()}s ({_failures.Count}) failed prior to any non-repeatable change",
                _failures
                    .Where(f => f.IsRecoverable)
                    .Select(f => new RecoverableEventDataItemException(f)));
    }
}
