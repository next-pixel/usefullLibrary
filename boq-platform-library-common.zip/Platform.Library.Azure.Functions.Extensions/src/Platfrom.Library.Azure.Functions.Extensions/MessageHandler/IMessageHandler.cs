using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Platform.Library.Azure.Functions.Extensions
{
    /// <summary>
    /// Standard message handler interface
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IMessageHandler<T> where T : class
    {
        /// <summary>
        /// Process message
        /// </summary>
        /// <param name="message"></param>
        /// <param name="messageReciever"></param>
        /// <param name="logger"></param>
        /// <param name="token"></param>
        /// <param name="refresher"></param>
        /// <returns></returns>
        Task ProcessMessageAsync(
            Message message,
            IMessageReceiver messageReciever,
            ILogger logger,
            CancellationToken token,
            IConfigurationRefresher refresher = null);
    }
}