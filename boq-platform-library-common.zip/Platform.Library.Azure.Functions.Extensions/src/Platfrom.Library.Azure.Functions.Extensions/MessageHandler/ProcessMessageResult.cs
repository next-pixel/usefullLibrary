namespace Platform.Library.Azure.Functions.Extensions
{
    /// <summary>
    /// Result status for processing with the <see cref="MessageHandler{T}"/>
    /// </summary>
    public enum ProcessMessageResult
    {
        /// <summary>Not set</summary>
        NoStatusSet,

        /// <summary>Successful</summary>
        SuccessfullyProcessedMessage,

        /// <summary>Poisoned</summary>
        PoisonMessageIdentified,

        /// <summary>Requires Retry</summary>
        RequiresRetry, // Do Nothing and Wait till the peek lock expires so that message will retry

        /// <summary>Requires retry (with abondoned delay)</summary>
        RequiresAbandonDelayRetry
    }
}
