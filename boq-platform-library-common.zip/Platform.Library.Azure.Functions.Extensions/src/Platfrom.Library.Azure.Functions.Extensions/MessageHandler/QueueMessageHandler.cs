﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using Platform.Library.Azure.Functions.Extensions.MessageHandler;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace Platform.Library.Azure.Functions.Extensions
{
    /// <inheritdoc cref="IMessageHandler{T}"/>
    public abstract class QueueMessageHandler<T> : BaseMessageHandler<T, ProcessRetrialMessageContext, ProcessRetrialMessageResult>
        where T : class
    {
        private readonly QueueMessageRetryPolicySettings _config;

        /// <summary>
        /// Initializes a new instance of the <see cref="QueueMessageHandler{T}"/> class.
        /// </summary>
        /// <param name="config"></param>
        protected QueueMessageHandler(QueueMessageRetryPolicySettings config)
        {
            _config = config;
        }

        /// <inheritdoc cref="BaseMessageHandler{TPayload, TContext, TEnum}.HandleCustomResultAsync(IMessageReceiver, TContext, ILogger, Message, CancellationToken)"/>
        [ExcludeFromCodeCoverage]
        protected override async Task HandleCustomResultAsync(IMessageReceiver messageReceiver, ProcessRetrialMessageContext context, ILogger logger, Message message, CancellationToken token)
        {
            if (context.Result == ProcessRetrialMessageResult.RequiresRetryWithClone)
            {
                // Clone and Enqueue, the message once pass the safe time msg will dql.

                logger.LogWarning(
                    "Will reenque Message with MessageId {MessageId}. Failure Message: {ErrorMessage} .Reason: {ErrorReason}",
                    message.MessageId,
                    context.ErrorMessage,
                    context.ErrorReason
                );

                await RetryByCloningMsg(message, messageReceiver, logger);
            }
        }

        /// <summary>
        /// Depreciated (we no longer retry by cloning)
        /// </summary>
        /// <param name="message"></param>
        /// <param name="messageReceiver"></param>
        /// <param name="logger"></param>
        /// <returns></returns>
        [ExcludeFromCodeCoverage]
        private async Task RetryByCloningMsg(Message message, IMessageReceiver messageReceiver, ILogger logger)
        {

            var msgIntent = message.GetUserProperty<string>("MessageIntent");
            var currentDateTime = DateTime.UtcNow;
            DateTime originalDeliveryTime;

            if (!string.IsNullOrEmpty(msgIntent) && msgIntent.Equals("Retrial"))
            {
                //If messgae is cloned copy
                var originalDeliveryTimeStr = message.GetUserProperty<string>("OriginalDeliveryTimestampUtc");
                originalDeliveryTime = DateTime.Parse(originalDeliveryTimeStr);

                if ((currentDateTime - originalDeliveryTime).Minutes > _config.MessageTimeToLiveMinutes)
                {
                    var errMsg = $"Deadlettering Message with MessageId {message.MessageId}";
                    var errReason = "Message cannot be enque anymore as has reach maximum safe-limit time."; 
                    logger.LogError(errReason);
                    await this.DeadLetterAsync(message, messageReceiver, logger, errMsg, errReason);
                    return;
                }
                else
                {
                    await CloneMessageaAndSend(message, messageReceiver, logger);
                }
            }
            else
            {
                //if message is original
                originalDeliveryTime = message.ExpiresAtUtc.AddTicks(-(message.TimeToLive.Ticks));
                await CloneMessageaAndSend(message, messageReceiver, logger, originalDeliveryTime);
            }
        }

        [ExcludeFromCodeCoverage]
        private async Task CloneMessageaAndSend(Message message, IMessageReceiver messageReceiver, ILogger logger, DateTime? originalDeliveryTime = null)
        {
            var queueClient = GetQueueClient(messageReceiver.Path, messageReceiver);
            //copy the expiry time from original to clone if not having that
            var cloneMessage = message.Clone();

            if (originalDeliveryTime.HasValue)
            {
                //Cloned From original message require this property to be added when message is enqueud
                cloneMessage.UserProperties.Add("MessageIntent", "Retrial");
                cloneMessage.UserProperties.Add("OriginalDeliveryTimestampUtc", originalDeliveryTime.Value);
            }
            logger.LogInformation("Retry Message - MessageId {messageId} after {minutes} mins", message.MessageId, _config.MessageRetryIntervalMinutes);

            await queueClient.ScheduleMessageAsync(cloneMessage, DateTime.UtcNow.AddMinutes(_config.MessageRetryIntervalMinutes));
            await messageReceiver.CompleteAsync(message.SystemProperties.ProtectedLockToken());
        }

        private IQueueClient GetQueueClient(string queueName, IMessageReceiver messageReceiver)
        {
            return new QueueClient(messageReceiver.ServiceBusConnection, queueName, ReceiveMode.PeekLock, RetryPolicy.Default);
        }

    }
}
