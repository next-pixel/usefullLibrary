﻿using System.Collections.Generic;

namespace Platform.Library.Azure.Functions.Extensions
{
    /// <summary>
    /// Context for <see cref="MessageHandler{T}"/>
    /// </summary>
    public class ProcessMessageContext : BaseMessageContext<ProcessMessageResult>
    {
        /// <inheritdoc cref="BaseMessageContext.SuccessStatus"/>
        protected override object SuccessStatus => ProcessMessageResult.SuccessfullyProcessedMessage;

        /// <inheritdoc cref="BaseMessageContext.PoisonedStatus"/>
        protected override object PoisonedStatus => ProcessMessageResult.PoisonMessageIdentified;

        /// <inheritdoc cref="BaseMessageContext.RequiresRetryStatus"/>
        protected override object RequiresRetryStatus => ProcessMessageResult.RequiresRetry;
    }
}