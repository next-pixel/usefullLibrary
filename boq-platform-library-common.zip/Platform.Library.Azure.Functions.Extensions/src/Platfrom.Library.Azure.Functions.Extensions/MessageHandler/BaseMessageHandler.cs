﻿using System;
using System.Collections.Generic;
using System.Runtime;
using System.Text;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using System.Threading.Tasks;
using System.Threading;
using Microsoft.Extensions.Logging;

namespace Platform.Library.Azure.Functions.Extensions.MessageHandler
{
    /// <summary>
    /// Base common class for all Message handling
    /// </summary>
    /// <typeparam name="TPayload"></typeparam>
    /// <typeparam name="TContext"></typeparam>
    /// <typeparam name="TEnum"></typeparam>
    public abstract class BaseMessageHandler<TPayload,TContext,TEnum> : IMessageHandler<TPayload> 
        where TPayload : class
        where TEnum : Enum
        where TContext : BaseMessageContext<TEnum>, new()
    {

        /// <inheritdoc cref="IMessageHandler{T}.ProcessMessageAsync(Message, IMessageReceiver, ILogger, CancellationToken, IConfigurationRefresher)"/>
        public async Task ProcessMessageAsync(
            Message message,
            IMessageReceiver messageReceiver,
            ILogger logger,
            CancellationToken token,
            IConfigurationRefresher refresher = null)
        {
            if (refresher != null)
                await refresher.TryRefreshAsync();

            var result = new TContext();

            try
            {
                logger.LogDebug("{assembly}: Received Message with MessageId {MessageId} Delivery Count: {deliveryCount}",
                    this.ReadableTypeName(),
                    message.MessageId,
                    message.SystemProperties.ProtectedDeliveryCount()
                );

                var deserializedPayload = DeserializeMessage(message, logger);

                // PRE-PROCESSING
                await PreProcessHandling(message.SystemProperties.ProtectedDeliveryCount(), deserializedPayload, result, logger, token);

                // PROCESS PAYLOAD
                await ActionPayload(deserializedPayload, result, logger, token);

                // POST-PROCESSING
                await PostProcessHandling(message.SystemProperties.ProtectedDeliveryCount(), deserializedPayload, result, logger, token);

                // Ensures that a successful result has occurred
                result.EnsureSuccess();
            }
            catch (UnrecoverableMessageException ex)
            {
                // Assume that because this is thrown in consumer code that it
                // is also logged correctly - so no need to re-log here
                result.Poisoned(ex);
            }
            catch (Exception ex) when (!(ex is UnrecoverableMessageException))
            {
                // Consume the exception without completing or abandoning the message
                // so that the peak lock times out and the message is available to be processed again
                result.RequiresRetry(ex);
            }

            if ( result.IsSuccessful )
            {
                // Do nothing as the message is already completed
                logger.LogInformation(
                    "{assembly}: Successfully processed Message with MessageId {MessageId}",
                    this.ReadableTypeName(),
                    message.MessageId);

                await messageReceiver.CompleteAsync(message.SystemProperties.ProtectedLockToken());
            }
            else if ( result.IsPoisoned )
            {
                logger.LogWarning(
                    "{assembly}: Dead-lettering Message with MessageId {MessageId}. Failure Message: {ErrorMessage} Reason: {ErrorReason}",
                    this.ReadableTypeName(),
                    message.MessageId,
                    result.ErrorMessage,
                    result.ErrorReason);

                await DeadLetterAsync(
                    message,
                    messageReceiver,
                    logger,
                    result.ErrorMessage,
                    result.ErrorReason);


            }
            else if ( result.IsRetryRequired )
            {
                // Do nothing and let PeekLock time itself out.
                // Once retries are exhausted, the message should automatically move to Deadletter.
                logger.LogWarning(
                    "{assembly}: Message with MessageId {MessageId} will retry after lock expiry. Failure Message: {ErrorMessage} Reason: {ErrorReason}",
                    this.ReadableTypeName(),
                    message.MessageId,
                result.ErrorMessage,
                result.ErrorReason);
            }
            else
            {
                // Custom handling based on specific message handler
                await HandleCustomResultAsync(messageReceiver, result, logger, message, token);
            }
        }

        /// <summary>
        /// Process any handler specific message statuses
        /// </summary>
        /// <param name="messageReceiver"></param>
        /// <param name="context"></param>
        /// <param name="logger"></param>
        /// <param name="message"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        protected virtual Task HandleCustomResultAsync(IMessageReceiver messageReceiver, TContext context, ILogger logger, Message message, CancellationToken token)
        {
            // Do nothing
            return Task.CompletedTask;
        }

        /// <summary>
        /// Pre-processing to be done before the payload is processed
        /// </summary>
        /// <param name="deliveryCount"></param>
        /// <param name="payload"></param>
        /// <param name="context"></param>
        /// <param name="logger"></param>
        /// <param name="cancellationToken"></param>
        protected virtual Task PreProcessHandling(
            int deliveryCount,
            TPayload payload,
            TContext context,
            ILogger logger,
            CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }

        /// <summary>
        /// Post-processing to be done after the payload is processed
        /// </summary>
        /// <param name="deliveryCount"></param>
        /// <param name="payload"></param>
        /// <param name="context"></param>
        /// <param name="logger"></param>
        /// <param name="cancellationToken"></param>
        protected virtual Task PostProcessHandling(
            int deliveryCount,
            TPayload payload,
            TContext context,
            ILogger logger,
            CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }

        /// <summary>
        /// Deserialize the message
        /// </summary>
        /// <param name="message"></param>
        /// <param name="logger"></param>
        /// <returns></returns>
        protected virtual TPayload DeserializeMessage(Message message, ILogger logger)
        {
            if (typeof(TPayload) == typeof(Message))
                return message as TPayload;

            var deserializedObject = message.GetBodyFromJson<TPayload>();

            logger.LogDebug($"{{assembly}}: Deserialized Message with MessageId {{MessageId}} into {typeof(TPayload).ReadableTypeName()}",
                this.ReadableTypeName(),
                message.MessageId
            );

            return deserializedObject;
        }

        /// <summary>
        /// Processing the actual message Payload
        /// </summary>
        /// <param name="payload"></param>
        /// <param name="context"></param>
        /// <param name="logger"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        protected abstract Task ActionPayload(
            TPayload payload,
            TContext context,
            ILogger logger,
            CancellationToken cancellationToken);

        /// <summary>
        /// Delegate for the method used to process an individual item
        /// </summary>
        /// <typeparam name="TItem"></typeparam>
        /// <param name="item"></param>
        /// <param name="itemState"></param>
        /// <param name="cancelationToken"></param>
        /// <returns></returns>
        public delegate Task<DataItemStatus> ProcessEventItemAsync<TItem>(TItem item, DataItemStatus itemState, CancellationToken cancelationToken);

        /// <summary>
        /// Use this method to initiate the processing of multiple event items
        /// </summary>
        /// <typeparam name="TEntity"></typeparam>
        /// <typeparam name="TItem"></typeparam>
        /// <param name="logger"></param>
        /// <param name="entity"></param>
        /// <param name="context"></param>
        /// <param name="iterationPredicate"></param>
        /// <param name="identifierPredicate"></param>
        /// <param name="processDelegate"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        protected async Task ProcessEventItems<TEntity,TItem>(
            ILogger logger,
            TEntity entity, 
            ProcessMessageContext context,
            Func<TEntity,IEnumerable<TItem>> iterationPredicate, 
            Func<TItem,string> identifierPredicate,
            ProcessEventItemAsync<TItem> processDelegate, 
            CancellationToken cancellationToken)
        {
            var iterator = new EventDataIterator<TItem>();

            var totalItems = 0;
            bool interrupted = false;
            var itemQueue = new Queue<TItem>(iterationPredicate(entity));
            int itemCount = itemQueue.Count;

            while ( itemQueue.Count > 0 )
            {
                // If cancelled then the total items
                if (cancellationToken.IsCancellationRequested)
                { 
                    interrupted = true;
                    break;
                }

                var item = itemQueue.Dequeue();
                var itemState = new DataItemStatus(TypeExtensions.ReadableTypeName<TItem>(), identifierPredicate.Invoke(item));

                try
                {
                    itemState = await processDelegate.Invoke(item, itemState, cancellationToken);
                    itemState.Completed();                
                }
                catch ( Exception ex )
                {
                    itemState.Failed(ex);
                }

                logger.LogItemStatus(itemState);
                iterator.AddItemStatus(itemState);
                totalItems++;
            }

            // If the process was interrupted then add any unprocessed items
            if ( interrupted && totalItems < itemCount )
            {
                // Add any remaining as unprocessed
                while (itemQueue.Count > 0)
                {
                    var item = itemQueue.Dequeue();
                    var itemState = new DataItemStatus(TypeExtensions.ReadableTypeName<TItem>(), identifierPredicate.Invoke(item));
                    itemState.Failed(new ThreadInterruptedException($"Thread was interrupted before {itemState.Entity} with identifier {itemState.Identifier} could be processed"));

                    logger.LogItemStatus(itemState);
                    iterator.AddItemStatus(itemState);
                }
            }

            // Now determine the overall result
            iterator.UpdateMessageContext(context, totalItems);
        }

        /// <summary>
        /// Handle message as Dead Lettered
        /// </summary>
        /// <param name="message"></param>
        /// <param name="messageReceiver"></param>
        /// <param name="logger"></param>
        /// <param name="deadLetterReason"></param>
        /// <param name="deadLetterErrorDescription"></param>
        /// <returns></returns>
        protected virtual async Task DeadLetterAsync(
            Message message,
            IMessageReceiver messageReceiver,
            ILogger logger,
            string deadLetterReason,
            string deadLetterErrorDescription)
        {
            await PreProcessDeadlettering(message, logger);
            await messageReceiver.DeadLetterAsync(message.SystemProperties.ProtectedLockToken(), deadLetterReason, deadLetterErrorDescription);
        }

        /// <summary>
        /// Pre-processing before dead lettering
        /// </summary>
        /// <param name="message"></param>
        /// <param name="logger"></param>
        /// <returns></returns>
        protected virtual Task PreProcessDeadlettering(Message message, ILogger logger)
        {
            return Task.CompletedTask;
        }
    }
}
