﻿using System.Collections.Generic;

namespace Platform.Library.Azure.Functions.Extensions
{
    /// <summary>
    /// Context for <see cref="QueueMessageHandler{T}"/>
    /// </summary>
    public class ProcessRetrialMessageContext : BaseMessageContext<ProcessRetrialMessageResult>
    {
        /// <inheritdoc cref="BaseMessageContext.SuccessStatus"/>
        protected override object SuccessStatus => ProcessRetrialMessageResult.SuccessfullyProcessedMessage;

        /// <inheritdoc cref="BaseMessageContext.PoisonedStatus"/>
        protected override object PoisonedStatus => ProcessRetrialMessageResult.PoisonMessageIdentified;

        /// <inheritdoc cref="BaseMessageContext.RequiresRetryStatus"/>
        protected override object RequiresRetryStatus => ProcessRetrialMessageResult.RequiresRetry;


    }
}