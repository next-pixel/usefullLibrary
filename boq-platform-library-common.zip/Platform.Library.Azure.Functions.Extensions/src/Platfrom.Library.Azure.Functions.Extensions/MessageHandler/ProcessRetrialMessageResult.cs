﻿namespace Platform.Library.Azure.Functions.Extensions
{
    /// <summary>
    /// Result status for processing with the <see cref="QueueMessageHandler{T}"/>
    /// </summary>
    public enum ProcessRetrialMessageResult
    {
        /// <summary>Not set</summary>
        NoStatusSet,

        /// <summary>Successful</summary>
        SuccessfullyProcessedMessage,

        /// <summary>Poisoned</summary>
        PoisonMessageIdentified,

        /// <summary>Requires Retry</summary>
        RequiresRetry,

        /// <summary>Requires Retry (by cloning)</summary>
        RequiresRetryWithClone,
    }
}
