﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Platform.Library.Azure.Functions.Extensions
{
    /// <summary>
    /// Abstract message context class
    /// </summary>
    /// <typeparam name="TEnum"></typeparam>
    public abstract class BaseMessageContext<TEnum> : BaseMessageContext
        where TEnum : Enum
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BaseMessageContext{TEnum}"/> class.
        /// </summary>
        protected BaseMessageContext() : base(Enum.GetValues(typeof(TEnum)).GetValue(0)) { }

        /// <summary>
        /// Result of the current processing
        /// </summary>
        public new TEnum Result 
        { 
            get => (TEnum)base.Result;
            set => base.Result = value; 
        }
    }
}
