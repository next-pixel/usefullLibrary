using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Extensions.Logging;
using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Platform.Library.Azure.Functions.Extensions.MessageHandler;
using Microsoft.AspNetCore.Mvc;
using Serilog.Core;

namespace Platform.Library.Azure.Functions.Extensions
{
    /// <inheritdoc cref="IMessageHandler{T}"/>
    public abstract class MessageHandler<T> : BaseMessageHandler<T,ProcessMessageContext,ProcessMessageResult>
        where T : class
    {
        private readonly TopicMessageRetryPolicySettings _settings;

        /// <summary>
        /// Default <see cref="TopicMessageRetryPolicySettings"/>
        /// </summary>
        public static readonly TopicMessageRetryPolicySettings DefaultRetryPolicySettings =  new TopicMessageRetryPolicySettings
        {
            MessageDelayBeforeAbandonSeconds = (int) TimeSpan.FromMinutes(4.5).TotalSeconds // Default value is 4mins 30sec
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="MessageHandler{T}"/> class with custom <see cref="TopicMessageRetryPolicySettings"/>
        /// </summary>
        /// <param name="settings"></param>
        protected MessageHandler(TopicMessageRetryPolicySettings settings)
        {
            _settings = settings;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MessageHandler{T}"/> class.
        /// </summary>
        protected MessageHandler() : this(DefaultRetryPolicySettings)
        {
        }

        /// <inheritdoc cref="BaseMessageHandler{TPayload, TContext, TEnum}.HandleCustomResultAsync(IMessageReceiver, TContext, ILogger, Message, CancellationToken)"/>
        protected override async Task HandleCustomResultAsync(IMessageReceiver messageReceiver, ProcessMessageContext context, ILogger logger, Message message, CancellationToken token)
        {
            if (context.Result == ProcessMessageResult.RequiresAbandonDelayRetry)
            {

                logger.LogWarning("Abandon Message after delaying {0} seconds for retry", _settings.MessageDelayBeforeAbandonSeconds);

                await Task.Delay((int)TimeSpan.FromSeconds(_settings.MessageDelayBeforeAbandonSeconds).TotalMilliseconds, token);

                logger.LogWarning(
                    "{assembly}: Will retry Message with MessageId {MessageId}. Failure Message: {ErrorMessage} Reason: {ErrorReason}",
                    this.ReadableTypeName(),
                    message.MessageId,
                    context.ErrorMessage,
                    context.ErrorReason
                );

                await messageReceiver.AbandonAsync(message.SystemProperties.ProtectedLockToken());
            }
        }
    }
}