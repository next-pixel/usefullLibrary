using Microsoft.Azure.ServiceBus;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Platform.Library.Azure.Functions.Extensions
{
    /// <summary>
    /// Extension methods for <see cref="Message"/>
    /// </summary>
    public static class MessageExtensions
    {
        /// <summary>
        /// Extract a user property from the <see cref="Message"/> as an object
        /// </summary>
        /// <param name="message"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static object GetUserPropertyNullSafe(this Message message, string key)
        {
            if (message.UserProperties != null)
            {
                if (message.UserProperties.ContainsKey(key))
                {
                    return message.UserProperties[key];
                }
            }

            return null;
        }

        /// <summary>
        /// Get the body of a <see cref="Message"/> as a string
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public static string GetBodyAsString(this Message message)
        {
            return Encoding.UTF8.GetString(message.Body);
        }

        /// <summary>
        /// Get the body of a message as an instance of <typeparamref name="T"/>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="message"></param>
        /// <returns></returns>
        /// <exception cref="MessageDeserializationException"></exception>
        public static T GetBodyFromJson<T>(this Message message)
        {
            try
            {
                var body = message.GetBodyAsString();
                return body.Deserialize<T>();
            }
            catch (Exception ex)
            {
                throw new MessageDeserializationException("Unable to deserialize message", ex);
            }
        }

        /// <summary>
        /// Get the body of a message as an instance of <typeparamref name="T"/>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="message"></param>
        /// <returns></returns>
        public static T GetStringBodyFromJson<T>(this Message message)
        {
            var body = message.GetBodyAsString();
            return body.Deserialize<T>();
        }

        /// <summary>
        /// Clone a <see cref="Message"/> (Depreciated as we only used this when copying messages to replay)
        /// </summary>
        /// <param name="originalMessage"></param>
        /// <param name="body"></param>
        /// <returns></returns>
        [ExcludeFromCodeCoverage]
        public static Message Clone(this Message originalMessage, string body)
        {
            var newmessage = new Message(Encoding.UTF8.GetBytes(body))
            {
                ContentType = originalMessage.ContentType,
                CorrelationId = originalMessage.CorrelationId,
                Label = originalMessage.Label,
                MessageId = originalMessage.MessageId,
                PartitionKey = originalMessage.PartitionKey,
                ReplyTo = originalMessage.ReplyTo,
                ReplyToSessionId = originalMessage.ReplyToSessionId,
                SessionId = originalMessage.SessionId,
                To = originalMessage.To,
                ViaPartitionKey = originalMessage.ViaPartitionKey
            };

            if (originalMessage.UserProperties != null)
            {
                foreach (var property in originalMessage.UserProperties)
                {
                    if (property.Key != "DeadLetterReason" && property.Key != "DeadLetterErrorDescription")
                    {
                        newmessage.UserProperties.Add(property.Key, property.Value);
                    }
                }
            }

            return newmessage;
        }

        /// <summary>
        /// Get a user property of a <see cref="Message"/> as type <typeparamref name="T"/> with null safety
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="message"></param>
        /// <param name="property"></param>
        /// <returns></returns>
        public static T GetPropertyNullSafe<T>(this Message message, string property)
        {
            return message.GetUserProperty<T>(property);
        }

        /// <summary>
        /// Get a user property of a <see cref="Message"/> as type <typeparamref name="T"/>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="message"></param>
        /// <param name="property"></param>
        /// <returns></returns>
        public static T GetUserProperty<T>(this Message message, string property)
        {
            var propertyValue = message.GetUserPropertyNullSafe(property);

            if (propertyValue != null)
            {
                if (propertyValue is T)
                {
                    return (T)propertyValue;
                }
                else
                {
                    return (T)Convert.ChangeType(propertyValue, typeof(T));
                }
            }

            return default(T);
        }
    }
}