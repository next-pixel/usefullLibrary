﻿using Microsoft.Extensions.Logging;
using Platform.Library.Azure.Functions.Extensions.MessageHandler;
using Platform.Library.Extensions;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text;

namespace Platform.Library.Azure.Functions.Extensions
{
    internal static class ExceptionExtensions
    {
        /// <summary>
        /// To only be used in the <see cref="BaseMessageHandler{TPayload, TContext, TEnum}"/>
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="itemStatus"></param>
        /// <exception cref="NotSupportedException"></exception>
        internal static void LogItemStatus(this ILogger logger, DataItemStatus itemStatus)
        {
            // Calling method will always be at this position
            var methodInfo = new StackTrace().GetFrame(8).GetMethod();
            var methodName = string.Concat(methodInfo.DeclaringType.AsFormattedTypeName(), ".", methodInfo.Name);

            switch ( itemStatus.State )
            {
                case DataItemState.Pending:
                case DataItemState.Success:
                    logger.LogInformation("{MethodName}: {Entity} with identifier {UniqueId} was processed successfully", methodName, itemStatus.Entity, itemStatus.Identifier);
                    break;
                case DataItemState.Recoverable:
                    logger.LogWarning("{MethodName}: {Entity} with identifier {UniqueId} failed recoverably while {Action}", methodName, itemStatus.Entity, itemStatus.Identifier, itemStatus.Action);
                    break;
                case DataItemState.Unrecoverable:
                    logger.LogWarning("{MethodName}: {Entity} with identifier {UniqueId} unrecoverably failed while {Action}", methodName, itemStatus.Entity, itemStatus.Identifier, itemStatus.Action);
                    break;
                default:
                    throw new NotSupportedException($"{nameof(LogItemStatus)} does not support a {nameof(DataItemState)} value of {itemStatus.State}");
            }
        }
    }
}
