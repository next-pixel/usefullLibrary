﻿namespace Platform.Library.Azure.Functions.Extensions
{
    /// <summary>
    /// Retry policy settings used with <see cref="QueueMessageHandler{T}"/>
    /// </summary>
    public class QueueMessageRetryPolicySettings
    {
        /// <summary>Minutes to live for the message</summary>
        public int MessageTimeToLiveMinutes { get; set; }

        /// <summary>Interval between retrying the message again</summary>
        public int MessageRetryIntervalMinutes { get; set; }
    }
}
