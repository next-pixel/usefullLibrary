using Platform.Library.Common.Standard.Configuration.Abstractions;

namespace Library.Azure.Functions.Extensions.Configuration
{
    /// <summary>
    /// Interface for the <see cref="StandardFunctionSettings"/>
    /// </summary>
    public interface IStandardFunctionSettings : IStandardSettings
    {
    }
}
