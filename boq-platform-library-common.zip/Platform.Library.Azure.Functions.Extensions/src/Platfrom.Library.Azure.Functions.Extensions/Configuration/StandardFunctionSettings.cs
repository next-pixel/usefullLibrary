using Microsoft.Extensions.Configuration;
using Platform.Library.Common.Standard.Configuration.Abstractions;

namespace Library.Azure.Functions.Extensions.Configuration
{
    /// <summary>
    /// Standard base settings class for all FunctionApps / Subscribers
    /// </summary>
    public abstract class StandardFunctionSettings : StandardSettings, IStandardFunctionSettings
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StandardFunctionSettings"/> class.
        /// </summary>
        /// <param name="configuration"></param>
        protected StandardFunctionSettings(IConfiguration configuration) : base(configuration)
        {
        }
    }
}