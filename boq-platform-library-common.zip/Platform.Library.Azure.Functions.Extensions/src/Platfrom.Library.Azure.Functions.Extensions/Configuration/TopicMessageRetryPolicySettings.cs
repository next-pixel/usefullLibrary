﻿namespace Platform.Library.Azure.Functions.Extensions
{
    /// <summary>
    /// Retry policy settings for use with the <see cref="MessageHandler{T}"/>
    /// </summary>
    public class TopicMessageRetryPolicySettings
    {
        /// <summary>Number of seconds to delay before abandoning the message</summary>
        public int MessageDelayBeforeAbandonSeconds { get; set; }
    }
}
