﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Platform.Library.Azure.Functions.Extensions
{
    /// <summary>
    /// Indicates a failure has occurred with an item of data in an event
    /// </summary>
    public sealed class DataItemStatus : IEquatable<DataItemStatus>, IComparable<DataItemStatus>
    {
        private bool? _nonRepeatableChange = false;
        private string _pendingAction = null;

        internal DataItemStatus(string entity, string identifier) 
        {
            if ( string.IsNullOrWhiteSpace(identifier) )
                throw new ArgumentNullException(nameof(identifier));

            Entity = entity;
            Identifier = identifier;
        }

        /// <summary>Name of the entity being referenced</summary>
        public string Entity { get; private set; }

        /// <summary>Unique identifier for this data item</summary>
        public string Identifier { get; private set; }

        /// <summary>Current action being performed for this data item</summary>
        public string Action { get; private set; }

        /// <summary>Exception if this has failed</summary>
        public Exception Exception { get; private set; }

        /// <summary>Indicates the current state of processing this item</summary>
        public DataItemState State { get; private set; }

        internal bool IsRecoverable { get; set; }

        internal void Completed()
        {
            if ( _nonRepeatableChange.HasValue )
            {
                Action = _pendingAction;
                IsRecoverable = !(_nonRepeatableChange.Value);
            }

            // If we are still pending then it completed successfully
            if (State == DataItemState.Pending)
                State = DataItemState.Success;
        }

        /// <summary>
        /// Indicate that this action is REPEATABLE
        /// </summary>
        /// <remarks>Repeatable actions are those which can be redone if the message was marked for retry</remarks>
        /// <param name="action">Describing the action as a verb (ie "retrieving profile")</param>
        public void RepeatableAction(string action)
        {
            Action = _pendingAction;
            IsRecoverable = !(_nonRepeatableChange ?? false);
            if (State == DataItemState.Pending)
                State = DataItemState.Success;

            _pendingAction = action;
        }

        /// <summary>
        /// Indicate that this action is NON-REPEATABLE
        /// </summary>
        /// <remarks>Non-repeatable actions are those you cannot redo if the message was marked for retry</remarks>
        /// <param name="action">Describing the action as a verb (ie "pushing notification")</param>
        public void NonRepeatableAction(string action)
        {
            Action = _pendingAction;
            IsRecoverable = !(_nonRepeatableChange ?? false);
            if (State == DataItemState.Pending)
                State = DataItemState.Success;

            _nonRepeatableChange = true;
            _pendingAction = action;
        }

        /// <summary>
        /// Indicate that the data item has failed
        /// </summary>
        /// <param name="ex"></param>
        public void Failed(Exception ex)
        {
            Action = _pendingAction;
            IsRecoverable = IsRecoverable && ex is not UnrecoverableMessageException;

            _pendingAction = null;
            _nonRepeatableChange = null;

            State = IsRecoverable
                ? DataItemState.Recoverable
                : DataItemState.Unrecoverable;

            Exception = ex;
        }

        /// <summary>
        /// Can I continue processing the item in this state
        /// </summary>
        public bool CanContinue => State.In(DataItemState.Pending, DataItemState.Success) && IsRecoverable;

        /// <inheritdoc cref="object.Equals(object)"/>
        public override bool Equals(object obj)
        {
            return obj is DataItemStatus dif
                && Equals(dif);
        }

        /// <inheritdoc cref="object.GetHashCode"/>
        public override int GetHashCode()
        {
            return Identifier.GetHashCode();
        }

        /// <inheritdoc cref="object.ToString"/>
        public override string ToString()
        {
            return $"[{Identifier}] {State}{(Exception == null ? "" : $" {Exception.Message}")}";
        }

        /// <inheritdoc cref="IEquatable{T}.Equals(T)"/>
        public bool Equals(DataItemStatus other)
        {
            return CompareTo(other) == 0;
        }

        /// <inheritdoc cref="IComparable{T}.CompareTo(T)"/>
        public int CompareTo(DataItemStatus other)
        {
            return Identifier.CompareTo(other.Identifier);
        }
    }
}
