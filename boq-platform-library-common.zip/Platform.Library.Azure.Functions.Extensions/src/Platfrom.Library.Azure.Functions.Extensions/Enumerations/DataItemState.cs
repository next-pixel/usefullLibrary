﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Platform.Library.Azure.Functions.Extensions
{
    /// <summary>
    /// Status of processing an individual data item
    /// </summary>
    public enum DataItemState
    {
        /// <summary>Data item is pending processing</summary>
        Pending, 

        /// <summary>Data item was successfully processed</summary>
        Success,

        /// <summary>Data item failed but is recoverable</summary>
        Recoverable,

        /// <summary>Data item failed but is unrecoverable</summary>
        Unrecoverable
    }
}
