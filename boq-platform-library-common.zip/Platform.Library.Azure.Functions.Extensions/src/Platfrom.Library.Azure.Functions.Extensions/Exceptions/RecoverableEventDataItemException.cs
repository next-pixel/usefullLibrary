﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Platform.Library.Azure.Functions.Extensions
{
    /// <summary>
    /// A recoverable exception for a specific data item
    /// </summary>
    public class RecoverableEventDataItemException : Exception
    {
        /// <summary>
        /// Set the status as a recoverable exception
        /// </summary>
        /// <param name="status"></param>
        public RecoverableEventDataItemException(DataItemStatus status) : base(DetermineMessage(status), status.Exception) 
        {
            if (!status.IsRecoverable)
                throw new ArgumentOutOfRangeException(nameof(status), $"Only a {nameof(DataItemStatus)} that is recoverable can be used with a {nameof(RecoverableEventDataItemException)}");
        }

        private static string DetermineMessage(DataItemStatus status) => $"{status.Entity} with identifier {status.Identifier} failed while {status.Action}: {status.Exception.Message}";
    }
}
