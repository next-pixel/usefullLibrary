﻿using System;

namespace Platform.Library.Azure.Functions.Extensions
{
    /// <summary>
    /// Exception indicating problem deserializing the message
    /// </summary>
    public class MessageDeserializationException : UnrecoverableMessageException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MessageDeserializationException"/> class.
        /// </summary>
        /// <param name="errorMessage"></param>
        /// <param name="innerException"></param>
        public MessageDeserializationException(string errorMessage, Exception innerException) : base(errorMessage, innerException)
        {
        }

        internal override string ErrorMessage => "Error deserializing the message.";
        internal override string ErrorReason => InnerException?.Message ?? Message;
    }
}
