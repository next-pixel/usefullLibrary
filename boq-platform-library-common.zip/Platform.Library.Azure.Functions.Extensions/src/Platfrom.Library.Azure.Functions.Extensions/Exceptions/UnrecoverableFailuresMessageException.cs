﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Platform.Library.Azure.Functions.Extensions
{
    /// <summary>
    /// Exception indicating multiple failures within message processing cannot be recovered
    /// </summary>
    public class UnrecoverableFailuresMessageException : UnrecoverableMessageException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UnrecoverableMessageException"/> class.
        /// </summary>
        /// <param name="failures"></param>
        public UnrecoverableFailuresMessageException(IEnumerable<DataItemStatus> failures) : base(DefineErrorMessage(failures), DefineInnerException(failures))
        {
            Failures = failures;
        }

        /// <summary>
        /// The failures that occurred for data items of this event
        /// </summary>
        public IEnumerable<DataItemStatus> Failures { get; private set; }

        private static string DefineErrorMessage(IEnumerable<DataItemStatus> failures)
        {
            var entity = failures.FirstOrDefault()?.Entity;

            var failureMsg = string.Join(
                "\n\t ",
                failures.Select(f => $"{f.Identifier}: {f.Exception.Message}")
            );

            return $"The event was only partially processed. The following {entity}s failed:\n\t {failureMsg}";
        }

        private static AggregateException DefineInnerException(IEnumerable<DataItemStatus> failures) 
        {
            return new AggregateException(failures.Select(e => e.Exception).ToArray());
        }
    }
}
