﻿using System;

namespace Platform.Library.Azure.Functions.Extensions
{
    /// <summary>
    /// Exception indicating message processing cannot be recovered
    /// </summary>
    public class UnrecoverableMessageException : Exception
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UnrecoverableMessageException"/> class.
        /// </summary>
        /// <param name="errorMessage"></param>
        /// <param name="innerException"></param>
        public UnrecoverableMessageException(string errorMessage, Exception innerException) : base(errorMessage, innerException)
        {
        }

        internal virtual string ErrorMessage => $"{GetType().Name} has occurred";
        internal virtual string ErrorReason => Message;
    }
}
