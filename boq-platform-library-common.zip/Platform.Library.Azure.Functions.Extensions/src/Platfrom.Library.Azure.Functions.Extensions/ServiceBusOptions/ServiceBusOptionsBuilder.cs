﻿using Microsoft.Azure.WebJobs.ServiceBus;
using System;
using System.Diagnostics.CodeAnalysis;

namespace Platform.Library.Azure.Functions.Extensions
{
    /// <summary>
    /// Extension methods for <see cref="ServiceBusOptions"/>
    /// </summary>
    /// <remarks>
    /// Manually adding reference to Microsoft.Azure.ServiceBus as latest version of Microsoft.Azure.WebJobs.Extensions.ServiceBus has dropped this
    /// in favor of Azure.Messaging.ServiceBus which we have not upgraded to yet
    /// 
    /// Excluding from code coverage due to <see cref="ServiceBusOptions"/> not being mockable
    /// </remarks>
    [ExcludeFromCodeCoverage]
    public static class ServiceBusOptionsBuilder
    {
        /// <summary>
        /// Configure the <see cref="ServiceBusOptions"/> to default or preset values
        /// </summary>
        /// <param name="options">The <see cref="ServiceBusOptions"/> to be configured</param>
        /// <param name="autoComplete">Determines whether or not to automatically complete messages after successful execution of the function</param>
        /// <param name="prefetchCount">The number of messages that the message receiver can simultaneously request</param>
        /// <param name="maxConcurrentCalls">The maximum number of concurrent calls to the callback that should be initiated</param>
        /// <param name="maxAutoRenewDurationSeconds">The maximum duration within which the message/session lock will be renewed automatically</param>
        /// <param name="maxConcurrentSessions">The maximum number of sessions that can be handled concurrently per scaled instance</param>
        /// <param name="messageWaitTimeoutSeconds">The maximum amount of time in seconds to wait for a message to be received for the currently active session before releasing the lock</param>
        public static void Configure(
            this ServiceBusOptions options,
            bool autoComplete = false,
            int prefetchCount = 0,
            int maxConcurrentCalls = 16,
            int maxAutoRenewDurationSeconds = 10,
            int maxConcurrentSessions = 8,
            int messageWaitTimeoutSeconds = 1)
        {
            options.MessageHandlerOptions.AutoComplete = autoComplete;
            options.PrefetchCount = prefetchCount;
            options.MessageHandlerOptions.MaxConcurrentCalls = maxConcurrentCalls;
            options.MessageHandlerOptions.MaxAutoRenewDuration = TimeSpan.FromSeconds(maxAutoRenewDurationSeconds);

            options.SessionHandlerOptions.AutoComplete = autoComplete;
            options.SessionHandlerOptions.MaxConcurrentSessions = maxConcurrentSessions;
            options.SessionHandlerOptions.MessageWaitTimeout = TimeSpan.FromSeconds(messageWaitTimeoutSeconds);
        }
    }
}
