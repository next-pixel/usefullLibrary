﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentAssertions.Execution;
using Microsoft.Azure.ServiceBus;
using Moq;
using Xunit.Abstractions;

namespace Platform.Library.Azure.Functions.Extensions.UnitTests
{
    public class MessageHandlerTest : BaseMessageHandlerTest
    {
        private TestMessageHandler _handler = null;

        public MessageHandlerTest(ITestOutputHelper outputHelper) : base(outputHelper) { }
       
        public TestMessageHandler MessageHandler
        {
            get
            {
                if (_handler == null)
                {
                    _handler = new TestMessageHandler(new TopicMessageRetryPolicySettings()
                    {
                        MessageDelayBeforeAbandonSeconds = 1
                    });
                }

                return _handler;
            }
        }

        [Fact]
        public async Task MessageHandler_Success()
        {
            // Arrange
            var payload = new TestPayload()
            {
                StringProperty = "Tada"
            };

            Message message = ToServiceBusMessage(payload, "Test");

            // Act
            await MessageHandler.ProcessMessageAsync(message, MessageReceiver, Logger, CancellationToken.None);

            // Assert
            using (new AssertionScope())
            {
                VerifyReceiver(
                    Times.Once(),   // Complete
                    Times.Never(),  // Abandoned
                    Times.Never()   // Dead Lettered
                );
            }
        }

        [Fact]
        public async Task MessageHandler_UnrecoverableException()
        {
            // Arrange
            MessageHandler.ReturnUnrecoverable();

            var payload = new TestPayload()
            {
                StringProperty = "Tada"
            };

            Message message = ToServiceBusMessage(payload, "Test");

            // Act
            await MessageHandler.ProcessMessageAsync(message, MessageReceiver, Logger, CancellationToken.None);

            // Assert
            using (new AssertionScope())
            {
                VerifyReceiver(
                    Times.Never(),  // Complete
                    Times.Never(),  // Abandoned
                    Times.Once()    // Dead Lettered
                );
            }
        }

        [Fact]
        public async Task MessageHandler_MessageDeserializeException()
        {
            // Arrange
            MessageHandler.ReturnDeserializeFailed();

            var payload = new TestPayload()
            {
                StringProperty = "Tada"
            };

            Message message = ToServiceBusMessage(payload, "Test");

            // Act
            await MessageHandler.ProcessMessageAsync(message, MessageReceiver, Logger, CancellationToken.None);

            // Assert
            using (new AssertionScope())
            {
                VerifyReceiver(
                    Times.Never(),  // Complete
                    Times.Never(),  // Abandoned
                    Times.Once()    // Dead Lettered
                );
            }
        }


        [Fact]
        public async Task MessageHandler_UnexpectedException()
        {
            // Arrange
            MessageHandler.ReturnUnexpectedError();

            var payload = new TestPayload()
            {
                StringProperty = "Tada"
            };

            Message message = ToServiceBusMessage(payload, "Test");

            // Act
            await MessageHandler.ProcessMessageAsync(message, MessageReceiver, Logger, CancellationToken.None);

            // Assert
            using (new AssertionScope())
            {
                VerifyReceiver(
                    Times.Never(),  // Complete
                    Times.Never(),  // Abandoned
                    Times.Never()    // Dead Lettered
                );
            }
        }

        [Fact]
        public async Task MessageHandler_CustomHandling()
        {
            // Arrange
            MessageHandler.ReturnCustom();

            var payload = new TestPayload()
            {
                StringProperty = "Tada"
            };

            Message message = ToServiceBusMessage(payload, "Test");

            // Act
            await MessageHandler.ProcessMessageAsync(message, MessageReceiver, Logger, CancellationToken.None);

            // Assert
            using (new AssertionScope())
            {
                VerifyReceiver(
                    Times.Never(),  // Complete
                    Times.Once(),   // Abandoned
                    Times.Never()   // Dead Lettered
                );
            }
        }
    }
}
