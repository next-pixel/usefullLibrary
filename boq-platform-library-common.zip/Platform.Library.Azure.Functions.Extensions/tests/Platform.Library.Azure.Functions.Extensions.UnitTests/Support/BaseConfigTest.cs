﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using Autofac;
using Autofac.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Platform.Library.Azure.Functions.Extensions.UnitTests
{
    public abstract class BaseConfigTests
    {
        private IContainer _container;
        private IServiceCollection _services;
        private MethodInfo _resolveMethod;

        protected BaseConfigTests(string folder, params string[] scenarios)
        {
            var builder = new ConfigurationBuilder();

            if (scenarios?.Any() ?? false)
            {
                foreach (var scenario in scenarios)
                    builder.AddJsonFile($"{folder}/local.settings.{scenario}.json");
            }

            builder.AddEnvironmentVariables();

            Config = builder.Build();
        }

        protected IConfigurationRoot Config { get; private set; }

        protected abstract void RegisterTypes(ContainerBuilder builder);

        protected T ResolveAsType<T>(string name)
        {
            return ResolveAsType<T>(typeof(T), name);
        }

        protected T ResolveAsType<T>(Type type, string name = null)
        {
            if (_resolveMethod == null)
                _resolveMethod = GetType()
                    .GetMethod(nameof(Resolve), BindingFlags.Instance | BindingFlags.NonPublic, null, string.IsNullOrWhiteSpace(name) ? new Type[] { } : new Type[] { typeof(string) }, null)
                    .MakeGenericMethod(type);

            return (T)_resolveMethod.Invoke(this, string.IsNullOrWhiteSpace(name) ? null : new object[] { name });
        }

        protected T Resolve<T>()
        {
            return Container.Resolve<T>();
        }

        protected T Resolve<T>(string name)
        {
            return Container.ResolveNamed<T>(name);
        }

        private ContainerBuilder Builder { get; set; }

        protected IContainer Container
        {
            get
            {
                if (Builder == null)
                {
                    Builder = new ContainerBuilder();

                    Builder.RegisterInstance(Config).AsImplementedInterfaces();

                    Builder.Populate(ServiceCollection);

                    RegisterTypes(Builder);
                    _container = Builder.Build();
                }

                return _container;
            }
        }

        protected IServiceCollection ServiceCollection
        {
            get
            {
                if (_services == null)
                {
                    _services = new ServiceCollection();
                }
                return _services;
            }
        }
    }
}
