﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace Platform.Library.Azure.Functions.Extensions.UnitTests
{
    public class TestMessageHandler : MessageHandler<TestPayload>
    {
        public TestMessageHandler() : base() { }
        public TestMessageHandler(TopicMessageRetryPolicySettings settings) : base(settings) { }

        private enum ExpectedAction
        {
            Success,
            Unrecoverable,
            Deserialization,
            Unexpected,
            Custom
        }

        private ExpectedAction _expectedAction = ExpectedAction.Success;
        private Exception _exception = null;

        protected override Task ActionPayload(TestPayload payload, ProcessMessageContext context, ILogger logger, CancellationToken cancellationToken)
        {
            if ( _expectedAction == ExpectedAction.Success )
                return Task.CompletedTask;
            else if ( _expectedAction == ExpectedAction.Custom )
            {
                context.Result = ProcessMessageResult.RequiresAbandonDelayRetry;
                return Task.CompletedTask;
            }
            else if (_exception != null )
                throw _exception;

            throw new NotSupportedException($"Action {_expectedAction} not supported by {nameof(TestMessageHandler)}");
        }

        public void ReturnUnrecoverable(string message = "Unrecoverable Message", string innerMessage = "test")
        {
            _expectedAction = ExpectedAction.Unrecoverable;
            _exception = new UnrecoverableMessageException(message, new Exception(innerMessage));
        }

        public void ReturnDeserializeFailed(string message = "Deserialization Failed", string innerMessage = "test")
        {
            _expectedAction = ExpectedAction.Deserialization;
            _exception = new MessageDeserializationException(message, new Exception(innerMessage));
        }

        public void ReturnUnexpectedError(string message = "Unexpected Error Occurred")
        {
            _expectedAction = ExpectedAction.Unexpected;
            _exception = new InvalidOperationException(message);
        }

        public void ReturnCustom(string message = "Expect Custom Handling")
        {
            _expectedAction = ExpectedAction.Custom;
            _exception = null;
        }
    }
}
