﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Castle.Core.Logging;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Azure.ServiceBus.Primitives;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Abstractions;
using Moq;
using Platform.Library.Common.Standard.Mocking;
using Xunit.Abstractions;
using Xunit.Sdk;

namespace Platform.Library.Azure.Functions.Extensions.UnitTests
{
    public abstract class BaseMessageHandlerTest
    {
        private readonly Mock<IMessageReceiver> _receiver;
        private readonly Mock<ITokenProvider> _tokenProvider;
        private readonly ILogger<BaseMessageHandlerTest> _logger;

        protected BaseMessageHandlerTest(ITestOutputHelper outputHelper) 
        {
            _tokenProvider = new Mock<ITokenProvider>();
            _receiver = new Mock<IMessageReceiver>();
            _receiver.Setup(x => x.Path).Returns("xxx");
            _receiver.Setup(x => x.ServiceBusConnection).Returns(new ServiceBusConnection("sb://test.servicebus.windows.net/", TransportType.AmqpWebSockets) {  TokenProvider = _tokenProvider.Object });

            _logger = LoggerFactory
                .Create(builder =>
                {
                    builder.AddXunit(outputHelper);
                })
                .CreateLogger<BaseMessageHandlerTest>();
        }

        protected Message ToServiceBusMessage<T>(T item, string label, string messageId = null)
        {
            var message = new Message()
            {
                MessageId = messageId ?? Guid.NewGuid().ToString(),
                Label = label,
                ContentType = "application/json",
                TimeToLive = TimeSpan.FromSeconds(1),
                Body = EncodedBody(item)
            };

            var systemProperties = message.SystemProperties;
            var type = systemProperties.GetType();
            type.GetMethod("set_SequenceNumber", BindingFlags.Instance | BindingFlags.NonPublic)
                .Invoke(systemProperties, new object[] { 0 });
            type.GetMethod("set_LockTokenGuid", BindingFlags.Instance | BindingFlags.NonPublic)
                .Invoke(systemProperties, new object[] { Guid.NewGuid() });
            type.GetMethod("set_DeliveryCount", BindingFlags.Instance | BindingFlags.NonPublic)
                .Invoke(systemProperties, new object[] { 0 });
            return message;
        }

        private byte[] EncodedBody<T>(T item)
        {
            var body = item.Serialize();
            return Encoding.UTF8.GetBytes(body);
        }

        protected IMessageReceiver MessageReceiver => _receiver.Object;

        public void VerifyReceiver(Times complete, Times abandoned, Times deadLettered)
        {
            _receiver.Verify(x => x.CompleteAsync(It.IsAny<string>()), complete);
            _receiver.Verify(x => x.AbandonAsync(It.IsAny<string>(), It.IsAny<IDictionary<string,object>>()), abandoned);
            _receiver.Verify(x => x.DeadLetterAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), deadLettered);
        }

        protected ILogger<BaseMessageHandlerTest> Logger => _logger;
    }
}
