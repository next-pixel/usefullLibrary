﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace Platform.Library.Azure.Functions.Extensions.UnitTests
{
    public class TestComplexMessageHandler : MessageHandler<TestComplexPayload>
    {
        public TestComplexMessageHandler() : base() { }

        public TestComplexMessageHandler(TopicMessageRetryPolicySettings settings) : base(settings) { }

        public enum ExpectedAction
        {
            Success,
            FailBeforeNonRepeatable,
            FailOnNonRepeatable,
            FailAfterNonRepeatable,
            FailAfterOtherNonRepeatable
        }

        protected override async Task ActionPayload(TestComplexPayload payload, ProcessMessageContext context, ILogger logger, CancellationToken cancellationToken)
        {
            // Process the payload items
            await ProcessEventItems(
                logger,
                payload,
                context,
                p => p.Items,
                i => i.Identifier,
                ProcessComplexPayloadItemAsync,
                cancellationToken
            );
        }

        private Task<DataItemStatus> ProcessComplexPayloadItemAsync(TestPayloadItem item, DataItemStatus itemStatus, CancellationToken cancellationToken)
        {
            // Process up to the non-repeatable change
            try
            {
                // Retrieve some data to do the work
                itemStatus.RepeatableAction("retrieving data which is repeatable");
                DoSomethingBeforeNonRepeatable(item);

                // If this next step works then it is a non-repeatable change
                itemStatus.NonRepeatableAction("do something non-repeatable");
                DoSomethingNonRepeatable(item);
            }
            catch ( Exception ex )
            {
                itemStatus.Failed(ex);
            }

            // Now check if you should continue processing the item
            if ( itemStatus.CanContinue )
            {
                // Continue Processing
                try
                {
                    // Preparing to do something else
                    itemStatus.RepeatableAction("do something after non-repeatable");
                    DoSomethingAfterNonRepeatable(item);

                    // Take an action because we are still successful
                    itemStatus.NonRepeatableAction("do something else after non-repeatable");
                    DoSomethingElseAfterNonRepeatable(item);
                }
                catch ( Exception ex )
                {
                    itemStatus.Failed(ex);
                }
            }

            return Task.FromResult(itemStatus);
        }

        private void DoSomethingBeforeNonRepeatable(TestPayloadItem item)
        {
            if (_expectedActions.TryGetValue(item.Identifier, out var expectedAction) && expectedAction == ExpectedAction.FailBeforeNonRepeatable)
                throw new Exception("Failed before non-repeatable");
        }

        private void DoSomethingNonRepeatable(TestPayloadItem item)
        {
            if (_expectedActions.TryGetValue(item.Identifier, out var expectedAction) && expectedAction == ExpectedAction.FailOnNonRepeatable)
                throw new Exception("Failed on non-repeatable");
        }

        private void DoSomethingAfterNonRepeatable(TestPayloadItem item)
        {
            if (_expectedActions.TryGetValue(item.Identifier, out var expectedAction) && expectedAction == ExpectedAction.FailAfterNonRepeatable)
                throw new Exception("Failed after non-repeatable");
        }
        private void DoSomethingElseAfterNonRepeatable(TestPayloadItem item)
        {
            if (_expectedActions.TryGetValue(item.Identifier, out var expectedAction) && expectedAction == ExpectedAction.FailAfterOtherNonRepeatable)
                throw new Exception("Failed after non-repeatable");
        }

        private IDictionary<string,ExpectedAction> _expectedActions = new Dictionary<string,ExpectedAction>();
        public void SetExpectedActions(params (string Identifier, ExpectedAction Action)[] actions)
        {
            if ( actions.AnyNullSafe() )
                foreach ( var action in actions)
                    _expectedActions.Add(action.Identifier, action.Action);
        }
    }
}
