﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Platform.Library.Azure.Functions.Extensions.UnitTests
{
    public class TestComplexPayload
    {
        public IEnumerable<TestPayloadItem> Items { get; set; } = Enumerable.Empty<TestPayloadItem>();
    }

    public class TestPayloadItem
    {
        public string Identifier { get; set; }
        public string StringProperty { get; set; }
    }
}
