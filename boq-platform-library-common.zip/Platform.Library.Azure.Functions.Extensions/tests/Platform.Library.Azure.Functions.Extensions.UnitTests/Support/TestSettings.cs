﻿using System;
using System.Collections.Generic;
using System.Text;
using Library.Azure.Functions.Extensions.Configuration;
using Microsoft.Extensions.Configuration;

namespace Platform.Library.Azure.Functions.Extensions.UnitTests
{
    public class TestSettings : StandardFunctionSettings
    {
        public TestSettings(IConfiguration configuration) : base(configuration)
        {
        }
    }
}
