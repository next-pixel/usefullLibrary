using System;
using Autofac;
using FluentAssertions;
using Library.Azure.Functions.Extensions.Configuration;
using Microsoft.Extensions.Configuration;
using Xunit;

namespace Platform.Library.Azure.Functions.Extensions.UnitTests
{
    public class StandardFunctionSettingsUnitTests : BaseConfigTests
    {
        public StandardFunctionSettingsUnitTests() : base("TestConfiguration", "test") { }

        protected override void RegisterTypes(ContainerBuilder builder)
        {
            builder.Register(c =>
            {
                var config = c.Resolve<IConfiguration>();

                return new TestSettings(Config);
            }).AsImplementedInterfaces()
            .SingleInstance();
        }

        [Fact]
        public void StandardFunctionSettings_Instantiate()
        {
            // Arrange / Act
            var settings = Container.Resolve<IStandardFunctionSettings>();

            // Assert
            settings.Should().NotBeNull();
        }
    }
}
