﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentAssertions.Execution;
using Microsoft.Azure.ServiceBus;
using Moq;
using Xunit.Abstractions;

namespace Platform.Library.Azure.Functions.Extensions.UnitTests
{
    public class ComplexMessageHandlerTest : BaseMessageHandlerTest
    {
        private TestComplexMessageHandler _handler = null;

        public ComplexMessageHandlerTest(ITestOutputHelper outputHelper) : base(outputHelper) { }
       
        public TestComplexMessageHandler MessageHandler
        {
            get
            {
                if (_handler == null)
                {
                    _handler = new TestComplexMessageHandler(new TopicMessageRetryPolicySettings()
                    {
                        MessageDelayBeforeAbandonSeconds = 1
                    });
                }

                return _handler;
            }
        }

        private static TestComplexPayload RetrievePayload(params ( string Identifier, string StringProperty)[] items)
            => new TestComplexPayload
            {
                Items = items.Select(i => new TestPayloadItem { Identifier = i.Identifier, StringProperty = i.StringProperty }).ToArray()
            };

        public static IEnumerable<object[]> ComplexMessageHandlerScenarios =>
            new[]
            {
                // Successful
                new object[]
                {
                    "Success",
                    false,
                    RetrievePayload(("1","one"),("2","two"), ("3","three")),
                    null,
                    1,
                    0,
                    0
                },

                // Simulate Cancellation
                new object[]
                {
                    "Simulate Cancellation",
                    true,
                    RetrievePayload(("1","one"),("2","two"), ("3","three")),
                    null,
                    0,
                    0,
                    0
                },

                // Fail ALL Before - Should Retry
                new object[]
                {
                    "Fail All Before (Retry)",
                    false,
                    RetrievePayload(("1","one"),("2","two"), ("3","three")),
                    new[] 
                    { 
                        ( "1", TestComplexMessageHandler.ExpectedAction.FailBeforeNonRepeatable),
                        ( "2", TestComplexMessageHandler.ExpectedAction.FailBeforeNonRepeatable),
                        ( "3", TestComplexMessageHandler.ExpectedAction.FailBeforeNonRepeatable)
                    },
                    0,
                    0,
                    0
                },

                // Fail ALL Before/On Non-Repeatable - Should Retry
                new object[]
                {
                    "Fail All Before/On (Retry)",
                    false,
                    RetrievePayload(("1","one"),("2","two"), ("3","three")),
                    new[]
                    {
                        ( "1", TestComplexMessageHandler.ExpectedAction.FailBeforeNonRepeatable),
                        ( "2", TestComplexMessageHandler.ExpectedAction.FailOnNonRepeatable),
                        ( "3", TestComplexMessageHandler.ExpectedAction.FailOnNonRepeatable)
                    },
                    0,
                    0,
                    0
                },

                // Fail Some Before/ Some After Non-Repeatable - Should Deadletter
                new object[]
                {
                    "Fail Some Before/After (Deadletter)",
                    false,
                    RetrievePayload(("1","one"),("2","two"), ("3","three"), ("4", "four")),
                    new[]
                    {
                        ( "1", TestComplexMessageHandler.ExpectedAction.FailBeforeNonRepeatable),
                        ( "2", TestComplexMessageHandler.ExpectedAction.FailOnNonRepeatable),
                        ( "3", TestComplexMessageHandler.ExpectedAction.FailAfterNonRepeatable),
                        ( "4", TestComplexMessageHandler.ExpectedAction.FailAfterOtherNonRepeatable)
                    },
                    0,
                    0,
                    1
                },

                // Fail First After Other Non-Repeatable - Should Deadletter
                new object[]
                {
                    "Fail First After (Deadletter)",
                    false,
                    RetrievePayload(("1","one"),("2","two"), ("3","three")),
                    new[] { ( "1", TestComplexMessageHandler.ExpectedAction.FailAfterOtherNonRepeatable) },
                    0,
                    0,
                    1
                },

                // Fail Second Before - Should Deadletter
                new object[]
                {
                    "Fail Second Before (Deadletter)",
                    false,
                    RetrievePayload(("1","one"),("2","two"), ("3","three")),
                    new[] { ( "2", TestComplexMessageHandler.ExpectedAction.FailBeforeNonRepeatable) },
                    0,
                    0,
                    1
                },

                // Fail Last On Non-Repeatable - Should Deadletter
                new object[]
                {
                    "Fail Last On (Deadletter)",
                    false,
                    RetrievePayload(("1","one"),("2","two"), ("3","three")),
                    new[] { ( "3", TestComplexMessageHandler.ExpectedAction.FailOnNonRepeatable) },
                    0,
                    0,
                    1
                },

                // Fail Second After Non-Repeatable - Should Deadletter
                new object[]
                {
                    "Fail Second After (Deadletter)",
                    false,
                    RetrievePayload(("1","one"),("2","two"), ("3","three")),
                    new[] { ( "2", TestComplexMessageHandler.ExpectedAction.FailAfterNonRepeatable) },
                    0,
                    0,
                    1
                },

                // Fail Last After Other Non-Repeatable - Should Deadletter
                new object[]
                {
                    "Fail Last After Other (Deadletter)",
                    false,
                    RetrievePayload(("1","one"),("2","two"), ("3","three")),
                    new[] { ( "3", TestComplexMessageHandler.ExpectedAction.FailAfterOtherNonRepeatable) },
                    0,
                    0,
                    1
                },

            };

        [Theory]
        [MemberData(nameof(ComplexMessageHandlerScenarios))]
        public async Task ComplexMessageHandler_VariousResults(string scenario, bool simulateCancellation, TestComplexPayload payload, (string Identifier, TestComplexMessageHandler.ExpectedAction Action)[] expectedActions, int expectedCompleted, int expectedAbandoned, int expectedDeadLettered)
        {
            // Arrange
            Message message = ToServiceBusMessage(payload, scenario);
            MessageHandler.SetExpectedActions(expectedActions);
            var token = simulateCancellation
                ? new CancellationTokenSource(0).Token
                : new CancellationToken();

            // Act
            await MessageHandler.ProcessMessageAsync(message, MessageReceiver, Logger, token);

            // Assert
            using (new AssertionScope())
            {
                VerifyReceiver(
                    Times.Exactly(expectedCompleted),   // Complete
                    Times.Exactly(expectedAbandoned),   // Abandoned
                    Times.Exactly(expectedDeadLettered) // Dead Lettered
                );
            }
        }
    }
}
