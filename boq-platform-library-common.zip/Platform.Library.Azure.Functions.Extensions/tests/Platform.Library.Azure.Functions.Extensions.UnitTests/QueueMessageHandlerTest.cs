﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using FluentAssertions.Execution;
using Microsoft.Azure.ServiceBus;
using Moq;
using Xunit.Abstractions;

namespace Platform.Library.Azure.Functions.Extensions.UnitTests
{
    public class QueueMessageHandlerTest : BaseMessageHandlerTest
    {
        private TestQueueMessageHandler _handler = null;

        public QueueMessageHandlerTest(ITestOutputHelper outputHelper) : base(outputHelper) { }

        public TestQueueMessageHandler MessageHandler
        {
            get
            {
                if (_handler == null)
                {
                    _handler = new TestQueueMessageHandler(new QueueMessageRetryPolicySettings()
                    {
                        MessageRetryIntervalMinutes = 1,
                        MessageTimeToLiveMinutes = 1
                    });
                }

                return _handler;
            }
        }
        [Fact]
        public async Task QueueMessageHandler_Success()
        {
            // Arrange
            var payload = new TestPayload()
            {
                StringProperty = "Tada"
            };

            Message message = ToServiceBusMessage(payload, "Test");

            // Act
            await MessageHandler.ProcessMessageAsync(message, MessageReceiver, Logger, CancellationToken.None);

            // Assert
            using (new AssertionScope())
            {
                VerifyReceiver(
                    Times.Once(),   // Complete
                    Times.Never(),  // Abandoned
                    Times.Never()   // Dead Lettered
                );
            }
        }

        [Fact]
        public async Task QueueMessageHandler_UnrecoverableException()
        {
            // Arrange
            MessageHandler.ReturnUnrecoverable();

            var payload = new TestPayload()
            {
                StringProperty = "Tada"
            };

            Message message = ToServiceBusMessage(payload, "Test");

            // Act
            await MessageHandler.ProcessMessageAsync(message, MessageReceiver, Logger, CancellationToken.None);

            // Assert
            using (new AssertionScope())
            {
                VerifyReceiver(
                    Times.Never(),  // Complete
                    Times.Never(),  // Abandoned
                    Times.Once()    // Dead Lettered
                );
            }
        }

        [Fact]
        public async Task QueueMessageHandler_MessageDeserializeException()
        {
            // Arrange
            MessageHandler.ReturnDeserializeFailed();

            var payload = new TestPayload()
            {
                StringProperty = "Tada"
            };

            Message message = ToServiceBusMessage(payload, "Test");

            // Act
            await MessageHandler.ProcessMessageAsync(message, MessageReceiver, Logger, CancellationToken.None);

            // Assert
            using (new AssertionScope())
            {
                VerifyReceiver(
                    Times.Never(),  // Complete
                    Times.Never(),  // Abandoned
                    Times.Once()    // Dead Lettered
                );
            }
        }


        [Fact(Skip = "Unable to mock QueueClient for this scenario")]
        public async Task QueueMessageHandler_UnexpectedException()
        {
            // Arrange
            MessageHandler.ReturnCustom();

            var payload = new TestPayload()
            {
                StringProperty = "Tada"
            };

            Message message = ToServiceBusMessage(payload, "Test");

            // Act
            await MessageHandler.ProcessMessageAsync(message, MessageReceiver, Logger, CancellationToken.None);

            // Assert
            using (new AssertionScope())
            {
                VerifyReceiver(
                    Times.Once(),   // Complete
                    Times.Never(),  // Abandoned
                    Times.Never()   // Dead Lettered
                );
            }
        }


        [Fact(Skip = "Unable to mock QueueClient for this scenario")]
        public async Task QueueMessageHandler_CustomHandling()
        {
            // Arrange
            MessageHandler.ReturnCustom();

            var payload = new TestPayload()
            {
                StringProperty = "Tada"
            };

            Message message = ToServiceBusMessage(payload, "Test");

            // Act
            await MessageHandler.ProcessMessageAsync(message, MessageReceiver, Logger, CancellationToken.None);

            // Assert
            using (new AssertionScope())
            {
                VerifyReceiver(
                    Times.Never(),  // Complete
                    Times.Once(),   // Abandoned
                    Times.Never()   // Dead Lettered
                );
            }
        }

    }
}