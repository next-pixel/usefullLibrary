[![Target Framework](https://img.shields.io/badge/Target%20Framework:-netstandard2.1-blue.svg?style=plastic&logo=dotnet)](https://shields.io/)
[![Platform.Library.Azure.Functions.Extensions package in Development feed in Azure Artifacts](https://feeds.dev.azure.com/qdigitalcode/_apis/public/Packaging/Feeds/Development/Packages/bf4673d0-07d9-42eb-a0ec-1139b0dd9aaa/Badge)](https://dev.azure.com/qdigitalcode/DenovoBank/_artifacts/feed/Development/NuGet/Platform.Library.Azure.Functions.Extensions)
[![Quality Gate Status](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Azure.Functions.Extensions&metric=alert_status&token=sqb_58069e20f6ce5e55c46c2f6b26e229e4ab8cc8a0)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Azure.Functions.Extensions)
[![Coverage](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Azure.Functions.Extensions&metric=coverage&token=sqb_58069e20f6ce5e55c46c2f6b26e229e4ab8cc8a0)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Azure.Functions.Extensions)

[![Bugs](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Azure.Functions.Extensions&metric=bugs&token=sqb_58069e20f6ce5e55c46c2f6b26e229e4ab8cc8a0)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Azure.Functions.Extensions)
[![Code Smells](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Azure.Functions.Extensions&metric=code_smells&token=sqb_58069e20f6ce5e55c46c2f6b26e229e4ab8cc8a0)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Azure.Functions.Extensions)
[![Security Hotspots](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Azure.Functions.Extensions&metric=security_hotspots&token=sqb_58069e20f6ce5e55c46c2f6b26e229e4ab8cc8a0)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Azure.Functions.Extensions)
[![Vulnerabilities](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Azure.Functions.Extensions&metric=vulnerabilities&token=sqb_58069e20f6ce5e55c46c2f6b26e229e4ab8cc8a0)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Azure.Functions.Extensions)

# Platform.Library.Azure.Functions.Extensions
Core platform library that must be referenced by all Function Apps

## Instructions

# Dependencies
- [Platform.Library.Common](https://dev.azure.com/qdigitalcode/DenovoBank/_git/Platform.Library.Common) [![Platform.Library.Common package in Development feed in Azure Artifacts](https://feeds.dev.azure.com/qdigitalcode/_apis/public/Packaging/Feeds/Development/Packages/bf4673d0-07d9-42eb-a0ec-1139b0dd9aaa/Badge)](https://dev.azure.com/qdigitalcode/DenovoBank/_artifacts/feed/Development/NuGet/Platform.Library.Common) - Core reference to access common platform libraries
- [Microsoft.Extensions.DependencyInjection 6.0.0](https://www.nuget.org/packages/Microsoft.Extensions.DependencyInjection/6.0.0)

# Consumers
- All subscribers should depend on this library

# IMPORTANT NOTE
In order to address the issue of ""too many open connections" causing subscribers to simply stop processing, a reference to the latest version of [Microsoft.Azure.WebJobs.Extensions.ServiceBus 5.8.1](https://www.nuget.org/packages/Microsoft.Azure.WebJobs.Extensions.ServiceBus/5.8.1)
is required. This version however breaks away from using [Microsoft.Azure.ServiceBus 4.2.1](https://www.nuget.org/packages/Microsoft.Azure.ServiceBus/4.2.1) which we are using for our messaging and replaces it with [Azure.Messaging.ServiceBus 7.11.1](https://www.nuget.org/packages/Azure.Messaging.ServiceBus/)
which we are **not yet ready to migrate to**. In order to retain current functionality a manual reference to [Microsoft.Azure.ServiceBus 5.2.0](https://www.nuget.org/packages/Microsoft.Azure.ServiceBus/5.2.0) has been added to be exposed in place
of it now missing from the extension libary.