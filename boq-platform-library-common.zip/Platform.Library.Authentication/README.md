[![Target Framework](https://img.shields.io/badge/Target%20Framework:-netstandard2.1-blue.svg?style=plastic&logo=dotnet)](https://shields.io/)
[![Build Status](https://dev.azure.com/qdigitalcode/DenovoBank/_apis/build/status/Platform.Library.Authentication?repoName=Platform.Library.Authentication&branchName=master)](https://dev.azure.com/qdigitalcode/DenovoBank/_build/latest?definitionId=1358&repoName=Platform.Library.Authentication&branchName=master)
[![Platform.Library.Authentication package in Development feed in Azure Artifacts](https://feeds.dev.azure.com/qdigitalcode/_apis/public/Packaging/Feeds/Development/Packages/c8f38315-90e8-4ac9-92ca-ee306ea65281/Badge)](https://dev.azure.com/qdigitalcode/DenovoBank/_artifacts/feed/Development/NuGet/Platform.Library.Authentication)

[![Quality Gate Status](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Authentication&metric=alert_status&token=aeff27f063bba219dbe9e1620cb3fe32a3f08316)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Authentication)
[![Coverage](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Authentication&metric=coverage&token=aeff27f063bba219dbe9e1620cb3fe32a3f08316)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Authentication)

[![Bugs](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Authentication&metric=bugs&token=aeff27f063bba219dbe9e1620cb3fe32a3f08316)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Authentication)
[![Code Smells](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Authentication&metric=code_smells&token=aeff27f063bba219dbe9e1620cb3fe32a3f08316)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Authentication)
[![Security Hotspots](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Authentication&metric=security_hotspots&token=aeff27f063bba219dbe9e1620cb3fe32a3f08316)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Authentication)
[![Vulnerabilities](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Authentication&metric=vulnerabilities&token=aeff27f063bba219dbe9e1620cb3fe32a3f08316)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Authentication)

# Platform.Library.Authentication

## Description
Library providing Authentication capabilities through the use of Guards as well as tools for handling encryption and decryption.

## Features

The library builds up a sequential list of "guards" to apply when verifying authorization. Guards verify discreet pieces of authorization such as => Bearer Token => Valid RSA signature => Valid Issuer => Token not expired

The list is configured via the GuardBuilder. The builder is created in the DI container with standard configuration and then injected into controllers for further configuration and execution.

Types of Encryption/Decryption capabilities:
- PGP

### Default Authentication Profiles

The library provide standard authentication types for a variety of usage. For preference and security reasons, those profile should be used since their will set the minimal security standard for the API.

Please check below the list of authentication types and 

**Common Guards** (always applicable when `Type != None`):
- HasAuthHeader
- HasValidIssuer
- HasValidToken
- HasNotExpired

| **Authentication Type** | **Propose**                                                                                                                                      | **Security Level** | **Baseline Guards**                                                                                                                                                                                                                                                                  |
|-------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------|--------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `None`                  | App needs to have full control of the authentication guards or no authentication at all.                                                         | Low                |                                                                                                                                                                                                                                                                                      |
| `CustomerToken`         | All is customer focused, require valid CIAM token with min L2.                                                                                   | High               | - HasAtLeastTokenLevelOf(L2)                                                                                                                                                                                                                                                         |
| `CiamToken`             | When at least a CIAM valid token must be provided.<br>The app may decide if token level should be set or any other guard.                        | Medium             | _All required is part of common guards_                                                                                                                                                                                                                                              |
| `CiamOrAdToken`         | When at least a CIAM or Azure Ad token must be provided.<br>The app may decide if token level should be set or any other guard.                  | Medium             | - IsManagedIdentityToken (IssuedBy: AzureAd, TokenType: ManagedIdentity)<br>- HasValidExternalAudience (IssuedBy: AzureAd, TokenType: AzureAdExternal)                                                                                                                               |
| `CustomerOrAdToken`     | All is customer focused, require valid CIAM token with min L2.<br>For AzureAd, it requires extra header with CIF and token level to be provided. | High               | - IsManagedIdentityToken (IssuedBy: AzureAd, TokenType: ManagedIdentity)<br>- HasValidExternalAudience (IssuedBy: AzureAd, TokenType: AzureAdExternal)<br>- HasCustomerHeader (IssuedBy: AzureAd)<br>- HasAzureAdAuthLevelHeader (IssuedBy: AzureAd)<br>- HasAtLeastTokenLevelOf(L2) |
| `AdToken`               | When at least an Azure Ad valid token must be provided.<br>The app may decide if token level should be set or any other guard.                   | Medium             | - IsManagedIdentityToken (IssuedBy: AzureAd, TokenType: ManagedIdentity)<br>- HasValidExternalAudience (IssuedBy: AzureAd, TokenType: AzureAdExternal)                                                                                                                               |

### Adding new guards to the validation queue

Doing the MS DI registration, any extra guard can be included to allow customisation and increase the security.

> Be cautious, the guard is transient and a new guard builder is generated for the given request.

Example:
> **Given** the web app will accept any valid CIAM or AzureAd token.<br />
> **Do** include an extra guard to validate the CIAM tokens to be at least L2

```csharp
services.ConfigureAuthentication(
    AuthenticationType.CiamOrAdToken,
    inDebug: false,
    componentConfigName: "component-config-name",
    configureGuard: (builder, standardGuards, serviceProvider) =>
    {
        builder.WithGuard(i => i.IssuedBy == IssuedBy.CIAM, standardGuards.HasAtLeastTokenLevelOf(TokenLevel.L2));
    }
);
```

### Writing custom guards
Just like an interface contract guards are simply the conformance to a method signature 

```
Func<AuthenticationContext, CancellationToken, Task<AuthenticationContext>>
```
To assist in dev an aid readability a `GuardTask` delegate is used. 

Instead of:
```csharp
Func<AuthenticationContext, CancellationToken, Task<AuthenticationContext>> MyGuard(string args)
```
Use This: 
```csharp
GuardTask MyGuard(string args)
```

### Notes on Guards

**Note** double check return paths. Make sure you either return the context or you return ```context.FailedAuthentication()```

**Note** guards are async all the way down

**Note** guards support cancellation tokens for long running tasks 

**Note** guards can exit early via a config on the ```.Execute()```

**Note**: **As the list gets executed in sequential order the order you add new items to the chain matters.**

#### Example Custom Guard

[In custom guard class]
```csharp
/// <summary>
/// Explain what it does
/// </summary>
public GuardTask MyGuard(string anyargs) => async (context, token) =>
{
    _logger.LogInformation($"Executing authentication check token[{nameof(MyGuard)}]");

    if (context.Principal.HasClaim(name, value) == false)
    {
        return context.FailedAuthentication($"Unable to match claim '{name}' - '{value}'");
    }

    return context;
};
```
[In controller class]
```csharp
var context = await guard
    .WithGuard(customGuard.MyGuard)
    .Execute();
```

## Dependencies
- [Platform.Library.Common](https://dev.azure.com/qdigitalcode/DenovoBank/_git/Platform.Library.Common) **(PRIVATE)** : Error handling and Http resources
- [Platform.Library.Http](https://dev.azure.com/qdigitalcode/DenovoBank/_git/Platform.Library.Http) : `ClientSettings` and `HttpClient` registration

## Consumers
- All APIs should be using this library to include `IGuardBuilder` to verify security context of caller

# Version & Change Control Gaps

## Description
A gap between this package version 1.0.22 and 1.0.23 has been found (10 months) where certain code changes made it to version 1.0.23 that may not be working as intended.

Searching for package version reference in *.csproj files (master) across both `BoqGroupNonProd\BOQ Group Denovo Development` & `qdigitalcode/DenovoBank`

- [Search BOQ Group Denovo Development](https://dev.azure.com/BOQGroupNonProd/BOQ%20Group%20Denovo%20Development/_search?action=contents&text=%22Platform.Library.Authentication%22%20Version%3D%221.0.&type=code&lp=dashboard-Project&filters=ProjectFilters%7BBOQ%20Group%20Denovo%20Development%7D&pageSize=25&result=DefaultCollection/BOQ%20Group%20Denovo%20Development/Loyalty/GBmaster//src/Loyalty.csproj)
- [Search DenovoBank](https://dev.azure.com/qdigitalcode/DenovoBank/_search?action=contents&text=%22Platform.Library.Authentication%22%20Version%3D%221.0.&type=code&lp=dashboard-Project&filters=ProjectFilters%7BDenovoBank%7D&pageSize=25&result=DefaultCollection/DenovoBank/Customer.Identity/GBmaster//src/CustomerIdentity.csproj)

## Breaking Changes

### **01/03/2024**

#### IGuardBuilder

The `WithGuard` method's signature was updated to return the interface instead of the class. 

It won't affect the functionality, but for those project where there is an implementation of the `IGuardBuilder` in the unit testing [like this](https://dev.azure.com/qdigitalcode/DenovoBank/_git/PaymentsLookup?path=/PaymentsLookup.UnitTests/MockGuardBuilder.cs&version=GBmaster&line=25&lineEnd=26&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents). The developer will need to update from `GuardBuilder` to `IGuardBuilder`

Example:

```diff
public class MockGuardBuilder : IGuardBuilder
{
-    public GuardBuilder WithGuard(GuardTask item)
+    public IGuardBuilder WithGuard(GuardTask item)
    {
        return new GuardBuilder(_loggerFactory.CreateLogger<AuthenticationContext>());
    }

-    public GuardBuilder WithGuard(Func<IAuthenticationContext, bool> predicate, GuardTask item)
+    public IGuardBuilder WithGuard(Func<IAuthenticationContext, bool> predicate, GuardTask item)    
    {
        return WithGuard(item);
    }
    
    public Task<IAuthenticationContext> Execute(
      CancellationToken? token = null,
      bool throwOnAuthenticationFailure = true,
      bool returnGenericErrorMessages = false)
    {
        ...
    }
}
```

#### IAuthenticationContext.Headers

It was created using the wrong casing (all lower case instead of PascalCase).
For those cases there this property is being used, the developer needs to change the casing to `Headers` instead.

Example:

```diff
var response = await _httpClientHelper.GetAsync<GetMerchantResponse>(
        InternalConstants.Configuration.HttpClients.CustomerPfm,
        UrlBuilder.Build(_customerPfmSettings.GetMerchantsPath, GetMerchantDetailsQuery(transaction)),
        new Dictionary<string, string>
        {
-            {"Authorization", context.headers["Authorization"]}
+            {"Authorization", context.Headers["Authorization"]}            
        },
        standardHeaders,
        cancellationToken);
```

#### IAuthenticationContext with private methods

As per this version, the private `set` for the `IAuthenticationContext` will be visible for the Moq proxy.
As result, the `IAuthenticationContext` is fully mockable and there is no requirement of creating additional testing interfaces like:

```diff
// Not required anymore, just mock the interface directly.
-  public interface IMockAuthenticationContext : IAuthenticationContext
-  {
-      public new TokenLevel TokenLevel { get; set; }
-  }
  
  public class MyTest
  {
      public MyTest()
      {
-          var authContext = new Mock<IMockAuthenticationContext>();
+          var authContext = new Mock<IAuthenticationContext>();
  
          // Auth Setup
          authContext.Setup(c => c.Temenos_cif).Returns(CustomerId);                     
          authContext.Setup(a => a.RawJwtToken).Returns(PreprocessCreditPaymentHandlerBlueprints.AuthorizationWithCiti);
      }
  }
```

## Change Log

- **01/03/2024:** (Minor Breaking Change - vide previous section)
  - Update the baseline guards per authentication types
  - Include new TokenType (AzureAdExternal) to cater external parties with valid AzureAd token
  - Include `HasValidExternalAudience` guard to validate the audience against a configurable list
  - Introduced the settings `AzureAd:ExternalAudiences` with a dictionary object providing the audience name and pattern (Regex)


## Package Versions & Project Usage

| Package Version | Release Date   | Used in Project                                                                                                                                                                                                                   |
|-----------------|----------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.0.23          | 28 September   | ...                                                                                                                                                                                                                               |
|                 |                | [HelpServicing](https://dev.azure.com/qdigitalcode/DenovoBank/_git/HelpServicing?path=/src/HelpServicing.csproj&_a=contents&version=GBmaster)                                                                                     |
| 1.0.22          | 6 January 2021 | ...                                                                                                                                                                                                                               |
|                 |                | [DocumentApi](https://dev.azure.com/qdigitalcode/DenovoBank/_git/Document?path=/src/DocumentApi.csproj&_a=contents&version=GBmaster)                                                                                              |
|                 |                | [OpenBanking](https://dev.azure.com/qdigitalcode/DenovoBank/_git/cue-open-banking-orch?path=/src/OpenBanking.csproj&_a=contents&version=GBmaster)                                                                                 |
|                 |                | [ScheduledPaymentsAPI](https://dev.azure.com/qdigitalcode/DenovoBank/_git/ScheduledPayments?path=/src/ScheduledPaymentsAPI.csproj&_a=contents&version=GBmaster)                                                                   |
|                 |                | [PaymentsLookupApi](https://dev.azure.com/qdigitalcode/DenovoBank/_git/PaymentsLookup?path=/src/PaymentsLookupApi.csproj&_a=contents&version=GBmaster)                                                                            |
|                 |                | [PaymentInitiationApi](https://dev.azure.com/qdigitalcode/DenovoBank/_git/PaymentInitiation?path=/src/PaymentInitiationApi.csproj&_a=contents&version=GBmaster)                                                                   |
|                 |                | [PaymentLimitsApi](https://dev.azure.com/qdigitalcode/DenovoBank/_git/PaymentLimits.Api?path=/src/PaymentLimitsApi.csproj&_a=contents&version=GBmaster)                                                                           |
| 1.0.21          | 15 July 2020   | ...                                                                                                                                                                                                                               |
|                 |                | [Loyalty](https://dev.azure.com/BOQGroupNonProd/BOQ%20Group%20Denovo%20Development/_git/Loyalty?path=/src/Loyalty.csproj&_a=contents&version=GBmaster)                                                                            |
|                 |                | [CustomerIdentity](https://dev.azure.com/qdigitalcode/DenovoBank/_git/Customer.Identity?path=/src/CustomerIdentity.csproj&_a=contents&version=GBmaster)                                                                           |
|                 |                | [CustomerAccountApi](https://dev.azure.com/qdigitalcode/DenovoBank/_git/CustomerAccount?path=/src/CustomerAccountApi.csproj&_a=contents&version=GBmaster)                                                                         |
|                 |                | [CommunicationApi](https://dev.azure.com/qdigitalcode/DenovoBank/_git/Communication?path=/src/CommunicationApi.csproj&_a=contents&version=GBmaster)                                                                               |
|                 |                | [ChatApi](https://dev.azure.com/qdigitalcode/DenovoBank/_git/Chat.Api?path=/src/ChatApi.csproj&_a=contents&version=GBmaster)                                                                                                      |
|                 |                | [CustomerProfileApi](https://dev.azure.com/qdigitalcode/DenovoBank/_git/CustomerProfile?path=/src/CustomerProfileApi.csproj&_a=contents&version=GBmaster)                                                                         |
|                 |                | [HomeLoanMgmtApi](https://dev.azure.com/qdigitalcode/DenovoBank/_git/HomeLoanMgmt?path=/src/HomeLoanMgmtApi.csproj&_a=contents&version=GBmaster)                                                                                  |
|                 |                | [Customer.Pfm](https://dev.azure.com/qdigitalcode/DenovoBank/_git/Customer.Pfm?path=/src/Customer.Pfm.csproj&_a=contents&version=GBmaster)                                                                                        |
|                 |                | [ReferenceDataApi](https://dev.azure.com/qdigitalcode/DenovoBank/_git/ReferenceData?path=/src/ReferenceDataApi.csproj&_a=contents&version=GBmaster)                                                                               |
|                 |                | [PaymentApi](https://dev.azure.com/qdigitalcode/DenovoBank/_git/Payment.Npp?path=/src/PaymentApi.csproj&_a=contents&version=GBmaster)                                                                                             |
|                 |                | [CustomerProfile.Tests](https://dev.azure.com/qdigitalcode/DenovoBank/_git/CustomerProfile?path=/Tests.Unit/CustomerProfile.Tests.csproj&_a=contents&version=GBmaster)                                                            |
|                 |                | [CustomerProfile.Downstream.TestServer](https://dev.azure.com/qdigitalcode/DenovoBank/_git/CustomerProfile?path=/CustomerProfile.Downstream.TestServer/CustomerProfile.Downstream.TestServer.csproj&_a=contents&version=GBmaster) |
|                 |                | [CustomerProfile.Dtos](https://dev.azure.com/qdigitalcode/DenovoBank/_git/CustomerProfile?path=/CustomerProfile.Dtos/CustomerProfile.Dtos.csproj&_a=contents&version=GBmaster)                                                    |
|                 |                | [CustomerProfile.Tests.Integration](https://dev.azure.com/qdigitalcode/DenovoBank/_git/CustomerProfile?path=/Tests.Integration/CustomerProfile.Tests.Integration.csproj&_a=contents&version=GBmaster)                             |
| 1.0.20          | 15 July 2020   | Not used                                                                                                                                                                                                                          |
| 1.0.19          | 9 July 2020    | Not used                                                                                                                                                                                                                          |
| 1.0.18          | 9 July 2020    | Not used                                                                                                                                                                                                                          |
| 1.0.17          | 26 May 2020    | ...                                                                                                                                                                                                                               | 
|                 |                | [DebitCard](https://dev.azure.com/qdigitalcode/DenovoBank/_git/DebitCard?path=/src/DebitCard.csproj&_a=contents&version=GBmaster)                                                                                                 |
|                 |                | [CustomerTransaction](https://dev.azure.com/qdigitalcode/DenovoBank/_git/CustomerTransaction?path=/src/CustomerTransaction.csproj&_a=contents&version=GBmaster)                                                                   |
|                 |                | [ManageAddressBookApi](https://dev.azure.com/qdigitalcode/DenovoBank/_git/ManageAddressBook?path=/src/ManageAddressBookApi.csproj&_a=contents&version=GBmaster)                                                                   |
| 1.0.16          | 25 May 2020    | Not used                                                                                                                                                                                                                          |

The following projects are in the BOQGroupNonProd - probably left over's as some have been transitioned to `qdigitalcode\DenovoBank`

| Package Version | Used in Project                                                                                                                                                                            |
|-----------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.0.22          | ...                                                                                                                                                                                        |
|                 | [OpenBanking](https://dev.azure.com/BOQGroupNonProd/BOQ%20Group%20Denovo%20Development/_git/OpenBanking?path=/src/OpenBanking.csproj&_a=contents&version=GBmain)                           |
|                 | [DocumentApi](https://dev.azure.com/BOQGroupNonProd/BOQ%20Group%20Denovo%20Development/_git/Document?path=/src/DocumentApi.csproj&_a=contents&version=GBmaster)                            |
|                 | [PaymentInitiationApi](https://dev.azure.com/BOQGroupNonProd/BOQ%20Group%20Denovo%20Development/_git/PaymentInitiation?path=/src/PaymentInitiationApi.csproj&_a=contents&version=GBmaster) |
| 1.0.21          | ...                                                                                                                                                                                        |
|                 | [Loyalty](https://dev.azure.com/BOQGroupNonProd/BOQ%20Group%20Denovo%20Development/_git/Loyalty?path=/src/Loyalty.csproj&_a=contents&version=GBmaster)                                     |
|                 | [CommunicationApi](https://dev.azure.com/BOQGroupNonProd/BOQ%20Group%20Denovo%20Development/_git/Communication?path=/src/CommunicationApi.csproj&_a=contents&version=GBmaster)             |
|                 | [ChatApi](https://dev.azure.com/BOQGroupNonProd/BOQ%20Group%20Denovo%20Development/_git/Chat.Api?path=/src/ChatApi.csproj&_a=contents&version=GBmaster)                                    |
|                 | [Customer.Pfm](https://dev.azure.com/BOQGroupNonProd/BOQ%20Group%20Denovo%20Development/_git/Customer.Pfm?path=/src/Customer.Pfm.csproj&_a=contents&version=GBmaster)                      |
|                 | [PaymentApi](https://dev.azure.com/BOQGroupNonProd/BOQ%20Group%20Denovo%20Development/_git/Payment.Npp?path=/src/PaymentApi.csproj&_a=contents&version=GBmaster)                           |
|                 | [ScheduledPaymentsAPI](https://dev.azure.com/BOQGroupNonProd/BOQ%20Group%20Denovo%20Development/_git/ScheduledPayments?path=/src/ScheduledPaymentsAPI.csproj&_a=contents&version=GBmaster) |
| 1.0.17          | ...                                                                                                                                                                                        |
|                 | [DebitCard](https://dev.azure.com/BOQGroupNonProd/BOQ%20Group%20Denovo%20Development/_git/DebitCard?path=/src/DebitCard.csproj&_a=contents&version=GBmaster)                               |
|                 | [TemplateApi](https://dev.azure.com/BOQGroupNonProd/BOQ%20Group%20Denovo%20Development/_git/Templates?path=/AppService/src/TemplateApi.csproj&_a=contents&version=GBmaster)                |
|                 | [CustomerTransaction](https://dev.azure.com/BOQGroupNonProd/BOQ%20Group%20Denovo%20Development/_git/CustomerTransaction?path=/src/CustomerTransaction.csproj&_a=contents&version=GBmaster) |
| 1.0.4           | very stale                                                                                                                                                                                 |
|                 | [SampleApi](https://dev.azure.com/BOQGroupNonProd/BOQ%20Group%20Denovo%20Development/_git/SampleNamespace.SampleApi?path=/src/SampleApi.csproj&_a=contents&version=GBmaster)               |
