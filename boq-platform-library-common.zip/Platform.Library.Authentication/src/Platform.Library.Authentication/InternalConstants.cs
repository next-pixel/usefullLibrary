﻿namespace Platform.Library.Authentication
{
    internal static class InternalConstants
    {
        /// <summary>
        /// ConfigurationManager Metadata Address
        /// </summary>
        internal const string StsDiscoveryEndpoint = "https://login.microsoftonline.com/common/v2.0/.well-known/openid-configuration";
        internal const string TimestampFormat = "yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'";
        internal const string BearerPrefix = "Bearer ";

        internal static class HttpClients
        {
            internal const string CIAM = nameof(CIAM);
            internal const string CertificateClient = "CIAM_CertificateFetcher";
        }

        /// <summary>
        /// App config path
        /// </summary>
        internal static class ConfigSections
        {
            /// <summary>
            /// Azure Ad Path Settings
            /// </summary>
            public const string AzureAd = nameof(AzureAd);

            /// <summary>
            /// CIAM Path Settings
            /// </summary>
            public const string CIAM = nameof(CIAM);
        }

        internal static class Algorithms
        {
            internal const string RS256 = "RS256";
        }

        internal static class Usage
        {
            internal const string Signature = "sig";
        }

        internal static class ClaimType
        {
            internal const string Subject = "sub";
            internal const string Issuer = "iss";
            internal const string Audience = "aud";
            internal const string QualityAssurance = "is_sqa_enabled";
            internal const string TemenosCIF = "temenos_cif";
            internal const string CitiLinkingStatus = "citi_linking_status";
            internal const string AuthLevel = "auth_level";
            internal const string CountryCode2 = "iso3166_2";

            internal static string MfaMethod(int value) => $"mfa_method.{value}";
        }

        internal static class CountryCode
        {
            internal const string Australia = "AU";
        }
    }

    internal static class CurrentSystem
    {
        internal const string Id = "Platform.Library.Authentication";
        internal const string Version = "1";
    }
}
