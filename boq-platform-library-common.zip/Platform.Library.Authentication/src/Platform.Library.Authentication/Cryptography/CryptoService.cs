using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Logging;

namespace Platform.Library.Authentication
{
    /// <inheritdoc cref="ICryptoService"/>
    public class CryptoService : ICryptoService
    {
        private readonly ILogger<ICryptoService> _logger;

        public CryptoService(ILogger<ICryptoService> logger)
        {
            _logger = logger;
        }

        /// <inheritdoc cref="ICryptoService.Encrypt(string, string)"/>
        public string Encrypt(string publicKeyPem, string plainText)
        {
            var rsa = RSA.Create();
            rsa.ImportSubjectPublicKeyInfo(Convert.FromBase64String(publicKeyPem.StripForPublicKey()), out _);

            var encryptedBytes = rsa.Encrypt(
                Encoding.UTF8.GetBytes(plainText),
                RSAEncryptionPadding.Pkcs1
            );

            return Convert.ToBase64String(encryptedBytes);
        }

        /// <inheritdoc cref="ICryptoService.Decrypt(string, string)"/>
        public string Decrypt(string privateKeyPem, string encryptedText)
        {
            var rsa = RSA.Create();
            rsa.ImportPkcs8PrivateKey(Convert.FromBase64String(privateKeyPem.StripForPrivateKey()), out _);

            var decryptedBytes = rsa.Decrypt(
                Convert.FromBase64String(encryptedText),
                RSAEncryptionPadding.Pkcs1
            );

            return Encoding.UTF8.GetString(decryptedBytes);
        }

        /// <inheritdoc cref="ICryptoService.TryDecrypt"/>
        public bool TryDecrypt(string privateKeyPem, string encryptedText, out string decryptedText)
        {
            try
            {
                decryptedText = Decrypt(privateKeyPem, encryptedText);
                return true;
            }
            // It is a try attempt, for any fails just back out and return false
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "TryDecrypt Method has failed due to: {ErrorMessage}", ex.Message);
                decryptedText = default;
                return false;
            }
        }

        /// <inheritdoc cref="ICryptoService.TryDecryptAes"/>
        public bool TryDecryptAes(string aesKey, string encryptedText, out string decryptedText)
        {
            try
            {
                decryptedText = DecryptAES(aesKey, encryptedText);
                return true;
            }
            // It is a try attempt, for any fails just back out and return false
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "TryDecryptAes Method has failed due to: {ErrorMessage}", ex.Message);
                decryptedText = default;
                return false;
            }
        }

        /// <inheritdoc cref="ICryptoService.EncryptAES(string, string)"/>
        public string EncryptAES(string aesKey, string plainText)
        {
            byte[] toEncrypt = Encoding.UTF8.GetBytes(plainText);
            byte[] key = Encoding.UTF8.GetBytes(aesKey);

            byte[] encryptedData;

            using (Rijndael aes = Rijndael.Create())
            {
                aes.Key = key;
                aes.IV = GenerateIV(aes.IV[..8]);
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;

                ICryptoTransform encryptor = aes.CreateEncryptor();
                using (MemoryStream mStream = new MemoryStream())
                {
                    using (CryptoStream cStream = new CryptoStream(mStream, encryptor, CryptoStreamMode.Write))
                    {
                        cStream.Write(toEncrypt, 0, toEncrypt.Length);
                        cStream.FlushFinalBlock();
                        // prepend the IV to the stream
                        // when decrypting the first 8 bytes will be the IV
                        encryptedData = Merge(aes.IV[..8], mStream.ToArray());
                    }
                }
            }

            return Convert.ToBase64String(encryptedData);
        }

        /// <inheritdoc cref="ICryptoService.DecryptAES(string, string)"/>
        public string DecryptAES(string aesKey, string base64EncodedString)
        {
            byte[] cipherText = Convert.FromBase64String(base64EncodedString);
            byte[] key = Encoding.UTF8.GetBytes(aesKey);

            string plaintext = null;

            using (Rijndael aes = Rijndael.Create())
            {
                aes.Key = key;
                aes.Padding = PaddingMode.PKCS7;

                // the IV is {cipherText[0:8]}{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}
                aes.IV = GenerateIV(cipherText[..8]);

                // the rest of the content is the actual cipher
                cipherText = cipherText[8..][..(cipherText.Length - 8)];

                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                // Create the streams used for decryption.
                using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {
                            plaintext = srDecrypt.ReadToEnd();
                        }
                    }
                }

            }

            return plaintext;
        }
        /// <summary>
        /// Create a vector of bytes of length 16, where the initialVector will
        /// be copied to the start of the result array. The rest of the bytes
        /// will be default 0x00
        /// </summary>
        /// <param name="initialVector"></param>
        /// <returns></returns>
        private byte[] GenerateIV(byte[] initialVector)
        {
            var result = new byte[16];

            var iterTo = Math.Min(initialVector.Length, 16);
            for (int i = 0; i < iterTo; i++)
            {
                result[i] = initialVector[i];
            }

            return result;
        }

        private byte[] Merge(byte[] first, byte[] second)
        {
            var target = new byte[first.Length + second.Length];
            Array.Copy(first, 0, target, 0, first.Length);
            Array.Copy(second, 0, target, first.Length, second.Length);
            return target;
        }
    }
}
