﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Platform.Library.Authentication
{
    /// <summary>
    /// Provides cryptography functionality
    /// </summary>
    public interface ICryptoService
    {
        /// <summary>
        /// Encrypt using a RSA private key
        /// </summary>
        /// <param name="privateKeyPem"></param>
        /// <param name="encryptedText"></param>
        /// <returns>Base64 encoded string</returns>
        string Decrypt(string privateKeyPem, string encryptedText);

        /// <summary>
        /// Decrypt using a RSA public key
        /// </summary>
        /// <param name="publicKeyPem"></param>
        /// <param name="plainText">Base64 encoded string</param>
        /// <returns></returns>
        string Encrypt(string publicKeyPem, string plainText);

        /// <summary>
        /// Attempt to Decrypt the input data, returning false if a CryptographicException is thrown/decryption failed.
        /// </summary>
        /// <param name="privateKeyPem"></param>
        /// <param name="encryptedText">Base64 encoded string</param>
        /// <param name="decryptedText">Decryption result</param>
        /// <returns>A Boolean to represent the state of the input value.</returns>
        bool TryDecrypt(string privateKeyPem, string encryptedText, out string decryptedText);

        /// <summary>
        /// Attempt to Decrypt the input data, returning false if an Exception is thrown/decryption failed.
        /// </summary>
        /// <param name="aesKey"></param>
        /// <param name="encryptedText">Base64 encoded string</param>
        /// <param name="decryptedText">Decryption result</param>
        /// <returns>A Boolean to represent the state of the input value.</returns>
        bool TryDecryptAes(string aesKey, string encryptedText, out string decryptedText);

        /// <summary>
        /// Encrypt plain text using an AES key
        /// Prepends a 16 byte IV before the actual cipher
        /// </summary>
        /// <param name="aesKey">Max 256 bits</param>
        /// <param name="plainText"></param>
        /// <returns>Base64 encoded string</returns>
        string EncryptAES(string aesKey, string plainText);

        /// <summary>
        /// Decrypt using an AES key
        /// Uses the first 16 bytes as the IV
        /// </summary>
        /// <param name="aesKey">Max 256 bits</param>
        /// <param name="base64EncodedString"></param>
        /// <returns></returns>
        string DecryptAES(string aesKey, string base64EncodedString);
    }
}
