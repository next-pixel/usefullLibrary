﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Platform.Library.Authentication.Configuration;
using Platform.Library.Authentication.Models;
using Platform.Library.Authentication.Models.Abstractions;
using Platform.Library.Common.Standard.ErrorHandling;

namespace Platform.Library.Authentication.Guards
{
    /// <summary>
    /// Fluent API for adding auth guards to services 
    /// </summary>
    public class GuardBuilder : IGuardBuilder
    {
        private readonly ILogger<AuthenticationContext> _logger;
        private readonly Queue<(Func<IAuthenticationContext,bool> Predicate, GuardTask GuardTask)> _guardQueue = new();
        private IAuthenticationContext _context;

        /// <summary>
        /// Initializes a new instance of the <see cref="GuardBuilder"/> class.
        /// </summary>
        /// <param name="standardAuthorizationSettings"></param>
        /// <param name="logger"></param>
        [Obsolete("Please use other constructor without IStandardAuthorizationSettings", false)]
        public GuardBuilder(
            IStandardAuthorizationSettings standardAuthorizationSettings,
            ILogger<AuthenticationContext> logger
        ) 
            : this(logger)
        { }

        /// <summary>
        /// Initializes a new instance of the <see cref="GuardBuilder"/> class.
        /// </summary>
        /// <param name="standardAuthorizationSettings"></param>
        /// <param name="context"></param>
        /// <param name="logger"></param>
        [Obsolete("Please use other constructor without IStandardAuthorizationSettings", false)]
        public GuardBuilder(
            IStandardAuthorizationSettings standardAuthorizationSettings,
            IAuthenticationContext context,
            ILogger<AuthenticationContext> logger
        ) 
            : this(context, logger)
        { }


        /// <summary>
        /// Initializes a new instance of the <see cref="GuardBuilder"/> class.
        /// </summary>
        /// <param name="logger"></param>
        public GuardBuilder(ILogger<AuthenticationContext> logger) 
            : this(new AuthenticationContext(logger), logger)
        { }

        /// <summary>
        /// Initializes a new instance of the <see cref="GuardBuilder"/> class.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="logger"></param>
        public GuardBuilder(
            IAuthenticationContext context,
            ILogger<AuthenticationContext> logger)
        {
            _logger = logger;
            _context = context;
        }

        /// <inheritdoc cref="IGuardBuilder.WithGuard(GuardTask)"/>
        public IGuardBuilder WithGuard(GuardTask item)
        {
            _guardQueue.Enqueue((null,item));

            return this;
        }

        /// <inheritdoc cref="IGuardBuilder.WithGuard(Func{IAuthenticationContext,bool},GuardTask)"/>
        public IGuardBuilder WithGuard(Func<IAuthenticationContext,bool> predicate, GuardTask item)
        {
            _guardQueue.Enqueue((predicate, item));

            return this;
        }

        /// <inheritdoc cref="IGuardBuilder.Execute(CancellationToken?, bool, bool)"/>
        public async Task<IAuthenticationContext> Execute(
            CancellationToken? token = null, 
            bool throwOnAuthenticationFailure = true,
            bool returnGenericErrorMessages = false)
        {
            if (token is null)
            {
                var source = new CancellationTokenSource(TimeSpan.FromSeconds(15)); //Reasonable default 
                token = source.Token;
            }

            foreach (var func in _guardQueue)
            {
                // Perform the guard task if there is no predicate or it is valid
                if (func.Predicate == null || func.Predicate.Invoke(_context))
                {
                    try
                    {
                        token.Value.ThrowIfCancellationRequested();

                        // Note: Tasks are weird
                        //       When we begin executing the func the task "starts" 
                        //       If during its execution it has ANOTHER nested await weird stuff happens
                        //       If the nested task yields (i.e is long running) the task will actually return
                        //       in this case we have joined task declaration and assigment - therefore:
                        //       any nested tasks will also get awaited/yielded upwards - otherwise we could
                        //       have a task that does not get evaluated downstream
                        //       To future dev RIP when this deadlocks
                        //
                        _context = await func.GuardTask(_context, token.Value);

                        if (_context.Authenticated == false && throwOnAuthenticationFailure)
                        {
                            throw _context.FailureResponse;
                        }
                    }
                    catch (Exception ex) when (!(ex is StandardApiException))
                    {
                        // Note: the task pattern should never fail 
                        //       if it does just return generic fail
                        //

                        _logger.LogError(ex, "Unhandled Authentication Failure");

                        throw _context
                            .FailedAuthentication("Failed Authentication", returnGenericErrorMessages: returnGenericErrorMessages)
                            .FailureResponse;
                    }
                }
            }

            return _context;
        }
    }
}