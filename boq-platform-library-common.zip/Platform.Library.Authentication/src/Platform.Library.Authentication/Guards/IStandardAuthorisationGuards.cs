﻿using System;
using Microsoft.AspNetCore.Http;
using Platform.Library.Authentication.Models.Common;

namespace Platform.Library.Authentication.Guards
{
    /// <summary>
    /// Standard Authorization Guards
    /// </summary>
    public interface IStandardAuthorisationGuards
    {
        /// <summary>
        /// Using a CIAM public key verify the token signature
        /// Populates
        ///     - ClaimsPrincipal
        ///     - SecurityToken
        ///     - IssuedBy
        ///     - TokenType
        /// <remarks>
        /// Only use this guard when you want to explicitly validate the CIAM token ONLY.
        /// Otherwise, use <see cref="HasValidToken"/> which will validate CIAM and Azure token based on the token issuer
        /// </remarks>
        /// </summary>
        GuardTask HasValidCiamSignature { get; }

        /// <summary>
        /// Parses a token without a signature into the claims principal  
        /// Populates
        ///     - ClaimsPrincipal
        ///     - SecurityToken
        /// </summary>
        GuardTask HasNoSignature { get; }

        /// <summary>
        /// Will check the 'iss' claim (from raw token) against CIAM and Azure issuers
        /// Populates
        ///     - IssuedBy
        /// </summary>
        GuardTask HasValidIssuer { get; }

        /// <summary>
        /// Will check the 'aud' claim against standardAuthorizationSettings.CiamCustomerAudience
        /// Populates
        ///     - TokenType
        /// </summary>
        GuardTask IsCiamCustomerToken { get; }

        /// <summary>
        /// Will check the 'aud' claim against standardAuthorizationSettings.CiamSystemAudience
        /// Populates
        ///     - TokenType
        /// </summary>
        GuardTask IsCiamSystemToken { get; }

        /// <summary>
        /// Will check the 'aud' claim against standardAuthorizationSettings.CiamCustomerAudience and standardAuthorizationSettings.CiamSystemAudience
        /// Populates
        ///     - TokenType
        /// </summary>
        GuardTask IsCiamCustomerOrSystemToken { get; }

        /// <summary>
        /// Will check the 'aud' claim against AzureAdSettings.Audience
        /// Populates
        ///    - TokenType
        /// </summary>
        GuardTask IsManagedIdentityToken { get; }

        /// <summary>
        /// Will check the token 'expiry' < 'DateTime.Now'
        /// NOTE: does not handle SKEW
        /// </summary>
        GuardTask HasNotExpired(TimeSpan? clockSkew = null);

        /// <summary>
        /// Checks blacklist in CIAM
        /// </summary>
        GuardTask NotBlacklisted { get; }

        /// <summary>
        /// Using a symmetric key verify the token signature - testing/debug only
        /// Populates
        ///     - ClaimsPrincipal
        ///     - SecurityToken
        /// </summary>
        GuardTask HasValidSymmetricSignature(string key);

        /// <summary>
        /// Checks for a key/value pair of claims in token
        /// </summary>
        GuardTask ContainsClaim(string name, string value);

        /// <summary>
        /// Checks token claim 'auth_level' to ensure its of a correct level
        /// </summary>
        GuardTask HasAtLeastTokenLevelOf(TokenLevel level);

        /// <summary>
        /// Safeguard non-bearer headers being passed
        /// Populates
        ///     - RawJwtToken
        /// </summary>
        GuardTask HasAuthHeader(IHeaderDictionary headers = null);

        /// <summary>
        /// Verifies if the token is a valid JWT token. 
        /// Checks against CIAM and Azure Ad Public Keys.
        /// Populates
        ///     - ClaimsPrincipal
        ///     - SecurityToken
        ///     - IssuedBy
        ///     - TokenType
        /// <remarks>
        /// Avoid calling in combination with <see cref="HasValidCiamSignature"/> to avoid the token to be validate twice.
        /// </remarks>
        /// </summary>
        GuardTask HasValidToken { get; }

        /// <summary>
        /// Verifies if the token is a valid Azure AD
        /// token that contains the expected customer
        /// identifier in the headers
        /// </summary>
        GuardTask HasCustomerHeader { get; }

        /// <summary>
        /// Verifies if the token is a valid Azure AD
        /// token that contains the expected Authentication Level
        /// identifier in the headers
        /// Populate TokenLevel
        /// </summary>
        GuardTask HasAzureAdAuthLevelHeader { get; }

        /// <summary>
        /// Verifies if the token contains a valid audience
        /// <remarks>
        /// Applicable only when the Issuer is <see cref="IssuedBy.AzureAd"/> and token type <see cref="TokenType.AzureAdExternal"/>
        /// </remarks>
        /// </summary>
        GuardTask HasValidExternalAudience();
    }
}