﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Extensions.Logging;
using Platform.Library.Authentication.Extensions;
using Platform.Library.Authentication.Models.Common;

namespace Platform.Library.Authentication.Guards;

// Use this class to include any internal / private method and the main class will have the interface implementations
public partial class NewStandardAuthorisationGuards
{
    private static readonly string HasNotExpiredDependenciesNotSetErrorMessage = string.Format("{0} must be called after one the security token is being set via one of the following methods: {1}",
        nameof(HasNotExpired), string.Join(", ", nameof(HasValidToken), nameof(HasValidSymmetricSignature), nameof(HasNoSignature), nameof(HasValidCiamSignature)));
    
    // Left this out the standard guard, kept the same signature, if required this method can be exposed via guards
    // Preferably, the `HasValidToken` should be the main be used.
    private GuardTask HasValidAzureAdSignature => async (context, cancellationToken) =>
    {
        _logger.LogDebug("Executing authentication check token [{MethodName}]", nameof(HasValidAzureAdSignature));

        try
        {
            if (context.IssuedBy == IssuedBy.AzureAd
                && context.SecurityToken is not null
                && context.Principal is not null)
            {
                _logger.LogInformation("Token already validated, skipping validation");
                return context;
            }

            // Don't attempt validating token if it's not there.
            if (string.IsNullOrWhiteSpace(context.RawJwtToken))
            {
                _logger.LogError(
                    "Failed to validate token signature, the raw JWT token is not present. " +
                    "This can occur when guard conditions are used for retrieving customer context before AzureAd adds the token to the context");

                return context.FailedAuthentication("Failed to validate token signature: JWT missing");
            }

            // Validate against Azure AD
            var azureAdKeys = (await RetrieveAzureAdConfig(cancellationToken)).SigningKeys;
            var azureAdResult = _jwtTokenValidatorHandler.ValidateToken(azureAdKeys, context.RawJwtToken);

            if (!azureAdResult.IsSuccess)
            {
                return context.FailedAuthentication("Token is not a valid Azure token");
            }

            context.IssuedBy = IssuedBy.AzureAd;
            context.Principal = azureAdResult.ClaimsPrincipal;
            context.SecurityToken = azureAdResult.SecurityToken;
            context.TokenType = _azureAdSettings.AudiencePattern.AsRegex().IsMatch(context.Audience)
                ? TokenType.ManagedIdentity
                : TokenType.AzureAdExternal;

            return context;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to validate token signature");

            return context.FailedAuthentication("Failed to validate token signature", exception: ex);
        }
    };
    
    
    /// <summary>
    /// Helper function to retrieve CIAM Keys
    /// </summary>
    private async Task<IEnumerable<X509SecurityKey>> RetrieveCiamKeys(CancellationToken cancellationToken)
    {
        return await _ciamCertificateService.GetSecurityKeys(cancellationToken);
    }

    /// <summary>
    /// Helper function to retrieve Azure Ad Config
    /// </summary>
    private async Task<OpenIdConnectConfiguration> RetrieveAzureAdConfig(CancellationToken cancellationToken)
    {
        // Fetch configuration
        return await _configurationManager.GetConfigurationAsync(cancellationToken);
    }
}