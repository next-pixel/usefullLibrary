﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Platform.Library.Authentication.Guards
{
    public interface IStepUpGuards
    {

        GuardTask CheckL3TokenWithStepUpOption { get; }
        GuardTask CheckL4TokenWithStepUpOption { get; }
    }
}
