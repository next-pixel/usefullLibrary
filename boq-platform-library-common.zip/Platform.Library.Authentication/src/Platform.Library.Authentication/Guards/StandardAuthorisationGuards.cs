﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using Platform.Library.Authentication.Configuration;
using Platform.Library.Authentication.Models.Common;
using Platform.Library.Authentication.Services;
#pragma warning disable 1998 // Disable Async running as sync for methods that lack await (read comment on builder)

namespace Platform.Library.Authentication.Guards
{
    /// <inheritdoc cref="IStandardAuthorisationGuards"/>
    [Obsolete("Please register library's sdk using ConfigureAuthentication in RegistrationExtension.", false)]
    [ExcludeFromCodeCoverage]
    public class StandardAuthorisationGuards : IStandardAuthorisationGuards
    {
        private readonly ILogger _logger;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IStandardAuthorizationSettings _standardAuthorizationSettings;
        private readonly ICiamCertificateService _ciamCertificateService;

        /// <summary>
        /// Initializes a new instance of the <see cref="StandardAuthorisationGuards"/> class.
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="httpContextAccessor"></param>
        /// <param name="standardAuthorizationSettings"></param>
        /// <param name="ciamCertificateService"></param>
        public StandardAuthorisationGuards(
            ILogger<StandardAuthorisationGuards> logger,
            IHttpContextAccessor httpContextAccessor,
            IStandardAuthorizationSettings standardAuthorizationSettings,
            ICiamCertificateService ciamCertificateService)
        {
            _logger = logger;
            _httpContextAccessor = httpContextAccessor;
            _standardAuthorizationSettings = standardAuthorizationSettings;
            _ciamCertificateService = ciamCertificateService;
        }

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasValidCiamSignature"/>
        public GuardTask HasValidCiamSignature => async (context, token) =>
        {
            _logger.LogDebug($"Executing authentication check token[${nameof(HasValidCiamSignature)}]");

            try
            {
                var certs = await _ciamCertificateService.GetCertificates(CurrentSystem.Id, CurrentSystem.Version, token);

                var validationParameters = new TokenValidationParameters
                {
                    // Note: Default all this off - just check the sig and populate the principal
                    //
                    NameClaimType = InternalConstants.ClaimType.Subject,
                    RequireExpirationTime = false,
                    ValidateAudience = false,
                    ValidateIssuer = false,
                    ValidateLifetime = false,

                    // Note: defaulted on - but be explicit 
                    //
                    RequireSignedTokens = true,
                    IssuerSigningKeyResolver = (s, securityToken, kid, parameters) =>
                    {
                        var matched = certs.FirstOrDefault(x => x.Kid.Equals(kid));
                        if (matched == null)
                        {
                            return new SecurityKey[0];
                        }

                        // Todo: could be perf problem - possible move to fetcher
                        //
                        var cert = new X509Certificate2(Convert.FromBase64String(matched.Base64Certificate));

                        // Todo: Test Chain
                        //
                        return new[]
                        {
                            new X509SecurityKey(cert)
                        };
                    },
                };

                var handler = new JwtSecurityTokenHandler();
                handler.InboundClaimTypeMap.Clear();

                //Don't attempt validating token if it's not there.
                if (string.IsNullOrWhiteSpace(context.RawJwtToken))
                {
                    _logger.LogError(
                        "Failed to validate token signature, the raw JWT token is not present. " +
                        "This can occur when guard conditions are used for retrieving customer context before CIAM adds the token to the context");

                    return context.FailedAuthentication("Failed to validate token signature: JWT missing");
                }

                var user = handler.ValidateToken(
                    context.RawJwtToken,
                    validationParameters,
                    out var validatedToken);

                if (user == null)
                {
                    throw new NotSupportedException($"Unable to refresh certificates");
                }

                context.Principal = user;
                context.SecurityToken = validatedToken;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to validate token signature");

                return context.FailedAuthentication("Failed to validate token signature", exception: ex);
            }

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasValidToken"/>
        public GuardTask HasValidToken => async (context, token) =>
        {
            _logger.LogDebug($"Executing valid JWT check");

            var ciamKeys = await RetrieveCiamKeys(token);

            var azureAdKeys = (await RetrieveAzureAdConfig()).SigningKeys;

            var totalKeys = ciamKeys.Concat(azureAdKeys);

            try
            {
                var validationParameters = new TokenValidationParameters
                {
                    // Note: Default all this off - just check the sig and populate the principal
                    //
                    NameClaimType = InternalConstants.ClaimType.Subject,
                    RequireExpirationTime = false,
                    ValidateAudience = false,
                    ValidateIssuer = false,
                    ValidateLifetime = false,
                    IssuerSigningKeys = totalKeys
                };

                var handler = new JwtSecurityTokenHandler();
                handler.InboundClaimTypeMap.Clear();

                var user = handler.ValidateToken(
                    context.RawJwtToken,
                    validationParameters,
                    out var validatedToken);

                context.Principal = user;
                context.SecurityToken = validatedToken;

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to validate token");

                return context.FailedAuthentication("Failed to validate token", exception: ex);
            }

            return context;

        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasValidSymmetricSignature(string)"/>
        public GuardTask HasValidSymmetricSignature(string key) => async (context, token) =>
        {
            _logger.LogDebug($"Executing authentication check token[{nameof(HasValidSymmetricSignature)}]");

            try
            {
                var validationParameters = new TokenValidationParameters
                {
                    NameClaimType = InternalConstants.ClaimType.Subject,
                    RequireExpirationTime = false,
                    ValidateAudience = false,
                    ValidateIssuer = false,
                    ValidateLifetime = false,
                    RequireSignedTokens = false,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(key))
                };

                var handler = new JwtSecurityTokenHandler();
                handler.InboundClaimTypeMap.Clear();

                var user = handler.ValidateToken(
                    context.RawJwtToken,
                    validationParameters,
                    out var validatedToken);

                context.Principal = user;
                context.SecurityToken = validatedToken;
            }
            catch (Exception ex)
            {
                return context.FailedAuthentication("Failed to validate token signature", exception: ex);
            }

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasNoSignature"/>
        public GuardTask HasNoSignature => async (context, token) =>
        {
            _logger.LogDebug($"Executing authentication check token[{nameof(HasNoSignature)}]");

            try
            {
                var validationParameters = new TokenValidationParameters
                {
                    NameClaimType = InternalConstants.ClaimType.Subject,
                    RequireExpirationTime = false,
                    ValidateAudience = false,
                    ValidateIssuer = false,
                    ValidateLifetime = false,
                    RequireSignedTokens = false
                };

                var handler = new JwtSecurityTokenHandler();
                handler.InboundClaimTypeMap.Clear();

                var user = handler.ValidateToken(
                    context.RawJwtToken,
                    validationParameters,
                    out var validatedToken);

                context.Principal = user;
                context.SecurityToken = validatedToken;
            }
            catch (Exception ex)
            {
                return context.FailedAuthentication("Failed to parse debug token", exception: ex);
            }

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.ContainsClaim(string, string)"/>
        public GuardTask ContainsClaim(string name, string value) => async (context, token) =>
        {
            _logger.LogDebug($"Executing authentication check token[{nameof(ContainsClaim)}]");

            if (context.Principal.HasClaim(name, value) == false)
            {
                return context.FailedAuthentication($"Unable to match claim '{name}' - '{value}'");
            }

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasAtLeastTokenLevelOf(TokenLevel)"/>
        public GuardTask HasAtLeastTokenLevelOf(TokenLevel level) => async (context, token) =>
        {
            _logger.LogDebug($"Executing authentication check token[{nameof(HasAtLeastTokenLevelOf)}] - {level}");

            if (context.TokenLevel < level)
            {
                return context.FailedAuthentication("Minimum token level required for this operation:" + level);
            }

            return context;
        };


        /// <inheritdoc cref="IStandardAuthorisationGuards.HasAuthHeader(IHeaderDictionary)"/>
        public GuardTask HasAuthHeader(IHeaderDictionary headers = null) => async (context, token) =>
        {
            _logger.LogDebug($"Executing authentication check token[{nameof(HasAuthHeader)}]");

            try
            {
                var header = headers["Authorization"]
                    .ToString()
                    .Replace("Bearer ", "");

                if (string.IsNullOrWhiteSpace(header))
                {
                    throw new FormatException("Authentication header not in correct format");
                }

                context.RawJwtToken = header;
                context.Headers = headers;
            }
            catch (Exception ex)
            {
                return context.FailedAuthentication("Failed to extract authentication header", exception: ex);
            }

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasValidIssuer"/>
        public GuardTask HasValidIssuer => async (context, token) =>
        {
            _logger.LogDebug("Executing authentication check token[{MethodName}] - {CiamIssuer} or {AzureAdIssuer}", nameof(HasValidIssuer), _standardAuthorizationSettings.CiamIssuer, _standardAuthorizationSettings.AzureAdIssuer);

            if (!context.Issuer.In(_standardAuthorizationSettings.CiamIssuer, _standardAuthorizationSettings.AzureAdIssuer))
            {
                return context.FailedAuthentication(
                    string.Concat(
                        "Token does not match allowed issuer - ",
                        $"Expected: '{_standardAuthorizationSettings.CiamIssuer}' or '{_standardAuthorizationSettings.AzureAdIssuer}'",
                        $"Actual: '{context.Issuer}' "
                    )
                );
            }

            context.IssuedBy = context.Issuer == _standardAuthorizationSettings.CiamIssuer
                                    ? IssuedBy.CIAM
                                    : IssuedBy.AzureAd;

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.IsCiamCustomerToken"/>
        public GuardTask IsCiamCustomerToken => async (context, token) =>
        {
            _logger.LogDebug($"Executing authentication check token[{nameof(IsCiamCustomerToken)}]");

            if (context.Audience != _standardAuthorizationSettings.CiamCustomerAudience)
            {
                return context.FailedAuthentication(
                    "Token not issued to customer - " +
                    $"Expected: '{_standardAuthorizationSettings.CiamCustomerAudience}' " +
                    $"Actual: '{context.Audience}' ");
            }

            context.TokenType = TokenType.CiamCustomer;

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.IsCiamSystemToken"/>
        public GuardTask IsCiamSystemToken => async (context, token) =>
        {
            _logger.LogDebug($"Executing authentication check token[{nameof(IsCiamSystemToken)}]");

            if (context.Audience != _standardAuthorizationSettings.CiamSystemAudience)
            {
                return context.FailedAuthentication(
                    "Token not issued to system - " +
                    $"Expected: '{_standardAuthorizationSettings.CiamSystemAudience}' " +
                    $"Actual: '{context.Audience}' ");
            }

            context.TokenType = TokenType.CiamSystem;

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.IsCiamCustomerOrSystemToken"/>
        public GuardTask IsCiamCustomerOrSystemToken => async (context, cancellationToken) =>
        {
            _logger.LogDebug("Executing authentication check token[{MethodName}]", nameof(IsCiamCustomerOrSystemToken));

            if (context.Audience.EqualsIgnoreCase(_standardAuthorizationSettings.CiamCustomerAudience))
                context.TokenType = TokenType.CiamCustomer;
            else if (context.Audience.EqualsIgnoreCase(_standardAuthorizationSettings.CiamSystemAudience))
                context.TokenType = TokenType.CiamSystem;
            else
            {
                return context.FailedAuthentication(
                    "Token not issued to customer - " +
                    $"Expected: '{_standardAuthorizationSettings.CiamCustomerAudience}' or '{_standardAuthorizationSettings.CiamSystemAudience}' " +
                    $"Actual: '{context.Audience}' ");
            }

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasNotExpired(TimeSpan?)"/>
        public GuardTask HasNotExpired(TimeSpan? clockSkew = null) => async (context, token) =>
        {
            _logger.LogDebug($"Executing authentication check token[{nameof(HasNotExpired)}]");

            try
            {
                var expires = context.SecurityToken.ValidTo;
                var notBefore = context.SecurityToken.ValidFrom;

                var tokenParameters = new TokenValidationParameters()
                {
                    ClockSkew = clockSkew ?? TimeSpan.FromSeconds(300) // default
                };

                var now = DateTime.UtcNow;

                var start = DateTimeUtil.Add(now, tokenParameters.ClockSkew.Negate());
                var end = DateTimeUtil.Add(now, tokenParameters.ClockSkew);

                var log = $@"
token expires: {expires}
token not before: {notBefore}
now: {now}
between ( {start} and {end} )
";
                Debug.WriteLine(log);

                _logger.LogDebug(log);

                Validators.ValidateLifetime(notBefore, expires, context.SecurityToken, tokenParameters);
            }

            catch (Exception badTime)
            {
                _logger.LogWarning(badTime, "Token has expired");

                // Note: to align with CIAM specs and make it easy for mobile we return the CIAM code 
                //       when a token has expired 
                //
                return context.FailedAuthentication(
                    "The access token provided is expired, revoked, malformed, or invalid for other reasons.",
                    "CIAM_E0036",
                    401);
            }

            return context;
        };

        /// <summary>
        /// Helper function to retrieve CIAM Keys
        /// </summary>
        private async Task<List<X509SecurityKey>> RetrieveCiamKeys(CancellationToken token)
        {
            var keys = new List<X509SecurityKey>();
            var certs = await _ciamCertificateService.GetCertificates(CurrentSystem.Id, CurrentSystem.Version, token);

            foreach (var cert in certs)
            {
                var key = new X509Certificate2(Convert.FromBase64String(cert.Base64Certificate));
                keys.Add(new X509SecurityKey(key));
            }

            return keys;
        }

        /// <summary>
        /// Helper function to retrieve Azure Ad Config
        /// </summary>
        private async Task<OpenIdConnectConfiguration> RetrieveAzureAdConfig()
        {
            string stsDiscoveryEndpoint = "https://login.microsoftonline.com/common/v2.0/.well-known/openid-configuration";

            // Fetch configuration
            ConfigurationManager<OpenIdConnectConfiguration> configManager = new ConfigurationManager<OpenIdConnectConfiguration>(stsDiscoveryEndpoint, new OpenIdConnectConfigurationRetriever());
            var azureAdConfig = await configManager.GetConfigurationAsync();

            return azureAdConfig;
        }

        /// <summary>
        /// Checks blacklist in CIAM
        /// </summary>
        public GuardTask NotBlacklisted => async (context, token) =>
        {
            throw new NotImplementedException("Pending blacklist signoff");
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasCustomerHeader"/>
        public GuardTask HasCustomerHeader => async (context, token) =>
        {
            throw new NotImplementedException("Not implemented - Please use NewStandardAuthenticationGuards");
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasAzureAdAuthLevelHeader"/>
        public GuardTask HasAzureAdAuthLevelHeader => async (context, token) =>
        {
            throw new NotImplementedException("Not implemented - Please use NewStandardAuthenticationGuards");
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasValidExternalAudience"/>
        public GuardTask HasValidExternalAudience() => async (context, token) =>
        {
            throw new NotImplementedException("Not implemented - Please use NewStandardAuthenticationGuards");
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.IsManagedIdentityToken"/>
        public GuardTask IsManagedIdentityToken => async (context, token) =>
        {
            throw new NotImplementedException("Not implemented - Please use NewStandardAuthenticationGuards");
        };
    }
}