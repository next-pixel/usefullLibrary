﻿
using System.Threading.Tasks;

namespace Platform.Library.Authentication.Guards;

internal static class InternalGuards
{
    /// <summary>
    /// Simple guard to attach the <see cref="AuthenticationType"/> into the context.
    /// This guard should be the first guard to be called.
    /// </summary>
    /// <param name="authenticationType">The type of authentication used to validate</param>
    /// <returns>Delegate task <see cref="GuardTask"/></returns>
    internal static GuardTask UseAuthenticationType(AuthenticationType authenticationType) =>
        (context, cancellationToken) =>
        {
            context.AuthenticationType = authenticationType;
            return Task.FromResult(context);
        };
}