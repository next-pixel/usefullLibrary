﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using Platform.Library.Authentication.Models.Common;
using Platform.Library.Authentication.Services;
using Platform.Library.Common.AspNetCore.StandardApi.Http;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using Platform.Library.Authentication.Extensions;

#pragma warning disable 1998 // Disable Async running as sync for methods that lack await (read comment on builder)

namespace Platform.Library.Authentication.Guards
{
    /// <inheritdoc cref="IStandardAuthorisationGuards"/>
    public partial class NewStandardAuthorisationGuards : IStandardAuthorisationGuards
    {
        private readonly ILogger<NewStandardAuthorisationGuards> _logger;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly CiamSettings _ciamSettings;
        private readonly AzureAdSettings _azureAdSettings;
        private readonly ICiamCertificateService _ciamCertificateService;
        private readonly IConfigurationManager<OpenIdConnectConfiguration> _configurationManager;
        private readonly IJwtTokenValidatorService _jwtTokenValidatorHandler;

        /// <summary>
        /// Initializes a new instance of the <see cref="NewStandardAuthorisationGuards"/> class.
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="httpContextAccessor"></param>
        /// <param name="ciamSettings"></param>
        /// <param name="azureAdSettings"></param>
        /// <param name="ciamCertificateService"></param>
        /// <param name="configurationManager"></param>
        /// <param name="jwtTokenValidatorHandler"></param>
        public NewStandardAuthorisationGuards(
            ILogger<NewStandardAuthorisationGuards> logger,
            IHttpContextAccessor httpContextAccessor,
            IOptions<CiamSettings> ciamSettings,
            IOptions<AzureAdSettings> azureAdSettings,
            ICiamCertificateService ciamCertificateService,
            IConfigurationManager<OpenIdConnectConfiguration> configurationManager,
            IJwtTokenValidatorService jwtTokenValidatorHandler)
        {
            _logger = logger.GuardNull(nameof(logger));
            _httpContextAccessor = httpContextAccessor.GuardNull(nameof(httpContextAccessor));
            _ciamSettings = ciamSettings.GuardNull(nameof(ciamSettings));
            _azureAdSettings = azureAdSettings.GuardNull(nameof(azureAdSettings));
            _ciamCertificateService = ciamCertificateService.GuardNull(nameof(ciamCertificateService));
            _configurationManager = configurationManager.GuardNull(nameof(configurationManager));
            _jwtTokenValidatorHandler = jwtTokenValidatorHandler.GuardNull(nameof(jwtTokenValidatorHandler));
        }

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasValidCiamSignature"/>
        public GuardTask HasValidCiamSignature => async (context, cancellationToken) =>
        {
            _logger.LogDebug("Executing authentication check token [{MethodName}]", nameof(HasValidCiamSignature));

            try
            {
                if (context.IssuedBy == IssuedBy.CIAM 
                    && context.SecurityToken is not null 
                    && context.Principal is not null)
                {
                    _logger.LogInformation("Token already validated, skipping validation");
                    return context;
                }
                
                //Don't attempt validating token if it's not there.
                if (string.IsNullOrWhiteSpace(context.RawJwtToken))
                {
                    _logger.LogError(
                        "Failed to validate token signature, the raw JWT token is not present. " +
                        "This can occur when guard conditions are used for retrieving customer context before CIAM adds the token to the context");

                    return context.FailedAuthentication("Failed to validate token signature: JWT missing");
                }

                var certs = await RetrieveCiamKeys(cancellationToken);
                var result = _jwtTokenValidatorHandler.ValidateToken(certs, context.RawJwtToken);

                if (!result.IsSuccess)
                {
                    return context.FailedAuthentication("Unable to validate CIAM token");
                }

                context.IssuedBy = IssuedBy.CIAM;
                context.Principal = result.ClaimsPrincipal;
                context.SecurityToken = result.SecurityToken;
                context.TokenType = context.Audience.EqualsIgnoreCase(_ciamSettings.SystemAudience)
                    ? TokenType.CiamSystem
                    : TokenType.CiamCustomer;
                return context;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to validate token signature");

                return context.FailedAuthentication("Failed to validate token signature", exception: ex);
            }
        };
        
        /// <inheritdoc cref="IStandardAuthorisationGuards.HasValidToken"/>
        public GuardTask HasValidToken => async (context, cancellationToken) =>
        {
            _logger.LogDebug("Executing valid JWT check [{MethodName}] for issuer: {IssuedBy}", nameof(HasValidToken), context.IssuedBy);

            try
            {
                if (context.IssuedBy == IssuedBy.Unknown)
                {
                    _logger.LogDebug("Issued By was not set, applying issuer validation");
                    await HasValidIssuer(context, cancellationToken);
                }
                
                if (context.IssuedBy == IssuedBy.CIAM)
                {
                    return await HasValidCiamSignature(context, cancellationToken);
                }

                if (context.IssuedBy == IssuedBy.AzureAd)
                {
                    return await HasValidAzureAdSignature(context, cancellationToken);
                }

                //Since neither of CIAM or Azure AD check passed, it will be treated as an invalid token.
                return context.FailedAuthentication("The token is not a valid token.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to validate token");

                return context.FailedAuthentication("Failed to validate token", exception: ex);
            }
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasCustomerHeader"/>
        public GuardTask HasCustomerHeader => async (context, cancellationToken) =>
        {
            _logger.LogDebug("Executing [{MethodName}]", nameof(HasCustomerHeader));
            
            if (context.IssuedBy != IssuedBy.AzureAd)
                throw new NotSupportedException($"The {nameof(HasCustomerHeader)} guard is only supported when {nameof(HasValidToken)} is issued by {IssuedBy.AzureAd}");

            if (!context.Headers.TryGetValue(AuthenticationConstants.Headers.TemenosCif, out var temenosCif) 
                || string.IsNullOrWhiteSpace(temenosCif))
                return context.FailedAuthentication($"Failed to retrieve {AuthenticationConstants.Headers.TemenosCif} header");

            context.Temenos_cif = temenosCif;

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasAzureAdAuthLevelHeader"/>
        public GuardTask HasAzureAdAuthLevelHeader => async (context, cancellationToken) =>
        {
            _logger.LogDebug("Executing authentication check token[{MethodName}]", nameof(HasAzureAdAuthLevelHeader));

            if (context.IssuedBy != IssuedBy.AzureAd)
                throw new NotSupportedException($"The {nameof(HasAzureAdAuthLevelHeader)} guard is only supported when {nameof(HasValidToken)} is issued by {IssuedBy.AzureAd}");

            if (!context.Headers.TryGetValue(AuthenticationConstants.Headers.AuthLevel, out var authLevel))
                return context.FailedAuthentication($"Failed to retrieve {AuthenticationConstants.Headers.AuthLevel} header");

            // Call `IsDefined` to ensure the enum value is defined.
            // TryParse would accept integer as string to be parsed successfully, representing unexpected behaviour.
            if (authLevel.ToString().TryParseDefined<TokenLevel>(out var tokenLevel))
            {
                context.TokenLevel = tokenLevel;
            }
            
            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasValidExternalAudience"/>
        public GuardTask HasValidExternalAudience() => async (context, cancellationToken) =>
        {
            _logger.LogDebug("Executing authentication check token[{MethodName}]", nameof(HasValidExternalAudience));

            if (context.IssuedBy != IssuedBy.AzureAd 
                && context.TokenType != TokenType.AzureAdExternal)
            {
                throw new NotSupportedException(
                    $"The {nameof(HasValidExternalAudience)} guard is only supported for {IssuedBy.AzureAd} issuer and token type {TokenType.AzureAdExternal}." +
                    $"Actual issuer: {context.IssuedBy}" +
                    $"Actual token type: {context.TokenType}");
            }

            var hasValidAudience = _azureAdSettings.ExternalAudiences.Any(kv =>
            {
                var isMatch = kv.Value.AsRegex().IsMatch(context.Audience);
                _logger.LogDebug("Validating audience for {AudienceName} with pattern {AudiencePattern}. Result: {IsMatch}", kv.Key, kv.Value, isMatch);
                return isMatch;
            });

            if (hasValidAudience)
            {
                return context;
            }

            return context.FailedAuthentication($"The audience {context.Audience} provided is not valid.");
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasValidSymmetricSignature(string)"/>
        public GuardTask HasValidSymmetricSignature(string key) => async (context, cancellationToken) =>
        {
            _logger.LogDebug("Executing authentication check token[{MethodName}]", nameof(HasValidSymmetricSignature));

            try
            {
                var validationParameters = new TokenValidationParameters
                {
                    NameClaimType = InternalConstants.ClaimType.Subject,
                    RequireExpirationTime = false,
                    ValidateAudience = false,
                    ValidateIssuer = false,
                    ValidateLifetime = false,
                    RequireSignedTokens = false,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(key))
                };

                var handler = new JwtSecurityTokenHandler();
                handler.InboundClaimTypeMap.Clear();

                var user = handler.ValidateToken(
                    context.RawJwtToken,
                    validationParameters,
                    out var validatedToken);

                context.Principal = user;
                context.SecurityToken = validatedToken;
            }
            catch (Exception ex)
            {
                return context.FailedAuthentication("Failed to validate token signature", exception: ex);
            }

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasNoSignature"/>
        public GuardTask HasNoSignature => async (context, cancellationToken) =>
        {
            _logger.LogDebug("Executing authentication check token[{MethodName}]", nameof(HasNoSignature));

            try
            {
                var validationParameters = new TokenValidationParameters
                {
                    NameClaimType = InternalConstants.ClaimType.Subject,
                    RequireExpirationTime = false,
                    ValidateAudience = false,
                    ValidateIssuer = false,
                    ValidateLifetime = false,
                    RequireSignedTokens = false
                };

                var handler = new JwtSecurityTokenHandler();
                handler.InboundClaimTypeMap.Clear();

                var user = handler.ValidateToken(
                    context.RawJwtToken,
                    validationParameters,
                    out var validatedToken);

                context.Principal = user;
                context.SecurityToken = validatedToken;
            }
            catch (Exception ex)
            {
                return context.FailedAuthentication("Failed to parse debug token", exception: ex);
            }

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.ContainsClaim(string, string)"/>
        public GuardTask ContainsClaim(string name, string value) => async (context, cancellationToken) =>
        {
            _logger.LogDebug("Executing authentication check token[{MethodName}]", nameof(ContainsClaim));


            if (!context.Principal.HasClaim(name, value))
            {
                return context.FailedAuthentication($"Unable to match claim '{name}' - '{value}'");
            }

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasAtLeastTokenLevelOf(TokenLevel)"/>
        public GuardTask HasAtLeastTokenLevelOf(TokenLevel level) => async (context, cancellationToken) =>
        {
            _logger.LogDebug("Executing authentication check token[{MethodName}] - {Level}", nameof(HasAtLeastTokenLevelOf), level);

            if (context.TokenLevel < level)
            {
                return context.FailedAuthentication("Minimum token level required for this operation:" + level);
            }

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasAuthHeader(IHeaderDictionary)"/>
        public GuardTask HasAuthHeader(IHeaderDictionary headers = null) => async (context, cancellationToken) =>
        {
            _logger.LogDebug("Executing authentication check token[{MethodName}]", nameof(HasAuthHeader));

            try
            {
                var headerDictionary = headers ?? _httpContextAccessor.HttpContext.Request.Headers;
                
                var rawToken = headerDictionary[StandardHeaderConstants.Authorization]
                    .ToString()
                    .Replace(InternalConstants.BearerPrefix, string.Empty);

                if (string.IsNullOrWhiteSpace(rawToken))
                {
                    throw new FormatException("Authentication header not in correct format");
                }

                context.RawJwtToken = rawToken;
                context.Headers = headerDictionary;
            }
            catch (Exception ex)
            {
                return context.FailedAuthentication("Failed to extract authentication header", exception: ex);
            }

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasValidIssuer"/>
        public GuardTask HasValidIssuer => async (context, cancellationToken) =>
        {
            _logger.LogDebug("Executing authentication check token[{MethodName}] - {CiamIssuer} or {AzureAdIssuer}", 
                nameof(HasValidIssuer), _ciamSettings.Issuer, _azureAdSettings.Issuer);

            if (context.RawJwtToken.IsNullOrWhiteSpace())
            {
                throw new NotSupportedException($"Raw token not provided or {nameof(HasAuthHeader)} was not called");
            }

            if (!_jwtTokenValidatorHandler.ValidateIssuer(context.RawJwtToken,
                    new[] { _ciamSettings.Issuer, _azureAdSettings.Issuer }, out var tokenIssuer))
            {
                return context.FailedAuthentication(
                    string.Concat(
                        "Token does not match allowed issuer - ",
                        $"Expected: '{_ciamSettings.Issuer}' or '{_azureAdSettings.Issuer}' ",
                        $"Actual: '{tokenIssuer}' "
                    )
                );
            }

            if (tokenIssuer == _ciamSettings.Issuer)
                context.IssuedBy = IssuedBy.CIAM;
            else if (tokenIssuer == _azureAdSettings.Issuer)
                context.IssuedBy = IssuedBy.AzureAd;
            else
                throw new NotSupportedException($"Issue not supported by {nameof(HasValidIssuer)}: {tokenIssuer}");

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.IsCiamCustomerToken"/>
        public GuardTask IsCiamCustomerToken => async (context, cancellationToken) =>
        {
            _logger.LogDebug("Executing authentication check token[{MethodName}]", nameof(IsCiamCustomerToken));

            if (context.Audience != _ciamSettings.CustomerAudience)
            {
                return context.FailedAuthentication(
                    "Token not issued to customer - " +
                    $"Expected: '{_ciamSettings.CustomerAudience}' " +
                    $"Actual: '{context.Audience}' ");
            }

            context.TokenType = TokenType.CiamCustomer;

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.IsCiamSystemToken"/>
        public GuardTask IsCiamSystemToken => async (context, cancellationToken) =>
        {
            _logger.LogDebug("Executing authentication check token[{MethodName}]", nameof(IsCiamSystemToken));

            if (context.Audience != _ciamSettings.SystemAudience)
            {
                return context.FailedAuthentication(
                    "Token not issued to system - " +
                    $"Expected: '{_ciamSettings.SystemAudience}' " +
                    $"Actual: '{context.Audience}' ");
            }

            context.TokenType = TokenType.CiamSystem;

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.IsCiamCustomerOrSystemToken"/>
        public GuardTask IsCiamCustomerOrSystemToken => async (context, cancellationToken) =>
        {
            _logger.LogDebug("Executing authentication check token[{MethodName}]", nameof(IsCiamCustomerOrSystemToken));

            if (context.Audience.EqualsIgnoreCase(_ciamSettings.CustomerAudience))
                context.TokenType = TokenType.CiamCustomer;
            else if (context.Audience.EqualsIgnoreCase(_ciamSettings.SystemAudience))
                context.TokenType = TokenType.CiamSystem;
            else
            {
                return context.FailedAuthentication(
                    "Token not issued to customer - " +
                    $"Expected: '{_ciamSettings.CustomerAudience}' or '{_ciamSettings.SystemAudience}' " +
                    $"Actual: '{context.Audience}' ");
            }

            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.IsManagedIdentityToken"/>
        public GuardTask IsManagedIdentityToken => async (context, cancellationToken) =>
        {
            _logger.LogDebug("Executing authentication check token[{MethodName}]", nameof(IsManagedIdentityToken));

            if (!_azureAdSettings.AudiencePattern.AsRegex().IsMatch(context.Audience))
            {
                return context.FailedAuthentication(
                    "Token not issued to managed identity - " +
                    $"Expected: '{_azureAdSettings.AudiencePattern}' " +
                    $"Actual: '{context.Audience}' ");
            }
            
            context.TokenType = TokenType.ManagedIdentity;
            return context;
        };

        /// <inheritdoc cref="IStandardAuthorisationGuards.HasNotExpired"/>
        public GuardTask HasNotExpired(TimeSpan? clockSkew = null) => async (context, cancellationToken) =>
        {
            _logger.LogDebug("Executing authentication check token[{MethodName}]", nameof(HasNotExpired));

            if (context.SecurityToken is null)
            {
                throw new NotSupportedException(
                    HasNotExpiredDependenciesNotSetErrorMessage);
            }

            try
            {
                var expires = context.SecurityToken.ValidTo;
                var notBefore = context.SecurityToken.ValidFrom;

                var tokenParameters = new TokenValidationParameters()
                {
                    ClockSkew = clockSkew ?? TimeSpan.FromSeconds(300) // default
                };

                var now = DateTime.UtcNow;

                var start = DateTimeUtil.Add(now, tokenParameters.ClockSkew.Negate());
                var end = DateTimeUtil.Add(now, tokenParameters.ClockSkew);

                Validators.ValidateLifetime(notBefore, expires, context.SecurityToken, tokenParameters);
            }

            catch (Exception badTime)
            {
                _logger.LogWarning(badTime, "Token has expired");

                // Note: to align with CIAM specs and make it easy for mobile we return the CIAM code 
                //       when a token has expired 
                //
                return context.FailedAuthentication(
                    "The access token provided is expired, revoked, malformed, or invalid for other reasons.",
                    "CIAM_E0036",
                    401);
            }

            return context;
        };
        
        /// <summary>
        /// Checks blacklist in CIAM
        /// </summary>
        public GuardTask NotBlacklisted => async (context, cancellationToken) =>
        {
#warning Not Implemented
            throw new NotImplementedException("Pending blacklist signoff");
        };
    }
}