﻿using Platform.Library.Authentication.Models.Abstractions;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Platform.Library.Authentication.Guards
{
    /// <summary>
    /// Interface for the <see cref="GuardBuilder"/>
    /// </summary>
    public interface IGuardBuilder
    {
        /// <summary>
        /// Enqueue a <see cref="GuardTask"/> to be performed
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        IGuardBuilder WithGuard(GuardTask item);

        /// <summary>
        /// Enqueue a <see cref="GuardTask"/> to be performed if
        /// the provided <paramref name="predicate"/> returns TRUE
        /// </summary>
        /// <param name="predicate"></param>
        /// <param name="item"></param>
        /// <returns></returns>
        IGuardBuilder WithGuard(Func<IAuthenticationContext, bool> predicate, GuardTask item);

        /// <summary>
        /// Execute the queued <see cref="GuardTask">guard tasks</see> to generate an <see cref="IAuthenticationContext"/>
        /// </summary>
        /// <param name="token"></param>
        /// <param name="throwOnAuthenticationFailure"></param>
        /// <param name="returnGenericErrorMessages"></param>
        /// <returns></returns>
        Task<IAuthenticationContext> Execute(
            CancellationToken? token = null, 
            bool throwOnAuthenticationFailure = true,
            bool returnGenericErrorMessages = false);
    }
}