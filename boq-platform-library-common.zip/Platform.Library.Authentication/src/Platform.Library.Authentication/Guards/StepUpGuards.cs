﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;
using Platform.Library.Authentication.Models.Common;

namespace Platform.Library.Authentication.Guards
{
    public class StepUpGuards : IStepUpGuards
    {
        /// <summary>
        /// Check if L3 Token is present and present step up options if not
        /// </summary>
        public GuardTask CheckL3TokenWithStepUpOption => async (context, token) =>
        {
            if (context.TokenLevel >= TokenLevel.L3)
            {
                return context;
            }

            if (context.TokenLevel == TokenLevel.L2)
            {
                if (context.IsAustraliaMobile != null && context.IsAustraliaMobile.Value)
                {
                    if (context.IsSqaEnabled)
                    {
                        return context.FailedAuthentication(
                            StepUpConstants.Messages.L3StepUpByOtpOrSqa,
                            StepUpConstants.Codes.L3StepUpByOtpOrSqa,
                            StatusCodes.Status403Forbidden);
                    }

                    return context.FailedAuthentication(
                        StepUpConstants.Messages.L3StepUpByOtp,
                        StepUpConstants.Codes.L3StepUpByOtp,
                        StatusCodes.Status403Forbidden);
                }

                if (context.IsSqaEnabled)
                {
                    return context.FailedAuthentication(
                        StepUpConstants.Messages.L3StepUpBySqa,
                        StepUpConstants.Codes.L3StepUpBySqa,
                        StatusCodes.Status403Forbidden);
                }

                return context.FailedAuthentication(
                    StepUpConstants.Messages.L3StepUpBySqaOrCall,
                    StepUpConstants.Codes.L3StepUpBySqaOrCall,
                    StatusCodes.Status403Forbidden);
            }

            return context;
        };

        /// <summary>
        /// Check if L4 Token is present and present step up options if not
        /// </summary>
        public GuardTask CheckL4TokenWithStepUpOption => async (context, token) =>
        {
            if (context.TokenLevel >= TokenLevel.L4)
            {
                return context;
            }

            if (context.TokenLevel == TokenLevel.L2)
            {
                if (context.IsAustraliaMobile != null && context.IsAustraliaMobile.Value)
                {
                    if (context.IsSqaEnabled)
                    {
                        return context.FailedAuthentication(
                            StepUpConstants.Messages.L4StepUpByOtpAndSqa,
                            StepUpConstants.Codes.L4StepUpByOtpAndSqa,
                            StatusCodes.Status403Forbidden);
                    }

                    return context.FailedAuthentication(
                        StepUpConstants.Messages.L4StepUpBySqaAndCall,
                        StepUpConstants.Codes.L4StepUpBySqaAndCall,
                        StatusCodes.Status403Forbidden);
                }

                return context.FailedAuthentication(
                    StepUpConstants.Messages.L4StepUpByCall,
                    StepUpConstants.Codes.L4StepUpByCall,
                    StatusCodes.Status403Forbidden);
            }

            else if (context.TokenLevel == TokenLevel.L3)
            {
                if (context.IsAustraliaMobile != null && context.IsAustraliaMobile.Value)
                {
                    if (context.MfaL3Method != null && context.MfaL3Method == "OTP-SMS")
                    {
                        if (context.IsSqaEnabled)
                        {
                            return context.FailedAuthentication(
                                StepUpConstants.Messages.L4StepUpBySqa,
                                StepUpConstants.Codes.L4StepUpBySqa,
                                StatusCodes.Status403Forbidden);
                        }

                        return context.FailedAuthentication(
                            StepUpConstants.Messages.L4StepUpBySqaOrCall,
                            StepUpConstants.Codes.L4StepUpBySqaOrCall,
                            StatusCodes.Status403Forbidden);
                    }

                    return context.FailedAuthentication(
                        StepUpConstants.Messages.L4StepUpByOtp,
                        StepUpConstants.Codes.L4StepUpByOtp,
                        StatusCodes.Status403Forbidden);
                }

                if (context.MfaL3Method != null && context.MfaL3Method == "OTP-SMS")
                {
                    if (context.IsSqaEnabled)
                    {
                        return context.FailedAuthentication(
                            StepUpConstants.Messages.L4StepUpBySqaNotAustralian,
                            StepUpConstants.Codes.L4StepUpBySqaNotAustralian,
                            StatusCodes.Status403Forbidden);
                    }

                    return context.FailedAuthentication(
                        StepUpConstants.Messages.L4StepUpBySqaOrCallNotAustralian,
                        StepUpConstants.Codes.L4StepUpBySqaOrCallNotAustralian,
                        StatusCodes.Status403Forbidden);
                }

                return context.FailedAuthentication(
                    StepUpConstants.Messages.L4StepUpByCallNotAustralian,
                    StepUpConstants.Codes.L4StepUpByCallNotAustralian,
                    StatusCodes.Status403Forbidden);
            }

            return context;
        };
    }
}
