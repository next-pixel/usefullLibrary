﻿using System.Collections.Generic;

namespace Platform.Library.Authentication
{
    /// <summary>
    /// Azure AD Settings
    /// </summary>
    public class AzureAdSettings
    {
        /// <summary>
        /// Expected Issuer
        /// </summary>
        public string Issuer { get; set; }

        /// <summary>
        /// Expected Audience
        /// </summary>
        public string AudiencePattern { get; set; }

        /// <summary>
        /// List of valid external audiences to be validated.
        /// The value will be parsed to regex and it can be a pattern. Like `api://*.`
        /// If the exact value is passed in, the regex will try to locate the exact match instead
        /// </summary>
        public IDictionary<string, string> ExternalAudiences { get; set; } = new Dictionary<string, string>();
    }
}
