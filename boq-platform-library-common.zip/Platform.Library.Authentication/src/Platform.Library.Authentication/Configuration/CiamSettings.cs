﻿using System;
using System.Collections.Generic;
using System.Text;
using Platform.Library.Http;

namespace Platform.Library.Authentication
{
    public class CiamSettings : ClientSettings
    {
        /// <summary>
        /// Configuration as found in AAC
        /// </summary>
        public override string ConfigName => InternalConstants.ConfigSections.CIAM;
        public override string ClientName => InternalConstants.HttpClients.CertificateClient;

        public int CertificateEvictInHours { get; set; }
        public string SubscriptionKey { get; set; }
        public string CustomerAudience { get; set; }
        public string SystemAudience { get; set; }
        public string Issuer { get; set; }
        public string CertificateUri { get; set; }
    }
}
