﻿using System;
using Microsoft.Extensions.Configuration;
using Platform.Library.Common.AspNetCore.StandardApi.Configuration.Abstractions;

namespace Platform.Library.Authentication.Configuration
{
    [Obsolete("This has now been replaced with CiamSettings and AzureAdSettings", false)]
    public class StandardAuthorizationSettings : StandardApiSettings, IStandardAuthorizationSettings
    {
        private readonly IConfiguration _configuration;

        public StandardAuthorizationSettings(IConfiguration configuration) : base(configuration)
        {
            _configuration = configuration;

            configuration.Bind("StandardAuthorization", this);
        }

        public string CiamCertificateUrl { get; set; }
        public int CiamCertificateEvictInHours { get; set; }
        public string CiamSubscriptionKey { get; set; }
        public string CiamCustomerAudience { get; set; }
        public string CiamSystemAudience { get; set; }
        public string CiamIssuer { get; set; }
        public bool ReturnGenericErrorMessages { get; set; }
        public string AzureAdIssuer { get; set; }
    }
}
