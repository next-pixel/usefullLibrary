﻿using System;

namespace Platform.Library.Authentication.Configuration
{
    [Obsolete("This has now been replaced with CiamSettings and AzureAdSettings", false)]
    public interface IStandardAuthorizationSettings
    {
        string CiamCertificateUrl { get; set; }
        int CiamCertificateEvictInHours { get; set; }

        string CiamSubscriptionKey { get; set; }
        string CiamCustomerAudience { get; set; }
        string CiamSystemAudience { get; set; }
        string CiamIssuer { get; set; }
        string AzureAdIssuer { get; set; }


        bool ReturnGenericErrorMessages { get; set; }
    }
}
