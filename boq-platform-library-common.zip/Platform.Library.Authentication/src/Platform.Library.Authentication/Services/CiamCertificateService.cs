﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using Platform.Library.Authentication.Configuration;
using Platform.Library.Authentication.Models;
using Platform.Library.Authentication.Models.CIAM;
using Platform.Library.Common.AspNetCore.StandardApi.Http;
using Platform.Library.Common.Standard.Extensions;

namespace Platform.Library.Authentication.Services
{
    [Obsolete("Please register library's sdk using ConfigureAuthentication in RegistrationExtension.", false)]
    public class CiamCertificateService : ICiamCertificateService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IStandardAuthorizationSettings _standardAuthorizationSettings;
        private readonly ILogger<CiamCertificateService> _logger;

        public List<GenericCertificate> MemoizedCertificates = new List<GenericCertificate>();
        public DateTime lastUpdated;

        public CiamCertificateService(
            IHttpClientFactory httpClientFactory,
            IStandardAuthorizationSettings standardAuthorizationSettings,
            ILogger<CiamCertificateService> logger)
        {
            _httpClientFactory = httpClientFactory;
            _standardAuthorizationSettings = standardAuthorizationSettings;
            _logger = logger;

            lastUpdated = DateTime.MinValue; // Start evicted
        }

        /// <inheritdoc cref="ICiamCertificateService.GetCertificates(string, string, CancellationToken)"/>
        public async Task<IEnumerable<GenericCertificate>> GetCertificates(
            string initiatingSystemId,
            string initiatingSystemVersion,
            CancellationToken cancellationToken)
        {
            // Todo: Datetime provider
            //
            if (DateTime.Now > lastUpdated + TimeSpan.FromHours(_standardAuthorizationSettings.CiamCertificateEvictInHours))
            {
                var keys = await FetchCiamCertificatesFromEndpoint(cancellationToken);

                return keys;
            }

            return MemoizedCertificates;
        }

        /// <inheritdoc cref="ICiamCertificateService.GetSecurityKeys(CancellationToken)"/>
        public Task<IEnumerable<X509SecurityKey>> GetSecurityKeys(CancellationToken cancellationToken = default) { throw new NotImplementedException(); }

        private async Task<List<GenericCertificate>> FetchCiamCertificatesFromEndpoint(CancellationToken token)
        {
            try
            {
                var client = _httpClientFactory.CreateClient("CIAM_CertificateFetcher");

                var request = new HttpRequestMessage(
                    HttpMethod.Get,
                    _standardAuthorizationSettings.CiamCertificateUrl);

                var timestamp = DateTime.UtcNow.ToString(InternalConstants.TimestampFormat);

                request.AddHeaders(new Dictionary<string, string>()
                {
                    [StandardHeaderConstants.OcpApimSubscriptionKey] = _standardAuthorizationSettings.CiamSubscriptionKey,
                    [StandardHeaderConstants.RequestId] = Guid.NewGuid().ToString(),
                    [StandardHeaderConstants.Timestamp] = timestamp,

                    [StandardHeaderConstants.SendingSystemVersion] = "1", //Todo: get from config
                    [StandardHeaderConstants.SendingSystemId] = "InternalService", //Todo: get from config 
                    [StandardHeaderConstants.InitiatingSystemId] = "InternalService", //Todo: get from config
                    [StandardHeaderConstants.InitiatingSystemVersion] = "1", //Todo: get from config
                });

                var response = await client.SendAsync(request, token);

                var body = await response.Content.ReadAsStringAsync();

                var keys = JsonConvert.DeserializeObject<CiamCertificates>(body);

                var certs = keys.keys
                    .Where(s => s.alg == InternalConstants.Algorithms.RS256 && s.use == InternalConstants.Usage.Signature) // Magic numbers provided by CIAM: should get from token
                    .Select(s =>
                        new GenericCertificate(s.kid, s.x5c.First())
                    );

                _logger.LogInformation("CIAM Certificates Updated");

                lastUpdated = DateTime.Now;
                MemoizedCertificates = certs.ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unable to refresh CIAM certificates", ex.Message);
            }

            return MemoizedCertificates;
        }
    }
}