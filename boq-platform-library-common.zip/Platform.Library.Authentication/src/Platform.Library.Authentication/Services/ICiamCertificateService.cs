﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Tokens;
using Platform.Library.Authentication.Models;

namespace Platform.Library.Authentication.Services
{
    public interface ICiamCertificateService
    {
        /// <summary>
        /// Gets certificates of a CIAM token
        /// </summary>
        /// <param name="initiatingSystemId"></param>
        /// <param name="initiatingSystemVersion"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task<IEnumerable<GenericCertificate>> GetCertificates(string initiatingSystemId, string initiatingSystemVersion, CancellationToken cancellationToken);

        /// <summary>
        /// Gets security keys of a CIAM token
        /// </summary>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task<IEnumerable<X509SecurityKey>> GetSecurityKeys(CancellationToken cancellationToken = default);
    }
}