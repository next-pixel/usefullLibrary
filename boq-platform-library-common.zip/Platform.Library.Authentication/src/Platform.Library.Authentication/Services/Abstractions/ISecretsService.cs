using System.Threading;
using System.Threading.Tasks;
using Platform.Library.Authentication.Models;

namespace Platform.Library.Authentication.Services.Abstractions;

/// <summary>
/// Performs operations with secrets in Azure Key Vault.
/// </summary>
public interface ISecretsService
{
    /// <summary>
    /// Gets a set of <see cref="PgpKeys"/> from Key Vault. Assumes public and private key are base64 encoded.
    /// </summary>
    /// <param name="pgpPublicKeySecretName"></param>
    /// <param name="pgpPrivateKeySecretName"></param>
    /// <param name="pgpPrivateKeyPhraseSecretName"></param>
    /// <param name="cancellationToken"></param>
    /// <returns>PgpKeys, public and private keys are decoded from base64.</returns>
    public Task<PgpKeys> GetPgpKeysAsync(
        string pgpPublicKeySecretName, 
        string pgpPrivateKeySecretName, 
        string pgpPrivateKeyPhraseSecretName, 
        CancellationToken cancellationToken);
}