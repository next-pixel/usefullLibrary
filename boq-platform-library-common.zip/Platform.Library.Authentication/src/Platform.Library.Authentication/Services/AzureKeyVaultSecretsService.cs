using System;
using System.Threading;
using System.Threading.Tasks;
using Azure.Security.KeyVault.Secrets;
using Platform.Library.Authentication.Extensions;
using Platform.Library.Authentication.Models;
using Platform.Library.Authentication.Services.Abstractions;

namespace Platform.Library.Authentication.Services;

/// <inheritdoc />
public class AzureKeyVaultSecretsService : ISecretsService
{
    private readonly SecretClient _secretClient;

    /// <summary>
    /// Constructor for creating new instance of <see cref="AzureKeyVaultSecretsService"/>
    /// </summary>
    /// <param name="secretClient"></param>
    public AzureKeyVaultSecretsService(SecretClient secretClient)
    {
        _secretClient = secretClient.GuardNull(nameof(secretClient));
    }
    
    /// <inheritdoc />
    public async Task<PgpKeys> GetPgpKeysAsync(
        string pgpPublicKeySecretName, 
        string pgpPrivateKeySecretName,
        string pgpPrivateKeyPhraseSecretName, 
        CancellationToken cancellationToken)
    {
        var publicKeyTask = _secretClient.GetSecretAsync(pgpPublicKeySecretName, cancellationToken: cancellationToken);
        var privateKeyTask = _secretClient.GetSecretAsync(pgpPrivateKeySecretName, cancellationToken: cancellationToken);
        var privateKeyPhraseKeyTask = _secretClient.GetSecretAsync(pgpPrivateKeyPhraseSecretName, cancellationToken: cancellationToken);
        await Task.WhenAll(publicKeyTask, privateKeyTask, privateKeyPhraseKeyTask);

        return new PgpKeys
        {
            PublicKey = publicKeyTask.Result.Value.Value.DecodeBase64String(),
            PrivateKey = privateKeyTask.Result.Value.Value.DecodeBase64String(),
            PrivateKeyPhrase = privateKeyPhraseKeyTask.Result.Value.Value,
        };
    }
}