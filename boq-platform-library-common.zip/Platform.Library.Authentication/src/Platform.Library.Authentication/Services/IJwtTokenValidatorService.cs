﻿using Microsoft.IdentityModel.Tokens;
using Platform.Library.Authentication.Models;
using System.Collections.Generic;

namespace Platform.Library.Authentication.Services
{
    /// <summary>
    /// Interface for token validation
    /// </summary>
    public interface IJwtTokenValidatorService
    {
        /// <summary>
        /// Validates security keys and rawJwtToken
        /// </summary>
        /// <param name="securityKeys"></param>
        /// <param name="rawJwtToken"></param>
        /// <returns></returns>
        JwtTokenValidationResult ValidateToken(IEnumerable<SecurityKey> securityKeys, string rawJwtToken);

        /// <summary>
        /// Validate that the give token has the expected issuers.
        /// </summary>
        /// <param name="rawToken">The raw JWT token to validate the issuer claim</param>
        /// <param name="validIssuers">List of valid issuers</param>
        /// <param name="tokenIssuer">Output the token issuer claim</param>
        /// <returns>True if the token is valid. Otherwise, returns false</returns>
        bool ValidateIssuer(string rawToken, string[] validIssuers, out string tokenIssuer);
    }
}
