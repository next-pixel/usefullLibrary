﻿using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Platform.Library.Authentication.Models;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;

namespace Platform.Library.Authentication.Services
{
    /// <inheritdoc cref="IJwtTokenValidatorService"/>
    public class JwtTokenValidatorService : IJwtTokenValidatorService
    {
        private readonly JwtSecurityTokenHandler _jwtSecurityTokenHandler;
        private readonly ILogger<JwtTokenValidatorService> _logger;

        /// <summary>
        /// JwtTokenValidatorService Constructor 
        /// </summary>
        public JwtTokenValidatorService(ILogger<JwtTokenValidatorService> logger)
        {
            _jwtSecurityTokenHandler = new JwtSecurityTokenHandler();
            _logger = logger.GuardNull(nameof(logger));
        }

        /// <inheritdoc cref="IJwtTokenValidatorService.ValidateToken(IEnumerable{SecurityKey}, string)"/>
        public JwtTokenValidationResult ValidateToken(IEnumerable<SecurityKey> securityKeys, string rawJwtToken)
        {
            try
            {
                var validationParameters = new TokenValidationParameters
                {
                    // Note: Default all this off - just check the sig and populate the principal
                    NameClaimType = InternalConstants.ClaimType.Subject,
                    RequireExpirationTime = false,
                    ValidateAudience = false,
                    ValidateIssuer = false,
                    ValidateLifetime = false,
                    IssuerSigningKeys = securityKeys
                };

                _jwtSecurityTokenHandler.InboundClaimTypeMap.Clear();

                var result = _jwtSecurityTokenHandler.ValidateToken(
                    rawJwtToken,
                    validationParameters,
                    out var token);

                return JwtTokenValidationResult.Success(token, result);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failure to validate token");

                return JwtTokenValidationResult.Fail(ex.Message);
            }
        }

        /// <inheritdoc cref="IJwtTokenValidatorService.ValidateIssuer"/>
        public bool ValidateIssuer(string rawToken, string[] validIssuers, out string tokenIssuer)
        {
            tokenIssuer = default;
            try
            {
                var jwtToken = _jwtSecurityTokenHandler.ReadJwtToken(rawToken);
                tokenIssuer = jwtToken.Issuer;
                return validIssuers.AnyNullSafe(issuer => issuer == jwtToken.Issuer);
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "The issuer could not be validated: {ErrorMessage}", ex.Message);
                return false;
            }
        }
    }
}
