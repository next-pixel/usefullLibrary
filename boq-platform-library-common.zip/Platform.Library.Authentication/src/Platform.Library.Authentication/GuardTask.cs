﻿using System.Threading;
using System.Threading.Tasks;
using Platform.Library.Authentication.Models.Abstractions;

namespace Platform.Library.Authentication
{
    // This is just an Alias over 
    // Func<AuthenticationContext, CancellationToken, Task<AuthenticationContext>>
    //
    public delegate Task<IAuthenticationContext> GuardTask(
        IAuthenticationContext context, CancellationToken token);
}