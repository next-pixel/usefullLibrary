﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using Platform.Library.Authentication.Extensions;

namespace Platform.Library.Authentication
{
    /// <summary>
    /// Public constants available with Platform.Library.Authentication
    /// </summary>
    public static class AuthenticationConstants
    {
        /// <summary>
        /// Custom headers
        /// </summary>
        /// <remarks>
        /// Please read https://www.rfc-editor.org/rfc/rfc6648
        ///
        /// The prefix for "X-" has been depreciated
        /// </remarks>
        public static class Headers
        {
            /// <summary>
            /// Standard Authorization header
            /// </summary>
            public const string Authorization = nameof(Authorization);

            /// <summary>
            /// Header indicating the Temenos CIF to use
            /// </summary>
            /// <remarks>To only be used when using an Azure AD system context</remarks>
            public const string TemenosCif = "temenos-cif";

            /// <summary>
            /// Header indicating the Token level to use
            /// </summary>
            /// <remarks>To only be used when using an Azure AD system context</remarks>
            public const string AuthLevel = "azure-ad-auth-level";
        }

        /// <summary>
        /// Group of audience patterns that can be used to validate the audience
        /// </summary>
        public static class AudiencePatterns
        {
            /// <summary>
            /// Azure Ad resource api wildcard.
            /// <example>
            /// api://39d49d40-1350-4014-9550-dff9c5d386b1
            /// </example>
            /// </summary>
            public static readonly Regex ApiWildcard =
                @"^api:\/\/[{]?[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}[}]?$".AsRegex();
        }
    }
}
