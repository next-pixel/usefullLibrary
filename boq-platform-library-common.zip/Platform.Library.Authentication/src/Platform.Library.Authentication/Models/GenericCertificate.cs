﻿namespace Platform.Library.Authentication.Models
{
    public class GenericCertificate
    {
        public GenericCertificate(string kid, string base64Certificate)
        {
            Kid = kid;
            Base64Certificate = base64Certificate;
        }
        public string Kid { get; set; }
        public string Base64Certificate { get; set; }
    }
}