﻿namespace Platform.Library.Authentication.Models.Common
{
    public enum TokenLevel
    {
        None = 0,
        L1 = 1,
        L2 = 2,
        L3 = 3,
        L4 = 4 
    }
}