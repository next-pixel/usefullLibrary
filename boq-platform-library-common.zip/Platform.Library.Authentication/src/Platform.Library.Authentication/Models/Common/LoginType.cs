﻿namespace Platform.Library.Authentication.Models.Common
{
    public enum LoginType
    {
        PassCode,
        BioMetric,
        Citi //?
    }
}