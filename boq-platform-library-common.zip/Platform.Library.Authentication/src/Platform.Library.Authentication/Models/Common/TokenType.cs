﻿namespace Platform.Library.Authentication.Models.Common
{
    /// <summary>
    /// Indicates the type of token
    /// </summary>
    public enum TokenType
    {
        /// <summary>The token type is unknown</summary>
        Unknown,

        /// <summary>The token is from a CIAM customer</summary>
        CiamCustomer,

        /// <summary>The token is from the CIAM system</summary>
        CiamSystem,

        /// <summary>The token is an Azure AD managed identity token</summary>
        ManagedIdentity,

        /// <summary>The token is from an Azure Ad external party</summary>
        AzureAdExternal
    }
}