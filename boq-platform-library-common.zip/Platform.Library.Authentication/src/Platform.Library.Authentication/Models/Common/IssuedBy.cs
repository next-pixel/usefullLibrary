﻿namespace Platform.Library.Authentication.Models.Common
{
    public enum IssuedBy
    {
        Unknown,
        CIAM, 
        AzureAd
    }
}