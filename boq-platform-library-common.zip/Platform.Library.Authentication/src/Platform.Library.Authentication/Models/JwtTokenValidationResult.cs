﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text;

namespace Platform.Library.Authentication.Models
{
    /// <summary>
    /// Class that is  returned when validating a Token
    /// </summary>
    public class JwtTokenValidationResult
    {
        /// <summary>
        /// Returns true if Token Validation was success
        /// Else false
        /// </summary>
        public bool IsSuccess { get; set; }

        /// <summary>
        /// The JWT Security Token that was validated
        /// </summary>
        public SecurityToken SecurityToken { get; set; }

        /// <summary>
        /// The claims principal of the Token
        /// </summary>
        public ClaimsPrincipal ClaimsPrincipal { get; set; }

        /// <summary>
        /// Exception message when validation fails
        /// </summary>
        public string FailReason { get; set; }

        /// <summary>
        /// Builds JwtTokenValidationResult instance for success Validation
        /// </summary>
        /// <param name="token"></param>
        /// <param name="claims"></param>
        /// <returns></returns>
        public static JwtTokenValidationResult Success(SecurityToken token, ClaimsPrincipal claims) => new()
        {
            IsSuccess = true,
            SecurityToken = token,
            ClaimsPrincipal = claims
        };

        /// <summary>
        /// Builds JwtTokenValidationResult instance for failure Validation
        /// </summary>
        /// <param name="reason"></param>
        /// <returns></returns>
        public static JwtTokenValidationResult Fail(string reason = null) => new()
        {
            IsSuccess = false,
            FailReason = reason
        };
    }
}
