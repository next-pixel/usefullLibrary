﻿using System.Collections.Generic;

namespace Platform.Library.Authentication.Models.CIAM
{
    public class CiamCertificates
    {
        public List<Key> keys { get; set; }
    }
}