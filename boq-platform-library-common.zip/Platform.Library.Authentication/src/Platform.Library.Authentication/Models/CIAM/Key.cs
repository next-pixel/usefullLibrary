﻿using System.Collections.Generic;

namespace Platform.Library.Authentication.Models.CIAM
{
    public class Key
    {
        public string kty { get; set; }
        public string kid { get; set; }
        public string use { get; set; }
        public string x5t { get; set; }
        public List<string> x5c { get; set; }
        public string x { get; set; }
        public string y { get; set; }
        public string crv { get; set; }
        public string alg { get; set; }
    }
}