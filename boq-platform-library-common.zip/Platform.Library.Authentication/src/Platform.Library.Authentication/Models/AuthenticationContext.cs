﻿using System;
using System.Linq;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Platform.Library.Authentication.Models.Abstractions;
using Platform.Library.Authentication.Models.Common;
using Platform.Library.Common.Standard.ErrorHandling;

namespace Platform.Library.Authentication.Models
{
    /// <summary>
    /// This is a wrapping class that is passed to each link
    /// in the chain and progressively builds state
    /// </summary>
    public class AuthenticationContext : IAuthenticationContext
    {
        private readonly ILogger<AuthenticationContext> _logger;
        private string _temenosCif = null;
        private TokenLevel _authLevel = TokenLevel.None;

        public AuthenticationContext(ILogger<AuthenticationContext> logger)
        {
            _logger = logger.GuardNull(nameof(logger));
        }

        /// <summary>
        /// Current auth state of context - will be set false by guards
        /// </summary>
        public bool Authenticated { get; set; } = true;

        /// <summary>
        /// Response thrown if a failure response is collected - see
        /// the FailedAuthentication() method to help with this
        /// </summary>
        public StandardApiException FailureResponse { get; set; } = new StandardApiException
        {
            HttpStatusCode = 403, // AuthR usually  
            ErrorMessage = new ErrorMessageModel
            {
                MessageCode = "SPAUTH9999",
                UserMessageText = "Authentication Failed"
            }
        };
        
        /// <inheritdoc cref="IAuthenticationContext.AuthenticationType"/>
        public AuthenticationType AuthenticationType { get; set; }

        /// <summary>
        /// Base64 encoded token from header
        /// </summary>
        public string RawJwtToken { get; set; } = string.Empty;

        /// <inheritdoc cref="IAuthenticationContext.Headers"/>
        public IHeaderDictionary Headers { get; set; } = null;

        /// <summary>
        /// CIF extracted from the 'temenos_cif' claim
        /// </summary>
        public string Temenos_cif
        {
            get => IssuedBy == IssuedBy.CIAM
                ? Principal?.Claims?.FirstOrDefault(s => s.Type == InternalConstants.ClaimType.TemenosCIF)?.Value ?? string.Empty
                : _temenosCif;

            set
            {
                if (IssuedBy == IssuedBy.CIAM)
                    throw new NotSupportedException($"The {nameof(Temenos_cif)} cannot be set when issuer is {IssuedBy}");
                _temenosCif = value;
            }
        }

        /// <summary>
        /// Token audience extracted from the 'aud' claim
        /// </summary>
        public string Audience => Principal?.Claims?.FirstOrDefault(s => s.Type == InternalConstants.ClaimType.Audience)?.Value ?? string.Empty;

        /// <summary>
        /// Token issuer extracted from the 'iss' claim
        /// </summary>
        public string Issuer => Principal?.Claims?.FirstOrDefault(s => s.Type == InternalConstants.ClaimType.Issuer)?.Value ?? string.Empty;

        /// <summary>
        /// Ciam Username extracted from the 'sub' claim
        /// NOTE: if using system tokens this could be incorrect 
        /// </summary>
        public string CiamUsername => Principal?.Claims?.FirstOrDefault(s => s.Type == InternalConstants.ClaimType.Subject)?.Value ?? string.Empty;

        /// <summary>
        /// Claim principal populated by validating a token signature - contains claims
        /// </summary>
        public ClaimsPrincipal Principal { get; set; }

        /// <summary>
        /// Token populated by validating a token signature - contains expiry etc..
        /// </summary>
        public SecurityToken SecurityToken { get; set; }

        /// <summary>
        /// Value confirming whether SQA is enabled
        /// </summary>
        public bool IsSqaEnabled => Convert.ToBoolean(Principal?.Claims?.FirstOrDefault(s => s.Type == InternalConstants.ClaimType.QualityAssurance)?.Value ?? false.ToString().ToLower());

        /// <summary>
        /// Provides the status of a Citi customer
        /// </summary>
        public string CitiLinkingStatus => Principal?.Claims?.FirstOrDefault(s => s.Type == InternalConstants.ClaimType.CitiLinkingStatus)?.Value;

        /// <summary>
        /// Method for obtaining L2 Token
        /// </summary>
        public string MfaL2Method => Principal?.Claims?.FirstOrDefault(s => s.Type == InternalConstants.ClaimType.MfaMethod(2))?.Value;

        /// <summary>
        /// Method for obtaining L3 Token
        /// </summary>
        public string MfaL3Method => Principal?.Claims?.FirstOrDefault(s => s.Type == InternalConstants.ClaimType.MfaMethod(3))?.Value;

        /// <summary>
        /// The 2-letter country code of the mobile number in the username, e.g. 61xxxx results in AU.
        /// </summary>
        public bool? IsAustraliaMobile => Principal?.Claims?.FirstOrDefault(s => s.Type == InternalConstants.ClaimType.CountryCode2)?.Value.Equals(InternalConstants.CountryCode.Australia);

        /// <summary>
        /// Helper to determine if token is Ciam Customer or Ciam System
        /// </summary>
        public TokenType TokenType { get; set; }

        /// <summary>
        /// To support multiple sources we can update this when we get a match
        /// from CIAM or AzureAd
        /// </summary>
        public IssuedBy IssuedBy { get; set; }

        /// <summary>
        /// Token level extracted from the 'auth_level' claim
        /// </summary>
        public TokenLevel TokenLevel
        {
            get
            {
                if (IssuedBy == IssuedBy.CIAM)
                {
                    var claim = Principal.Claims.FirstOrDefault(s => s.Type.Equals(InternalConstants.ClaimType.AuthLevel));

                    if (claim == null)
                    {
                        return TokenLevel.None;
                    }

                    Enum.TryParse(claim.Value, out TokenLevel level);

                    return level;
                }
                else
                {
                    return _authLevel;
                }
            }
            set
            {
                if (IssuedBy == IssuedBy.CIAM)
                    throw new NotSupportedException($"The {nameof(TokenLevel)} cannot be set when issuer is {IssuedBy}");
                _authLevel = value;
            }
        }


        // Note: Future will need to know this for OTP
        //
        // public LoginType LoginType;

        // Note: look to add dynamic state between middleware
        //
        //public Dictionary<string, dynamic> Collector;

        /// <summary>
        /// Helper to assist in failing the middleware chains
        /// </summary>
        public AuthenticationContext FailedAuthentication(
            string message,
            string code = null, 
            int statusCode = 0,
            Exception exception = null,
            bool returnGenericErrorMessages = false)
        {
            // Note: log levels in prod wont log these
            //
            _logger.LogInformation(exception, message);

            Authenticated = false;

            // Note: for most operation we want to provide a generic failure
            //       so info is not leaked - log internal / return generic 
            //       SOME cases like OTP SHOULD NOT USE this as they MUST return 
            //       specific error codes/responses
            //
            if (returnGenericErrorMessages)
            {
                FailureResponse.ErrorMessage.UserMessageText = "Authentication Failed";
                return this; 
            }

            if (string.IsNullOrWhiteSpace(message) == false)
            {
                FailureResponse.ErrorMessage.UserMessageText = message;
            }

            if (string.IsNullOrWhiteSpace(code) == false)
            {
                FailureResponse.ErrorMessage.MessageCode = code;
            }

            if (statusCode != 0)
            {
                FailureResponse.HttpStatusCode = statusCode;
            }

            return this;
        }
        
        /// <summary>
        /// Current auth state of context - will be set false by guards
        /// </summary>
        /// <param name="item">The instance of <see cref="AuthenticationContext"/></param>
        /// <returns>true if authenticated, otherwise, returns false</returns>
        public static implicit operator bool(AuthenticationContext item) => item.Authenticated;
    }
}