﻿using Microsoft.AspNetCore.Http;
using Microsoft.IdentityModel.Tokens;
using Platform.Library.Authentication.Models.Common;
using Platform.Library.Common.Standard.ErrorHandling;
using System;
using System.Runtime.CompilerServices;
using System.Security.Claims;

namespace Platform.Library.Authentication.Models.Abstractions
{
    /// <summary>
    /// Authentication context
    /// </summary>
    public interface IAuthenticationContext
    {
        /// <summary>Is the mobile number from Australia</summary>
        bool? IsAustraliaMobile { get; }

        /// <summary>Has the Security Questions & Answers been enabled</summary>
        bool IsSqaEnabled { get; }

        /// <summary>Has this context been confirmed as authenticated</summary>
        bool Authenticated { get; internal set;  }

        /// <summary>Temenos customer identifier</summary>
        string Temenos_cif { get; internal set; }

        /// <summary>User name from Ciam</summary>
        string CiamUsername { get; }

        /// <summary>Audience</summary>
        string Audience { get; }

        /// <summary>Issuer</summary>
        string Issuer { get; }

        /// <summary>The raw JWT token</summary>
        string RawJwtToken { get; internal set; }

        /// <summary>Status for Citi bank linking</summary>
        string CitiLinkingStatus { get; }

        /// <summary>The Multi-Factor Authentication L2 method</summary>
        string MfaL2Method { get; }

        /// <summary>The Multi-Factor Authentication L3 method</summary>
        string MfaL3Method { get; }

        /// <summary>Token Level</summary>
        TokenLevel TokenLevel { get; internal set; }

        /// <summary>Identified issuer</summary>
        IssuedBy IssuedBy { get; internal set; }

        /// <summary>Identified type of token</summary>
        TokenType TokenType { get; internal set; }

        /// <summary>The headers for the authentication context</summary>
        IHeaderDictionary Headers { get; internal set; }

        /// <summary>The underlying <see cref="SecurityToken"/></summary>
        SecurityToken SecurityToken { get; internal set; }

        /// <summary>The claims principal</summary>
        ClaimsPrincipal Principal { get; internal set; }

        /// <summary>Failure response when guard failed</summary>
        StandardApiException FailureResponse { get; }
        
        /// <summary>Instance of <see cref="AuthenticationType"/> with the baseline authentication used for this context</summary>
        AuthenticationType AuthenticationType { get; internal set; }

        /// <summary>Generated failed authentication context</summary>
        AuthenticationContext FailedAuthentication(
            string message,
            string code = null,
            int statusCode = 0,
            Exception exception = null,
            bool returnGenericErrorMessages = false);
    }
}

