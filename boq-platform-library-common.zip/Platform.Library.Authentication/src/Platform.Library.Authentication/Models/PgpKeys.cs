namespace Platform.Library.Authentication.Models;

/// <summary>
/// Pgp keys that can be used for cryptography 
/// </summary>
public class PgpKeys
{
    /// <summary>
    /// Public key in Pgp generated keys.
    /// </summary>
    public string PublicKey { get; set; }

    /// <summary>
    /// Private key in Pgp generated keys.
    /// </summary>
    public string PrivateKey { get; set; }

    /// <summary>
    /// Private key phrase in Pgp generated keys.
    /// </summary>
    public string PrivateKeyPhrase { get; set; }
}