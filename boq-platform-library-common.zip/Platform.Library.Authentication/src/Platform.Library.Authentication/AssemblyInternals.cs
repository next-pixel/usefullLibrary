﻿using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("Platform.Library.Authentication.UnitTests")]
// Required for unit testing, so the internal properties will be visible for mocking
[assembly:InternalsVisibleTo("DynamicProxyGenAssembly2")]