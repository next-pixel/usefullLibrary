﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Platform.Library.Authentication
{
    /// <summary>
    /// Indicates the type of authentication checks required
    /// </summary>
    public enum AuthenticationType
    {
        /// <summary>No authentication checks</summary>
        None,

        /// <summary>Perform authentication checks for an L2 customer token</summary>
        CustomerToken,

        /// <summary>Perform authentication checks against being a valid CIAM token</summary>
        CiamToken,

        /// <summary>Perform authentication checks against being a valid CIAM or AD token</summary>
        CiamOrAdToken,

        /// <summary>Perform authentication checks against being a valid L2 customer token or AD token</summary>
        CustomerOrAdToken,
        
        /// <summary>Perform authentication checks against AD token only</summary>
        AdToken
    }
}
