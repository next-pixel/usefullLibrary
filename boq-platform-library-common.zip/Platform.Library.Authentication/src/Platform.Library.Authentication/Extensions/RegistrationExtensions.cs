﻿using System;
using System.Collections.Generic;
using Autofac;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Protocols;
using Platform.Library.Authentication.Guards;
using Platform.Library.Authentication.Models;
using Platform.Library.Authentication.Models.Common;
using Platform.Library.Authentication.Services;
using Platform.Library.Common;
using Platform.Library.Http;
using System.Diagnostics.CodeAnalysis;
using Platform.Library.Authentication.Extensions;

namespace Platform.Library.Authentication
{
    /// <summary>
    /// Extension methods relating to Authentication registration in containers
    /// </summary>
    public static class RegistrationExtensions
    {
        /// <summary>
        /// Register Authentication purely with Microsoft Dependency Injection
        /// </summary>
        /// <param name="services">Microsoft Dependency Injection <see cref="IServiceCollection"/></param>
        /// <param name="authType">Type of <see cref="AuthenticationType">authentication</see> required</param>
        /// <param name="inDebug">Indication of whether you are running in debug mode</param>
        /// <param name="componentConfigName">Configuration section of the parent for overriding client settings</param>
        /// <param name="configureGuard">Custom configure action which will be called at the end of the guard build configuration by the library</param>
        /// <param name="additionalGuardTypes">Any additional guard types to be registered</param>
        /// <returns>The instance of <see cref="IServiceCollection"/> passed in by the parameter</returns>
        [ExcludeFromCodeCoverage]
        public static IServiceCollection ConfigureAuthentication(
            this IServiceCollection services, 
            AuthenticationType authType,
            bool inDebug, 
            string componentConfigName, 
            Action<IGuardBuilder, IStandardAuthorisationGuards, IServiceProvider> configureGuard = null,
            params (Type ServiceType, Type ImplementationType)[] additionalGuardTypes)
        {
            // HttpClient & Settings
            services.RegisterHttpClient<CiamSettings>(
                inDebug,
                componentConfigName
            );

            services.
                AddOptions<AzureAdSettings>()
                .Configure<IConfiguration>((settings, config) => config.GetSection(InternalConstants.ConfigSections.AzureAd).Bind(settings));

            // Guard Builder
            services.AddTransient<IGuardBuilder>(provider =>
            {
                var guard = new GuardBuilder(provider.GetRequiredService<ILogger<AuthenticationContext>>());

                var standardGuard = provider.GetRequiredService<IStandardAuthorisationGuards>();

                guard.WithGuard(InternalGuards.UseAuthenticationType(authType));

                if (inDebug) return guard;
                
                guard.ConfigureGuardBuilder(authType, standardGuard);
                
                // Apply any extra validation
                configureGuard?.Invoke(guard, standardGuard, provider);

                return guard;
            });

            // Services
            //
            services.AddSingleton<ICiamCertificateService,NewCiamCertificateService>();
            services.AddSingleton<IJwtTokenValidatorService,JwtTokenValidatorService>();
            services.AddSingleton<IConfigurationRetriever<OpenIdConnectConfiguration>, OpenIdConnectConfigurationRetriever>();
            services.AddSingleton<IConfigurationManager<OpenIdConnectConfiguration>, ConfigurationManager<OpenIdConnectConfiguration>>(services =>
            {
                return new ConfigurationManager<OpenIdConnectConfiguration>(InternalConstants.StsDiscoveryEndpoint, services.GetRequiredService<IConfigurationRetriever<OpenIdConnectConfiguration>>());
            });

            // Guards
            //
            services.AddTransient<IStandardAuthorisationGuards,NewStandardAuthorisationGuards>();
            services.AddTransient<IStepUpGuards, StepUpGuards>();
            additionalGuardTypes.ForEachNullSafe(t => services.AddTransient(t.ServiceType,t.ImplementationType));

            return services;
        }
        
        /// <summary>
        /// Configure Authentication purely with Autofac
        /// (To be used in conjunction with <see cref="AddAuthenticationHttpClient(IServiceCollection, ContainerBuilder, IConfiguration, bool, string)">AddAuthenticationHttpClient</see>)
        /// </summary>
        /// <param name="builder">Autofac <see cref="ContainerBuilder"/></param>
        /// <param name="configuration">The <see cref="IConfiguration"/> root</param>
        /// <param name="authType">Type of <see cref="AuthenticationType">authentication</see> required</param>
        /// <param name="inDebug">Indication of whether you are running in debug mode</param>
        /// <param name="additionalGuardTypes">Any additional guard types to be registered</param>
        [ExcludeFromCodeCoverage]
        public static void ConfigureAuthentication(this ContainerBuilder builder, IConfiguration configuration, AuthenticationType authType, bool inDebug, params Type[] additionalGuardTypes)
        {
            // Settings 
            //
            builder.RegisterOptions<AzureAdSettings>(InternalConstants.ConfigSections.AzureAd);

            // Guard Builder
            //
            builder.Register(context =>
            {
                var guard = new GuardBuilder(context.Resolve<ILogger<AuthenticationContext>>());

                var standardGuard = context.Resolve<IStandardAuthorisationGuards>();

                // You must always have an Auth header
                guard.WithGuard(standardGuard.HasAuthHeader());

                if (!inDebug)
                    guard.ConfigureGuardBuilder(authType, standardGuard);

                return guard;
            }).AsImplementedInterfaces();

            // Services
            //
            builder.RegisterType<NewCiamCertificateService>().AsImplementedInterfaces().SingleInstance();
            builder.RegisterType<JwtTokenValidatorService>().AsImplementedInterfaces().SingleInstance();
            builder.RegisterType<OpenIdConnectConfigurationRetriever>().AsImplementedInterfaces().SingleInstance();
            builder.Register(context =>
            {
                return new ConfigurationManager<OpenIdConnectConfiguration>(InternalConstants.StsDiscoveryEndpoint, context.Resolve<IConfigurationRetriever<OpenIdConnectConfiguration>>());
            }).AsImplementedInterfaces().SingleInstance();

            // Guards
            //
            builder.RegisterType<NewStandardAuthorisationGuards>().AsImplementedInterfaces();
            builder.RegisterType<StepUpGuards>().AsImplementedInterfaces();
            additionalGuardTypes.ForEachNullSafe(t => builder.RegisterType(t).AsImplementedInterfaces());
        }

        /// <summary>
        /// Adds the client required for Authentication
        /// (To be used in conjunction with <see cref="ConfigureAuthentication(ContainerBuilder, IConfiguration, AuthenticationType, bool, Type[])">ConfigureAuthentication</see>)
        /// </summary>
        /// <param name="services">Microsoft Dependency Injection <see cref="IServiceCollection"/></param>
        /// <param name="builder">Autofac <see cref="ContainerBuilder"/></param>
        /// <param name="configuration">The <see cref="IConfiguration"/> root</param>
        /// <param name="inDebug">Indication of whether you are running in debug mode</param>
        /// <param name="componentConfigName">Configuration section of the parent for overriding client settings</param>
        [ExcludeFromCodeCoverage]
        public static IServiceCollection AddAuthenticationHttpClient(this IServiceCollection services, ContainerBuilder builder, IConfiguration configuration, bool inDebug, string componentConfigName)
        {
            // Http Client and Settings
            services.RegisterHttpClient<CiamSettings>(
                builder,
                configuration,
                inDebug,
                componentConfigName
            );
            return services;
        }
        
        /// <summary>
        /// Configure the Guard Builder based on the Authentication Type provided
        /// </summary>
        /// <param name="guard"></param>
        /// <param name="authType"></param>
        /// <param name="standardGuard"></param>
        /// <returns></returns>
         internal static IGuardBuilder ConfigureGuardBuilder(this IGuardBuilder guard,
            AuthenticationType authType,
            IStandardAuthorisationGuards standardGuard)
        {
            if (authType != AuthenticationType.None)
            {
                guard.WithDefaultTokenGuards(standardGuard);
            }

            switch (authType)
            {
                case AuthenticationType.CustomerToken:
                    guard
                        // Customer token must be at least level 2
                        .WithGuard(standardGuard.HasAtLeastTokenLevelOf(TokenLevel.L2));
                    break;
                case AuthenticationType.CiamToken:
                    // No extra guard, the HasValidToken is already present
                    break;
                case AuthenticationType.AdToken:
                case AuthenticationType.CiamOrAdToken:
                    guard.WithDefaultAzureTokenGuards(standardGuard);
                    break;
                case AuthenticationType.CustomerOrAdToken:
                    guard
                        .WithDefaultAzureTokenGuards(standardGuard)
                        // AzureAd Issued must have customer header provided
                        .WithGuard(i => i.IssuedBy == IssuedBy.AzureAd, standardGuard.HasCustomerHeader)
                        // AzureAd Issued must have auth level header
                        .WithGuard(i => i.IssuedBy == IssuedBy.AzureAd, standardGuard.HasAzureAdAuthLevelHeader)
                        // Token must have at least L2
                        .WithGuard(standardGuard.HasAtLeastTokenLevelOf(TokenLevel.L2));
                    break;
            }

            return guard;
        }
    }
}
