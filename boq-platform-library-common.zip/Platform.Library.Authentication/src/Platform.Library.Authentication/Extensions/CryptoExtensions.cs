﻿using System.IO;
using System.Text.RegularExpressions;
using DidiSoft.Pgp;
using Platform.Library.Authentication.Models;

namespace System
{
    public static class CryptoExtensions
    {
        private const string Regex_KeySeparator = "{0}-----{1} {2} KEY-----{3}{4}";
        private const string BofEofOptions = "(\\r\\n|\\n|)\\s*";

        public static bool IsBase64Encoded(this string base64String)
        {
            if (string.IsNullOrEmpty(base64String) || base64String.Length % 4 != 0)
                return false;

            try
            {
                var result = Convert.FromBase64String(base64String);
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Returns the number of bytes
        /// </summary>
        /// <param name="s">Base64 encoded string</param>
        /// <returns>The number of bytes or -1 if string cannot be converted to Base64</returns>
        public static int Base64EncodedStringByteCount(this string s)
        {
            try
            {
                byte[] bytes = Convert.FromBase64String(s);
                return bytes.Length;
            }
            catch
            {
                return -1;
            }
        }

        public static string StripForPublicKey(this string key)
        {
            return key.StripHeaderFooter(true);

        }

        public static string StripForPrivateKey(this string key)
        {
            return key.StripHeaderFooter(false);
        }

        /// <summary>
        /// Decrypts a stream using PGP
        /// </summary>
        /// <param name="encryptedStream"></param>
        /// <param name="keys"></param>
        /// <returns></returns>
        public static Stream DecryptPgp(this Stream encryptedStream, PgpKeys keys)
        {
            using var publicKeyStream = keys.PublicKey.ToMemoryStream();
            using var privateKeyStream = keys.PrivateKey.ToMemoryStream();
            var decryptedStream = new MemoryStream();
            var pgp = PgpLibConfig;
            pgp.DecryptAndVerifyStream(
                encryptedStream,
                privateKeyStream,
                keys.PrivateKeyPhrase,
                publicKeyStream,
                decryptedStream);
            return decryptedStream;
        }
        
        /// <summary>
        /// Encrypt a stream using PGP
        /// </summary>
        /// <param name="unencryptedStream"></param>
        /// <param name="keys"></param>
        /// <returns></returns>
        public static Stream EncryptPgp(this Stream unencryptedStream, PgpKeys keys)
        {
            using var publicKeyStream = keys.PublicKey.ToMemoryStream();
            using var privateKeyStream = keys.PrivateKey.ToMemoryStream();
            var encryptedStream = new MemoryStream();
            var pgp = PgpLibConfig;
            pgp.SignAndEncryptStream(
                unencryptedStream,
                privateKeyStream,
                keys.PrivateKeyPhrase,
                publicKeyStream,
                encryptedStream,
                true,
                true);
            return encryptedStream;
        }

        private static string RegexPattern(this string scope, bool isHeader)
        {
            return string.Format(
                Regex_KeySeparator,
                isHeader ? "^" : BofEofOptions,
                isHeader ? "BEGIN" : "END",
                scope,
                BofEofOptions,
                isHeader ? "" : "$"
            );
        }

        private static string StripHeaderFooter(this string key, bool isPublic)
        {
            var keyResult = key;
            var scope = isPublic ? "PUBLIC" : "PRIVATE";

            var pattern = scope.RegexPattern(true);
            var match = Regex.Match(keyResult, pattern);
            if (match.Success)
            {
                keyResult = keyResult.Replace(match.Value, "");

                pattern = scope.RegexPattern(false);
                match = Regex.Match(keyResult, pattern);
                if (match.Success)
                    return keyResult.Replace(match.Value, "");

                throw new ArgumentException($"{scope} key does not end with expected string: {pattern}", nameof(key));
            }
            else
                throw new ArgumentException($"{scope} key does not start with expected string: {pattern}", nameof(key));
        }
        
        private static readonly PGPLib PgpLibConfig = new PGPLib
        {
            Cypher = CypherAlgorithm.AES_256,
            Hash = HashAlgorithm.SHA256,
        };
    }
}
