﻿using System;
using System.Text;
using System.Text.RegularExpressions;

namespace Platform.Library.Authentication.Extensions;

internal static class StringExtensions
{
    /// <summary>
    /// Parse the given string to the <see cref="Regex"/> object
    /// </summary>
    /// <param name="pattern">The regex pattern to be used</param>
    /// <returns>The instance of the regex with the given pattern</returns>
    internal static Regex AsRegex(this string pattern) => new(pattern, RegexOptions.Compiled, TimeSpan.FromSeconds(2));

    
    /// <summary>
    /// Implement a custom enum parse that execute extra checks ensuring that the value is defined in the given <typeparamref name="TEnum"/> enum.
    /// The framework implementation allows integer to be passed into enum, resulting unexpected behaviour.
    /// </summary>
    /// <param name="source">The enum value string either as string format</param>
    /// <param name="value">The out</param>
    /// <typeparam name="TEnum">The target enum type to be parsed</typeparam>
    /// <returns>Return the equivalent enum for the given value or return the default for the enum (first option)</returns>
    internal static bool TryParseDefined<TEnum>(this string source, out TEnum value)
        where TEnum : struct, IConvertible
    {
        value = default;
        return Enum.IsDefined(typeof(TEnum), source) && Enum.TryParse<TEnum>(source, out value);
    }
    
    /// <summary>
    /// Decodes base 64 string
    /// </summary>
    /// <param name="base64String"></param>
    /// <returns></returns>
    internal static string DecodeBase64String(this string base64String)
    {
        var bytes = Convert.FromBase64String(base64String);
        return Encoding.UTF8.GetString(bytes);
    }
}