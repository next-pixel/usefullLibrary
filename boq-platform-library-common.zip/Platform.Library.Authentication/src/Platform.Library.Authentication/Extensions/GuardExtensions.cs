﻿using System;
using Platform.Library.Authentication.Guards;
using Platform.Library.Authentication.Models.Common;

namespace Platform.Library.Authentication.Extensions
{
    public static class GuardExtensions
    {
        [Obsolete("Use `WithDefaultTokenGuards` instead", false)]
        public static void WithDefaultGuards(this GuardBuilder guardBuilder, IStandardAuthorisationGuards standardAuthorisationGuards)
        {
            guardBuilder.WithGuard(standardAuthorisationGuards.HasValidToken);
            guardBuilder.WithGuard(standardAuthorisationGuards.HasNotExpired());
            guardBuilder.WithGuard(standardAuthorisationGuards.HasValidIssuer);
        }

        /// <summary>
        /// Include the common token guards for the basic validations.
        /// Token guards (called in this order):<para />
        /// - <see cref="IStandardAuthorisationGuards.HasAuthHeader"/><para />
        /// - <see cref="IStandardAuthorisationGuards.HasValidIssuer"/><para />
        /// - <see cref="IStandardAuthorisationGuards.HasValidToken"/><para />
        /// - <see cref="IStandardAuthorisationGuards.HasNotExpired"/><para />
        /// </summary>
        /// <param name="guardBuilder">Instance of <see cref="IGuardBuilder"/> to include the default guards</param>
        /// <param name="standardGuards">Instance of <see cref="IStandardAuthorisationGuards"/> to retrieve the guards</param>
        /// <returns>The same instance of <see cref="IGuardBuilder"/> passed via parameter</returns>
        public static IGuardBuilder WithDefaultTokenGuards(this IGuardBuilder guardBuilder,
            IStandardAuthorisationGuards standardGuards)
        {
            return guardBuilder
                // Ensure the auth header is set and assign to context
                .WithGuard(standardGuards.HasAuthHeader())
                // Validate the raw token issuer
                .WithGuard(standardGuards.HasValidIssuer)
                // Validate if the token is valid based on the issuer (CIAM / AzureAd)
                .WithGuard(standardGuards.HasValidToken)
                // Validate if the token is not expired
                .WithGuard(standardGuards.HasNotExpired());
        }

        /// <summary>
        /// Include the common token for Azure verification.
        /// Token guards:<para />
        /// - <see cref="IStandardAuthorisationGuards.IsManagedIdentityToken"/> (when <see cref="IssuedBy.AzureAd"/>, <see cref="TokenType.ManagedIdentity"/>)<para />
        /// - <see cref="IStandardAuthorisationGuards.HasValidExternalAudience"/> (when <see cref="IssuedBy.AzureAd"/>, <see cref="TokenType.AzureAdExternal"/>)<para />
        /// </summary>
        /// <param name="guardBuilder"></param>
        /// <param name="standardGuards"></param>
        /// <returns></returns>
        public static IGuardBuilder WithDefaultAzureTokenGuards(this IGuardBuilder guardBuilder,
            IStandardAuthorisationGuards standardGuards)
        {
            return guardBuilder
                // AzureAd Issued AND internal audience must use managed identity token
                .WithGuard(i => i.IssuedBy == IssuedBy.AzureAd && i.TokenType == TokenType.ManagedIdentity,
                    standardGuards.IsManagedIdentityToken)
                // AzureAd Issued AND external audience must have valid audience
                .WithGuard(i => i.IssuedBy == IssuedBy.AzureAd && i.TokenType == TokenType.AzureAdExternal,
                    standardGuards.HasValidExternalAudience());
        }
    }
}