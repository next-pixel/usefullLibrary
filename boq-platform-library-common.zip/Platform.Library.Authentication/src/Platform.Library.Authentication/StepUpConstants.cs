﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Platform.Library.Authentication
{
    public class StepUpConstants
    {
        public class Codes
        {
            public static string GenericError = "SPAUTH9999";
            public static string L3StepUpByOtpOrSqa = "SPSTPUP001";
            public static string L3StepUpByOtp = "SPSTPUP009";
            public static string L3StepUpBySqa = "SPSTPUP002";
            public static string L3StepUpBySqaOrCall = "SPSTPUP010";
            public static string L4StepUpByOtpAndSqa = "SPSTPUP003";
            public static string L4StepUpBySqaAndCall = "SPSTPUP011";
            public static string L4StepUpByCall = "SPSTPUP004";
            public static string L4StepUpBySqa = "SPSTPUP005";
            public static string L4StepUpBySqaOrCall = "SPSTPUP012";
            public static string L4StepUpBySqaNotAustralian = "SPSTPUP006";
            public static string L4StepUpBySqaOrCallNotAustralian = "SPSTPUP013";
            public static string L4StepUpByOtp = "SPSTPUP007";
            public static string L4StepUpByCallNotAustralian = "SPSTPUP008";
        }

        public class Messages
        {
            public static string GenericError = "Authentication Failed";
            public static string L3StepUpByOtpOrSqa = "Level 3 Token Required for this operation. Stepup Required using OTP via SMS or SQA";
            public static string L3StepUpByOtp = "Level 3 Token Required for this operation. Stepup Required using OTP via SMS";
            public static string L3StepUpBySqa = "Level 3 Token Required for this operation. Stepup Required using SQA";
            public static string L3StepUpBySqaOrCall = "Level 3 Token Required for this operation.  Set up SQA and try again OR call VMA call centre";
            public static string L4StepUpByOtpAndSqa = "Level 4 Token Required for this operation. Stepup Required using OTP via SMS followed by SQ";
            public static string L4StepUpBySqaAndCall = "Level 4 Token Required for this operation.  Set up SQA and try again OR call VMA call centre";
            public static string L4StepUpByCall = "Level 4 Token Required for this operation. Ring VMA Call Centre";
            public static string L4StepUpBySqa = "Level 4 Token Required for this operation. Stepup using SQA";
            public static string L4StepUpBySqaOrCall = "Level 4 Token Required for this operation. Set up SQA and try again OR call VMA call centre";
            public static string L4StepUpBySqaNotAustralian = "Level 4 Token Required for this operation. Stepup using SQA";
            public static string L4StepUpBySqaOrCallNotAustralian = "Level 4 Token Required for this operation. Set up SQA and try again OR call VMA call centre ";
            public static string L4StepUpByOtp = "Level 4 Token Required for this operation. Stepup using OTP via SMS";
            public static string L4StepUpByCallNotAustralian = "Level 4 Token Required for this operation. Ring VMA Call Centre";
        }
    }
}
