using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Azure;
using Azure.Security.KeyVault.Secrets;
using FluentAssertions;
using FluentAssertions.Execution;
using Moq;
using Platform.Library.Authentication.Services;
using Xunit;

namespace Platform.Library.Authentication.UnitTests;

public class AzureKeyVaultSecretsServiceTests
{
    private readonly Mock<SecretClient> _mockSecretClient;
    private readonly AzureKeyVaultSecretsService _service;

    public AzureKeyVaultSecretsServiceTests()
    {
        _mockSecretClient = new Mock<SecretClient>();
        _service = new AzureKeyVaultSecretsService(_mockSecretClient.Object);
    }

    [Fact]
    public async Task GetPgpKeysAsync_ShouldReturnPgpKeys_WhenSecretsExist()
    {
        // Arrange
        var publicKeySecret = new KeyVaultSecret("publicKey", Convert.ToBase64String(Encoding.UTF8.GetBytes("publicKeyContent")));
        var privateKeySecret = new KeyVaultSecret("privateKey", Convert.ToBase64String(Encoding.UTF8.GetBytes("privateKeyContent")));
        var privateKeyPhraseSecret = new KeyVaultSecret("privateKeyPhrase", "privateKeyPhraseContent");

        _mockSecretClient.Setup(x => x.GetSecretAsync("publicKeySecretName", null, It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue(publicKeySecret, null));
        _mockSecretClient.Setup(x => x.GetSecretAsync("privateKeySecretName", null, It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue(privateKeySecret, null));
        _mockSecretClient.Setup(x => x.GetSecretAsync("privateKeyPhraseSecretName", null, It.IsAny<CancellationToken>()))
            .ReturnsAsync(Response.FromValue(privateKeyPhraseSecret, null));

        // Act
        var result = await _service.GetPgpKeysAsync("publicKeySecretName", "privateKeySecretName", "privateKeyPhraseSecretName", CancellationToken.None);

        // Assert
        using (new AssertionScope())
        {
            result.Should().NotBeNull();
            result.PublicKey.Should().Be("publicKeyContent");
            result.PrivateKey.Should().Be("privateKeyContent");
            result.PrivateKeyPhrase.Should().Be("privateKeyPhraseContent");
        }
    }

    [Fact]
    public void Constructor_ShouldThrowArgumentNullException_WhenSecretClientIsNull()
    {
        // Arrange
        Action act = () => new AzureKeyVaultSecretsService(null);

        // Act & Assert
        act.Should().Throw<ArgumentNullException>().WithMessage("*secretClient*");
    }
}