﻿using FluentAssertions;
using Xunit;

namespace Platform.Library.Authentication.UnitTests;

public class AuthenticationConstantsTests
{
    [Theory]
    [InlineData("api://39d49d40-1350-4014-9550-dff9c5d386b1", true)]
    [InlineData("api://3C3E086E-E54D-4E79-9107-3FFD71F86CCE", true)]
    [InlineData("api://39d40-1350-4014-9550-dff9c5d386b1", false)]
    [InlineData("api://39d49d40-1350-4014-9550-dff9c5d386b1d  ", false)]
    [InlineData("i-am-invalid", false)]
    [InlineData("api://let-me-in", false)]
    [InlineData("  ", false)]
    [InlineData("", false)]
    [InlineData("39d49d40-1350-4014-9550-dff9c5d386b1", false)]
    public void ApiAudienceWildcard_Should_BeAsExpected(string audience, bool expectedBeValid)
    {
        // act
        var isMatch = AuthenticationConstants.AudiencePatterns.ApiWildcard.IsMatch(audience);
        
        // assert
        isMatch.Should().Be(expectedBeValid);
    }
}