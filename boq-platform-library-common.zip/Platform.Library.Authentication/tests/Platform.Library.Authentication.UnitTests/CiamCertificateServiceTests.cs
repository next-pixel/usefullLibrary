﻿using FluentAssertions;
using FluentAssertions.Execution;
using Platform.Library.Authentication.Models.CIAM;
using Platform.Library.Authentication.Services;
using Platform.Library.Common.AspNetCore.StandardApi.Http;
using Platform.Library.Testing.XUnit;
using System;
using System.Collections.Generic;
using System.Net;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using Xunit;
using Xunit.Abstractions;

namespace Platform.Library.Authentication.UnitTests
{
    [TestType(TestTypeEnum.UnitTest)]
    public class CiamCertificateServiceTests : XUnitTestFixture
    {
        public CiamCertificateServiceTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture) { }

        protected ContextModule Context => Module<ContextModule>();
        protected ModelModule Models => Module<ModelModule>();
        protected ResourceModule Resource => Module<ResourceModule>();
        
        [ModuleInit(nameof(InitHttpModule))]
        protected HttpModule Http => Module<HttpModule>();

        // Initialize any modules
        private void InitHttpModule()
        {
            Http.HandleMockRequestEvent += HttpModule_HandleMockRequestEvent;
        }

        private void HttpModule_HandleMockRequestEvent(object sender, HttpRequestEventArgs args)
        {
            switch ( args.ClientName )
            {
                case InternalConstants.HttpClients.CertificateClient:

                    if ( args.RequestPath.AbsolutePath == "/public-keys" )
                    {
                        args.RequestMessage.Headers.TryGetValues(StandardHeaderConstants.InitiatingSystemVersion, out var version);
                        if (version.AnyNullSafe(a => a.Equals("2")))
                            args.SetResponse<CiamCertificates>(HttpStatusCode.OK, Resource.ExtractManifestResource<CiamCertificates>("valid"), null);
                        else
                            args.SetResponse(HttpStatusCode.OK, Resource.ExtractManifestResource<CiamCertificates>("nokeys"), null);
                        return;
                    }
                    break;
            }

            throw new NotSupportedException($"[{args.ClientName}] {args.Method.ToString().ToUpper()}[{args.RequestPath.AbsoluteUri}] Not supported by {nameof(HttpModule_HandleMockRequestEvent)}");
        }

        protected override void TestSetup()
        {
            Context.RegisterMockHttpClient<CiamSettings>();

            Context.RegisterModule<TestModule>(
                PlatformContext.ApplicationConfiguration.AsArg("configuration"),
                AuthenticationType.CustomerToken.AsArg("authType"),
#if DEBUG
                true.AsArg("inDebug")
#else
                false.AsArg("inDebug")
#endif
            );
        }

        [Fact]
        public async Task GetCertificate_ExpectedBehavior()
        {
            // Arrange
            var initiatingSystemId = Assembly.GetExecutingAssembly().GetName().Name;

            var client = Context.Resolve<ICiamCertificateService>();

            // Act
            var certificates = await client.GetCertificates(initiatingSystemId, "2", CancellationToken.None);

            // Assert
            using (new AssertionScope())
            {
                certificates.Should().NotBeEmpty();
                certificates.Should().HaveCount(2);
            }
        }

        [Fact]
        public async Task GetCertificate_GetSecurityKeys_Should_ReturnEmpty()
        {
            // Arrange
            var initiatingSystemId = Assembly.GetExecutingAssembly().GetName().Name;

            var client = Context.Resolve<ICiamCertificateService>();

            // Act
            var certificates = await client.GetSecurityKeys(CancellationToken.None);

            // Assert
            certificates.Should().BeEmpty();
        }
    }
}
