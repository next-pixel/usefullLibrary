﻿using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Protocols;
using Platform.Library.Authentication.Services;
using Platform.Library.Testing.XUnit;
using Xunit.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Xunit;
using Microsoft.Extensions.Configuration;
using FluentAssertions;
using FluentAssertions.Execution;

namespace Platform.Library.Authentication.UnitTests
{
    [TestType(TestTypeEnum.UnitTest)]
    public class JwtTokenValidatorServiceTest : XUnitTestFixture
    {
        private const string JwtToken = "eyJ0eXAiOiJKV1QiLCJraWQiOiJyTWhnRnFmUmlITzdNbEpISEh4UkpmN0JuSkU9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJDMzg1NWZkMGUtZjNjNy00ODUzLWJmNDAtMDg3MDQ1NjIwNDBmIiwiY3RzIjoiT0FVVEgyX1NUQVRFTEVTU19HUkFOVCIsImF1dGhfbGV2ZWwiOjIsImF1ZGl0VHJhY2tpbmdJZCI6IjlmOWEyZWRhLThhYzktNDQwNS04MTBhLTA3NjE5NzYxYzdmYi0xMDkyNTczMTIiLCJpc3MiOiJodHRwOi8vYW0tYjEuc2l0Mi5pZC5hd3MtYm9xOjgwODAvb3BlbmFtL29hdXRoMi9yZWFsbXMvcm9vdC9yZWFsbXMvdm1hIiwidG9rZW5OYW1lIjoiYWNjZXNzX3Rva2VuIiwidG9rZW5fdHlwZSI6IkJlYXJlciIsImF1dGhHcmFudElkIjoiY3YxekwycF8wT0RkZ1kxMEUyNjB3a3FBUFo4IiwiYXVkIjoiVk1BTW9iaWxlQXBwIiwibmJmIjoxNjk2OTA2NzEwLCJncmFudF90eXBlIjoiYXV0aG9yaXphdGlvbl9jb2RlIiwic2NvcGUiOlsibWZhLmFjY2Vzc19jb2RlLjIiLCJjdXN0b21lci5mdWxsLm5vcm1hbCJdLCJhdXRoX3RpbWUiOjE2OTY5MDY3MDksInJlYWxtIjoiL3ZtYSIsImV4cCI6MTY5NjkwNzMxMCwiaWF0IjoxNjk2OTA2NzEwLCJleHBpcmVzX2luIjo2MDAsImp0aSI6Imdiek1Bd1JJWFZxbDNHZ3luY3NwN0VLQzZWcyIsIm1mYV9tZXRob2QuMiI6IkFDQ0VTU19DT0RFIiwiaXNfc3FhX2VuYWJsZWQiOnRydWUsInRlbWVub3NfY2lmIjoiMTMwMDA3NjA3NiIsImNpdGlfbGlua2luZ19zdGF0dXMiOiJQRU5ESU5HIiwibXVzdF9hY2NlcHRfVENzIjpmYWxzZSwiaXNvMzE2Nl8yIjoiQVUifQ.TYdpgNtmzCp-1D3jyQLHF6-8Y3XDbMcFGHQ7BPsk9bLPGTW8eUF3B6SQk3OVpWhviVBnBvpVgZlZXAOxHorHgHTDUOfpdW8H0La87dWCWE-9HsI-5WnQOra1IasxFexUohbtrwD58z7P2UJsO2dBYYqBDOQKC4cVjVglFtCAJdhP6N6nWc-q350Ig5kvdpL6J3VZazXJBrQBKxI-HCrc6_08bzJbvesMrAMPFjc2KEwcDeObdxDGSTkmEd8A7auRIEe0N1voEWosBLJskdbCc3zZRy2cDMG0Czp7nAnjI9pWgGvt0lhrMBBR55fzJfVgayBZ-o-Po8-PJ2V7rUmrlQ";
        public JwtTokenValidatorServiceTest(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) 
            : base(outputHelper, classFixture)
        {
        }
        
        private ContextModule Context => Module<ContextModule>();

        protected override void TestSetup()
        {
            Context.RegisterWithMsDi(services =>
            {
                services.
                    AddOptions<AzureAdSettings>()
                    .Configure<IConfiguration>((settings, config) => config.GetSection(InternalConstants.ConfigSections.AzureAd).Bind(settings));

                services.AddSingleton<IJwtTokenValidatorService, JwtTokenValidatorService>();
                services.AddSingleton<IConfigurationRetriever<OpenIdConnectConfiguration>, OpenIdConnectConfigurationRetriever>();
                services.AddSingleton<IConfigurationManager<OpenIdConnectConfiguration>, ConfigurationManager<OpenIdConnectConfiguration>>(services =>
                {
                    return new ConfigurationManager<OpenIdConnectConfiguration>(InternalConstants.StsDiscoveryEndpoint, services.GetRequiredService<IConfigurationRetriever<OpenIdConnectConfiguration>>());
                });
            });
        }

        [Fact]
        public void ValidateToken_InvalidSecurityKeys()
        {
            //Arrange
            var service = Context.Resolve<IJwtTokenValidatorService>();

            //Act
            var result = service.ValidateToken(null, JwtToken);

            //Assert
            using (new AssertionScope())
            {
                result.IsSuccess.Should().BeFalse();
                result.SecurityToken.Should().BeNull();
                result.ClaimsPrincipal.Should().BeNull();
            }
        }

        [Theory]
        [InlineData(JwtToken, new [] { "http://am-b1.sit2.id.aws-boq:8080/openam/oauth2/realms/root/realms/vma"}, true, "http://am-b1.sit2.id.aws-boq:8080/openam/oauth2/realms/root/realms/vma")]
        [InlineData(JwtToken, new [] { "http://my-cool-issuer"}, false, "http://am-b1.sit2.id.aws-boq:8080/openam/oauth2/realms/root/realms/vma")]
        [InlineData(JwtToken, null, false, "http://am-b1.sit2.id.aws-boq:8080/openam/oauth2/realms/root/realms/vma")]
        [InlineData(" ", new [] { "http://my-cool-issuer"}, false, null)]
        [InlineData("", new [] { "http://my-cool-issuer"}, false, null)]
        [InlineData(null, new [] { "http://my-cool-issuer"}, false, null)]
        public void ValidateIssuer_Should_BeAsExpected(string rawToken, string[] validIssuers, bool expectedValid, string expectedIssuer)
        {
            // arrange
            var service = Context.Resolve<IJwtTokenValidatorService>();
            
            // act
            var result = service.ValidateIssuer(rawToken, validIssuers, out var returnIssuer);

            // assert
            using (new AssertionScope())
            {
                result.Should().Be(expectedValid);
                returnIssuer.Should().BeEquivalentTo(expectedIssuer);
            }
        }
    }
}
