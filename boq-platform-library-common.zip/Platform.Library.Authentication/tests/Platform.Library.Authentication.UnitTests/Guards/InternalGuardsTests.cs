﻿using System.Threading.Tasks;
using FluentAssertions;
using FluentAssertions.Execution;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Platform.Library.Authentication.Guards;
using Platform.Library.Authentication.Models;
using Platform.Library.Authentication.Services;
using Platform.Library.Testing.XUnit;
using Xunit;
using Xunit.Abstractions;

namespace Platform.Library.Authentication.UnitTests.Guards;

[TestType(TestTypeEnum.UnitTest)]
public class InternalGuardsTests : XUnitTestFixture
{
 
    protected ContextModule Context => Module<ContextModule>();
    
    public InternalGuardsTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) 
        : base(outputHelper, classFixture)
    {
    }
    
    protected override void TestSetup()
    {
        Context.RegisterTypeAsInterfaces<GuardBuilder>();
    }

    [Theory]
    [InlineData(AuthenticationType.None)]
    [InlineData(AuthenticationType.AdToken)]
    [InlineData(AuthenticationType.CustomerOrAdToken)]
    public async Task UseAuthenticationType_Should_SetAuthenticationTypeInContext(AuthenticationType authenticationType)
    {
        // arrange
        var guardBuilder = Context.Resolve<IGuardBuilder>();

        // act
        var context = await guardBuilder
            .WithGuard(InternalGuards.UseAuthenticationType(authenticationType))
            .Execute();
        
        // assert
        using (new AssertionScope())
        {
            context.AuthenticationType.Should().Be(authenticationType);
        }
    }
}