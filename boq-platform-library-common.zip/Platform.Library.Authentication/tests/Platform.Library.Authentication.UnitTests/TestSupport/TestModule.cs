﻿using System;
using System.Collections.Generic;
using System.Text;
using Autofac;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Platform.Library.Authentication;

namespace Platform.Library.Authentication.UnitTests
{
    public class TestModule : Module
    {
        private readonly IConfiguration _config;
        private readonly AuthenticationType _authType;
        private readonly bool _inDebug;

        public TestModule(IConfiguration configuration, AuthenticationType authType, bool inDebug)
        {
            _config = configuration.GuardNull();
            _authType = authType;
            _inDebug = inDebug;
        }

        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterInstance<IConfiguration>(_config);
            builder.ConfigureAuthentication(_config, _authType, _inDebug);
        }
    }
}
