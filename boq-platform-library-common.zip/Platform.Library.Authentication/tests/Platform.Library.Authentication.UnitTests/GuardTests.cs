using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FluentAssertions;
using FluentAssertions.Execution;
using Microsoft.AspNetCore.Connections;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Moq;
using Platform.Library.Authentication.Guards;
using Platform.Library.Authentication.Models;
using Platform.Library.Authentication.Services;
using Platform.Library.Common.Standard.ErrorHandling;
using Xunit;
using Xunit.Abstractions;
using Microsoft.Extensions.Options;
using Platform.Library.Testing.XUnit;
using Platform.Library.Authentication.Models.Abstractions;
using Platform.Library.Authentication.Models.Common;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;

namespace Platform.Library.Authentication.UnitTests
{
    [TestType(TestTypeEnum.UnitTest)]
    public class GuardTests : XUnitTestFixture
    {
        private const string CiamTestIssuer = "https://am-b1.dev.id.aws-boq:8443/openam/oauth2/realms/root/realms/vma";
        private const string AzureTestIssuer = "https://sts.windows.net/b0e7ed13-0b42-4ca9-82f8-c753aecbae79/";
        
        private const string CustomerTokenRestrictedSigned =
            "eyJ0eXAiOiJKV1QiLCJ6aXAiOiJOT05FIiwiYWxnIjoiSFMyNTYifQ.eyJzdWIiOiJDMzA0NjFhMGUtNzZmYi00ZWY5LTk3ZjAtMWY0YzRiNmYxYWMwIiwiY3RzIjoiT0FVVEgyX1NUQVRFTEVTU19HUkFOVCIsImF1dGhfbGV2ZWwiOjEsImF1ZGl0VHJhY2tpbmdJZCI6IjE3Yzg0MGU5LTg4OTItNDk0Ny1hODM4LTFmMTY5YjhmMzM1Ni0xNTEiLCJpc3MiOiJodHRwczovL2FtLWIxLmRldi5pZC5hd3MtYm9xOjg0NDMvb3BlbmFtL29hdXRoMi9yZWFsbXMvcm9vdC9yZWFsbXMvdm1hIiwidG9rZW5OYW1lIjoiYWNjZXNzX3Rva2VuIiwidG9rZW5fdHlwZSI6IkJlYXJlciIsImF1dGhHcmFudElkIjoiUXZ2SHJBcjZTb3VoeGZ0aDhzWl80SW9wdTgwIiwiYXVkIjoiVk1BTW9iaWxlQXBwIiwibmJmIjoxNTg1MDg4MDM0LCJncmFudF90eXBlIjoiYXV0aG9yaXphdGlvbl9jb2RlIiwic2NvcGUiOlsiY3VzdG9tZXIucmVzdHJpY3RlZC5ub3JtYWwiXSwiYXV0aF90aW1lIjoxNTg1MDg4MDM0LCJyZWFsbSI6Ii92bWEiLCJleHAiOjE1ODUwODgzMzQsImlhdCI6MTU4NTA4ODAzNCwiZXhwaXJlc19pbiI6MzAwLCJqdGkiOiI4cnBLcWhtbG05RmtrZDNxRzhwNlFOcC1uVDAiLCJzZXNzaW9uIjoialZsS0dKOE9qOFJoSjJTUjBGQVBjZ1FrVFRZLipBQUpUU1FBQ01ERUFBbE5MQUJ4TGNYQnZRemRhWW1kekwwOVZhRFpTZG1zNVFqUXJOMmRLVUUwOUFBUjBlWEJsQUFORFZGTUFBbE14QUFBLioifQ.wBPcANhVqqV-SxV-2OEW14HWjuEWHoNY0MQEZznTfvk";

        private const string CustomerTokenExpiredSigned =
            "eyJ0eXAiOiJKV1QiLCJraWQiOiJHdEhFTmZmcmxRTis5ZWxTVmlaNHJCdUIvSFU9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJDNjNjMDAxODUtODI1MC00OWFlLTg1ZjEtZWEzMzc4NzdhZDk5IiwiY3RzIjoiT0FVVEgyX1NUQVRFTEVTU19HUkFOVCIsImF1dGhfbGV2ZWwiOjMsImF1ZGl0VHJhY2tpbmdJZCI6IjgyYzFlY2QwLTEwODUtNGE1ZS04ZTE1LTczNjFiZDhhZDliYy03ODM1MDQ1IiwiaXNzIjoiaHR0cDovL2FtLWIxLnNpdDIuaWQuYXdzLWJvcTo4MDgwL29wZW5hbS9vYXV0aDIvcmVhbG1zL3Jvb3QvcmVhbG1zL3ZtYSIsInRva2VuTmFtZSI6ImFjY2Vzc190b2tlbiIsInRva2VuX3R5cGUiOiJCZWFyZXIiLCJhdXRoR3JhbnRJZCI6IlM1a3hSakMybGthVDR6ZW1hclBqQmtFUTBjMCIsImF1ZCI6IlZNQU1vYmlsZUFwcCIsIm5iZiI6MTY4Mjk4NzMwMywiZ3JhbnRfdHlwZSI6ImF1dGhvcml6YXRpb25fY29kZSIsInNjb3BlIjpbIm1mYS5hY2Nlc3NfY29kZS4yIiwiY3VzdG9tZXIuZnVsbC5oaWdoIiwibWZhLm90cC1zbXMuMyJdLCJhdXRoX3RpbWUiOjE2ODI5ODczMDMsInJlYWxtIjoiL3ZtYSIsImV4cCI6MTY4Mjk4NzkwMywiaWF0IjoxNjgyOTg3MzAzLCJleHBpcmVzX2luIjo2MDAsImp0aSI6IkFsY2FDQ0tGX3FUX0RIeHZSU0wtZWVhRk0zSSIsIm1mYV9tZXRob2QuMiI6IkFDQ0VTU19DT0RFIiwibWZhX21ldGhvZC4zIjoiT1RQLVNNUyIsImlzX3NxYV9lbmFibGVkIjpmYWxzZSwicmVtYWluaW5nX2xvZ2luX2NvdW50IjowLCJ0ZW1lbm9zX2NpZiI6IjExMDAyMDI0NTEiLCJjaXRpX2xpbmtpbmdfc3RhdHVzIjoiUEVORElORyIsIm11c3RfYWNjZXB0X1RDcyI6dHJ1ZSwiaXNvMzE2Nl8yIjoiQVUifQ.X8PZRJtO_SXM8FnDwohuSLQJJt5FAYhHs0XqVnXlO2mquQwJFNNsSAlujbf2va1i7DT-uzpQKemUyCKUafwov3JTpvuqaER9MjC-njcKI5M1d3cwESzQbkLQDR2_lmuzT0UGubxDKdYcLIrgmE46GEGrY-NMWbgamhkQo7gV5a-9tLbC3PRJ6YneO7dBWl0Tm0pkWbHkSPP2FbZtLDdi8xAOgDtbk70ys6c4inrxvjeX8iBFZQaZ6q75LMvaxY15mUtZ2S6rrm5qc1sG-iiOwtQ8owDDba8ZFdtZIKu6Me0pC85fbA-3syNpwwmLDD9hrhtd-c35nWgTLkqhE8Wo4A";

        private const string SystemTokenNotSigned =
            "eyJ0eXAiOiJKV1QiLCJ6aXAiOiJOT05FIiwia2lkIjoid1UzaWZJSWFMT1VBUmVSQi9GRzZlTTFQMVFNPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJWTUFBUElHYXRld2F5IiwiY3RzIjoiT0FVVEgyX1NUQVRFTEVTU19HUkFOVCIsImF1ZGl0VHJhY2tpbmdJZCI6ImNhYWZkNDgxLWY4ODMtNDk0Ny1hMzA3LTA2ZWY3OWY3MzBkYy00ODQiLCJpc3MiOiJodHRwczovL2FtLWIxLmRldi5pZC5hd3MtYm9xOjg0NDMvb3BlbmFtL29hdXRoMi9yZWFsbXMvcm9vdC9yZWFsbXMvdm1hIiwidG9rZW5OYW1lIjoiYWNjZXNzX3Rva2VuIiwidG9rZW5fdHlwZSI6IkJlYXJlciIsImF1dGhHcmFudElkIjoiTXZHWFNFNWJ4N0FpU1VGdUV1elZGX2RsU1FBIiwiYXVkIjoiVk1BQVBJR2F0ZXdheSIsIm5iZiI6MTU4NTg5MTI0NywiZ3JhbnRfdHlwZSI6ImNsaWVudF9jcmVkZW50aWFscyIsInNjb3BlIjpbImFtLWludHJvc3BlY3QtYWxsLXRva2VucyIsInN5c3RlbS5mdWxsIl0sImF1dGhfdGltZSI6MTU4NTg5MTI0NywicmVhbG0iOiIvdm1hIiwiZXhwIjoxNTg1OTc3NjQ3LCJpYXQiOjE1ODU4OTEyNDcsImV4cGlyZXNfaW4iOjg2NDAwLCJqdGkiOiJhWFM4MTd3aUtEcGFZNml0Ykxzam1QSmZHaHMifQ.";

        private const string ManagedIdentityToken = 
            "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IkN0VHVoTUptRDVNN0RMZHpEMnYyeDNRS1NSWSIsImtpZCI6IkN0VHVoTUptRDVNN0RMZHpEMnYyeDNRS1NSWSJ9.eyJhdWQiOiJhcGk6Ly8zOWQ0OWQ0MC0xMzUwLTQwMTQtOTU1MC1kZmY5YzVkMzg2YjEiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9iMGU3ZWQxMy0wYjQyLTRjYTktODJmOC1jNzUzYWVjYmFlNzkvIiwiaWF0IjoxNTkwNjUwNDc0LCJuYmYiOjE1OTA2NTA0NzQsImV4cCI6MTU5MDY1NDM3NCwiYWlvIjoiNDJkZ1lManhvdk50WERlbngvR0ZJcFpHU3hzK0FBQT0iLCJhcHBpZCI6IjU4OTg0MDU0LTlmMWItNGJmNS04OGVjLTNmYzQzMzdkNDBlOSIsImFwcGlkYWNyIjoiMSIsImlkcCI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0L2IwZTdlZDEzLTBiNDItNGNhOS04MmY4LWM3NTNhZWNiYWU3OS8iLCJvaWQiOiI1NGMwMTZmZC0yMWJkLTRiY2YtOGRmMS0zZDkwNTViY2NmNmQiLCJzdWIiOiI1NGMwMTZmZC0yMWJkLTRiY2YtOGRmMS0zZDkwNTViY2NmNmQiLCJ0aWQiOiJiMGU3ZWQxMy0wYjQyLTRjYTktODJmOC1jNzUzYWVjYmFlNzkiLCJ1dGkiOiI0akY5NVhhNEEwMkh1OGJvaXp0RUFBIiwidmVyIjoiMS4wIn0.p_RiOu8OhkihhAHUwj40Hf8UoPXJRnRr0tG7CqJByttSvqxmdcFqnN3vCN3Y-6hqpL0p0T7Pg2W2dfEcnbC_tqgF4BboB13-nTNWdDAEWoJoD-mB9aScJgOPRx2WgCaJnVIM7r8dn5pTkrdkGY1DCxAhCDx7eLyz3kmG51G3FGwDDfR-khKf4cE4r6g2cJBcpvKLFTAGU8yF2N2nZ_R93jglBezMp8kVIonbzvQ3WIS8OmCHJ7VWUjc7k9jL4R3lHRL3phzMbSKG_JnrGepgPbedTVt5CCZhFOyQ3EZDM1NOVXQ_Ukoias_fZyu6jZ6otsHAg-xLSTEYpBAv97I6EA";

        private const string InvalidToken =
            "eyJ0eXAiOiJKV1QiLCJraWQiOiJyTWhnRnFmUmlITzdNbEpISEh4UkpmN0JuSkU9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJDMzg1NWZkMGUtZjNjNy00ODUzLWJmNDAtMDg3MDQ1NjIwNDBmIiwiY3RzIjoiT0FVVEgyX1NUQVRFTEVTU19HUkFOVCIsImF1dGhfbGV2ZWwiOjIsImF1ZGl0VHJhY2tpbmdJZCI6IjlmOWEyZWRhLThhYzktNDQwNS04MTBhLTA3NjE5NzYxYzdmYi0xMDkyNTczMTIiLCJpc3MiOiJodHRwOi8vYW0tYjEuc2l0Mi5pZC5hd3MtYm9xOjgwODAvb3BlbmFtL29hdXRoMi9yZWFsbXMvcm9vdC9yZWFsbXMvdm1hIiwidG9rZW5OYW1lIjoiYWNjZXNzX3Rva2VuIiwidG9rZW5fdHlwZSI6IkJlYXJlciIsImF1dGhHcmFudElkIjoiY3YxekwycF8wT0RkZ1kxMEUyNjB3a3FBUFo4IiwiYXVkIjoiVk1BTW9iaWxlQXBwIiwibmJmIjoxNjk2OTA2NzEwLCJncmFudF90eXBlIjoiYXV0aG9yaXphdGlvbl9jb2RlIiwic2NvcGUiOlsibWZhLmFjY2Vzc19jb2RlLjIiLCJjdXN0b21lci5mdWxsLm5vcm1hbCJdLCJhdXRoX3RpbWUiOjE2OTY5MDY3MDksInJlYWxtIjoiL3ZtYSIsImV4cCI6MTY5NjkwNzMxMCwiaWF0IjoxNjk2OTA2NzEwLCJleHBpcmVzX2luIjo2MDAsImp0aSI6Imdiek1Bd1JJWFZxbDNHZ3luY3NwN0VLQzZWcyIsIm1mYV9tZXRob2QuMiI6IkFDQ0VTU19DT0RFIiwiaXNfc3FhX2VuYWJsZWQiOnRydWUsInRlbWVub3NfY2lmIjoiMTMwMDA3NjA3NiIsImNpdGlfbGlua2luZ19zdGF0dXMiOiJQRU5ESU5HIiwibXVzdF9hY2NlcHRfVENzIjpmYWxzZSwiaXNvMzE2Nl8yIjoiQVUifQ";

        private const string AzureAdExternalAppToken =
            "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IlhSdmtvOFA3QTNVYVdTblU3Yk05blQwTWpoQSIsImtpZCI6IlhSdmtvOFA3QTNVYVdTblU3Yk05blQwTWpoQSJ9.eyJhdWQiOiJhcGk6Ly8zOWQ0OWQ0MC0xMzUwLTQwMTQtOTU1MC1kZmY5YzVkMzg2YjEiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9iMGU3ZWQxMy0wYjQyLTRjYTktODJmOC1jNzUzYWVjYmFlNzkvIiwiaWF0IjoxNzA5MTgzNjgwLCJuYmYiOjE3MDkxODM2ODAsImV4cCI6MTcwOTE4NzU4MCwiYWlvIjoiRTJOZ1lNZzhHYmI4MDZlK3VLWFRhKy85c2Z1N0d3QT0iLCJhcHBpZCI6IjZkZGFjZjFlLTVhNzItNGU2ZC1hYTgwLTAwNmU3MmM4MDc1MSIsImFwcGlkYWNyIjoiMSIsImlkcCI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0L2IwZTdlZDEzLTBiNDItNGNhOS04MmY4LWM3NTNhZWNiYWU3OS8iLCJvaWQiOiI3NjY3ZGM0Ny1jZTRiLTQ0ZDMtODU1NC1hOTMwYTRkNzZhZWIiLCJyaCI6IjAuQVdZQUUtM25zRUlMcVV5Qy1NZFRyc3V1ZVVDZDFEbFFFeFJBbFZEZi1jWFRockZtQUFBLiIsInJvbGVzIjpbIkFzY2VuZGFMb3lhbHR5Um9sIl0sInN1YiI6Ijc2NjdkYzQ3LWNlNGItNDRkMy04NTU0LWE5MzBhNGQ3NmFlYiIsInRpZCI6ImIwZTdlZDEzLTBiNDItNGNhOS04MmY4LWM3NTNhZWNiYWU3OSIsInV0aSI6IlMzWC16QTdUQWtPaHYyTGZxTllfQUEiLCJ2ZXIiOiIxLjAifQ.TDXvbO7T7bB16SoVLfotpYPy-1vs7wxS0SKlAaV4d8hrXjKYy8Cxlq5foD8fFj4zmq_dSImBw1mOJjAfjr1CcNF_sj0XpCfguFDNUGjxmDrKUtC7IvO465uZSE3LpsV9ovfBN-VlW41jJMl_XG2wi3sBLcubG2w4SWFY0EZachpIiOyDoT_GYI3tvngJgg-cwPYA5gqA9FyaYBVptYt3-eRRjoa2tSzaSQ5Dp3tPFSwH-PQAJAAVJP7NxlcW8b31UD2-LwDPhtXfot5pyquF9wW4qh2HD-JfObDFg-fw1quismJtTignKoS0Kgce_H0urR8L0CPV5YhjYp0hQeajAg";
        
        private const string AzureAdCrmAppToken =
            "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IlhSdmtvOFA3QTNVYVdTblU3Yk05blQwTWpoQSIsImtpZCI6IlhSdmtvOFA3QTNVYVdTblU3Yk05blQwTWpoQSJ9.eyJhdWQiOiJodHRwczovL2NlcGJvcXBiYmRldi5jcm02LmR5bmFtaWNzLmNvbSIsImlzcyI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzhjZmIzMTI5LTYyZTEtNDZkOS05OWVmLTZkMzY0MWE3ZjAwNy8iLCJpYXQiOjE3MDkyNTIyMTAsIm5iZiI6MTcwOTI1MjIxMCwiZXhwIjoxNzA5MjU2MTEwLCJhaW8iOiJFMk5nWU5oNnRGRmFnRlZlSVdlYnd5S2h5V3Y5QUE9PSIsImFwcGlkIjoiMGM4YjU3MzUtY2QzMC00MzJiLWEzZTctYThiZTdkMjYxZWI4IiwiYXBwaWRhY3IiOiIxIiwiaWRwIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvOGNmYjMxMjktNjJlMS00NmQ5LTk5ZWYtNmQzNjQxYTdmMDA3LyIsIm9pZCI6ImM0NDgwMmMwLWY4OWQtNDlmYy1iNWFkLTgyMDQ3YzY0YjgzNyIsInJoIjoiMC5BV1lBS1RIN2pPRmkyVWFaNzIwMlFhZndCd2NBQUFBQUFBQUF3QUFBQUFBQUFBQm1BQUEuIiwic3ViIjoiYzQ0ODAyYzAtZjg5ZC00OWZjLWI1YWQtODIwNDdjNjRiODM3IiwidGVuYW50X3JlZ2lvbl9zY29wZSI6Ik9DIiwidGlkIjoiOGNmYjMxMjktNjJlMS00NmQ5LTk5ZWYtNmQzNjQxYTdmMDA3IiwidXRpIjoiT3MteDZSSzhmMG1ZNl96SjhsTlhBQSIsInZlciI6IjEuMCIsInhtc19jYWUiOiIxIn0.MuWjZYjU37l72FaGrE5yi7BVctxQEii0wFxMyedcGXBEfSTiz0pkk-gXPiLcUGZhZFLJZGhWMwh5FFoM-AxsgxD4Uw051bDKfogdM6WNfgVK3FdZ_WVrzUzBnA43ps5lLy6xKTe96KzkrAmI6_5v-nMaLiE2LP8DISEaut_eN44Y3zBb6Py4MIq2ujxPEGE_R4HxqEHBHPWFQUP4HSD9c0K-mawf_jBnFiZszsGZ9m9NontkbzUae5XavO_6xFmw-f5Etg5rawDST-03-GqkHxzcFxQ0oiR_QWn9IoXkfepmtPb8J76mVz5oA7PK95yNCLhmgve5YqbXr3bIu3aQ6w";
        
        public GuardTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture) { }

        protected ContextModule Context => Module<ContextModule>();

        protected override void TestSetup()
        {
            Context.RegisterTypeAsInterfaces<NewStandardAuthorisationGuards>();
            Context.RegisterOptionsUsingConfig<CiamSettings>((s) => s.ConfigName);
            Context.RegisterOptionsUsingConfig<AzureAdSettings>(s => InternalConstants.ConfigSections.AzureAd);
            Context.RegisterTypeAsInterfaces<GuardBuilder>();

            Context.RegisterMockAsInterface<IHttpContextAccessor>(mock => SetupAuthHeader(mock, new HeaderDictionary()));
            Context.RegisterMockAsInterface<ICiamCertificateService>(SetupCiamCertificateService);
            Context.RegisterMockAsInterface<IJwtTokenValidatorService>(SetupJwtTokenValidatorHandler);
            Context.RegisterMockAsInterface<IConfigurationManager<OpenIdConnectConfiguration>>(SetupConfigurationManager);
        }

        private void SetupConfigurationManager(Mock<IConfigurationManager<OpenIdConnectConfiguration>> mock)
        {
            mock.Setup(x => x.GetConfigurationAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync((CancellationToken cancellationToken) =>
                {
                    return new OpenIdConnectConfiguration();
                });
        }
        
        delegate bool ValidateIssuerReturns(string rawToken, string[] validIssuers, out string tokenIssuer);

        private void SetupAuthHeader(Mock<IHttpContextAccessor> httpContextAccessorMock, IHeaderDictionary headerDictionary)
        {
            var httpContext = new DefaultHttpContext();
            foreach (var (key, value) in headerDictionary)
            {
                httpContext.Request.Headers.Add(key, value);
            }
            httpContextAccessorMock.Setup(x => x.HttpContext).Returns(httpContext);
        }

        private void SetupJwtTokenValidatorHandler(Mock<IJwtTokenValidatorService> mock)
        {
            var securityTokenMock = new Mock<SecurityToken>();
            securityTokenMock.SetupGet(x => x.ValidFrom).Returns(DateTime.UtcNow);
            securityTokenMock.SetupGet(x => x.ValidTo).Returns(DateTime.UtcNow.AddHours(2));
            var securityToken = securityTokenMock.Object;
            
            var expiredSecurityTokenMock = new Mock<SecurityToken>();
            expiredSecurityTokenMock.SetupGet(x => x.ValidFrom).Returns(DateTime.UtcNow.AddDays(-10));
            expiredSecurityTokenMock.SetupGet(x => x.ValidTo).Returns(DateTime.UtcNow.AddHours(-8));
            var expiredSecurityToken = expiredSecurityTokenMock.Object;

            var azureAdClaims = new List<Claim>()
            {
                new Claim(InternalConstants.ClaimType.Issuer, "https://sts.windows.net/b0e7ed13-0b42-4ca9-82f8-c753aecbae79/"),
                new Claim(InternalConstants.ClaimType.Audience, "https://vault.azure.net"),
            };

            var azureAdClaimsPrincipalMock = new Mock<ClaimsPrincipal>();
            azureAdClaimsPrincipalMock.SetupGet(x => x.Claims).Returns(azureAdClaims);
            var claimsPrincipal = azureAdClaimsPrincipalMock.Object;

            var azureAdValidationResult = new JwtTokenValidationResult(){ IsSuccess = true, ClaimsPrincipal = claimsPrincipal, SecurityToken = securityToken};

            // string tokenIssuer = null;
            
            
            mock.Setup(x => x.ValidateIssuer(It.IsAny<string>(), It.IsAny<string[]>(), out It.Ref<string>.IsAny))
                .Returns(new ValidateIssuerReturns((string rawToken, string[] issuers, out string issuer) =>
                {
                    var handler = new JwtSecurityTokenHandler();
                    var tokenIssuer = handler.ReadJwtToken(rawToken).Issuer;
                    issuer = null;

                    if (tokenIssuer.Contains("sts.windows.net"))
                    {
                        issuer = AzureTestIssuer;
                    } else if (tokenIssuer.Contains("id.aws-boq"))
                    {
                        issuer = CiamTestIssuer;
                    }
                    
                    return !issuer.IsNullOrWhiteSpace();
                }));

            mock.Setup(x => x.ValidateToken(It.IsAny<ICollection<SecurityKey>>(), ManagedIdentityToken))
                .Returns(() =>
                {
                    return azureAdValidationResult;
                });

            mock.Setup(x => x.ValidateToken(It.IsAny<IEnumerable<X509SecurityKey>>(), CustomerTokenRestrictedSigned))
                .Returns(() =>
                {
                    var customerCiamClaims = new List<Claim>()
                    {
                        new Claim(InternalConstants.ClaimType.Issuer, "https://am-b1.dev.id.aws-boq:8443/openam/oauth2/realms/root/realms/vma"),
                        new Claim(InternalConstants.ClaimType.TemenosCIF, "4567"),
                        new Claim(InternalConstants.ClaimType.AuthLevel, "2"),
                        new Claim(InternalConstants.ClaimType.Audience, "VMAMobileApp"),
                    };

                    var ciamClaimsPrincipalMock = new Mock<ClaimsPrincipal>();
                    ciamClaimsPrincipalMock.SetupGet(x => x.Claims).Returns(customerCiamClaims);
                    var ciamClaimsPrincipal = ciamClaimsPrincipalMock.Object;

                    var ciamValidationResult = new JwtTokenValidationResult() { IsSuccess = true, ClaimsPrincipal = ciamClaimsPrincipal, SecurityToken = securityToken };
                    
                    return ciamValidationResult;
                });
            
            mock.Setup(x => x.ValidateToken(It.IsAny<IEnumerable<X509SecurityKey>>(), CustomerTokenExpiredSigned))
                .Returns(() =>
                {
                    var customerCiamClaims = new List<Claim>()
                    {
                        new Claim(InternalConstants.ClaimType.Issuer, "https://am-b1.dev.id.aws-boq:8443/openam/oauth2/realms/root/realms/vma"),
                        new Claim(InternalConstants.ClaimType.TemenosCIF, "4567"),
                        new Claim(InternalConstants.ClaimType.AuthLevel, "2"),
                        new Claim(InternalConstants.ClaimType.Audience, "VMAMobileApp"),
                    };

                    var ciamClaimsPrincipalMock = new Mock<ClaimsPrincipal>();
                    ciamClaimsPrincipalMock.SetupGet(x => x.Claims).Returns(customerCiamClaims);
                    var ciamClaimsPrincipal = ciamClaimsPrincipalMock.Object;

                    var ciamValidationResult = new JwtTokenValidationResult() { IsSuccess = true, ClaimsPrincipal = ciamClaimsPrincipal, SecurityToken = expiredSecurityToken };
                    
                    return ciamValidationResult;
                });
            
            mock.Setup(x => x.ValidateToken(It.IsAny<IEnumerable<X509SecurityKey>>(), AzureAdExternalAppToken))
                .Returns(() =>
                {
                    var ciamValidationResult = new JwtTokenValidationResult() { IsSuccess = false, ClaimsPrincipal = null, SecurityToken = securityToken };
                    
                    return ciamValidationResult;
                });
            
            mock.Setup(x => x.ValidateToken(It.IsAny<ICollection<SecurityKey>>(), AzureAdExternalAppToken))
                .Returns(() =>
                {
                    var customerCiamClaims = new List<Claim>()
                    {
                        new Claim(InternalConstants.ClaimType.Issuer, "https://sts.windows.net/b0e7ed13-0b42-4ca9-82f8-c753aecbae79/"),
                        new Claim(InternalConstants.ClaimType.Audience, "api://39d49d40-1350-4014-9550-dff9c5d386b1"),
                        new Claim(ClaimTypes.Role, "AscendaLoyaltyRol")
                    };

                    var ciamClaimsPrincipalMock = new Mock<ClaimsPrincipal>();
                    ciamClaimsPrincipalMock.SetupGet(x => x.Claims).Returns(customerCiamClaims);
                    var ciamClaimsPrincipal = ciamClaimsPrincipalMock.Object;

                    var ciamValidationResult = new JwtTokenValidationResult() { IsSuccess = true, ClaimsPrincipal = ciamClaimsPrincipal, SecurityToken = securityToken };
                    
                    return ciamValidationResult;
                });
            
            // required to make the first check for ciam token fails
            mock.Setup(x => x.ValidateToken(It.IsAny<IEnumerable<X509SecurityKey>>(), AzureAdCrmAppToken))
                .Returns(() =>
                {
                    var ciamValidationResult = new JwtTokenValidationResult() { IsSuccess = false, ClaimsPrincipal = null, SecurityToken = securityToken };
                    
                    return ciamValidationResult;
                });
            
            mock.Setup(x => x.ValidateToken(It.IsAny<ICollection<SecurityKey>>(), AzureAdCrmAppToken))
                .Returns(() =>
                {
                    var claims = new List<Claim>()
                    {
                        new Claim(InternalConstants.ClaimType.Issuer, "https://sts.windows.net/b0e7ed13-0b42-4ca9-82f8-c753aecbae79/"),
                        new Claim(InternalConstants.ClaimType.Audience, "https://cepboqpbbdev.crm6.dynamics.com"),
                    };

                    var claimsPrincipal = new ClaimsPrincipal(new ClaimsIdentity[]
                    {
                        new ClaimsIdentity(claims)
                    });

                    var ciamValidationResult = new JwtTokenValidationResult() { IsSuccess = true, ClaimsPrincipal = claimsPrincipal, SecurityToken = securityToken };
                    
                    return ciamValidationResult;
                });
            
            mock.Setup(x => x.ValidateToken(It.IsAny<IEnumerable<X509SecurityKey>>(), SystemTokenNotSigned))
                .Returns(() =>
                {
                    var customerCiamClaims = new List<Claim>()
                    {
                        new Claim(InternalConstants.ClaimType.Issuer, "https://am-b1.dev.id.aws-boq:8443/openam/oauth2/realms/root/realms/vma"),
                        new Claim(InternalConstants.ClaimType.Audience, "VMAAPIGateway"),
                        // new Claim(ClaimTypes.Role, "am-introspect-all-tokens"),
                        new Claim("scope", "system.full")
                    };

                    var principal = new ClaimsPrincipal(new List<ClaimsIdentity>()
                    {
                        new ClaimsIdentity(customerCiamClaims)
                    });

                    var ciamValidationResult = new JwtTokenValidationResult() { IsSuccess = true, ClaimsPrincipal = principal, SecurityToken = expiredSecurityToken };
                    
                    return ciamValidationResult;
                });

            var customerInvalidClaims = new List<Claim>()
            {
                new Claim(InternalConstants.ClaimType.Issuer, "https://invalid-issuer")
            };

            var invalidClaimsPrincipalMock = new Mock<ClaimsPrincipal>();
            invalidClaimsPrincipalMock.SetupGet(x => x.Claims).Returns(customerInvalidClaims);
            var cinvalidClaimsPrincipal = invalidClaimsPrincipalMock.Object;

            var invalidValidationResult = new JwtTokenValidationResult() { IsSuccess = false, ClaimsPrincipal = null, SecurityToken = null };

            mock.Setup(x => x.ValidateToken(It.IsAny<IEnumerable<SecurityKey>>(), InvalidToken))
                .Returns(() =>
                {
                    return invalidValidationResult;
                });

            mock.Setup(x => x.ValidateToken(It.IsAny<IEnumerable<X509SecurityKey>>(), ManagedIdentityToken))
                .Returns(() =>
                {
                    return invalidValidationResult;
                }); 
            
            mock.Setup(x => x.ValidateToken(It.IsAny<ICollection<SecurityKey>>(), CustomerTokenRestrictedSigned))
                .Returns(() =>
                {
                    return invalidValidationResult;
                });
        }

        private void SetupCiamCertificateService(Mock<ICiamCertificateService> mock)
        {
            var result = new List<X509SecurityKey>() { };
            mock.Setup(x => x.GetSecurityKeys(It.IsAny<CancellationToken>()))
                .Returns(
                Task.FromResult(result.AsEnumerable()));
        }

        [Theory]
        [InlineData(CustomerTokenExpiredSigned)]
        [InlineData(SystemTokenNotSigned)]
        public async Task ExpiredCiamTokenIsParsed(string bearerToken)
        {
            // Arrange 
            var builder = Context.Resolve<IGuardBuilder>();
            var standardGuards = Context.Resolve<IStandardAuthorisationGuards>();
            var httpContextAccessor = Context.GetMock<IHttpContextAccessor>();

            // Mimic HttpContext.Request.Headers
            var headerDictionary = new HeaderDictionary(
                new Dictionary<string, StringValues>()
                {
                    { "Authorization", new StringValues($"Bearer {bearerToken}") }
                }
            );
            
            SetupAuthHeader(httpContextAccessor, headerDictionary);

            builder
                .ConfigureGuardBuilder(AuthenticationType.CiamToken, standardGuards);

            // Act 
            Exception actualException = null;
            IAuthenticationContext context = null;
            try
            {
                context = await builder.Execute(CancellationToken.None);
            }
            catch (Exception ex)
            {
                actualException = ex;
            }

            // Assert
            using (new AssertionScope())
            {
                context.Should().BeNull();
                actualException.Should().BeOfType<StandardApiException>()
                    .Which.ErrorMessage.UserMessageText.Should().BeEquivalentTo("The access token provided is expired, revoked, malformed, or invalid for other reasons.");
            };
        }
        
        [Theory]
        [InlineData(AuthenticationType.CustomerOrAdToken, AzureAdExternalAppToken, "L2")]
        [InlineData(AuthenticationType.CustomerOrAdToken, AzureAdExternalAppToken, "L3")]
        [InlineData(AuthenticationType.CustomerOrAdToken, AzureAdExternalAppToken, "L4")]
        [InlineData(AuthenticationType.AdToken, AzureAdExternalAppToken, null)]
        [InlineData(AuthenticationType.CiamOrAdToken, AzureAdExternalAppToken, null)]
        public async Task ValidAzureAdToken_Should_ValidatedWithSuccess(AuthenticationType authType, string bearerToken, string authLevel)
        {
            // Arrange 
            var builder = Context.Resolve<IGuardBuilder>();
            var standardGuards = Context.Resolve<IStandardAuthorisationGuards>();
            var httpContextAccessorMock = Context.GetMock<IHttpContextAccessor>();

            // Mimic HttpContext.Request.Headers
            var headerDictionary = new HeaderDictionary(
                new Dictionary<string, StringValues>()
                {
                    { "Authorization", new StringValues($"Bearer {bearerToken}") },
                    {AuthenticationConstants.Headers.TemenosCif, "200"}
                }
            );

            if (authLevel is not null)
            {
                headerDictionary.Add(AuthenticationConstants.Headers.AuthLevel, authLevel);
            }

            SetupAuthHeader(httpContextAccessorMock, headerDictionary);

            builder
                .ConfigureGuardBuilder(authType, standardGuards);

            // Act
            IAuthenticationContext context = await builder.Execute(CancellationToken.None);

            // Assert
            using (new AssertionScope())
            {
                context.Should().NotBeNull();
                context.Authenticated.Should().BeTrue();
                context.IssuedBy.Should().Be(IssuedBy.AzureAd);
                context.TokenType.Should().Be(TokenType.AzureAdExternal);
                context.TokenLevel.Should().Be(authLevel is null ? TokenLevel.None : Enum.Parse<TokenLevel>(authLevel));
            };
        }
        
        [Theory]
        [InlineData(AuthenticationType.CustomerOrAdToken, AzureAdExternalAppToken, null, null, "Failed to retrieve temenos-cif header")]
        [InlineData(AuthenticationType.CustomerOrAdToken, AzureAdExternalAppToken, null, "10", "Failed to retrieve temenos-cif header")]
        [InlineData(AuthenticationType.CustomerOrAdToken, AzureAdExternalAppToken, "333", "10", "Minimum token level required for this operation:L2")]
        [InlineData(AuthenticationType.CustomerOrAdToken, AzureAdExternalAppToken, "333", " ", "Failed to retrieve azure-ad-auth-level header")]
        public async Task ValidAzureAdToken_Should_Fail_When_MissingOrInvalidHeaders(AuthenticationType authType, string bearerToken, string cif, string authLevel, string expectedErrorMessage)
        {
            // Arrange 
            var builder = Context.Resolve<IGuardBuilder>();
            var standardGuards = Context.Resolve<IStandardAuthorisationGuards>();
            var httpContextAccessorMock = Context.GetMock<IHttpContextAccessor>();

            // Mimic HttpContext.Request.Headers
            var headerDictionary = new HeaderDictionary(
                new Dictionary<string, StringValues>()
                {
                    { "Authorization", new StringValues($"Bearer {bearerToken}") },
                }
            );

            if (!cif.IsNullOrWhiteSpace())
            {
                headerDictionary.Add(AuthenticationConstants.Headers.TemenosCif, cif);
            }

            if (!authLevel.IsNullOrWhiteSpace())
            {
                headerDictionary.Add(AuthenticationConstants.Headers.AuthLevel, authLevel);
            }
            
            SetupAuthHeader(httpContextAccessorMock, headerDictionary);

            builder
                .ConfigureGuardBuilder(authType, standardGuards)
                .WithGuard(i => i.IssuedBy == IssuedBy.AzureAd, standardGuards.HasAtLeastTokenLevelOf(TokenLevel.L1));

            // Act
            var act = async () =>
            {
                await builder.Execute(CancellationToken.None);
            };

            // Assert
            using (new AssertionScope())
            {
                var exceptionAssertion = await act.Should().ThrowAsync<StandardApiException>();

                
                exceptionAssertion.Which.ErrorMessage.UserMessageText
                    .Should().BeEquivalentTo(expectedErrorMessage);
            };
        }

        [Fact]
        public async Task ExpiredSystemTokenIsParsed()
        {
            // Arrange 
            var builder = Context.Resolve<IGuardBuilder>();
            var standardGuards = Context.Resolve<IStandardAuthorisationGuards>();
            var httpContextAccessorMock = Context.GetMock<IHttpContextAccessor>();

            // Mimic HttpContext.Request.Headers
            var headerDictionary = new HeaderDictionary(
                new Dictionary<string, StringValues>()
                {
                    { "Authorization", new StringValues($"Bearer {SystemTokenNotSigned}") }
                }
            );
            
            SetupAuthHeader(httpContextAccessorMock, headerDictionary);

            builder
                .ConfigureGuardBuilder(AuthenticationType.CiamToken, standardGuards)
                .WithGuard(standardGuards.IsCiamSystemToken)
                .WithGuard(standardGuards.ContainsClaim("scope", "system.full"));

            // Act 
            Exception actualException = null;
            IAuthenticationContext context = null;
            try
            {
                context = await builder.Execute(CancellationToken.None);
            }
            catch ( Exception ex )
            {
                actualException = ex;
            }

            // Assert
            using (new AssertionScope())
            {
                context.Should().BeNull();
                actualException.Should().BeOfType<StandardApiException>()
                    .Which.ErrorMessage.UserMessageText.Should().BeEquivalentTo("The access token provided is expired, revoked, malformed, or invalid for other reasons.");
            };
        }

        [Fact]
        public async Task ExpiredAzureAdSystemTokenIsParsed()
        {
            // Arrange 
            var builder = Context.Resolve<IGuardBuilder>();
            var standardGuards = Context.Resolve<IStandardAuthorisationGuards>();
            var httpContextAccessorMock = Context.GetMock<IHttpContextAccessor>();

            // Mimic HttpContext.Request.Headers
            var headerDictionary = new HeaderDictionary(
                new Dictionary<string, StringValues>()
                {
                    { "Authorization", new StringValues($"Bearer {SystemTokenNotSigned}") }
                }
            );
            SetupAuthHeader(httpContextAccessorMock, headerDictionary);

            builder
                .ConfigureGuardBuilder(AuthenticationType.CiamToken, standardGuards)
                .WithGuard(standardGuards.IsCiamSystemToken)
                .WithGuard(standardGuards.ContainsClaim("scope", "system.full"));

            // Act 
            Exception actualException = null;
            IAuthenticationContext context = null;
            try
            {
                context = await builder.Execute(CancellationToken.None);
            }
            catch ( Exception ex) 
            { 
                actualException = ex;
            }

            // Assert
            using (new AssertionScope())
            {
                context.Should().BeNull();
                actualException.Should().NotBeNull();
                actualException.Should().BeOfType<StandardApiException>()
                    .Which.ErrorMessage.UserMessageText.Should().BeEquivalentTo("The access token provided is expired, revoked, malformed, or invalid for other reasons.");
            };
        }

        [Theory]
        [InlineData(ManagedIdentityToken, AuthenticationType.CustomerOrAdToken, "L2", "1234")]
        [InlineData(CustomerTokenRestrictedSigned, AuthenticationType.CustomerOrAdToken, "L2", "1234")]
        [InlineData(CustomerTokenRestrictedSigned, AuthenticationType.CustomerToken, null, null)]
        public async Task ValidCiamOrManagedIdentitySystemTokenIsParsed_Ciam(string bearerToken, AuthenticationType authType, string authLevel, string customerIdHeaderValue)
        {
            // Arrange
            var builder = Context.Resolve<IGuardBuilder>();
            var standardGuards = Context.Resolve<IStandardAuthorisationGuards>();
            var httpContextAccessorMock = Context.GetMock<IHttpContextAccessor>();

            // Mimic HttpContext.Request.Headers
            var headerDictionary = new HeaderDictionary(
                new Dictionary<string, StringValues>()
                {
                    { AuthenticationConstants.Headers.Authorization, new StringValues($"Bearer {bearerToken}") }
                }
            );

            if (!string.IsNullOrWhiteSpace(customerIdHeaderValue))
                headerDictionary.Add(AuthenticationConstants.Headers.TemenosCif, customerIdHeaderValue);

            if (!string.IsNullOrWhiteSpace(authLevel))
                headerDictionary.Add(AuthenticationConstants.Headers.AuthLevel, authLevel);

            SetupAuthHeader(httpContextAccessorMock, headerDictionary);
            
            // Expected Order of guards
            builder
                .ConfigureGuardBuilder(authType, standardGuards);

            // Act
            var context = await builder.Execute(CancellationToken.None);

            // Assert
            using (new AssertionScope())
            {
                context.Should().NotBeNull();
                if ( context != null )
                {
                    context.Principal.Should().NotBeNull();
                    context.Temenos_cif.Should().NotBeNullOrWhiteSpace();
                    if (context.IssuedBy == IssuedBy.AzureAd)
                    {
                        context.TokenType.Should().Be(TokenType.ManagedIdentity);
                    }
                }
            }
        }


        [Theory]
        [InlineData()]
        public async Task HasAzureAdAuthLevelHeader_NoHeader_Failure()
        {
            // Arrange
            var builder = Context.Resolve<IGuardBuilder>();
            var standardGuards = Context.Resolve<IStandardAuthorisationGuards>();
            var httpContextAccessorMock = Context.GetMock<IHttpContextAccessor>();

            // Mimic HttpContext.Request.Headers
            var headerDictionary = new HeaderDictionary(
                new Dictionary<string, StringValues>()
                {
                    { AuthenticationConstants.Headers.TemenosCif, new StringValues("1234") },
                    { AuthenticationConstants.Headers.Authorization, new StringValues($"Bearer {ManagedIdentityToken}") }
                }
            );
            SetupAuthHeader(httpContextAccessorMock, headerDictionary);

            // Expected Order of guards
            builder
                .WithGuard(standardGuards.HasAtLeastTokenLevelOf(TokenLevel.L1))
                .ConfigureGuardBuilder(AuthenticationType.CustomerOrAdToken, standardGuards);

            // Act  
            Exception actualException = null;
            try
            {
                await builder.Execute(CancellationToken.None);
            }
            catch (Exception e)
            {
                actualException = e;
            }

            // Assert
            using (new AssertionScope())
            {
                actualException.Should().BeOfType<StandardApiException>();
                if (actualException is StandardApiException apiException)
                {
                    apiException.ErrorMessage.UserMessageText.Should().BeEquivalentTo("Minimum token level required for this operation:L1");
                }
            }
        }
        
        [Theory]
        [InlineData(TokenLevel.L2, AuthenticationType.CustomerToken, null, CustomerTokenRestrictedSigned)]
        [InlineData(TokenLevel.L2, AuthenticationType.CustomerOrAdToken, "L3", CustomerTokenRestrictedSigned)]
        [InlineData(TokenLevel.L3, AuthenticationType.CustomerOrAdToken, "L3", ManagedIdentityToken)]
        public async Task ValidTokenLevel_Success(TokenLevel tokenLevel, AuthenticationType authType, string authlevel, string bearerToken)
        {
            // Arrange
            var builder = Context.Resolve<IGuardBuilder>();
            var standardGuards = Context.Resolve<IStandardAuthorisationGuards>();
            var ciamSettings = Context.Resolve<IOptions<CiamSettings>>();
            var azureAdSettings = Context.Resolve<IOptions<AzureAdSettings>>();
            var httpContextAccessorMock = Context.GetMock<IHttpContextAccessor>();

            // Mimic HttpContext.Request.Headers
            var headerDictionary = new HeaderDictionary(
                new Dictionary<string, StringValues>()
                {
                    { AuthenticationConstants.Headers.Authorization, new StringValues($"Bearer {bearerToken}") }
                }
            );

            if (authType == AuthenticationType.CustomerOrAdToken )
                headerDictionary.Add(AuthenticationConstants.Headers.TemenosCif, "1234");

            if (!string.IsNullOrWhiteSpace(authlevel))
                headerDictionary.Add(AuthenticationConstants.Headers.AuthLevel, authlevel);
            
            SetupAuthHeader(httpContextAccessorMock, headerDictionary);

            // Expected Order of guards
            builder
                .ConfigureGuardBuilder(authType, standardGuards);

            // Act
            var context = await builder.Execute(CancellationToken.None);

            // Assert
            using (new AssertionScope())
            {
                context.Should().NotBeNull();
                if (context != null)
                {
                    context.Principal.Should().NotBeNull();
                    context.TokenLevel.Should().Be(tokenLevel);
                    switch (bearerToken)
                    {
                        case CustomerTokenRestrictedSigned:
                            context.IssuedBy.Should().Be(IssuedBy.CIAM);
                            context.Issuer.Should().Be(ciamSettings.Value.Issuer);
                            context.Temenos_cif.Should().Be("4567");
                            context.Audience.Should().Be(ciamSettings.Value.CustomerAudience);
                            break;
                        case ManagedIdentityToken:
                            context.IssuedBy.Should().Be(IssuedBy.AzureAd);
                            context.Issuer.Should().Be(azureAdSettings.Value.Issuer);
                            context.Audience.Should().Be(azureAdSettings.Value.AudiencePattern);
                            break;
                    }
                }
            }
        }

        [Theory]
        [InlineData(CustomerTokenRestrictedSigned)]
        public async Task ValidateCustomerToken_Success(string token)
        {
            // Arrange
            var builder = Context.Resolve<IGuardBuilder>();
            var standardGuards = Context.Resolve<IStandardAuthorisationGuards>();
            var ciamSettings = Context.Resolve<IOptions<CiamSettings>>();
            var httpContextAccessorMock = Context.GetMock<IHttpContextAccessor>();

            // Mimic HttpContext.Request.Headers
            var headerDictionary = new HeaderDictionary(
                new Dictionary<string, StringValues>()
                {
                    { AuthenticationConstants.Headers.Authorization, new StringValues($"Bearer {token}") }
                }
            );

            SetupAuthHeader(httpContextAccessorMock, headerDictionary);
            
            // Expected Order of guards
            builder
                .ConfigureGuardBuilder(AuthenticationType.CustomerToken, standardGuards)
                .WithGuard(standardGuards.IsCiamCustomerToken);

            // Act
            var context = await builder.Execute(CancellationToken.None);

            // Assert
            using (new AssertionScope())
            {
                context.Should().NotBeNull();
                if (context != null)
                {
                    context.Principal.Should().NotBeNull();
                    context.IssuedBy.Should().Be(IssuedBy.CIAM);
                    context.Issuer.Should().Be(ciamSettings.Value.Issuer);
                    context.Temenos_cif.Should().Be("4567");
                    context.Audience.Should().Be(ciamSettings.Value.CustomerAudience);
                    context.TokenLevel.Should().Be(TokenLevel.L2);
                }
            }
        }

        [Fact]
        public async Task GuardsHandleCancellationToken()
        {
            // Arrange 
            var builder = new GuardBuilder(Context.Resolve<ILogger<AuthenticationContext>>());

            builder.WithGuard(async (context, token) =>
            {
                await Task.Delay(1000000, token);
                return context;
            });

            var tokenSource = new CancellationTokenSource(500);

            // Act  
            Exception actualException = null;
            try
            {
                await builder.Execute(tokenSource.Token);
            }
            catch (Exception e)
            {
                actualException = e;
            }

            // Assert
            using (new AssertionScope())
            {
                actualException.Should().BeOfType<StandardApiException>();
                if (actualException is StandardApiException apiException)
                {
                    apiException.ErrorMessage.UserMessageText.Should().BeEquivalentTo("Failed Authentication");
                }
            }
        }

        [Fact]
        public async Task GuardsReturnAuthFailureOnUnhandledException()
        {
            // Arrange 
            var builder = Context.Resolve<IGuardBuilder>();

            builder.WithGuard(async (context, token) =>
            {
                // Random Exception
                throw new AddressInUseException("Some Message");
            });

            // Act  
            Exception actualException = null;
            try
            {
                await builder.Execute(CancellationToken.None);
            }
            catch (Exception e)
            {
                actualException = e;
            }

            // Assert
            using ( new AssertionScope() )
            {
                actualException.Should().BeOfType<StandardApiException>();
                if (actualException is StandardApiException apiException)
                {
                    apiException.ErrorMessage.UserMessageText.Should().BeEquivalentTo("Failed Authentication");
                }
            }
        }

        [Fact] 
        public async Task GuardsAreCalledInOrder()
        {
            // Arrange 
            var builder = Context.Resolve<IGuardBuilder>();

            var queue = new Queue<int>();

            builder.WithGuard(async (context, token) =>
            {
                queue.Enqueue(1);
                return context;
            });

            builder.WithGuard(async (context, token) =>
            {
                queue.Enqueue(2);
                await Task.Delay(10000); // Force a task yield
                return context;
            });

            builder.WithGuard(async (context, token) =>
            {
                queue.Enqueue(3);
                return context;
            });

            // Act  
            await builder.Execute(CancellationToken.None);

            // Assert
            using (new AssertionScope())
            {
                var idx = 1;
                while (queue.Any())
                {
                    var next = queue.Dequeue();
                    next.Should().Be(idx++);
                }
            }
        }

        [Fact]
        public async Task GuardsExitEarly()
        {
            // Arrange 
            var builder = Context.Resolve<IGuardBuilder>();

            var queue = new Queue<int>();

            builder.WithGuard(async (context, token) =>
            {
                queue.Enqueue(1);
                return context;
            });

            builder.WithGuard(async (context, token) =>
            {
                queue.Enqueue(2);
                return context.FailedAuthentication("Test Exit");
            });

            builder.WithGuard(async (context, token) =>
            {
                queue.Enqueue(3);
                return context;
            });

            // Act  
            Exception actualException = null;
            try
            {
                await builder.Execute(CancellationToken.None);
            }
            catch (Exception e)
            {
                actualException = e;
            }

            // Assert
            using (new AssertionScope())
            {
                actualException.Should().BeOfType<StandardApiException>();
                if (actualException is StandardApiException apiException)
                {
                    apiException.ErrorMessage.UserMessageText.Should().BeEquivalentTo("Test Exit");
                }

                queue.Count.Should().Be(2);
            }
        }

        [Fact]
        public async Task GuardsDoNotExitEarly()
        {
            // Arrange 
            var builder = Context.Resolve<IGuardBuilder>();

            var queue = new Queue<int>();

            builder.WithGuard(async (context, token) =>
            {
                queue.Enqueue(1);
                return context;
            });

            builder.WithGuard(async (context, token) =>
            {
                queue.Enqueue(2);
                return context.FailedAuthentication("Test Exit");
            });

            builder.WithGuard(async (context, token) =>
            {
                queue.Enqueue(3);
                return context;
            });

            // Act  
            await builder.Execute(CancellationToken.None, false);

            // Assert
            using (new AssertionScope())
            {
                queue.Count.Should().Be(3);
            }
        }

        [Fact]
        public async Task ExipredTokenThrows()
        {
            // Arrange 
            var builder = Context.Resolve<IGuardBuilder>();
            var standardGuards = Context.Resolve<IStandardAuthorisationGuards>();

            // Mimic HttpContext.Request.Headers
            var request = new HeaderDictionary(
                new Dictionary<string, StringValues>()
                {
                    { "Authorization", new StringValues($"Bearer {SystemTokenNotSigned}") }
                }
            );

            builder.WithGuard(standardGuards.HasAuthHeader(request));
            builder.WithGuard(standardGuards.HasNoSignature); // used to extract principal 
            builder.WithGuard(standardGuards.HasNotExpired());

            // Act 
            Exception actualException = null;
            try

            {
                await builder.Execute(CancellationToken.None);
            }
            catch (Exception e)
            {
                actualException = e;
            }

            // Assert
            using ( new AssertionScope() )
            {
                actualException.Should().BeOfType<StandardApiException>();
                if (actualException is StandardApiException apiException)
                {
                    apiException.ErrorMessage.UserMessageText.Should().BeEquivalentTo("The access token provided is expired, revoked, malformed, or invalid for other reasons.");
                }
            }
        }


        [Fact]
        public async Task InvalidTokenShouldThrowError()
        {
            // Arrange 
            var standardGuards = Context.Resolve<IStandardAuthorisationGuards>();

            List<GuardTask> guardTasks = new()
            {
                standardGuards.HasValidIssuer,
                standardGuards.IsCiamCustomerToken,
                standardGuards.HasValidToken,
                standardGuards.IsManagedIdentityToken
            };

            // Mimic HttpContext.Request.Headers
            var request = new HeaderDictionary(
                new Dictionary<string, StringValues>()
                {
                    { "Authorization", new StringValues($"Bearer {InvalidToken}") }
                }
            );

            // Act
            foreach (var task in guardTasks)
            {
                var builder = Context.Resolve<IGuardBuilder>();
                builder.WithGuard(standardGuards.HasAuthHeader(request));
                builder.WithGuard(task);

                Exception actualException = null;
                try

                {
                    await builder.Execute(CancellationToken.None);
                }
                catch (Exception e)
                {
                    actualException = e;
                }

                // Assert
                using (new AssertionScope())
                {
                    actualException.Should().BeOfType<StandardApiException>();
                    if (actualException is StandardApiException apiException)
                    {
                        apiException.ErrorMessage.MessageCode.Should().BeEquivalentTo("SPAUTH9999");
                    }
                }
            }
        }

        // Note: to align with CIAM specs and make it easy for mobile we return the CIAM code 
        //       when a token has expired 
        //
        [Fact]
        public async Task ExipredTokenThrowsCIAMException()
        {
            // Arrange 
            var builder = Context.Resolve<IGuardBuilder>();
            var standardGuards = Context.Resolve<IStandardAuthorisationGuards>();

            // Mimic HttpContext.Request.Headers
            var request = new HeaderDictionary(
                new Dictionary<string, StringValues>()
                {
                    { "Authorization", new StringValues($"Bearer {SystemTokenNotSigned}") }
                }
            );

            builder.WithGuard(standardGuards.HasAuthHeader(request));
            builder.WithGuard(standardGuards.HasNoSignature); // used to extract principal 
            builder.WithGuard(standardGuards.HasNotExpired());

            // Act 
            Exception actualException = null;
            try

            {
                await builder.Execute(CancellationToken.None);
            }
            catch (Exception e)
            {
                actualException = e;
            }

            // Assert
            using ( new AssertionScope() )
            {
                actualException.Should().BeOfType<StandardApiException>();
                if (actualException is StandardApiException apiException)
                {
                    apiException.ErrorMessage.MessageCode.Should().BeEquivalentTo("CIAM_E0036");
                    apiException.ErrorMessage.UserMessageText.Should().BeEquivalentTo("The access token provided is expired, revoked, malformed, or invalid for other reasons.");
                }
            }
        }
        
        [Theory]
        [InlineData(AuthenticationType.AdToken, AzureAdCrmAppToken)]
        [InlineData(AuthenticationType.CiamOrAdToken, AzureAdCrmAppToken)]
        [InlineData(AuthenticationType.CustomerOrAdToken, AzureAdCrmAppToken)]
        public async Task HasValidAudience_Should_BeValidatedWithSuccess(AuthenticationType authType, string bearerToken)
        {
            // Arrange 
            var builder = Context.Resolve<IGuardBuilder>();
            var standardGuards = Context.Resolve<IStandardAuthorisationGuards>();
            var httpContextAccessorMock = Context.GetMock<IHttpContextAccessor>();

            // Mimic HttpContext.Request.Headers
            var headerDictionary = new HeaderDictionary(
                new Dictionary<string, StringValues>()
                {
                    { "Authorization", new StringValues($"Bearer {bearerToken}") },
                    {AuthenticationConstants.Headers.TemenosCif, "200"},
                    {AuthenticationConstants.Headers.AuthLevel, "L2"}
                }
            );
            SetupAuthHeader(httpContextAccessorMock, headerDictionary);

            builder
                .ConfigureGuardBuilder(authType, standardGuards);

            // Act
            var act = async () =>
            {
                await builder.Execute(CancellationToken.None);
            };

            // Assert
            using (new AssertionScope())
            {
                var exceptionAssertion = await act.Should().ThrowExactlyAsync<StandardApiException>();
                
                exceptionAssertion.Which
                    .ErrorMessage.UserMessageText.Should().BeEquivalentTo("The audience https://cepboqpbbdev.crm6.dynamics.com provided is not valid.");
            }
        }
        
        [Fact]
        public async Task RawTokenNotProvided_Should_Throw()
        {
            // Arrange 
            var builder = Context.Resolve<IGuardBuilder>();
            var standardGuards = Context.Resolve<IStandardAuthorisationGuards>();

            builder
                .ConfigureGuardBuilder(AuthenticationType.None, standardGuards)
                .WithGuard(standardGuards.HasValidCiamSignature);

            // Act
            var act = async () =>
            {
                await builder.Execute(CancellationToken.None);
            };

            // Assert
            using (new AssertionScope())
            {
                var exceptionAssertion = await act.Should().ThrowExactlyAsync<StandardApiException>();
                
                exceptionAssertion.Which
                    .ErrorMessage.UserMessageText.Should().BeEquivalentTo("Failed to validate token signature: JWT missing");
            }
        }
        
        [Fact]
        public async Task HasValidExternalAudience_Should_Throw_When_ContextInvalid()
        {
            // Arrange 
            var builder = Context.Resolve<IGuardBuilder>();
            var standardGuards = Context.Resolve<IStandardAuthorisationGuards>();

            builder
                .ConfigureGuardBuilder(AuthenticationType.None, standardGuards)
                .WithGuard(standardGuards.HasValidExternalAudience());

            // Act
            var act = async () =>
            {
                await builder.Execute(CancellationToken.None);
            };

            // Assert
            using (new AssertionScope())
            {
                var exceptionAssertion = await act.Should().ThrowExactlyAsync<StandardApiException>();
                
                exceptionAssertion.Which
                    .ErrorMessage.UserMessageText.Should().BeEquivalentTo("Failed Authentication");
            }
        }
    }
}
