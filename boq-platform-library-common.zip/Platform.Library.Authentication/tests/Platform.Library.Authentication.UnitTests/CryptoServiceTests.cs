using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using FluentAssertions;
using FluentAssertions.Execution;
using Microsoft.Extensions.Logging.Abstractions;
using Platform.Library.Authentication.UnitTests.Helper;
using Xunit;

namespace Platform.Library.Authentication.UnitTests
{
    public class CryptoServiceTests
    {
        private readonly CryptoService CryptoService;
        
        public CryptoServiceTests()
        {
            CryptoService = new CryptoService(new NullLogger<ICryptoService>());
        }
        
        [Fact]
        public void CryptoEngineAesEncryptTwice_ShouldNotEqual()
        {
            // arrange
            var plain = "123123123123";
            var key = "vmKBpC9essSrSHTVu+QpF/kmlKDTvEeD";

            // act
            var encryptedOnce = CryptoService.EncryptAES(key, plain);
            var encryptedTwice = CryptoService.EncryptAES(key, plain);
            var cipherBytesOne = Convert.FromBase64String(encryptedOnce);
            var cipherBytesTwo = Convert.FromBase64String(encryptedTwice);

            // assert
            using (new AssertionScope())
            {
                encryptedOnce.Should().NotBe(encryptedTwice);
                cipherBytesOne.Should().NotBeSameAs(cipherBytesTwo);
            }
        }

        [Theory]
        [InlineData("a")]
        [InlineData("1")]
        [InlineData("pinkfloyd")]
        [InlineData("pink floyd")]
        [InlineData("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.")]
        public void CryptoEngine_Aes256EncryptDecrypt_ShouldSucceed(string text)
        {
            // Arrange
            var plain = text;
            // 256 bit key
            var key = "vmKBpC9essSrSHTVu+QpF/kmlKDTvEeD";

            // Act
            var encrypted = CryptoService.EncryptAES(key, plain);
            var isBase64Encoded = encrypted.IsBase64Encoded();
            var byteCount = encrypted.Base64EncodedStringByteCount();
            var decrypted = CryptoService.DecryptAES(key, encrypted);

            // Assert
            using (new AssertionScope())
            {
                decrypted.Should().Be(plain);
                isBase64Encoded.Should().BeTrue();
                byteCount.Should().BeGreaterThanOrEqualTo(24);
            }
        }

        [Fact]
        public void CryptoEngine_Aes128EncryptDecrypt_ShouldSucceed()
        {
            // Arrange
            var plain = "pink floyd";
            // 512 bit key
            var key = "r5u8x/A?D(G+KaPd";
     
            // Act
            var encrypted = CryptoService.EncryptAES(key, plain);
            var isBase64Encoded = encrypted.IsBase64Encoded();
            var byteCount = encrypted.Base64EncodedStringByteCount();
            var decrypted = CryptoService.DecryptAES(key, encrypted);

            // Assert
            using (new AssertionScope())
            {
                decrypted.Should().Be(plain);
                isBase64Encoded.Should().BeTrue();
                byteCount.Should().BeGreaterThanOrEqualTo(24);
            }
        }

        [Theory]
        [InlineData("")]
        [InlineData("a")]
        [InlineData("This is my text...")]
        [InlineData("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.")]
        public void CryptoEngine_ShouldDecrypt_OwnEncryptedData(string text)
        {
            // Arrange
            var plain = text;

            // Act
            var encrypted = CryptoService.Encrypt(publicKey, plain);
            var isBase64Encoded = encrypted.IsBase64Encoded();
            var byteCount = encrypted.Base64EncodedStringByteCount();
            var decrypted = CryptoService.Decrypt(privateKey, encrypted);

            // Assert
            using (new AssertionScope())
            {
                decrypted.Should().Be(plain);
                isBase64Encoded.Should().BeTrue();
                byteCount.Should().BeGreaterThanOrEqualTo(256);
            }
        }

        [Fact]
        public void CryptoEngine_ShouldDecrypt_JavaScriptEncryptedData()
        {
            // Arrange
            var plain = "This is a test!";
            var encrypted = "sTjQbJ/SOBdpcFIAAZ5EhG30hWBV9XC2C7BactYVxzqAAe4t3V48UCWsBBLrtZJE845DmLrQLyHITRNZXtDr441ajzLTdY3huKyeuFgBGMS8zC2N2HuqxitSIkhi1rksnYUxCsF1HH0G1h3JzvSJ+sKH7l1jtNyTJIg1U2AIGKrvbMHKsKBEfOC8LNxaEkLJzcqRXaDEe5+gT1jToXxHbIjmGzZIlst4ZrIsqHYHpgXlXSzs8hDhrGKGPCgVZkkLICQWI+tjeaV94qRq1iqz+5+TSXsRDA9AhJeHzbafbI0HSx0cpRfGFckt3lhd87T0Sptqut+l2H55b9f2lrUyNw==";

            // Act
            var decrypted = CryptoService.Decrypt(privateKey, encrypted);

            // Assert
            decrypted.Should().Be(plain);
        }

        [Fact]
        public void CryptoEngine_ShouldReturnTrue_RSAEncryption()
        {
            // Arrange
            var plain = "000000000";
            var encrypted = CryptoService.Encrypt(publicKey, plain);
            var decrypted = String.Empty;

            // Act
            var isEncrypted = CryptoService.TryDecrypt(privateKey, encrypted, out decrypted);

            // Assert
            Assert.Equal(plain, decrypted);
            Assert.True(isEncrypted);
        }

        [Fact]
        public void CryptoEngine_ShouldReturnFalse_NoRSAEncryption_PlaintextInput()
        {
            // Arrange
            var plain = "000000000";

            // Act
            var isEncrypted = CryptoService.TryDecrypt(privateKey, plain, out _);

            // Assert
            Assert.False(isEncrypted);
        }

        [Fact]
        public void CryptoEngine_ShouldReturnFalse_NoRSAEncryption_AESEncryptedInput()
        {
            // Arrange
            var key = "vmKBpC9essSrSHTVu+QpF/kmlKDTvEeD";
            var plain = "000000000";
            var encrypted = CryptoService.EncryptAES(key, plain);

            // Act
            var isEncrypted = CryptoService.TryDecrypt(privateKey, encrypted, out _);

            // Assert
            Assert.False(isEncrypted);
        }

        [Fact]
        public void CryptoEngine_ShouldBeFalse_NoRSAEncryption_BadPrivateKey()
        {
            // Arrange
            var plain = "123456789";

            // Act
            var result = CryptoService.TryDecrypt(privateKey.StripForPrivateKey(), plain, out _);

            // Assert
            result.Should().BeFalse();
        }

        [Fact]
        public void CryptoEngine_ShouldReturnTrue_AESEncryption()
        {
            // Arrange
            var key = "vmKBpC9essSrSHTVu+QpF/kmlKDTvEeD";
            var plain = "000000000";
            var encrypted = CryptoService.EncryptAES(key, plain);
            var decrypted = String.Empty;

            // Act
            var isEncrypted = CryptoService.TryDecryptAes(key, encrypted, out decrypted);

            // Assert
            Assert.Equal(plain, decrypted);
            Assert.True(isEncrypted);
        }

        public static IList<object[]> PlaintTextTins = new[]
        {
            new object[] { "123456789"},
            new object[] { "123456789123456789"},
            new object[] { "ABCDEFGHI"},
            new object[] { "ABCD567890123456"},
            new object[] { "1213456789A"},
            new object[] { "A1234569"},// Hong Kong TIN (8 chars)
        };

        [Theory]
        [MemberData(nameof(PlaintTextTins))]
        public void CryptoEngine_ShouldReturnFalse_NoAESEncryption_PlaintextInput(string value)
        {
            // Arrange
            var plain = value;

            // Act
            var isEncrypted = CryptoService.TryDecryptAes(privateKey, plain, out _);

            // Assert
            isEncrypted.Should().BeFalse();
        }

        [Fact]
        public void CryptoEngine_ShouldBeFalse_NoAESEncryption_IncorrectInputLength()
        {
            // Arrange
            var key = "vmKBpC9essSrSHTVu+QpF/kmlKDTvEeD";
            var plain = "1234";

            // Act
            var result = CryptoService.TryDecryptAes(key, plain, out _);

            // Assert
            result.Should().BeFalse();
        }
        
        [Fact]
        public void DecryptPgp_ShouldReturnDecryptedStream_WhenCalledWithValidInput()
        {
            // Arrange
            const string unencryptedString = "encrypted data";
            var unencryptedStream = new MemoryStream(Encoding.UTF8.GetBytes(unencryptedString));
            var pgpKeys = PgpKeysHelper.GetTestPgpKeys();

            // Act
            var encryptedStream = unencryptedStream.EncryptPgp(pgpKeys);
            var decryptedStream = encryptedStream.DecryptPgp(pgpKeys);

            // Assert
            using (new AssertionScope())
            {
                decryptedStream.Should().NotBeNull();
                decryptedStream.CanRead.Should().BeTrue();
                encryptedStream.Should().NotBeNull();
                encryptedStream.CanRead.Should().BeTrue();
            }

            decryptedStream.Position = 0;
            using var resultReader = new StreamReader(decryptedStream);
            var resultString = resultReader.ReadToEnd();

            resultString.Should().Be(unencryptedString);
        }

        private static string Base64Encode(string plainText)
        {
            var plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            return Convert.ToBase64String(plainTextBytes);
        }

        private const string publicKey =
@"-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1BrypQXlhka2MCU48/lv
T33PoVWLipZvD7JY4E3EufhauI90DLHKpkNPMMGscKzGlIaD/iO/c+qNXxBpNAxg
pRwYI60KhlpVRuHnQxSqO8cvJFA3a74jDaLk0T/is1Wo7grTLEl9TvSmFssHepcu
jFh0Cb5xr0zt26ONLHNhBRCN/shAsx1cclFaRavhGO5uN4Q/v9rnED2S4s2EL39f
rjlLEWQnxF4Est9xg3NvYklSbtIpsBqzCF5VPHnP6j67SQVyhjczNfp9pqs5fkzL
KwZZ22zO8tpRdmi5qv6RF9+XNaVehXtYh7tV6ZtGweKJIVqLmNa47ZXTqsFNxalC
9wIDAQAB
-----END PUBLIC KEY-----
";

        private const string privateKey =
@"-----BEGIN PRIVATE KEY-----
MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDUGvKlBeWGRrYw
JTjz+W9Pfc+hVYuKlm8PsljgTcS5+Fq4j3QMscqmQ08wwaxwrMaUhoP+I79z6o1f
EGk0DGClHBgjrQqGWlVG4edDFKo7xy8kUDdrviMNouTRP+KzVajuCtMsSX1O9KYW
ywd6ly6MWHQJvnGvTO3bo40sc2EFEI3+yECzHVxyUVpFq+EY7m43hD+/2ucQPZLi
zYQvf1+uOUsRZCfEXgSy33GDc29iSVJu0imwGrMIXlU8ec/qPrtJBXKGNzM1+n2m
qzl+TMsrBlnbbM7y2lF2aLmq/pEX35c1pV6Fe1iHu1Xpm0bB4okhWouY1rjtldOq
wU3FqUL3AgMBAAECggEAFLTkx1OCCs/QbXbUzoylXz9LC9cMHmV9Ri0FHDC7aeRj
Bu2KSMr6m6yqiHn/2agkYs+XBzJ6OFjHoGY7vwcOUFAj0yfLhT5AYQEg0J2t2NQj
OApUvsH7LhOe/wabnSJZsZOA9ivefdzIciUz/7XOp4jjGyhqdNCvz+dxmstQx2ue
0bTrMCF7ZrBgUDgBslOdC1X2BGICiVigK+hxi3mqLB3ZGx1R/akipu+WQZVqD6V5
GVT3IUZVLyHrZiMTatI/GyezNZbrAL/OgVb/x/EBiLxQlQk32JTNGmj1xWkTi9tW
Cqf7vXPhakC4nUpdd0O1ABQbaBRCDbHN6qiA3TqwYQKBgQDpb0DdRY7rO45liwJf
uDfP1gradgaTATCnfEdRexTdefvFyo2p6gUfNfYq0eD8watpiuAUcx30TAvdQ6Na
qBYOlaAr20ylgJAyiM0kDS05Tti/zyyt5Dr6ZNj50xOY0m8RN7x4/VmOVRojXL5w
qa/auSrzjqDxu/u+pbcY32Ud2QKBgQDom9z6tpep8d5xyNBSJlKc0oJiZMv4Dkij
MlLDjaKzRKUGKJJEHZpspbbkiUCtKcxf2vryf232S1zZwqRM2ZRkJFvRihnTGojQ
EoYXZ6Yc37SNHBp7adM1fVpJEk1cvs1bQkAHKjKj8MN+VV258MdbbfvCICZ87rTn
8nUPI2xVTwKBgQCvSI4BWSjfNAJR91bZ/19RXh0aO8PmAN/C9Awtf+mEAQPwWo+T
hhlAfWmSb7SsttR61QA7+tEET1IdXJu+CDc/zlTOecaNBAPDHnxD1O0fejhBl1Sq
YpVyzeUrerbday5hVGPeygbEXNzartqFiLV23NIGvxPVUN3RI2hgcebgyQKBgQDD
R/chVKHHPxOtGxYpoZrBpcloqY7D1doNiHYLTqFFN2AD55PEM8YtaII/Iyt1NR4r
a0A6zdiXaXWuK8ab7h6yZAPhyrsbi69IYATLKW0/2F9QCEQDUDjNM0vVBNSGBHmL
H/d5DGgvUjYNncVuEUKM86zksPEe+ZhPEjJMX0TX6QKBgQCH4mv/BG6CYypvWkb/
q+DCULe5Sat/z5dP77ERPJgByrKyJizT67EKJg0x7ncZSNygkWYOG+EmflUbxiPc
yb779/k73I/dQbfnYVX3JgBbszPqjnyWizv+0k1fnHVGWmfSpUFZQkxYfaFTLgyo
CFATeZ0ggFYIW75pApjXjmP6hg==
-----END PRIVATE KEY-----
";
    }
}
