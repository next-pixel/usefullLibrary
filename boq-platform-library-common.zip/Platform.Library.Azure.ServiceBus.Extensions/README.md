[![Target Framework](https://img.shields.io/badge/Target%20Framework:-netstandard2.1-blue.svg?style=plastic&logo=dotnet)](https://shields.io/)
[![Build Status](https://dev.azure.com/qdigitalcode/DenovoBank/_apis/build/status/Platform.Library.Azure.ServiceBus.Extensions?repoName=Platform.Library.Azure.ServiceBus.Extensions&branchName=master)](https://dev.azure.com/qdigitalcode/DenovoBank/_build/latest?definitionId=1352&repoName=Platform.Library.Azure.ServiceBus.Extensions&branchName=master)
[![Platform.Library.Azure.ServiceBus.Extensions package in Development feed in Azure Artifacts](https://feeds.dev.azure.com/qdigitalcode/_apis/public/Packaging/Feeds/Development/Packages/293391a6-9555-4f91-b9b4-cc9217df1369/Badge)](https://dev.azure.com/qdigitalcode/DenovoBank/_artifacts/feed/Development/NuGet/Platform.Library.Azure.ServiceBus.Extensions)

[![Quality Gate Status](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Azure.ServiceBus.Extensions&metric=alert_status&token=5a93842792b206d1cfd6b08a38aafe70c3e3cb09)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Azure.ServiceBus.Extensions)
[![Coverage](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Azure.ServiceBus.Extensions&metric=coverage&token=5a93842792b206d1cfd6b08a38aafe70c3e3cb09)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Azure.ServiceBus.Extensions)
[![Vulnerabilities](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=Platform.Library.Azure.ServiceBus.Extensions&metric=vulnerabilities&token=5a93842792b206d1cfd6b08a38aafe70c3e3cb09)](https://sonarqube.boqdev.com.au/dashboard?id=Platform.Library.Azure.ServiceBus.Extensions)

# Platform.Library.Azure.ServiceBus.Extensions

## Changes
### 2023-08-28
- Add extension methods for ProcessMessageContext class
### 2022-12-02
- Updated Microsoft.Azure.WebJobs.ServiceBus.Extensions to use 5.8.1
- Refactored code to support new version
- Marked old method as obsolete
### 2022-04-28
- Update pipeline to allow for pre-releases 
- Update Platform.Library dependencies 
### 2020-10-15
- Major Version Upgrade
- Updated Default Retry to use - Delay + Abandon.
- Refer - https://github.com/Azure/azure-functions-host/issues/6788
- Delay time can be configured and passed to the extension. Default value - 4mins 30sec
### 2020-06-15
- Changed MessageReceiver signatures to IMessageReceiver to make the classes testable