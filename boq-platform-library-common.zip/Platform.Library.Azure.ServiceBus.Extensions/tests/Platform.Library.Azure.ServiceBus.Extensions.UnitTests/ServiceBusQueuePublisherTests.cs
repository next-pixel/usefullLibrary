﻿using FluentAssertions;
using FluentAssertions.Execution;
using Library.Azure.ServiceBus;
using Platform.Library.Testing;
using Platform.Library.Testing.XUnit;
using Xunit;
using Xunit.Abstractions;

namespace Platform.Library.Azure.ServiceBus.Extensions.UnitTests
{
    [TestType(TestTypeEnum.UnitTest)]
    public class ServiceBusQueuePublisherTests : XUnitTestFixture
    {
        protected ContextModule Context => Module<ContextModule>();

        public ServiceBusQueuePublisherTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture) { }

        protected override void TestSetup()
        {
            Context.RegisterWithMsDi(services =>
            {
                services.RegisterServiceBusQueueEventPublisher<TestQueuePublisher, ITestQueuePublisher, MyEvent>();
                services.RegisterMockServiceBusQueueClientFactory();
            });
        }

        [Theory]
        [InlineData(false)]
        [InlineData(true)]
        public async Task ServiecBusQueuePublisher_Success(bool useAdditionalProperties)
        {
            // Arrange
            var publisher = Context.Resolve<ITestQueuePublisher>();
            var clientFactory = Context.GetMockServiceBusQueueClientFactory();

            var payload = ServiceBusEventHelper.GenerateEvent<MyEvent, MyEventPayload>(new MyEventPayload { EventProperty = "Test" });

            // Act
            Exception actualException = null;
            try
            {
                if (useAdditionalProperties)
                    await publisher.PublishEvent(payload, new Dictionary<string, object> { { "TestKey", "TestValue" } }, CancellationToken.None);
                else
                    await publisher.PublishEvent(payload, CancellationToken.None);
            }
            catch (Exception ex)
            {
                actualException = ex;
            }

            // Assert
            using (new AssertionScope())
            {
                actualException.Should().BeNull();
                clientFactory.MessagesSent("myevent.queue").Should().Be(1);

                var sentMessage = clientFactory.GetMessage("myevent.queue", 0);
                sentMessage.Should().NotBeNull();
                if ( sentMessage != null )
                {
                    WriteLine(sentMessage.GetBodyAsString());
                    sentMessage.Body.Should().NotBeEmpty();
                    sentMessage.Label.Should().Be("TestLabel");
                    sentMessage.CorrelationId.Should().NotBeNullOrWhiteSpace();
                    sentMessage.MessageId.Should().NotBeNullOrWhiteSpace();
                    sentMessage.UserProperties.Should().NotBeEmpty();

                    if (sentMessage.UserProperties.TryGetValue("EnrichKey", out var enrichValue))
                    {
                        enrichValue.Should().Be("EnrichValue");
                    }
                    else
                        sentMessage.UserProperties.Should().ContainKey("EnrichKey");

                    if (useAdditionalProperties)
                    {
                        if (sentMessage.UserProperties.TryGetValue("TestKey", out var additionalValue))
                            additionalValue.Should().Be("TestValue");
                        else
                            sentMessage.UserProperties.Should().ContainKey("TestKey");
                    }
                    else
                    {
                        sentMessage.UserProperties.Should().NotContainKey("TestKey");
                    }
                }
            }
        }

        [Fact]
        public async Task ServiecBusQueuePublisher_Failure()
        {
            // Arrange
            var publisher = Context.Resolve<ITestQueuePublisher>();
            var clientFactory = Context.GetMockServiceBusQueueClientFactory();

            var payload = ServiceBusEventHelper.GenerateEvent<MyEvent, MyEventPayload>(new MyEventPayload { EventProperty = "Test" });
            clientFactory.CauseExceptionForMessage(payload.Metadata.MessageId);

            // Act
            Exception actualException = null;
            try
            {
                await publisher.PublishEvent(payload, CancellationToken.None);
            }
            catch (Exception ex)
            {
                actualException = ex;
            }

            // Assert
            using (new AssertionScope())
            {
                actualException.Should().NotBeNull();
                clientFactory.MessagesSent("myevent.queue").Should().Be(0);                
            }
        }
    }
}
