﻿using Library.Azure.ServiceBus;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Platform.Library.Azure.ServiceBus.Extensions.UnitTests
{
    public interface ITestTopicPublisher : IServiceBusTopicEventPublisher<MyEvent>
    {

    }

    public class TestTopicPublisher : ServiceBusTopicEventPublisher<MyEvent>, ITestTopicPublisher
    {
        public TestTopicPublisher(ILogger logger, ServiceBusSettings settings, IServiceBusTopicClient serviceBusTopicClient) : base(logger, settings, serviceBusTopicClient)
        {
        }
    }
}
