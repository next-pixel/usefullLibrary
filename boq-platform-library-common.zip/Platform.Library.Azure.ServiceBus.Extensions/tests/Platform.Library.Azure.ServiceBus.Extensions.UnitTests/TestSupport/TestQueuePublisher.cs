﻿using Library.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Platform.Library.Azure.ServiceBus.Extensions.UnitTests
{
    public interface ITestQueuePublisher : IServiceBusQueueEventPublisher<MyEvent> { }

    public class TestQueuePublisher : ServiceBusQueueEventPublisher<MyEvent>, ITestQueuePublisher
    {
        public TestQueuePublisher(ILogger logger, ServiceBusSettings settings, IServiceBusQueueClient serviceBusQueueClient) : base(logger, settings, serviceBusQueueClient)
        {
        }

        protected override void EnrichMessage(Message message)
        {
            message.UserProperties.Add("EnrichKey", "EnrichValue");
        }

        protected override string CalculateLabel(MyEvent payload, Message message)
            => "TestLabel";
    }
}
