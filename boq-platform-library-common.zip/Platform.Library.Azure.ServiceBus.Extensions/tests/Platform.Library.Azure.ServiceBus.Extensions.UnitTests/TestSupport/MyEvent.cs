﻿using Platform.Library.BaseEvent;
using System;
using System.Collections.Generic;
using System.Text;

namespace Platform.Library.Azure.ServiceBus.Extensions.UnitTests
{
    public class MyEventPayload
    {
        public string EventProperty { get; set; }
    }

    [EventName("MyEventName")]
    public class MyEvent : Platform.Library.BaseEvent.BaseEvent<MyEventPayload>
    {
    }
}
