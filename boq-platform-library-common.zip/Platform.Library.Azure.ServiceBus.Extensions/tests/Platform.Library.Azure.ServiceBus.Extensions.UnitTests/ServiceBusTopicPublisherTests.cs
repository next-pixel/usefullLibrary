﻿using Autofac.Core;
using FluentAssertions;
using FluentAssertions.Execution;
using Library.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Moq;
using Platform.Library.Testing;
using Platform.Library.Testing.XUnit;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Xunit;
using Xunit.Abstractions;

namespace Platform.Library.Azure.ServiceBus.Extensions.UnitTests
{
    [TestType(TestTypeEnum.UnitTest)]
    public class ServiceBusTopicPublisherTests : XUnitTestFixture
    {
        protected ContextModule Context => Module<ContextModule>();

        public ServiceBusTopicPublisherTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture) { }

        protected override void TestSetup()
        {
            Context.RegisterWithMsDi(services =>
            {
                services.RegisterServiceBusTopicEventPublisher<TestTopicPublisher, ITestTopicPublisher, MyEvent>();
                services.RegisterMockServiceBusTopicClientFactory();
            });
        }

        [Theory]
        [InlineData(false)]
        [InlineData(true)]
        public async Task ServiecBusTopicPublisher_Success(bool useAdditionalProperties)
        {
            // Arrange
            var publisher = Context.Resolve<ITestTopicPublisher>();
            var clientFactory = Context.GetMockServiceBusTopicClientFactory();

            var payload = ServiceBusEventHelper.GenerateEvent<MyEvent, MyEventPayload>(new MyEventPayload { EventProperty = "Test" });

            // Act
            Exception actualException = null;
            try
            {
                if (useAdditionalProperties)
                    await publisher.PublishEvent(payload, new Dictionary<string, object> { { "TestKey", "TestValue" } }, CancellationToken.None);
                else
                    await publisher.PublishEvent(payload, CancellationToken.None);
            }
            catch (Exception ex)
            {
                actualException = ex;
            }

            // Assert
            using (new AssertionScope())
            {
                actualException.Should().BeNull();
                clientFactory.MessagesSent("myevent.topic").Should().Be(1);

                var sentMessage = clientFactory.GetMessage("myevent.topic", 0);
                sentMessage.Should().NotBeNull();
                if ( sentMessage != null )
                {
                    WriteLine(sentMessage.GetBodyAsString());
                    sentMessage.Body.Should().NotBeEmpty();
                    sentMessage.Label.Should().BeNull();
                    sentMessage.CorrelationId.Should().NotBeNullOrWhiteSpace();
                    sentMessage.MessageId.Should().NotBeNullOrWhiteSpace();
                    sentMessage.UserProperties.Should().NotBeEmpty();

                    if (useAdditionalProperties)
                    {
                        if (sentMessage.UserProperties.TryGetValue("TestKey", out var additionalValue))
                            additionalValue.Should().Be("TestValue");
                        else
                            sentMessage.UserProperties.Should().ContainKey("TestKey");
                    }
                    else
                    {
                        sentMessage.UserProperties.Should().NotContainKey("TestKey");
                    }
                }
            }
        }

        [Fact]
        public async Task ServiecBusTopicPublisher_Failure()
        {
            // Arrange
            var publisher = Context.Resolve<ITestTopicPublisher>();
            var clientFactory = Context.GetMockServiceBusTopicClientFactory();

            var payload = ServiceBusEventHelper.GenerateEvent<MyEvent, MyEventPayload>(new MyEventPayload { EventProperty = "Test" });
            clientFactory.CauseExceptionForMessage(payload.Metadata.MessageId);

            // Act
            Exception actualException = null;
            try
            {
                await publisher.PublishEvent(payload, CancellationToken.None);
            }
            catch (Exception ex)
            {
                actualException = ex;
            }

            // Assert
            using (new AssertionScope())
            {
                actualException.Should().NotBeNull();
                clientFactory.MessagesSent("myevent.topic").Should().Be(0);                
            }
        }
    }
}
