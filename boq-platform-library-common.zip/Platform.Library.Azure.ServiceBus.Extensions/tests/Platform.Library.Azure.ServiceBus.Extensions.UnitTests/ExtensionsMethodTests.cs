using FluentAssertions;
using FluentAssertions.Execution;
using Library.Azure.ServiceBus;
using Platform.Library.Common.Standard.Models;
using System;
using Xunit;

namespace Platform.Library.Azure.ServiceBus.Extensions.UnitTests
{
    public class ExtensionsMethodTests
    {
        [Theory]
        [InlineData(null, "A Exception error occurred. Message will be dead lettered.")]
        [InlineData("Test", "Test")]
        public void PoisonMessageGeneralExceptionTest(string customErrorMessage, string expectedErrorMessage)
        {
            //Arrange
            var context = new ProcessMessageContext();
            var exceptionMessage = "Test exception message";
            var exception = new Exception(exceptionMessage);

            //Act
            context.PoisonMessage(exception, customErrorMessage);

            //Assert
            using (new AssertionScope())
            {
                context.ErrorReason.Should().Be(exceptionMessage);
                context.ErrorMessage.Should().Be(expectedErrorMessage);
                context.Result.Should().Be(ProcessMessageResult.PoisonMessageIdentified);
            }
        }
        
        [Theory]
        [InlineData(null, "A Exception error occurred. Message will be retried.")]
        [InlineData("Test", "Test")]
        public void RetryMessageGeneralExceptionTest(string customErrorMessage, string expectedErrorMessage)
        {
            //Arrange
            var context = new ProcessMessageContext();
            var exceptionMessage = "Test exception message";
            var exception = new Exception(exceptionMessage);

            //Act
            context.RetryMessage(exception, customErrorMessage);

            //Assert
            using (new AssertionScope())
            {
                context.ErrorReason.Should().Be(exceptionMessage);
                context.ErrorMessage.Should().Be(expectedErrorMessage);
                context.Result.Should().Be(ProcessMessageResult.RequiresRetry);
            }
        }

        [Fact]
        public void MapMetadataSuccessfulTest()
        {
            // Arrange
            var standardHeaders = new StandardHeaderModel
            {
                RequestId = "1234",
                InitiatingSystemId = "InitiatingSystem",
                InitiatingSystemVersion = "1.0",
                SendingSystemId = "SendingSystem",
                SendingSystemVersion = "2.0",
                Timestamp = DateTimeOffset.UtcNow
            };

            // Act
            var metadata = standardHeaders.MapMetadata();

            // Assert
            using ( new AssertionScope()) 
            {
                metadata.Should().NotBeNull();
                if ( metadata != null )
                {
                    metadata.RequestId.Should().Be(standardHeaders.RequestId);
                    metadata.MessageId.Should().NotBeNullOrWhiteSpace();
                    metadata.EventName.Should().BeNull();
                    metadata.AssemblyQualifiedName.Should().BeNullOrWhiteSpace();
                    metadata.InitiatingSystemId.Should().Be(standardHeaders.InitiatingSystemId);
                    metadata.InitiatingSystemVersion.Should().Be(standardHeaders.InitiatingSystemVersion);
                    metadata.SendingSystemId.Should().Be(standardHeaders.SendingSystemId);
                    metadata.SendingSystemVersion.Should().Be(standardHeaders.SendingSystemVersion);
                    metadata.Timestamp.Should().NotBe(standardHeaders.Timestamp);
                }
            }
        }
    }
}