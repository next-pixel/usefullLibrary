﻿namespace Library.Azure.ServiceBus
{
    public class QueueClientInstances
    {
        public Microsoft.Azure.ServiceBus.IQueueClient QueueClient { get; set; }

        public int SuccessiveFailures { get; set; }
        public string ConnectionString { get; set; }
    }
}
