namespace Library.Azure.ServiceBus
{
    public enum ProcessMessageResult
    {
        SuccessfullyProcessedMessage,
        PoisonMessageIdentified,
        RequiresRetry, // Do Nothing and Wait till the peek lock expires so that message will retry
        RequiresAbandonDelayRetry, 
        NoStatusSet
    }
}
