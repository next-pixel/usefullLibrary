using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Extensions.Logging;
using Platform.Library.Azure.ServiceBus.Extensions.Models;
using System;
using System.Threading;
using System.Threading.Tasks;
using Platform.Library.Azure.ServiceBus.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;

namespace Library.Azure.ServiceBus
{
    public class MessageHandler<T> : IMessageHandler<T> where T : class
    {
        private readonly TopicMessageRetryPolicySettings _settings;

        public static readonly TopicMessageRetryPolicySettings DefaultRetryPolicySettings =  new TopicMessageRetryPolicySettings
        {
            MessageDelayBeforeAbandonSeconds = (int) TimeSpan.FromMinutes(4.5).TotalSeconds // Default value is 4mins 30sec
        };

        public MessageHandler(TopicMessageRetryPolicySettings settings)
        {
            _settings = settings;
        }

        public MessageHandler() : this(DefaultRetryPolicySettings)
        {
        }

        public async Task ProcessMessageAsync(
            Message message,
            IMessageReceiver messageReceiver,
            ILogger logger,
            CancellationToken token,
            IConfigurationRefresher refresher = null)
        {
            if (refresher != null)
                await refresher.TryRefreshAsync();

            var result = new ProcessMessageContext();

            try
            {
                logger.LogInformation(
                    "{assembly}: Received Message with MessageId {message} Delivery Count: {deliveryCount}",
                    GetType().FullName,
                    message.MessageId,
                    message.SystemProperties.ProtectedDeliveryCount());

                var deserializedPayload = DeserializeMessage(message, logger);

                await ActionPayload(deserializedPayload, result, logger, token);

                if (result.Result == ProcessMessageResult.NoStatusSet)
                {
                    result.Result = ProcessMessageResult.SuccessfullyProcessedMessage;
                }
            }
            catch (UnrecoverableMessageException ex)
            {
                // Assume that because this is thrown in consumer code that it
                // is also logged correctly - so no need to re-log here

                result.Result = ProcessMessageResult.PoisonMessageIdentified;

                if (ex is MessageDeserializationException)
                {
                    result.ErrorMessage = "Error deserializing the message.";
                    result.ErrorReason = ex.InnerException?.Message;
                }
                else
                {
                    result.ErrorMessage = $"{ex.GetType().Name} has occurred";
                    result.ErrorReason = ex.Message;
                }

                logger.LogError(ex,
                    "{assembly}: Unrecoverable Exception processing Message with MessageId {message}. Failure Message: {messageContent} Reason: {reason}",
                    GetType().FullName,
                    message.MessageId,
                    result.ErrorMessage,
                    result.ErrorReason);
            }
            catch (Exception ex) when (!(ex is UnrecoverableMessageException))
            {
                result.ErrorMessage = $"{ex.GetType().Name} has occurred";
                result.ErrorReason = ex.Message;

                // Consume the exception without completing or abandoning the message
                // so that the peak lock times out and the message is available to be processed again
                logger.LogError(ex,
                    "{assembly}: Exception processing Message with MessageId {message}. Failure Message: {messageContent} Reason: {reason}",
                    GetType().FullName,
                    message.MessageId,
                    result.ErrorMessage,
                    result.ErrorReason);

                result.Result = ProcessMessageResult.RequiresRetry;
            }

            if (result.Result != null)
            {
                switch (result.Result)
                {
                    case ProcessMessageResult.PoisonMessageIdentified:

                        logger.LogWarning(
                            "{assembly}: Dead-lettering Message with MessageId {message}. Failure Message: {messageContent} Reason: {reason}",
                            GetType().FullName,
                            message.MessageId,
                            result.ErrorMessage,
                            result.ErrorReason);

                        await DeadLetterAsync(
                            message,
                            messageReceiver,
                            logger,
                            result.ErrorMessage,
                            result.ErrorReason);

                        break;

                    case ProcessMessageResult.SuccessfullyProcessedMessage:
                        // Do nothing as the message is already completed
                        logger.LogInformation(
                            "{assembly}: Successfully processed Message with MessageId {message}",
                            GetType().FullName,
                            message.MessageId);

                        await messageReceiver.CompleteAsync(message.SystemProperties.ProtectedLockToken());

                        break;

                    case ProcessMessageResult.RequiresRetry:
                        // Do nothing and let PeekLock time itself out.
                        // Once retries are exhausted, the message should automatically move to Deadletter.
                        logger.LogWarning("Message will retry after lock expiry");
                        logger.LogWarning(
                            "{assembly}: Will retry Message with MessageId {message}. Failure Message: {messageContent} Reason: {reason}",
                            GetType().FullName,
                            message.MessageId,
                            result.ErrorMessage,
                            result.ErrorReason);

                        break;

                    case ProcessMessageResult.RequiresAbandonDelayRetry:
                        
                        logger.LogWarning("Abandon Message after delaying {0} seconds for retry", _settings.MessageDelayBeforeAbandonSeconds);

                        await Task.Delay((int)TimeSpan.FromSeconds(_settings.MessageDelayBeforeAbandonSeconds).TotalMilliseconds, token);

                        logger.LogWarning(
                            "{assembly}: Will retry Message with MessageId {message}. Failure Message: {messageContent} Reason: {reason}",
                            GetType().FullName,
                            message.MessageId,
                            result.ErrorMessage,
                            result.ErrorReason);
                        await messageReceiver.AbandonAsync(message.SystemProperties.ProtectedLockToken());

                        break;
                }
            }
        }

        protected virtual async Task DeadLetterAsync(
            Message message,
            IMessageReceiver messageReceiver,
            ILogger logger,
            string deadLetterReason,
            string deadLetterErrorDescription)
        {
            await PreProcessDeadlettering(message, logger);
            await messageReceiver.DeadLetterAsync(message.SystemProperties.ProtectedLockToken(), deadLetterReason, deadLetterErrorDescription);
        }

        protected virtual T DeserializeMessage(Message message, ILogger logger)
        {
            if (typeof(T) == typeof(Message))
            {
                return message as T;
            }

            var deserializedObject = message.GetBodyFromJson<T>();

            logger.LogDebug(
                "{assembly}: Deserialized Message with MessageId {message}",
                GetType().FullName,
                message.MessageId);

            return deserializedObject;
        }

        protected virtual Task ActionPayload(
            T payload,
            ProcessMessageContext context,
            ILogger logger,
            CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }

        protected virtual Task PreProcessDeadlettering(Message message, ILogger logger)
        {
            return Task.CompletedTask;
        }
    }
}