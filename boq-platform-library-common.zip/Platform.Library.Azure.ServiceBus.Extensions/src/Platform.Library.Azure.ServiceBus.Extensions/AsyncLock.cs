﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Library.Azure.ServiceBus.Extensions
{
    internal class AsyncLock : IDisposable
    {
        private SemaphoreSlim _semaphoreSlim = new SemaphoreSlim(1, 1);
        bool disposed = false;

        public async Task<AsyncLock> LockAsync()
        {
            await _semaphoreSlim.WaitAsync();
            return this;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // Protected implementation of Dispose pattern.
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            _semaphoreSlim.Release();
            disposed = true;
        }
    }
}
