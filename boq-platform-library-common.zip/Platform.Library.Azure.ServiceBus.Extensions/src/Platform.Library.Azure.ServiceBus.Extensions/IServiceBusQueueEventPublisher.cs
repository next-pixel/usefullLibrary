﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Platform.Library.Azure.ServiceBus.Extensions
{
    /// <summary>
    /// Interface for a service bus queue event publisher
    /// </summary>
    /// <typeparam name="TEvent">The event this is publishing</typeparam>
    public interface IServiceBusQueueEventPublisher<TEvent>
        where TEvent : Platform.Library.BaseEvent.BaseEvent
    {
        /// <summary>
        /// Publish the <paramref name="payload"/> to service bus
        /// </summary>
        /// <param name="payload">Instance of the <typeparamref name="TEvent">event</typeparamref> to be published</param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task PublishEvent(TEvent payload, CancellationToken cancellationToken);

        /// <summary>
        /// <inheritdoc cref="IServiceBusQueueEventPublisher{TEvent}.PublishEvent(TEvent, CancellationToken)" path="/summary"/>
        /// </summary>
        /// <param name="payload"><inheritdoc cref="IServiceBusQueueEventPublisher{TEvent}.PublishEvent(TEvent, CancellationToken)" path="/param[@name='payload']"/></param>
        /// <param name="additionalProperties">Additional properties to add to the <see cref="Microsoft.Azure.ServiceBus.Message.UserProperties"/> of the message before sending</param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task PublishEvent(TEvent payload, IDictionary<string,object> additionalProperties, CancellationToken cancellationToken);
    }
}
