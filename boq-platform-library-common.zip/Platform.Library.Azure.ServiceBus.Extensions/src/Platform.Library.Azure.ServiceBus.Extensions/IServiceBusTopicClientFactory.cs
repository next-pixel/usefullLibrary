﻿using Library.Azure.ServiceBus;
using System;
using System.Collections.Generic;
using System.Text;

namespace Platform.Library.Azure.ServiceBus.Extensions
{
    /// <summary>
    /// Factory to create service bus topic client
    /// </summary>
    public interface IServiceBusTopicClientFactory
    {
        /// <summary>
        /// Create a new client for the given topic.
        /// The client might be cached and the instance will be recycled.
        /// </summary>
        /// <param name="topicName">The topic name to bind the service bus client</param>
        /// <returns>An instance of <see cref="IServiceBusTopicClient"/> to represent the service bus connection</returns>
        IServiceBusTopicClient GetClient(string topicName);
    }
}
