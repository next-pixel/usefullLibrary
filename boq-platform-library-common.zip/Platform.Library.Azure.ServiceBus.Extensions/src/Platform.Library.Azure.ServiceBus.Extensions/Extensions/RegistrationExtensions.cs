﻿using Autofac;
using Library.Azure.ServiceBus;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Platform.Library.BaseEvent;
using Platform.Library.Common;
using Platform.Library.Extensions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Text;

namespace Platform.Library.Azure.ServiceBus.Extensions
{
    /// <summary>
    /// Extension methods for registering service bus publishers
    /// </summary>
    public static class RegistrationExtensions
    {
        /// <summary>
        /// Register a Service Bus Topic Event Publisher for a specific topic
        /// </summary>
        /// <typeparam name="TPublisher">Concrete publisher class</typeparam>
        /// <typeparam name="TInterface">Interface for this specific publisher</typeparam>
        /// <typeparam name="TEvent"></typeparam>
        /// <param name="services"></param>
        /// <param name="topicName">If not provided, it will be retrieved from the <see cref="ServiceBusSettings.Topics"/> collection</param>
        /// <returns></returns>
        public static IServiceCollection RegisterServiceBusTopicEventPublisher<TPublisher, TInterface, TEvent>(this IServiceCollection services, string topicName = null)
            where TPublisher : ServiceBusTopicEventPublisher<TEvent>, TInterface
            where TInterface : class, IServiceBusTopicEventPublisher<TEvent>
            where TEvent : Platform.Library.BaseEvent.BaseEvent
        {
            ValidateTypes<TPublisher, TInterface>();

            if ( !services.AnyNullSafe(x => x.ServiceType == typeof(IOptions<ServiceBusSettings>)) )
                services.RegisterOptions<ServiceBusSettings>(InternalConstants.Configuration.Sections.ServiceBus);

            services.TryAddSingleton<IServiceBusTopicClientFactory, ServiceBusTopicClientFactory>();

            services.AddSingleton<TInterface, TPublisher>(c =>
            {
                var settings = c.GetRequiredService<IOptions<ServiceBusSettings>>().GuardNull(nameof(ServiceBusSettings));
                var logger = c.GetRequiredService<ILogger<TPublisher>>();
                var factory = c.GetRequiredService<IServiceBusTopicClientFactory>();
                var topicClient = factory.GetClient(settings.RetrieveTopicName<TEvent>(topicName));

                return (TPublisher)Activator.CreateInstance(typeof(TPublisher), logger, settings, topicClient);
            });
            
            return services;
        }

        /// <summary>
        /// Register a Service Bus Topic Event Publisher for a specific topic
        /// </summary>
        /// <typeparam name="TPublisher">Concrete publisher class</typeparam>
        /// <typeparam name="TInterface">Interface for this specific publisher</typeparam>
        /// <typeparam name="TEvent"></typeparam>
        /// <param name="builder"></param>
        /// <param name="topicName">If not provided, it will be retrieved from the <see cref="ServiceBusSettings.Topics"/> collection</param>
        /// <returns></returns>
        public static ContainerBuilder RegisterServiceBusTopicEventPublisher<TPublisher, TInterface,TEvent>(this ContainerBuilder builder, string topicName = null)
            where TPublisher : ServiceBusTopicEventPublisher<TEvent>, TInterface
            where TInterface : class, IServiceBusTopicEventPublisher<TEvent>
            where TEvent : Platform.Library.BaseEvent.BaseEvent
        {
            ValidateTypes<TPublisher, TInterface>();

            builder.RegisterOptions<ServiceBusSettings>(InternalConstants.Configuration.Sections.ServiceBus);

            builder.RegisterType<ServiceBusTopicClientFactory>()
                .AsImplementedInterfaces()
                .SingleInstance()
                .IfNotRegistered(typeof(IServiceBusTopicClientFactory));

            builder.Register(c =>
            {
                var settings = c.Resolve<IOptions<ServiceBusSettings>>().GuardNull(nameof(ServiceBusSettings));
                var logger = c.Resolve<ILogger<TPublisher>>();
                var factory = c.Resolve<IServiceBusTopicClientFactory>();
                var topicClient = factory.GetClient(settings.RetrieveTopicName<TEvent>(topicName));

                return (TInterface)Activator.CreateInstance(typeof(TPublisher), logger, settings, topicClient);

            }).As<TInterface>().SingleInstance();

            return builder;
        }

        /// <summary>
        /// Register a Service Bus Queue Event Publisher for a specific queue
        /// </summary>
        /// <typeparam name="TPublisher">Concrete publisher class</typeparam>
        /// <typeparam name="TInterface">Interface for this specific publisher</typeparam>
        /// <typeparam name="TEvent"></typeparam>
        /// <param name="services"></param>
        /// <param name="queueName">If not provided, it will be retrieved from the <see cref="ServiceBusSettings.Queues"/> collection</param>
        /// <returns></returns>
        public static IServiceCollection RegisterServiceBusQueueEventPublisher<TPublisher, TInterface, TEvent>(this IServiceCollection services, string queueName = null)
            where TPublisher : ServiceBusQueueEventPublisher<TEvent>, TInterface
            where TInterface : class, IServiceBusQueueEventPublisher<TEvent>
            where TEvent : Platform.Library.BaseEvent.BaseEvent
        {
            ValidateTypes<TPublisher, TInterface>();

            if (!services.AnyNullSafe(x => x.ServiceType == typeof(IOptions<ServiceBusSettings>)))
                services.RegisterOptions<ServiceBusSettings>(InternalConstants.Configuration.Sections.ServiceBus);

            services.TryAddSingleton<IServiceBusQueueClientFactory, ServiceBusQueueClientFactory>();

            services.AddSingleton<TInterface, TPublisher>(c =>
            {
                var settings = c.GetRequiredService<IOptions<ServiceBusSettings>>().GuardNull(nameof(ServiceBusSettings));
                var logger = c.GetRequiredService<ILogger<TPublisher>>();
                var factory = c.GetRequiredService<IServiceBusQueueClientFactory>();
                var queueClient = factory.GetClient(settings.RetrieveQueueName<TEvent>(queueName));

                return (TPublisher)Activator.CreateInstance(typeof(TPublisher), logger, settings, queueClient);
            });

            return services;
        }

        /// <summary>
        /// Register a Service Bus Event Publisher for a specific queue
        /// </summary>
        /// <typeparam name="TPublisher">Concrete publisher class</typeparam>
        /// <typeparam name="TInterface">Interface for this specific publisher</typeparam>
        /// <typeparam name="TEvent"></typeparam>
        /// <param name="builder"></param>
        /// <param name="queueName">If not provided, it will be retrieved from the <see cref="ServiceBusSettings.Queues"/> collection</param>
        /// <returns></returns>
        public static ContainerBuilder RegisterServiceBusQueueEventPublisher<TPublisher, TInterface, TEvent>(this ContainerBuilder builder, string queueName = null)
            where TPublisher : ServiceBusQueueEventPublisher<TEvent>, TInterface
            where TInterface : class, IServiceBusQueueEventPublisher<TEvent>
            where TEvent : Platform.Library.BaseEvent.BaseEvent
        {
            ValidateTypes<TPublisher, TInterface>();

            builder.RegisterOptions<ServiceBusSettings>(InternalConstants.Configuration.Sections.ServiceBus);

            builder.RegisterType<ServiceBusQueueClientFactory>()
                .AsImplementedInterfaces()
                .SingleInstance()
                .IfNotRegistered(typeof(IServiceBusQueueClientFactory));

            builder.Register(c =>
            {
                var settings = c.Resolve<IOptions<ServiceBusSettings>>().GuardNull(nameof(ServiceBusSettings));
                var logger = c.Resolve<ILogger<TPublisher>>();
                var factory = c.Resolve<IServiceBusQueueClientFactory>();
                var queueClient = factory.GetClient(settings.RetrieveQueueName<TEvent>(queueName));

                return (TInterface)Activator.CreateInstance(typeof(TPublisher), logger, settings, queueClient);

            }).As<TInterface>().SingleInstance();

            return builder;
        }

        private static void ValidateTypes<TPublisher,TInterface>()
        {
            // Confirm the right types have been passed
            if (typeof(TPublisher).IsInterface)
                throw new ArgumentException($"The provided {nameof(TPublisher)} must be a concrete class", typeof(TPublisher).FormattedTypeName());

            if (!typeof(TInterface).IsInterface)
                throw new ArgumentException($"The provided {nameof(TInterface)} must be an interface", typeof(TPublisher).FormattedTypeName());
        }

        private static string RetrieveTopicName<TEvent>(this ServiceBusSettings settings, string topicName = null)
            where TEvent : Platform.Library.BaseEvent.BaseEvent
        {
            if (!string.IsNullOrWhiteSpace(topicName))
                return topicName;

            var attr = typeof(TEvent).EventNameAttribute();
            if (attr == null)
                throw new ArgumentException(nameof(topicName), $"Event of type {typeof(TEvent)} does not have a {nameof(EventNameAttribute)} in order to determine the topic");

            return settings.Topics.TryGetValue(attr.Name, out var foundTopic)
                ? foundTopic
                : throw new ConfigurationErrorsException($"Unable to locate configuration for 'ServiceBus:Topics:{attr.Name}'");
        }

        private static string RetrieveQueueName<TEvent>(this ServiceBusSettings settings, string queueName = null)
            where TEvent : Platform.Library.BaseEvent.BaseEvent
        {
            if (!string.IsNullOrWhiteSpace(queueName))
                return queueName;

            var attr = typeof(TEvent).EventNameAttribute();
            if (attr == null)
                throw new ArgumentException(nameof(queueName), $"Event of type {typeof(TEvent)} does not have a {nameof(EventNameAttribute)} in order to determine the queue");

            return settings.Queues.TryGetValue(attr.Name, out var foundQueue)
                ? foundQueue
                : throw new ConfigurationErrorsException($"Unable to locate configuration for 'ServiceBus:Queues:{attr.Name}'");
        }
    }
}
