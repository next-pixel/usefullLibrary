﻿using Microsoft.Extensions.Logging;
using Platform.Library.Common.Standard.ErrorHandling;
using System;
using System.Collections.Generic;
using System.Net;

namespace Platform.Library.Azure.ServiceBus.Extensions
{
    internal static class ErrorExtensions
    {
        internal static StandardApiException LogAndRaiseException(this ILogger logger, ( HttpStatusCode StatusCode, ErrorMessageModel Error) errorDetails, string messagePrefix, params object[] args)
        {
            var exception = new StandardApiException
            {
                HttpStatusCode = (int)errorDetails.StatusCode,
                ErrorMessage = errorDetails.Error
            };

            var argList = new List<object>(args);
            argList.Add(errorDetails.Error.SupportMessageText);

            logger.LogError(
                errorDetails.Error.Exception,
                $"{messagePrefix}: {{ErrorMessage}}",
                argList.ToArray()
            );

            return exception;
        }


        /// <summary>
        /// Error message to send when the payload fails to send
        /// </summary>
        /// <param name="ex"></param>
        /// <returns></returns>
        internal static (HttpStatusCode StatusCode, ErrorMessageModel Error) SendFailedErrorMessage(this Exception ex)
            => (
                HttpStatusCode.BadGateway,
                new ErrorMessageModel
                {
                    EventId = InternalConstants.Errors.DefaultSendFailed.EventId,
                    MessageCode = InternalConstants.Errors.DefaultSendFailed.MessageCode,
                    UserMessageText = InternalConstants.Errors.DefaultSendFailed.UserMessageText,
                    Exception = ex,
                    SupportMessageText = ex.Message
                }
            );
    }
}
