﻿using static Microsoft.Azure.ServiceBus.Message;

namespace Library.Azure.ServiceBus
{
    public static class SystemPropertyExtensions
    {
        /// <summary>
        /// Only way to overcome this error happening in unit tests
        /// </summary>
        /// <param name="collection"></param>
        /// <returns></returns>
        public static int ProtectedDeliveryCount(this SystemPropertiesCollection collection)
        {
            try
            {
                return collection.DeliveryCount;
            }
            catch
            {
                return 0;
            }
        }

        /// <summary>
        /// Only way to overcome this error happening in unit tests
        /// </summary>
        /// <param name="collection"></param>
        /// <returns></returns>
        public static string ProtectedLockToken(this SystemPropertiesCollection collection)
        {
            try
            {
                return collection.LockToken;
            }
            catch
            {
                return null;
            }
        }
    }
}
