﻿using Microsoft.Azure.Amqp;
using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Platform.Library.BaseEvent;
using Platform.Library.Common.Telemetry;
using Platform.Library.Extensions;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Mime;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime;
using System.Text;
using System.Text.RegularExpressions;

namespace Platform.Library.Azure.ServiceBus.Extensions
{
    public static class ServiceBusMessageExtension
    {
        private static readonly Regex EndpointRegex = new Regex(
            @"(^|;)Endpoint=(?<endpoint>.*?)(;|$)",
            RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Singleline,
            TimeSpan.FromMilliseconds(500)
        );

        /// <summary>
        /// Convert a <typeparamref name="TEvent"/> into a <see cref="Message"/>
        /// </summary>
        /// <typeparam name="TEvent"></typeparam>
        /// <param name="payload"></param>
        /// <param name="eventName"></param>
        /// <param name="additionalProperties"></param>
        /// <returns></returns>
        public static Message ToServiceBusMessage<TEvent>(this TEvent payload, string eventName = null, IDictionary<string,object> additionalProperties = null)
            where TEvent : Platform.Library.BaseEvent.BaseEvent
        {
            return payload.ToServiceBusMessage<TEvent>((p, m) => p.ExtractEventName(eventName), additionalProperties);
        }

        /// <summary>
        /// Convert a <typeparamref name="TEvent"/> into a <see cref="Message"/>
        /// </summary>
        /// <typeparam name="TEvent"></typeparam>
        /// <param name="payload"></param>
        /// <param name="labelDelegate"></param>
        /// <param name="additionalProperties"></param>
        /// <returns></returns>
        public static Message ToServiceBusMessage<TEvent>(this TEvent payload, Func<TEvent, Message, string> labelDelegate, IDictionary<string,object> additionalProperties = null)
            where TEvent : Platform.Library.BaseEvent.BaseEvent
        {
            // Construct the message
            var result = new Message(Encoding.UTF8.GetBytes(payload.Serialize()))
            {
                CorrelationId = payload.Metadata.RequestId,
                MessageId = payload.Metadata.MessageId,
                ContentType = MediaTypeNames.Application.Json
            };

            // Assign the label if required
            result.Label = labelDelegate.Invoke(payload, result);

            // Add the metadata to user properties
            result.UserProperties.AddMetadata(payload.Metadata);

            // Add any additional properties
            if ( additionalProperties != null )
            {
                foreach (var property in additionalProperties)
                    result.UserProperties.Add(property.Key, property.Value);
            }

            return result;
        }

        internal static DependencyTracer GetDependency(this ILogger logger, ServiceBusSettings settings, string operation, string eventName, string correlationId, string messageId)
        {
            var dependency = new DependencyTracer(logger, "Service Bus", $"{settings.ConnectionString01.GetEndpoint()}--{settings.ConnectionString02.GetEndpoint()}", operation);
            dependency.AddProperty("Message_EventType", eventName);
            dependency.AddProperty("Message_CorrelationId", correlationId);
            dependency.AddProperty("Message_MessageId", messageId);
            return dependency;
        }

        /// <summary>
        /// Extract the <see cref="EventNameAttribute"/> of the item
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="item"></param>
        /// <returns></returns>
        public static EventNameAttribute ExtractEventNameAttribute<T>(this T item)
            => typeof(T).EventNameAttribute();

        /// <summary>
        /// Extract the <see cref="EventNameAttribute"/> from the provided type
        /// </summary>
        /// <param name="itemType"></param>
        /// <returns></returns>
        public static EventNameAttribute EventNameAttribute(this Type itemType)
            => itemType.GetCustomAttribute<EventNameAttribute>();

        /// <summary>
        /// Extract the event name from the event
        /// </summary>
        /// <typeparam name="TEvent"></typeparam>
        /// <param name="payload"></param>
        /// <param name="defaultName"></param>
        /// <returns></returns>
        public static string ExtractEventName<TEvent>(this TEvent payload, string defaultName = null)
            where TEvent : Platform.Library.BaseEvent.BaseEvent
        {
            return payload.ExtractEventNameAttribute()?.Name
                ?? defaultName
                ?? typeof(TEvent).FormattedTypeName();
        }

        /// <summary>
        /// Gets the end point from the connection string
        /// </summary>
        /// <param name="serviceBusConnectionString"></param>
        /// <returns></returns>
        public static string GetEndpoint(this string serviceBusConnectionString)
        {
            if (string.IsNullOrWhiteSpace(serviceBusConnectionString))
            {
                return default;
            }

            var matchGroup = EndpointRegex.Match(serviceBusConnectionString);

            var endpointGroup = matchGroup.Groups["endpoint"];

            return endpointGroup.Success ? endpointGroup.Value : null;
        }
    }
}