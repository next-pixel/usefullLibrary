using Library.Azure.ServiceBus;
using System;

namespace Platform.Library.Azure.ServiceBus.Extensions
{
    /// <summary>
    /// Extension methods for the class <see cref="ProcessMessageContext"/>. This class is used for tracking the state of a message
    /// from the service bus.
    /// </summary>
    public static class ProcessMessageContextExtensions
    {
        /// <summary>
        /// Sets the <see cref="ProcessMessageContext"/> result to <see cref="ProcessMessageResult.PoisonMessageIdentified"/>
        /// and sets the error reason as the provided <see cref="Exception"/> message.
        /// </summary>
        /// <param name="messageContext"></param>
        /// <param name="exception"></param>
        /// <param name="customErrorMessage"></param>
        public static void PoisonMessage<T>(this ProcessMessageContext messageContext, T exception, string customErrorMessage = null) where T : Exception
        {
            messageContext.Result = ProcessMessageResult.PoisonMessageIdentified;
            messageContext.ErrorReason = exception.Message;
            messageContext.ErrorMessage = customErrorMessage ?? $"A {typeof(T).Name} error occurred. Message will be dead lettered.";
        }

        /// <summary>
        /// Sets the <see cref="ProcessMessageContext"/> result to <see cref="ProcessMessageResult.RequiresRetry"/> and
        /// sets the error reason as the provided <see cref="Exception"/> message.
        /// </summary>
        /// <param name="messageContext"></param>
        /// <param name="exception"></param>
        /// <param name="customErrorMessage"></param>
        public static void RetryMessage<T>(this ProcessMessageContext messageContext, T exception, string customErrorMessage = null) where T : Exception
        {
            messageContext.Result = ProcessMessageResult.RequiresRetry;
            messageContext.ErrorReason = exception.Message;
            messageContext.ErrorMessage = customErrorMessage ?? $"A {typeof(T).Name} error occurred. Message will be retried.";
        }
    }
}