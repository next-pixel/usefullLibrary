﻿using Platform.Library.BaseEvent;
using Platform.Library.Common.Standard.Models.Abstractions;
using System;

namespace Platform.Library.Azure.ServiceBus.Extensions
{
    public static class StandardMetadataMapperExtension
    {
        public static Metadata MapMetadata(this IStandardHeaderModel headerModel)
        {
            return new Metadata
            {
                RequestId = headerModel?.RequestId,
                MessageId = Guid.NewGuid().ToString(),
                Timestamp = DateTime.UtcNow,
                SendingSystemId = headerModel?.SendingSystemId,
                SendingSystemVersion = headerModel?.SendingSystemVersion,
                InitiatingSystemId = headerModel?.InitiatingSystemId,
                InitiatingSystemVersion = headerModel?.InitiatingSystemVersion
            };
        }
    }
}
