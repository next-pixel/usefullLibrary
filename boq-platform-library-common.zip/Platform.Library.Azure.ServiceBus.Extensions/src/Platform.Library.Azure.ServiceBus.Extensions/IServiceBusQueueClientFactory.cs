﻿using Library.Azure.ServiceBus;
using System;
using System.Collections.Generic;
using System.Text;

namespace Platform.Library.Azure.ServiceBus.Extensions
{
    /// <summary>
    /// Factory to create service bus queue client
    /// </summary>
    public interface IServiceBusQueueClientFactory
    {
        /// <summary>
        /// Create a new client for the given queue.
        /// The client might be cached and the instance will be recycled.
        /// </summary>
        /// <param name="queueName">The queue name to bind the service bus client</param>
        /// <returns>An instance of <see cref="IServiceBusQueueClient"/> to represent the service bus connection</returns>
        IServiceBusQueueClient GetClient(string queueName);
    }
}
