﻿using Library.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Platform.Library.BaseEvent;
using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.Common.Telemetry;
using Platform.Library.Extensions;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Mime;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Platform.Library.Azure.ServiceBus.Extensions
{
    /// <inheritdoc cref="IServiceBusQueueEventPublisher{TEvent}"/>
    public abstract class ServiceBusQueueEventPublisher<TEvent> : IServiceBusQueueEventPublisher<TEvent>
        where TEvent : Platform.Library.BaseEvent.BaseEvent
    {
        private readonly ILogger _logger;
        private readonly ServiceBusSettings _settings;
        private readonly IServiceBusQueueClient _queueClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceBusQueueEventPublisher{TEvent}"/> class.
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="settings"></param>
        /// <param name="serviceBusQueueClient"></param>
        protected ServiceBusQueueEventPublisher(ILogger logger, ServiceBusSettings settings, IServiceBusQueueClient serviceBusQueueClient) 
        { 
            _logger = logger.GuardNull(nameof(logger));
            _settings = settings.GuardNull(nameof(settings));
            _queueClient = serviceBusQueueClient.GuardNull(nameof(serviceBusQueueClient));
        }

        /// <inheritdoc cref="IServiceBusQueueEventPublisher{TEvent}.PublishEvent(TEvent, CancellationToken)"/>
        public async Task PublishEvent(TEvent payload, CancellationToken cancellationToken)
        {
            await PublishEvent(payload, null, cancellationToken);
        }

        /// <inheritdoc cref="IServiceBusQueueEventPublisher{TEvent}.PublishEvent(TEvent, IDictionary{string,object}, CancellationToken)"/>
        public async Task PublishEvent(TEvent payload, IDictionary<string,object> additionalProperties, CancellationToken cancellationToken)
        {
            using (var dependency = _logger.GetDependency(_settings, nameof(PublishEvent), typeof(TEvent).AsFormattedTypeName(), payload.Metadata.RequestId, payload.Metadata.MessageId))
            {
                var message = payload.ToServiceBusMessage(labelDelegate:CalculateLabel, additionalProperties:additionalProperties);
                EnrichMessage(message);

                try
                {
                    await _queueClient.SendAsync(message);
                    dependency.StopTimer();
                }
                catch ( Exception ex )
                {
                    dependency.StopTimer().Enrich(false, ex.Message, "Failure");
                    throw _logger.LogAndRaiseException(
                        SendFailedErrorMessage(ex), 
                        "{System}.{Method} failed to send {EventName} with message id {MessageId} and label '{Label}'",
                        this.FormattedTypeName(), 
                        nameof(PublishEvent), 
                        typeof(TEvent).AsFormattedTypeName(), 
                        payload.Metadata.MessageId,
                        message.Label
                    );
                }
            }
        }

        /// <summary>
        /// Provide additional enrichment to the generated message
        /// </summary>
        /// <remarks>User properties have already been populated from <see cref="Metadata"/></remarks>
        /// <param name="message">The instance of a message already generated and configured for sending</param>
        protected virtual void EnrichMessage(Microsoft.Azure.ServiceBus.Message message)
        {
            // Override to perform any enrichment not already done by the base
        }


        /// <summary>
        /// Calculate the label to apply to the message
        /// </summary>
        /// <returns></returns>
        protected virtual string CalculateLabel(TEvent payload, Message message) => null;

        /// <summary>
        /// Error message to send when the payload fails to send
        /// </summary>
        /// <param name="ex"></param>
        /// <returns></returns>
        protected virtual (HttpStatusCode StatusCode, ErrorMessageModel Error) SendFailedErrorMessage(Exception ex) => ex.SendFailedErrorMessage();
    }
}
