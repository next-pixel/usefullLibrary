﻿using Microsoft.Azure.ServiceBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Library.Azure.ServiceBus
{
    internal class SubscriptionClientWrapper : ISubscriptionClient
    {
        private SubscriptionClient _subscriptionClient;

        public SubscriptionClientWrapper(SubscriptionClient subscriptionClient)
        {
            _subscriptionClient = subscriptionClient;
        }

        public Task CompleteAsync(string lockToken)
        {
            return _subscriptionClient.CompleteAsync(lockToken);
        }

        public Task DeadLetterAsync(string lockToken, IDictionary<string, object> propertiesToModify)
        {
            return _subscriptionClient.DeadLetterAsync(lockToken, propertiesToModify);
        }

        public Task DeadLetterAsync(string lockToken, string deadLetterReason, string deadLetterErrorDescription = null)
        {
            return _subscriptionClient.DeadLetterAsync(lockToken, deadLetterReason, deadLetterErrorDescription);
        }
    }
}
