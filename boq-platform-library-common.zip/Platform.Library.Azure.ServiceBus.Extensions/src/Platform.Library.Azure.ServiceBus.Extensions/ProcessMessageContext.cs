﻿namespace Library.Azure.ServiceBus
{
    public class ProcessMessageContext
    {
        public ProcessMessageResult? Result { get; set; } = ProcessMessageResult.NoStatusSet;

        public string ErrorMessage { get; set; } = "Business error occured. Message will be dead lettered";

        public string ErrorReason { get; set; } = string.Empty;
    }
}