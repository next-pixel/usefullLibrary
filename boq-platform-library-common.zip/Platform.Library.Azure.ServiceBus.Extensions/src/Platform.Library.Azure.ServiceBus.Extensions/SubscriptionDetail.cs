namespace Library.Azure.ServiceBus
{
    public class SubscriptionDetail
    {
        public string TopicName { get; set; }
        public string SubscriptionName { get; set; }
    }
}
