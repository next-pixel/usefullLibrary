﻿namespace Library.Azure.ServiceBus
{
    public enum ProcessRetrialMessageResult
    {
        SuccessfullyProcessedMessage,
        PoisonMessageIdentified,
        RequiresRetry,
        NoStatusSet,
        RequiresRetryWithClone,
    }
}
