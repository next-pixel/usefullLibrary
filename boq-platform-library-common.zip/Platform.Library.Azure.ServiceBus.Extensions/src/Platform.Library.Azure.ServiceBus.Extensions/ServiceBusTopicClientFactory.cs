﻿using Library.Azure.ServiceBus;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Platform.Library.Azure.ServiceBus.Extensions
{
    /// <inheritdoc cref="IServiceBusTopicClientFactory"/>
    public class ServiceBusTopicClientFactory : IServiceBusTopicClientFactory
    {
        private readonly ServiceBusSettings _serviceBusSettings;
        private readonly ConcurrentDictionary<string, IServiceBusTopicClient> _topicClientCache = new ConcurrentDictionary<string, IServiceBusTopicClient>();

        /// <summary>
        /// Default constructor to create an instance of the factory giving the settings
        /// </summary>
        /// <param name="serviceBusSettings">An instance of <see cref="IOptions{ServiceBusPublisherSettings}"/> with the service bus configuration</param>
        [ActivatorUtilitiesConstructor]
        public ServiceBusTopicClientFactory(IOptions<ServiceBusSettings> serviceBusSettings)
        {
            _serviceBusSettings = serviceBusSettings.GuardNull(nameof(serviceBusSettings));

            if (string.IsNullOrWhiteSpace(_serviceBusSettings.ConnectionString01))
                throw new ArgumentNullException(nameof(ServiceBusSettings.ConnectionString01), $"{nameof(ServiceBusSettings)} did not provide a value for {nameof(ServiceBusSettings.ConnectionString01)}");

            if (string.IsNullOrWhiteSpace(_serviceBusSettings.ConnectionString02))
                throw new ArgumentNullException(nameof(ServiceBusSettings.ConnectionString02), $"{nameof(ServiceBusSettings)} did not provide a value for {nameof(ServiceBusSettings.ConnectionString02)}");
        }

        /// <summary>
        /// Get the collection of Connection strings
        /// </summary>
        /// <returns></returns>
        protected internal IEnumerable<string> GetConnectionStrings() => new[] { _serviceBusSettings.ConnectionString01 , _serviceBusSettings.ConnectionString02 };

        /// <summary>
        /// Used to support mocking for unit testing
        /// </summary>
        /// <param name="topicName"></param>
        /// <returns></returns>
        [ExcludeFromCodeCoverage()]
        protected virtual IServiceBusTopicClient GenerateTopicClient(string topicName) => new ServiceBusTopicClient(GetConnectionStrings(), topicName);

        /// <summary>
        /// Try to get the client if it was created
        /// </summary>
        /// <param name="topicName"></param>
        /// <param name="topicClient"></param>
        /// <returns></returns>
        protected bool TryGetClient(string topicName, out IServiceBusTopicClient topicClient)
        {
            return _topicClientCache.TryGetValue(topicName, out topicClient);
        }

        /// <inheritdoc cref="IServiceBusTopicClientFactory.GetClient"/>
        public IServiceBusTopicClient GetClient(string topicName)
        {
            return _topicClientCache.GetOrAdd(topicName, key => GenerateTopicClient(key));
        }
    }
}
