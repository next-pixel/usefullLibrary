﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]
[assembly: InternalsVisibleTo("BehaviourSpecs")]

namespace Platform.Library.Azure.ServiceBus.Extensions
{
    internal static class InternalConstants
    {
        internal static class Configuration
        {
            internal static class Sections
            {
                internal const string ServiceBus = nameof(ServiceBus);
            }
        }

        internal static class Errors
        {
            internal static class DefaultSendFailed
            {
                internal const int EventId = 9999;
                internal const string MessageCode = "NPPDEG0001";
                internal const string UserMessageText = "Publishing to Service Bus Failed";
            }
        }
    }
}
