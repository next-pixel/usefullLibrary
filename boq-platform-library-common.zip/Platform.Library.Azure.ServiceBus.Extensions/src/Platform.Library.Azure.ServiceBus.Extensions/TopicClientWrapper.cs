﻿using Microsoft.Azure.ServiceBus;
using System.Threading.Tasks;

namespace Library.Azure.ServiceBus
{
    internal class TopicClientWrapper : ITopicClient
    {
        private TopicClient _topicClient;

        public TopicClientWrapper(TopicClient topicClient)
        {
            _topicClient = topicClient;
        }

        public async Task SendAsync(Message deferTriggerMessage)
        {
            await _topicClient.SendAsync(deferTriggerMessage);
        }
    }
}
