﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Azure.ServiceBus;

namespace Library.Azure.ServiceBus
{
    public interface IServiceBusQueueClient
    {
        IEnumerable<string> ConnectionStrings { get; }
        string Path { get; }

        void RandomiseClients();
        Task SendAsync(Message message);
    }
}
