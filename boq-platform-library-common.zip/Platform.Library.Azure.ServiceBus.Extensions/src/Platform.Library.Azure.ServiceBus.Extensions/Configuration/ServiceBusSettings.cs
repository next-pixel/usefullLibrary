﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Platform.Library.Azure.ServiceBus.Extensions
{
    /// <summary>
    /// Default settings class for service bus configuration
    /// </summary>
    /// <rename>To be mapped to the "ServiceBus:" section in configuration</rename>
    public class ServiceBusSettings
    {
        /// <summary>
        /// Connection string for 1st region
        /// </summary>
        public string ConnectionString01 { get; set; }

        /// <summary>
        /// Connection string for 2nd region etc
        /// </summary>
        public string ConnectionString02 { get; set; }

        /// <summary>
        /// Topics that have been defined
        /// </summary>
        public CaseInsensitiveDictionary<string> Topics { get; set; }

        /// <summary>
        /// Queues that have been defined
        /// </summary>
        public CaseInsensitiveDictionary<string> Queues { get; set; }
    }
}
