﻿namespace Platform.Library.Azure.ServiceBus.Extensions.Configuration
{
    public class QueueMessageRetryPolicySettings
    {
        public int MessageTimeToLiveMinutes { get; set; }
        public int MessageRetryIntervalMinutes { get; set; }
    }
}
