﻿using System;
using Microsoft.Azure.WebJobs.ServiceBus;

namespace Platform.Library.Azure.ServiceBus.Extensions.Configuration
{
    /// <summary>
    /// Extension methods for <see cref="ServiceBusOptions"/>
    /// </summary>
    public static class ServiceBusOptionsBuilder
    {
        /// <summary>
        /// Obsolete method for setting <see cref="ServiceBusOptions"/> configuration values
        /// </summary>
        /// <remarks>
        /// This service bus options builder is only compatible with Microsoft.Azure.WebJobs.ServiceBus
        /// version 4.x.x. Hence, upgrading to version 5.x.x will be incompatible with this method as it has a model change.
        /// </remarks>
        /// <param name="options"></param>
        [Obsolete("Please switch to using the .Configure extension method", true)]
        public static void Build(ServiceBusOptions options)
        {
            throw new NotSupportedException("Please switch to using the .Configure extension method");
            //options.MessageHandlerOptions.AutoComplete = false;
            //options.PrefetchCount = 0;
            //options.MessageHandlerOptions.MaxConcurrentCalls = 16;
            //options.MessageHandlerOptions.MaxAutoRenewDuration = TimeSpan.FromSeconds(10);
        }

        /// <summary>
        /// Configure the <see cref="ServiceBusOptions"/> to default or preset values
        /// </summary>
        /// <param name="options"></param>
        /// <param name="autoComplete"></param>
        /// <param name="prefetchCount"></param>
        /// <param name="maxConcurrentCalls"></param>
        /// <param name="maxAutoRenewDurationSeconds"></param>
        public static void Configure(this ServiceBusOptions options, bool autoComplete = false, int prefetchCount = 0, int maxConcurrentCalls = 16, int maxAutoRenewDurationSeconds = 10)
        {
            options.MessageHandlerOptions.AutoComplete = autoComplete;
            options.PrefetchCount = prefetchCount;
            options.MessageHandlerOptions.MaxConcurrentCalls = maxConcurrentCalls;
            options.MessageHandlerOptions.MaxAutoRenewDuration = TimeSpan.FromSeconds(maxAutoRenewDurationSeconds);
        }
    }
}
