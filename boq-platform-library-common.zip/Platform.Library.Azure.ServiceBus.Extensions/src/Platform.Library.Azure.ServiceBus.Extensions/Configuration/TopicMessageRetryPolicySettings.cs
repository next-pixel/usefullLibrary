﻿namespace Platform.Library.Azure.ServiceBus.Extensions.Configuration
{
    public class TopicMessageRetryPolicySettings
    {
        public int MessageDelayBeforeAbandonSeconds { get; set; }
    }
}
