﻿namespace Library.Azure.ServiceBus
{
    public class ProcessRetrialMessageContext
    {
        public ProcessRetrialMessageResult? Result { get; set; } = ProcessRetrialMessageResult.NoStatusSet;

        public string ErrorMessage { get; set; } = "Business error occured. Message will be dead lettered";

        public string ErrorReason { get; set; } = string.Empty;
    }
}