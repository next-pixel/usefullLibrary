﻿using Library.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus;
using System;

namespace Platform.Library.Azure.ServiceBus.Extensions
{
    public static class MessageUtility
    {
        public static TimeSpan ExponentialBackoff(Message message, int maxDelayInSeconds)
        {
            return ExponentialBackoff(message.SystemProperties.ProtectedDeliveryCount(), maxDelayInSeconds);
        }

        public static TimeSpan ExponentialBackoff(Message message, TimeSpan maxDelay)
        {
            return ExponentialBackoff(message, (int)maxDelay.TotalSeconds);
        }

        public static TimeSpan ExponentialBackoff(int deliveryCount, TimeSpan maxDelay)
        {
            return ExponentialBackoff(deliveryCount, (int)maxDelay.TotalSeconds);
        }

        public static TimeSpan ExponentialBackoff(int deliveryCount, int maxDelayInSeconds)
        {
            return TimeSpan.FromSeconds(ExponentialDelay(deliveryCount, maxDelayInSeconds));
        }

        private static int ExponentialDelay(int failedAttempts, int maxDelayInSeconds)
        {
            // Attempt:01    Delay:00D 00H 00M 00.333S    AccumulatedDelay:00D 00H 00M 00.333S
            // Attempt:02    Delay:00D 00H 00M 01.000S    AccumulatedDelay:00D 00H 00M 01.333S
            // Attempt:03    Delay:00D 00H 00M 02.333S    AccumulatedDelay:00D 00H 00M 03.667S
            // Attempt:04    Delay:00D 00H 00M 05.000S    AccumulatedDelay:00D 00H 00M 08.667S
            // Attempt:05    Delay:00D 00H 00M 10.333S    AccumulatedDelay:00D 00H 00M 19.000S
            // Attempt:06    Delay:00D 00H 00M 21.000S    AccumulatedDelay:00D 00H 00M 40.000S
            // Attempt:07    Delay:00D 00H 00M 42.333S    AccumulatedDelay:00D 00H 01M 22.333S
            // Attempt:08    Delay:00D 00H 01M 25.000S    AccumulatedDelay:00D 00H 02M 47.333S
            // Attempt:09    Delay:00D 00H 02M 50.333S    AccumulatedDelay:00D 00H 05M 37.667S
            // Attempt:10    Delay:00D 00H 05M 41.000S    AccumulatedDelay:00D 00H 11M 18.667S
            // Attempt:11    Delay:00D 00H 11M 22.333S    AccumulatedDelay:00D 00H 22M 41.000S
            // Attempt:12    Delay:00D 00H 22M 45.000S    AccumulatedDelay:00D 00H 45M 26.000S
            // Attempt:13    Delay:00D 00H 45M 30.333S    AccumulatedDelay:00D 01H 30M 56.333S
            // Attempt:14    Delay:00D 01H 31M 01.000S    AccumulatedDelay:00D 03H 01M 57.333S
            // Attempt:15    Delay:00D 03H 02M 02.333S    AccumulatedDelay:00D 06H 03M 59.667S
            // Attempt:16    Delay:00D 06H 04M 05.000S    AccumulatedDelay:00D 12H 08M 04.667S
            // Attempt:17    Delay:00D 12H 08M 10.333S    AccumulatedDelay:01D 00H 16M 15.000S
            // Attempt:18    Delay:01D 00H 16M 21.000S    AccumulatedDelay:02D 00H 32M 36.000S
            // Attempt:19    Delay:02D 00H 32M 42.333S    AccumulatedDelay:04D 01H 05M 18.333S
            // Attempt:20    Delay:04D 01H 05M 25.000S    AccumulatedDelay:08D 02H 10M 43.333S

            var delayInSeconds = Convert.ToInt32(((1d / 2d) * (Math.Pow(2d, failedAttempts) - 1d)));

            if (delayInSeconds < 10)
            {
                return 10;
            }
            else if (delayInSeconds > maxDelayInSeconds)
            {
                return maxDelayInSeconds;
            }
            else
            {
                return delayInSeconds;
            }
        }
    }
}
