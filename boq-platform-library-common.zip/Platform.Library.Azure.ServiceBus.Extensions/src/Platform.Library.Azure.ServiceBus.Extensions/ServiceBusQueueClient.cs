﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Azure.ServiceBus;

namespace Library.Azure.ServiceBus
{
    public class ServiceBusQueueClient : IServiceBusQueueClient
    {
        private object _lock = new object();
        private QueueClientInstances[] _clients;
        private CancellationTokenSource _cancellationTokenSource;

        public ServiceBusQueueClient(IEnumerable<string> connectionStrings, string path, bool randomiseClientsOnStartup = true, int failoverAfterSuccessiveFailures = 2)
        {
            Path = path;
            ConnectionStrings = connectionStrings;
            RandomiseClientsOnStartup = randomiseClientsOnStartup;
            FailoverAfterSuccessiveFailures = failoverAfterSuccessiveFailures;
        }

        public IEnumerable<string> ConnectionStrings { get; private set; }

        public string Path { get; private set; }

        public bool RandomiseClientsOnStartup { get; private set; }

        public int FailoverAfterSuccessiveFailures { get; private set; }

        public async Task SendAsync(Message message)
        {
            var exceptions = new List<Exception>();

            foreach (var client in Clients)
            {
                try
                {
                    await client.QueueClient.SendAsync(message);
                    client.SuccessiveFailures = 0;
                    return;
                }
                catch (Exception ex)
                {
                    exceptions.Add(ex);
                    ++client.SuccessiveFailures;
                    message = message.Clone();
                }
            }

            throw new AggregateException("Failed to send the service bus messages", exceptions);
        }

        public void RandomiseClients()
        {
            _clients = Randomise(Clients);
        }

        private QueueClientInstances[] Clients
        {
            get
            {
                if (_clients == null)
                {
                    lock (_lock)
                    {
                        if (_clients == null)
                        {
                            var clients = new List<QueueClientInstances>();

                            foreach (var c in ConnectionStrings)
                            {
                                var client = new QueueClient(c, Path);

                                clients.Add(new QueueClientInstances
                                {
                                    QueueClient = client,
                                    SuccessiveFailures = 0,
                                    ConnectionString = c,
                                });
                            }

                            if (RandomiseClientsOnStartup)
                            {
                                clients = Randomise(clients.ToArray()).ToList();
                            }

                            _clients = clients.ToArray();
                        }
                    }
                }

                if (_clients.Any(x => x.SuccessiveFailures >= FailoverAfterSuccessiveFailures))
                {
                    lock (_clients)
                    {
                        var failedClients = _clients.WhereNullSafe(x => x.SuccessiveFailures >= FailoverAfterSuccessiveFailures).ToList();
                        if (failedClients.Any())
                        {
                            _cancellationTokenSource = new CancellationTokenSource();

                            foreach (var failedClient in failedClients)
                            {
                                ThreadPool.QueueUserWorkItem(RetryFailedClient, failedClient);
                            }

                            _clients = _clients.OrderBy(x => x.SuccessiveFailures).ToArray();
                            _clients.ForEachNullSafe(x => x.SuccessiveFailures = 0);
                        }
                    }
                }

                return _clients;
            }
        }

        private void RetryFailedClient(object state)
        {
            _cancellationTokenSource.Token.WaitHandle.WaitOne(TimeSpan.FromMinutes(10));

            var failedClient = (QueueClientInstances)state;
            failedClient.QueueClient = new QueueClient(failedClient.ConnectionString, Path);

            try
            {
                // await failedClient.TopicClient.PeekAsync();
                lock (_clients)
                {
                    _clients = _clients.MoveToFirst(failedClient, x => x.ConnectionString == failedClient.ConnectionString).ToArray();
                }
            }
            catch
            {
                //try again later
                ThreadPool.QueueUserWorkItem(RetryFailedClient, failedClient);
            }
        }

        private QueueClientInstances[] Randomise(QueueClientInstances[] queueClient)
        {
            return queueClient.OrderBy(x => Guid.NewGuid()).ToArray();
        }
    }
}
