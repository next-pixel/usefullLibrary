using Microsoft.Azure.ServiceBus;

namespace Library.Azure.ServiceBus
{
    public class TopicClientInstances
    {
        public Microsoft.Azure.ServiceBus.ITopicClient TopicClient { get; set; }

        public int SuccessiveFailures { get; set; }
        public string ConnectionString { get; set; }
    }
}
