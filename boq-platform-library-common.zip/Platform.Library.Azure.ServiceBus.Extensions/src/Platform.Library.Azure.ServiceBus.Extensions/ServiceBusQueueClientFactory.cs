﻿using Library.Azure.ServiceBus;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Platform.Library.Azure.ServiceBus.Extensions
{
    /// <inheritdoc cref="IServiceBusQueueClientFactory"/>
    public class ServiceBusQueueClientFactory : IServiceBusQueueClientFactory
    {
        private readonly ServiceBusSettings _serviceBusSettings;
        private readonly ConcurrentDictionary<string, IServiceBusQueueClient> _queueClientCache = new ConcurrentDictionary<string, IServiceBusQueueClient>();

        /// <summary>
        /// Default constructor to create an instance of the factory giving the settings
        /// </summary>
        /// <param name="serviceBusSettings">An instance of <see cref="IOptions{ServiceBusPublisherSettings}"/> with the service bus configuration</param>
        [ActivatorUtilitiesConstructor]
        public ServiceBusQueueClientFactory(IOptions<ServiceBusSettings> serviceBusSettings)
        {
            _serviceBusSettings = serviceBusSettings.GuardNull(nameof(serviceBusSettings));

            if (string.IsNullOrWhiteSpace(_serviceBusSettings.ConnectionString01))
                throw new ArgumentNullException(nameof(ServiceBusSettings.ConnectionString01), $"{nameof(ServiceBusSettings)} did not provide a value for {nameof(ServiceBusSettings.ConnectionString01)}");

            if (string.IsNullOrWhiteSpace(_serviceBusSettings.ConnectionString02))
                throw new ArgumentNullException(nameof(ServiceBusSettings.ConnectionString02), $"{nameof(ServiceBusSettings)} did not provide a value for {nameof(ServiceBusSettings.ConnectionString02)}");
        }

        /// <summary>
        /// Get the collection of Connection strings
        /// </summary>
        /// <returns></returns>
        protected internal IEnumerable<string> GetConnectionStrings() => new[] { _serviceBusSettings.ConnectionString01 , _serviceBusSettings.ConnectionString02 };

        /// <summary>
        /// Used to support mocking for unit testing
        /// </summary>
        /// <param name="queueName"></param>
        /// <returns></returns>
        [ExcludeFromCodeCoverage()]
        protected virtual IServiceBusQueueClient GenerateQueueClient(string queueName) => new ServiceBusQueueClient(GetConnectionStrings(), queueName);

        /// <summary>
        /// Try to get the client if it was created
        /// </summary>
        /// <param name="queueName"></param>
        /// <param name="queueClient"></param>
        /// <returns></returns>
        protected bool TryGetClient(string queueName, out IServiceBusQueueClient queueClient)
        {
            return _queueClientCache.TryGetValue(queueName, out queueClient);
        }

        /// <inheritdoc cref="IServiceBusQueueClientFactory.GetClient"/>
        public IServiceBusQueueClient GetClient(string queueName)
        {
            return _queueClientCache.GetOrAdd(queueName, key => GenerateQueueClient(key));
        }
    }
}
