﻿using System;

namespace Platform.Library.Azure.ServiceBus.Extensions.Models
{
    public class MessageDeserializationException : UnrecoverableMessageException
    {
        public MessageDeserializationException(string errorMessage, Exception innerException) : base(errorMessage, innerException)
        {
        }
    }
}
