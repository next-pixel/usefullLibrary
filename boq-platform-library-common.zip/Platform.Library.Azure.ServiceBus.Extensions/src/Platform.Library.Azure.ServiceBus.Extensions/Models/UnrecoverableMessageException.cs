﻿using System;

namespace Platform.Library.Azure.ServiceBus.Extensions.Models
{
    public class UnrecoverableMessageException : Exception
    {
        public UnrecoverableMessageException(string errorMessage, Exception innerException) : base(errorMessage, innerException)
        {
        }
    }
}
