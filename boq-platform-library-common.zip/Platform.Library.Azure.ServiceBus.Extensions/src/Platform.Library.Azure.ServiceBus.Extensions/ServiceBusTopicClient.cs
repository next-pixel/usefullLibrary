using Microsoft.Azure.ServiceBus;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Library.Azure.ServiceBus
{
    [ExcludeFromCodeCoverage]
    public class ServiceBusTopicClient : IServiceBusTopicClient
    {
        private object _lock = new object();
        private TopicClientInstances[] _clients;
        private CancellationTokenSource _cancellationTokenSource;

        public ServiceBusTopicClient(IEnumerable<string> connectionStrings, string topicPath, bool randomiseClientsOnStartup = true, int failoverAfterSuccessiveFailures = 2)
        {
            TopicPath = topicPath;
            ConnectionStrings = connectionStrings;
            RandomiseClientsOnStartup = randomiseClientsOnStartup;
            FailoverAfterSuccessiveFailures = failoverAfterSuccessiveFailures;
        }

        public IEnumerable<string> ConnectionStrings { get; private set; }

        public string TopicPath { get; private set; }

        public bool RandomiseClientsOnStartup { get; private set; }

        public int FailoverAfterSuccessiveFailures { get; private set; }

        public async Task SendAsync(Message message)
        {
            var exceptions = new List<Exception>();

            foreach (var client in Clients)
            {
                try
                {
                    await client.TopicClient.SendAsync(message);
                    client.SuccessiveFailures = 0;
                    return;
                }
                catch (Exception ex)
                {
                    exceptions.Add(ex);
                    ++client.SuccessiveFailures;
                    message = message.Clone();
                }
            }

            throw new AggregateException("Failed to send the service bus messages", exceptions);
        } 

        public void RandomiseClients()
        {
            _clients = Randomise(Clients);
        }

        private TopicClientInstances[] Clients
        {
            get
            {
                if (_clients == null)
                {
                    lock (_lock)
                    {
                        if (_clients == null)
                        {
                            var clients = new List<TopicClientInstances>();

                            foreach (var c in ConnectionStrings)
                            {
                                var client = new TopicClient(c, TopicPath);

                                clients.Add(new TopicClientInstances
                                {
                                    TopicClient = client,
                                    SuccessiveFailures = 0,
                                    ConnectionString = c,
                                });
                            }

                            if (RandomiseClientsOnStartup)
                            {
                                clients = Randomise(clients.ToArray()).ToList();
                            }

                            _clients = clients.ToArray();
                        }
                    }
                }

                if (_clients.Any(x => x.SuccessiveFailures >= FailoverAfterSuccessiveFailures))
                {
                    lock (_clients)
                    {
                        var failedClients = _clients.WhereNullSafe(x => x.SuccessiveFailures >= FailoverAfterSuccessiveFailures).ToList();
                        if (failedClients.Any())
                        {
                            _cancellationTokenSource = new CancellationTokenSource();

                            foreach (var failedClient in failedClients)
                            {
                                ThreadPool.QueueUserWorkItem(RetryFailedClient, failedClient);
                            }

                            _clients = _clients.OrderBy(x => x.SuccessiveFailures).ToArray();
                            _clients.ForEachNullSafe(x => x.SuccessiveFailures = 0);
                        }
                    }
                }

                return _clients;
            }
        }

        private void RetryFailedClient(object state)
        {
            _cancellationTokenSource.Token.WaitHandle.WaitOne(TimeSpan.FromMinutes(10));

            var failedClient = (TopicClientInstances)state;
            failedClient.TopicClient = new TopicClient(failedClient.ConnectionString, TopicPath);

            try
            {
                //await failedClient.TopicClient.PeekAsync();
                lock (_clients)
                {
                    _clients = _clients.MoveToFirst(failedClient, x => x.ConnectionString == failedClient.ConnectionString).ToArray();
                }
            }
            catch
            {
                //try again later
                ThreadPool.QueueUserWorkItem(RetryFailedClient, failedClient);
            }
        }

        private TopicClientInstances[] Randomise(TopicClientInstances[] topicClient)
        {
            return topicClient.OrderBy(x => Guid.NewGuid()).ToArray();
        }
    }
}
