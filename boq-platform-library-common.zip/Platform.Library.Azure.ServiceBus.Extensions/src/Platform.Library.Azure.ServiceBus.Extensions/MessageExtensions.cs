using Microsoft.Azure.ServiceBus;
using Platform.Library.Azure.ServiceBus.Extensions.Models;
using System;
using System.Text;

namespace Library.Azure.ServiceBus
{
    public static class MessageExtensions
    {
        public static object GetUserPropertyNullSafe(this Message message, string key)
        {
            if (message.UserProperties != null)
            {
                if (message.UserProperties.ContainsKey(key))
                {
                    return message.UserProperties[key];
                }
            }

            return null;
        }

        public static string GetBodyAsString(this Message message)
        {
            return Encoding.UTF8.GetString(message.Body);
        }

        public static T GetBodyFromJson<T>(this Message message)
        {
            try
            {
                var body = message.GetBodyAsString();
                return body.Deserialize<T>();
            }
            catch (Exception ex)
            {
                throw new MessageDeserializationException("Unable to deserialize message", ex);
            }
        }

        public static T GetStringBodyFromJson<T>(this Message message)
        {
            var body = message.GetBodyAsString();
            return body.Deserialize<T>();
        }

        public static Message Clone(this Message originalMessage, string body)
        {
            var newmessage = new Message(Encoding.UTF8.GetBytes(body))
            {
                ContentType = originalMessage.ContentType,
                CorrelationId = originalMessage.CorrelationId,
                Label = originalMessage.Label,
                MessageId = originalMessage.MessageId,
                PartitionKey = originalMessage.PartitionKey,
                ReplyTo = originalMessage.ReplyTo,
                ReplyToSessionId = originalMessage.ReplyToSessionId,
                SessionId = originalMessage.SessionId,
                To = originalMessage.To,
                ViaPartitionKey = originalMessage.ViaPartitionKey
            };

            if (originalMessage.UserProperties != null)
            {
                foreach (var property in originalMessage.UserProperties)
                {
                    if (property.Key != "DeadLetterReason" && property.Key != "DeadLetterErrorDescription")
                    {
                        newmessage.UserProperties.Add(property.Key, property.Value);
                    }
                }
            }

            return newmessage;
        }

        public static T GetPropertyNullSafe<T>(this Message message, string property)
        {
            return message.GetUserProperty<T>(property);
        }

        public static T GetUserProperty<T>(this Message message, string property)
        {
            var propertyValue = message.GetUserPropertyNullSafe(property);

            if (propertyValue != null)
            {
                if (propertyValue is T)
                {
                    return (T)propertyValue;
                }
                else
                {
                    return (T)Convert.ChangeType(propertyValue, typeof(T));
                }
            }

            return default(T);
        }
    }
}