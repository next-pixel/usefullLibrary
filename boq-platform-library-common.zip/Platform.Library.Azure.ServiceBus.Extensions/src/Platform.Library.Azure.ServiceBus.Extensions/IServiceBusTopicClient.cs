using Microsoft.Azure.ServiceBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Library.Azure.ServiceBus
{
    public interface IServiceBusTopicClient
    {
        IEnumerable<string> ConnectionStrings { get; }
        string TopicPath { get; }

        void RandomiseClients();
        Task SendAsync(Message message);
    }
}
