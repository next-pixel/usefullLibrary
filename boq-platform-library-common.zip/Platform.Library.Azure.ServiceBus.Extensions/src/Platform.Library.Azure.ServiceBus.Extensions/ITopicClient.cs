﻿using Microsoft.Azure.ServiceBus;
using System.Threading.Tasks;

namespace Library.Azure.ServiceBus
{
    internal interface ITopicClient
    {
        Task SendAsync(Message deferTriggerMessage);
    }
}
