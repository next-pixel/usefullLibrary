using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using System.Threading;
using System.Threading.Tasks;

namespace Library.Azure.ServiceBus
{
    public interface IMessageHandler<T> where T : class
    {
        Task ProcessMessageAsync(
            Message message,
            IMessageReceiver messageReciever,
            ILogger logger,
            CancellationToken token,
            IConfigurationRefresher refresher = null);
    }
}