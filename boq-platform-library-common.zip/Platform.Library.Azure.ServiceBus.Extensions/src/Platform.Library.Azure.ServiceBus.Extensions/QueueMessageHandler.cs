﻿using Library.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using Platform.Library.Azure.ServiceBus.Extensions.Configuration;
using Platform.Library.Azure.ServiceBus.Extensions.Models;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Platform.Library.Azure.ServiceBus.Extensions
{
    public class QueueMessageHandler<T> : IMessageHandler<T> where T : class
    {
        private readonly QueueMessageRetryPolicySettings _config;

        public QueueMessageHandler(QueueMessageRetryPolicySettings config)
        {
            _config = config;
        }

        public async Task ProcessMessageAsync(
            Message message, 
            IMessageReceiver messageReceiver, 
            ILogger logger, 
            CancellationToken token, 
            IConfigurationRefresher refresher = null)
        {
            if (refresher != null)
                await refresher.TryRefreshAsync();

            var result = new ProcessRetrialMessageContext();
            try
            {
                logger.LogInformation($"{GetType().FullName} received Message with MessageId '{message.MessageId}' Delivery Count: {message.SystemProperties.ProtectedDeliveryCount()}");

                var deserializedPayload = DeserializeMessage(message, logger);

                await ActionPayload(deserializedPayload, result, logger, token);

                if (result.Result == ProcessRetrialMessageResult.NoStatusSet)
                {
                    result.Result = ProcessRetrialMessageResult.SuccessfullyProcessedMessage;
                }
            }
            catch (UnrecoverableMessageException ex)
            {
                result.Result = ProcessRetrialMessageResult.PoisonMessageIdentified;

                if (ex is MessageDeserializationException)
                {
                    result.ErrorMessage = "Error deserializing the message.";
                    result.ErrorReason = ex.InnerException.Message;
                }
            }
            catch (Exception ex) when (!(ex is UnrecoverableMessageException))
            {
                // Consume the exception without completing or abandoning the message
                // so that the peak lock times out and the message is available to be processed again
                logger.LogError($"{GetType().FullName}: exception processing Message with MessageId '{message.MessageId}'", ex);
                result.Result = ProcessRetrialMessageResult.RequiresRetry;
            }

            if (result.Result != null)
            {
                switch (result.Result)
                {
                    case ProcessRetrialMessageResult.PoisonMessageIdentified:
                        logger.LogInformation(
                            "{assembly}: Dead-lettering Message with MessageId {message}. Failure Message: {messageContent} Reason: {reason}",
                            GetType().FullName,
                            message.MessageId,
                            result.ErrorMessage,
                            result.ErrorReason);

                        await this.DeadLetterAsync(
                            message,
                            messageReceiver,
                            logger,
                            result.ErrorMessage,
                            result.ErrorReason);
                        break;

                    case ProcessRetrialMessageResult.SuccessfullyProcessedMessage:
                        // Do nothing as the message is already completed
                        logger.LogInformation($"{GetType().FullName}: Successfully processed Message with MessageId '{message.MessageId}'");
                        await messageReceiver.CompleteAsync(message.SystemProperties.ProtectedLockToken());
                        break;

                    case ProcessRetrialMessageResult.RequiresRetry:
                        // Do nothing and let PeekLock time itself out.
                        // Once retries are exhausted, the message should automatically move to Deadletter.
                        logger.LogWarning(
                            "{assembly}: Will retry Message with MessageId {message}. Failure Message: {messageContent} Reason: {reason}",
                            GetType().FullName,
                            message.MessageId,
                            result.ErrorMessage,
                            result.ErrorReason);

                        break;
                    case ProcessRetrialMessageResult.RequiresRetryWithClone:
                        // Clone and Enqueue, the message once pass the safe time msg will dql.

                        logger.LogWarning(
                            "Will reenque Message with MessageId {message}. Failure Message: {messageContent} .Reason: {reason}",
                            message.MessageId,
                            result.ErrorMessage,
                            result.ErrorReason);

                        await RetryByCloningMsg(message, messageReceiver, logger);
                        break;
                }
            }
        }
        protected virtual T DeserializeMessage(Message message, ILogger logger)
        {
            if (typeof(T) == typeof(Message))
            {
                return message as T;
            }

            var deserializedObject = MessageExtensions.GetBodyFromJson<T>(message);

            logger.LogDebug($"{GetType().FullName} deserialized Message with MessageId '{message.MessageId}'");
            return deserializedObject;
        }

        protected virtual async Task DeadLetterAsync(
          Message message,
          IMessageReceiver messageReceiver,
          ILogger logger,
          string deadLetterReason,
          string deadLetterErrorDescription)
        {
            await PreProcessDeadlettering(message, logger);
            await messageReceiver.DeadLetterAsync(message.SystemProperties.ProtectedLockToken(), deadLetterReason, deadLetterErrorDescription);
        }


        protected virtual Task ActionPayload(T payload, ProcessRetrialMessageContext context, ILogger logger, CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }

        protected virtual Task PreProcessDeadlettering(Message message, ILogger logger)
        {
            return Task.CompletedTask;
        }

        private async Task RetryByCloningMsg(Message message, IMessageReceiver messageReceiver, ILogger logger)
        {

            var msgIntent = message.GetUserProperty<string>("MessageIntent");
            var currentDateTime = DateTime.UtcNow;
            DateTime originalDeliveryTime;

            if (!string.IsNullOrEmpty(msgIntent) && msgIntent.Equals("Retrial"))
            {
                //If messgae is cloned copy
                var originalDeliveryTimeStr = message.GetUserProperty<string>("OriginalDeliveryTimestampUtc");
                originalDeliveryTime = DateTime.Parse(originalDeliveryTimeStr);

                if ((currentDateTime - originalDeliveryTime).Minutes > _config.MessageTimeToLiveMinutes)
                {
                    var errMsg = $"MessageId {message.MessageId} will be dlq.";
                    var errReason = "Message cannot be enque anymore as has reach maximum safe-limit time."; 
                    logger.LogError(errReason);
                    logger.LogInformation("Deadlettering Message with MessageId -{message.MessageId}", message.MessageId);
                    await this.DeadLetterAsync(message, messageReceiver, logger, errMsg, errReason);
                    return;
                }
                else
                {
                    await CloneMessageaAndSend(message, messageReceiver, logger);
                }
            }
            else
            {
                //if message is original
                originalDeliveryTime = message.ExpiresAtUtc.AddTicks(-(message.TimeToLive.Ticks));
                await CloneMessageaAndSend(message, messageReceiver, logger, originalDeliveryTime);
            }
        }

        private async Task CloneMessageaAndSend(Message message, IMessageReceiver messageReceiver, ILogger logger, DateTime? originalDeliveryTime = null)
        {
            var queueClient = GetQueueClient(messageReceiver.Path, messageReceiver);
            //copy the expiry time from original to clone if not having that
            var cloneMessage = message.Clone();

            if (originalDeliveryTime.HasValue)
            {
                //Cloned From original message require this property to be added when message is enqueud
                cloneMessage.UserProperties.Add("MessageIntent", "Retrial");
                cloneMessage.UserProperties.Add("OriginalDeliveryTimestampUtc", originalDeliveryTime.Value);
            }
            logger.LogInformation("Retry Message - MessageId {messageId} after {minutes} mins", message.MessageId, _config.MessageRetryIntervalMinutes);

            await queueClient.ScheduleMessageAsync(cloneMessage, DateTime.UtcNow.AddMinutes(_config.MessageRetryIntervalMinutes));
            await messageReceiver.CompleteAsync(message.SystemProperties.ProtectedLockToken());
        }

        private IQueueClient GetQueueClient(string queueName, IMessageReceiver messageReceiver)
        {
            return new QueueClient(messageReceiver.ServiceBusConnection, queueName, ReceiveMode.PeekLock, RetryPolicy.Default);
        }

    }
}
