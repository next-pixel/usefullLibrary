﻿using Microsoft.Azure.ServiceBus;
using System.Threading.Tasks;

namespace Library.Azure.ServiceBus
{
    internal interface ISubscriptionClient
    {
        Task CompleteAsync(string lockToken);
        Task DeadLetterAsync(string lockToken, System.Collections.Generic.IDictionary<string, object> propertiesToModify);
        Task DeadLetterAsync(string lockToken, string deadLetterReason, string deadLetterErrorDescription = null);
    }
}
