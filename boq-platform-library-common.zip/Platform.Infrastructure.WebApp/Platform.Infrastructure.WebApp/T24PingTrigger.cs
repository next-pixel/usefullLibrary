﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Platform.Infrastructure.WebApp
{
    public class T24PingTrigger
    {
        [FunctionName("T24PingTimer")]
        public static async Task Run([TimerTrigger("0 */5 * * * *")]TimerInfo myTimer, ILogger log)
        {
            log.LogInformation($"T24 PingTimer Azure Function executed at: {DateTime.Now}");

            var t24Host = System.Environment.GetEnvironmentVariable("t24Host", EnvironmentVariableTarget.Process);
            var t24FcmHost = System.Environment.GetEnvironmentVariable("t24FcmHost", EnvironmentVariableTarget.Process);
            bool t24Success = false;
            bool fcmSuccess = false;

            if (!string.IsNullOrEmpty(t24Host))
            {
                t24Success = await HttpGet(t24Host, log);
            }
            else
            {
                log.LogError("T24 host not configured");
            }

            if (!string.IsNullOrEmpty(t24FcmHost))
            {
                fcmSuccess = await HttpGet(t24FcmHost, log);
            }
            else
            {
                log.LogError("FCM host not configured");
            }

            if (!t24Success && ! fcmSuccess)
            {
                throw new Exception("T24 & FCM unavailable");
            }
            if (!t24Success)
            {
                throw new Exception("T24 unavailable");
            }
            if (!fcmSuccess)
            {
                throw new Exception("FCM unavailable");
            }
        }

        public static async Task<bool> HttpGet(string url, ILogger log)
        {
            HttpClient client = new HttpClient();

            try
            {
                var response = await client.GetAsync(url);

                log.LogInformation($"{url} called with response status {response.StatusCode}");

                response.EnsureSuccessStatusCode();
            }
            catch (Exception ex)
            {
                log.LogError(ex.Message);
                return false;
            }
            return true;
        }
    }
}
