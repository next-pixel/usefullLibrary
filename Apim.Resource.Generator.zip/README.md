# APIM Resource Generator

## Introduction
The APIM Resource Generator is a .NET tool designed to generate Azure API Management (APIM) deployment templates.
This tool helps streamline the process of creating and managing APIM resources by automating the generation of necessary templates.

### Attention :warning::warning::warning:

The current pipeline will get the latest artifacts deployed being from master or from any feature branch.

**If the version is defective, it will impact any gateway pipeline deployment at build stage.**

It should be mitigated once the pipeline is updated to use the dotnet tool version, which provide version set for release only.

## Getting Started

### Installation Process
To install the APIM Resource Generator tool, you can use the following command:
```sh
dotnet tool install --global Apim.Resource.Generator.Tool
```

### Latest Releases
You can find the latest releases of the APIM Resource Generator tool in the `./nupkg` directory.

### API References
For detailed API references, please refer to the source code and the documentation provided within the codebase.

## Usage

### Commands and Options
The `APIM Resource Generator` tool provides several commands and options to help you generate APIM deployment templates. Below are some examples:

- **Create a new template:**
  ```sh
  dib-apim-template create --configFile <input-file> --outputFile <output-directory>
  ```
  - `--configFile`: Specifies the input file containing the API definitions. Config YAML file location.
  - `--outputFile`: Specifies the directory where the generated templates will be saved.

- **Extract templates from an existing APIM service:**
  ```sh
  dib-apim-template extract --sourceApimName <sourceApimName> --destinationApimName <destinationApimName> --resourceGroup <resourceGroup> --fileFolder <filefolder> [--apiName <apiName>] [--linkedTemplatesBaseUrl <linkedTemplatesBaseUrl>] [--linkedTemplatesUrlQueryString <linkedTemplatesUrlQueryString>] [--policyXMLBaseUrl <policyXMLBaseUrl>]
  ```
  - `--sourceApimName`: Source API Management name.
  - `--destinationApimName`: Destination API Management name.
  - `--resourceGroup`: Resource Group name.
  - `--fileFolder`: ARM Template files folder.
  - `--apiName`: (Optional) API name.
  - `--linkedTemplatesBaseUrl`: (Optional) Creates a master template with links.
  - `--linkedTemplatesUrlQueryString`: (Optional) Query string appended to linked templates URIs that enables retrieval from private storage.
  - `--policyXMLBaseUrl`: (Optional) Writes policies to local XML files that require deployment to a remote folder.

- **List available commands:**
  ```sh
  dib-apim-template --help
  ```

- **Show version information:**
  ```sh
  dib-apim-template version
  ```

## Build and Test

### Building the Project
To build the project, use the following command:
```sh
dotnet build --configuration Release
```

### Running Tests
To run the tests, use the following command:
```sh
dotnet test
```

## Contribute
We welcome contributions from the community to make this tool better. Here are some ways you can contribute:
1. Fork the repository.
2. Create a new branch (`git checkout -b feature-branch`).
3. Make your changes.
4. Commit your changes (`git commit -am 'Add new feature'`).
5. Push to the branch (`git push origin feature-branch`).
6. Create a new Pull Request.

For more detailed guidelines on contributing, please refer to the [contribution guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops).

## Change Log

- **19/09/2024**
  - Dotnet8 uplift
  - Support to dotnet tool install
  - Refactored namespace and project structure
  - Updated pipeline deployment