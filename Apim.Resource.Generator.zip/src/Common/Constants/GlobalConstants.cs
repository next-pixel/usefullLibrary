namespace Apim.Resource.Generator.Common.Constants;

internal static class GlobalConstants
{
    public const string AppShortName = "apimtemplate";
    public const string AppLongName = "API Management DevOps Toolkit";
    public const string AppDescription = "API Management DevOps Toolkit is a tool to create API Management definitions from files and to extract existing API Management APIs to files.";
    public const string CreateName = "create";
    public const string CreateDescription = "Create an API Management instance from files";
    public const string ConfigFileDescription = "Config YAML file location";
    public const string OutputFileDescription = "Specify Output file location";
    public const string ExtractName = "extract";
    public const string ExtractDescription = "Extract an existing API Management instance";
    public const string SourceApimNameDescription = "Source API Management name";
    public const string DestinationApimNameDescription = "Destination API Management name";
    public const string ResourceGroupDescription = "Resource Group name";
    public const string FileFolderDescription = "ARM Template files folder";
    public const string ApiNameDescription = "API name";
    public const string LinkedTemplatesBaseUrlDescription = "Creates a master template with links";
    public const string LinkedTemplatesUrlQueryStringDescription = "Query string appended to linked templates URIs that enables retrieval from private storage";
    public const string PolicyXMLBaseUrlDescription = "Writes policies to local XML files that require deployment to remote folder";
    public const string VersionName = "version";
    public const string VersionDescription = "Show version information";

    public const string ApiVersion = "2019-01-01";
    public const string LinkedApiVersion = "2018-01-01";

    public const string AzAccessToken = "account get-access-token --query \"accessToken\" --output json";
    public const string AzSubscriptionId = "account show --query id -o json";
}

internal static class ConsoleColours
{
    public static readonly string Red = Console.IsOutputRedirected ? "" : "\x1b[91m";
    public static readonly string Normal = Console.IsOutputRedirected ? "" : "\x1b[39m";
}