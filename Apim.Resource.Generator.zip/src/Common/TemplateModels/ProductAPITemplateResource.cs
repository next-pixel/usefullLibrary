﻿
namespace Apim.Resource.Generator.Common.TemplateModels
{
    public class ProductAPITemplateResource : TemplateResource
    {
        public ProductAPITemplateProperties properties { get; set; }
    }

    public class ProductAPITemplateProperties { }
}