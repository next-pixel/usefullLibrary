﻿using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Apim.Resource.Generator.Common.FileHandlers
{
    public class OpenAPISpecReader
    {
        public async Task<bool> IsJsonOpenApiSpecVersionThreeAsync(string openApiSpecFileLocation,string basePath, CancellationToken cancellationToken = default)
        {
            // determine whether file location is local file path or remote url and read content
            bool isUrl = Uri.TryCreate(openApiSpecFileLocation, UriKind.Absolute, out var uriResult) && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);
            if (isUrl)
            {

                HttpClient client = new HttpClient();
                HttpResponseMessage response = await client.GetAsync(uriResult, cancellationToken);
                if (response.IsSuccessStatusCode)
                {
                    string fileContents = await response.Content.ReadAsStringAsync(cancellationToken);
                    OpenAPISpecWithVersion openApiSpecWithVersion = JsonConvert.DeserializeObject<OpenAPISpecWithVersion>(fileContents);
                    // OASv3 has the property 'openapi' but not the property 'swagger'
                    return openApiSpecWithVersion.Swagger == null;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                string fileContents = await File.ReadAllTextAsync(basePath+openApiSpecFileLocation, cancellationToken);
                OpenAPISpecWithVersion openAPISpecWithVersion = JsonConvert.DeserializeObject<OpenAPISpecWithVersion>(fileContents);
                // OASv3 has the property 'openapi' but not the property 'swagger'
                return openAPISpecWithVersion.Swagger == null;
            }
        }
    }

    public class OpenAPISpecWithVersion
    {
        // OASv3 has the property 'swagger'
        [JsonProperty(PropertyName = "swagger")]
        public string Swagger { get; set; }
        // OASv3 has the property 'openapi'
        [JsonProperty(PropertyName = "openapi")]
        public string OpenAPISpec { get; set; }
    }

}