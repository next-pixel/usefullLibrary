﻿namespace Apim.Resource.Generator.Common.FileHandlers;

public class FileNameGenerator
{

    public FileNames GenerateFileNames(string apimServiceName) =>
        // generate useable object with file names for consistency throughout project
        new()
        {
            ApiVersionSets = $@"/{apimServiceName}-apiVersionSets.template.json",
            AuthorizationServers = $@"/{apimServiceName}-authorizationServers.template.json",
            Backends = $@"/{apimServiceName}-backends.template.json",
            GlobalServicePolicy = $@"/{apimServiceName}-globalServicePolicy.template.json",
            Loggers = $@"/{apimServiceName}-loggers.template.json",
            NamedValues = $@"/{apimServiceName}-namedValues.template.json",
            Tags = $@"/{apimServiceName}-tags.template.json",
            Products = $@"/{apimServiceName}-products.template.json",
            Parameters = $@"/{apimServiceName}-parameters.json",
            LinkedMaster = $@"/{apimServiceName}-master.template.json"
        };

    public string GenerateCreatorAPIFileName(
        string apiName,
        bool isSplitAPI,
        bool isInitialAPI,
        string apimServiceName)
    {
        // in case the api name has been appended with ;rev={revisionNumber}, take only the api name initially provided by the user in the creator config
        string sanitizedAPIName = GenerateOriginalAPIName(apiName);

        if (isSplitAPI == true)
        {
            return isInitialAPI == true ? $@"/initial.azuredeploy.json" : $@"/subsequent.azuredeploy.json";
        }
        else
        {
            return $@"/{apimServiceName}-{sanitizedAPIName}.api.template.json";
        }
    }

    public string GenerateExtractorAPIFileName(
        string singleAPIName,
        string apimServiceName)
    {
        return singleAPIName == null ? $@"/{apimServiceName}-apis.template.json" : $@"/{apimServiceName}-{singleAPIName}-api.template.json";
    }

    public string GenerateOriginalAPIName(
        string apiName)
    {
        // in case the api name has been appended with ;rev={revisionNumber}, take only the api name initially provided by the user in the creator config
        string originalName = apiName.Split(";")[0];
        return originalName;
    }
}

public class FileNames
{
    public string ApiVersionSets { get; set; }
    public string AuthorizationServers { get; set; }
    public string Backends { get; set; }
    public string GlobalServicePolicy { get; set; }
    public string Loggers { get; set; }
    public string NamedValues { get; set; }
    public string Tags { get; set; }
    public string Products { get; set; }
    public string Parameters { get; set; }
    // linked property outputs 1 master template
    public string LinkedMaster { get; set; }
}