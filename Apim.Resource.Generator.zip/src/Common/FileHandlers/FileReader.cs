﻿using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Apim.Resource.Generator.Creator.Models;
using Newtonsoft.Json;
using YamlDotNet.Serialization;

namespace Apim.Resource.Generator.Common.FileHandlers;
public class FileReader
{
    public async Task<CreatorConfig> ConvertConfigYamlToCreatorConfigAsync(
        string configFileLocation,
        string outputFileLocation,
        CancellationToken cancellationToken = default)
    {
        // determine whether file location is local file path or remote url and convert appropriately
        Console.WriteLine("Config File Location : " + configFileLocation);
        Console.WriteLine("Output File Location : " + outputFileLocation);
        Console.WriteLine("Base Path : " + configFileLocation.Replace("config.yml", ""));

        bool isUrl = Uri.TryCreate(configFileLocation, UriKind.Absolute, out Uri uriResult) && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);

        if (isUrl)
        {
            // make a request to the provided url and convert the response's content
            HttpClient client = new();
            HttpResponseMessage response = await client.GetAsync(uriResult, cancellationToken);
            if (response.IsSuccessStatusCode)
            {
                Stream stream = await response.Content.ReadAsStreamAsync(cancellationToken);
                using (StreamReader reader = new(stream))
                {
                    Deserializer deserializer = new();
                    object deserializedYaml = deserializer.Deserialize(reader);
                    JsonSerializer jsonSerializer = new();
                    StringWriter writer = new();
                    jsonSerializer.Serialize(writer, deserializedYaml);
                    string jsonText = writer.ToString();
                    CreatorConfig yamlObject = JsonConvert.DeserializeObject<CreatorConfig>(jsonText);
                    return yamlObject;
                }
            }
            else
            {
                throw new Exception("Unable to fetch remote config YAML file.");
            }
        }
        else
        {
            using StreamReader reader = new(configFileLocation);
            // deserialize provided file contents into yaml
            Deserializer deserializer = new();
            object deserializedYaml = deserializer.Deserialize(reader);
            JsonSerializer jsonSerializer = new();
            StringWriter writer = new();
            // serialize json from yaml object
            jsonSerializer.Serialize(writer, deserializedYaml);
            string jsonText = writer.ToString();
            // deserialize CreatorConfig from json string
            CreatorConfig yamlObject = JsonConvert.DeserializeObject<CreatorConfig>(jsonText);
            yamlObject.apis[0].basePath = configFileLocation.Replace("config.yml", "");
            Console.WriteLine("Reading Configs");
            yamlObject.outputLocation = outputFileLocation;

            return yamlObject;
        }
    }

    public string RetrieveLocalFileContents(string fileLocation) => File.ReadAllText(fileLocation);

    public string RetrieveLocalFileContents(string fileLocation, string basePath) => File.ReadAllText(basePath + fileLocation);
    
    public async Task<string> RetrieveFileContentsAsync(
        string fileLocation,
        string basePath = default,
        CancellationToken cancellationToken = default)
    {
        // determine whether file location is local file path or remote url and convert appropriately
        bool isUrl = Uri.TryCreate(fileLocation, UriKind.Absolute, out Uri uriResult) && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);

        if (isUrl)
        {
            // make a request to the provided url and convert the response's content
            HttpClient client = new();
            HttpResponseMessage response = await client.GetAsync(uriResult, cancellationToken);
            if (response.IsSuccessStatusCode)
            {
                string content = await response.Content.ReadAsStringAsync(cancellationToken);
                return content;
            }
            else
            {
                throw new Exception($"Unable to fetch remote file - {fileLocation}");
            }
        }
        else
        {
            return RetrieveLocalFileContents(fileLocation, basePath);
        }
    }

    public bool IsJson(
        string fileContents)
    {
        try
        {
            JsonConvert.DeserializeObject<object>(fileContents);
            return true;
        }
        catch (Exception)
        {
            return false;
        }
    }
}