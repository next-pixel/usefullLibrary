global using System;
global using Apim.Resource.Generator.Common.Constants;