﻿using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace Apim.Resource.Generator.Extractor.Utilities;

internal class Executable(
    string exeName,
    string arguments = null,
    bool streamOutput = true,
    bool shareConsole = false,
    bool visibleProcess = false,
    string workingDirectory = null)
{
    private readonly string _exeName = exeName;
    private readonly string _arguments = arguments;
    private readonly bool _shareConsole = shareConsole;
    private readonly bool _streamOutput = streamOutput;
    private readonly bool _visibleProcess = visibleProcess;
    private readonly string _workingDirectory = workingDirectory;

    public Process Process { get; private set; }

    public async Task<int> RunAsync(
        Action<string> outputCallback = null,
        Action<string> errorCallback = null,
        TimeSpan? timeout = null,
        CancellationToken cancellationToken = default)
    {
        var processInfo = new ProcessStartInfo
        {
            FileName = _exeName,
            Arguments = _arguments,
            CreateNoWindow = !_visibleProcess,
            UseShellExecute = _shareConsole,
            RedirectStandardError = _streamOutput,
            RedirectStandardInput = _streamOutput,
            RedirectStandardOutput = _streamOutput,
            WorkingDirectory = _workingDirectory ?? Environment.CurrentDirectory
        };

        try
        {
            Process = Process.Start(processInfo)!;
        }
        catch (Win32Exception ex)
        {
            if (ex.Message == "The system cannot find the file specified")
            {
                throw new FileNotFoundException(ex.Message, ex);
            }
            throw;
        }
        catch (Exception ex)
        {
            throw new Exception("Error starting process", ex);
        }

        if (_streamOutput)
        {
            Process.OutputDataReceived += (s, e) => outputCallback?.Invoke(e.Data);
            Process.BeginOutputReadLine();
            Process.ErrorDataReceived += (s, e) => errorCallback?.Invoke(e.Data);
            Process.BeginErrorReadLine();
            Process.EnableRaisingEvents = true;
        }

        try
        {
            await Process.WaitForExitAsync(cancellationToken);
        }
        catch (Exception ex)
        {
            Process.Kill();
            Console.WriteLine(ex.ToString());
        }
        return Process.ExitCode;
    }
}