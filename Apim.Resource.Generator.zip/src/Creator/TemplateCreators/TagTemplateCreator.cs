using System.Collections.Generic;
using Apim.Resource.Generator.Common.TemplateModels;
using Apim.Resource.Generator.Creator.Models;

namespace Apim.Resource.Generator.Creator.TemplateCreators
{
    public class TagTemplateCreator: TemplateCreator
    {
        public Template CreateTagTemplate(CreatorConfig creatorConfig)
        {
            // create empty template
            Template tagTemplate = CreateEmptyTemplate();

            // add parameters
            tagTemplate.parameters = new Dictionary<string, TemplateParameterProperties>
            {
                {"ApimServiceName", new TemplateParameterProperties(){ type = "string" }}
            };

            List<TemplateResource> resources = new List<TemplateResource>();
            foreach (TagTemplateProperties tag in creatorConfig.tags)
            {
                // create tag resource with properties
                TagTemplateResource tagTemplateResource = new TagTemplateResource()
                {
                    name = $"[concat(parameters('ApimServiceName'), '/{tag.displayName}')]",
                    type = ResourceTypeConstants.Tag,
                    apiVersion = GlobalConstants.ApiVersion,
                    properties = new TagTemplateProperties()
                    {
                        displayName = tag.displayName
                    },
                    dependsOn = new string[] { }
                };
                resources.Add(tagTemplateResource);
            }

            tagTemplate.resources = resources.ToArray();
            return tagTemplate;
        }
    }
}