﻿using System.Collections.Generic;
using Apim.Resource.Generator.Common.TemplateModels;
using Apim.Resource.Generator.Creator.Models;

namespace Apim.Resource.Generator.Creator.TemplateCreators
{
    public class AuthorizationServerTemplateCreator : TemplateCreator
    {
        public Template CreateAuthorizationServerTemplate(CreatorConfig creatorConfig)
        {
            // create empty template
            Template authorizationTemplate = CreateEmptyTemplate();

            // add parameters
            authorizationTemplate.parameters = new Dictionary<string, TemplateParameterProperties>
            {
                { "ApimServiceName", new TemplateParameterProperties(){ type = "string" } }
            };

            List<TemplateResource> resources = new List<TemplateResource>();
            foreach (AuthorizationServerTemplateProperties authorizationServerTemplateProperties in creatorConfig.authorizationServers)
            {
                // create authorization server resource with properties
                AuthorizationServerTemplateResource authorizationServerTemplateResource = new AuthorizationServerTemplateResource()
                {
                    name = $"[concat(parameters('ApimServiceName'), '/{authorizationServerTemplateProperties.displayName}')]",
                    type = ResourceTypeConstants.AuthorizationServer,
                    apiVersion = GlobalConstants.ApiVersion,
                    properties = authorizationServerTemplateProperties,
                    dependsOn = new string[] { }
                };
                resources.Add(authorizationServerTemplateResource);
            }

            authorizationTemplate.resources = resources.ToArray();
            return authorizationTemplate;
        }
    }
}
