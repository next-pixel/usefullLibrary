﻿using Apim.Resource.Generator.Commands;
using McMaster.Extensions.CommandLineUtils;

namespace Apim.Resource.Generator
{
    [Command(Name = GlobalConstants.AppShortName, 
         FullName = GlobalConstants.AppLongName,
         Description = GlobalConstants.AppDescription),
     Subcommand(
         typeof(CreateCommand), 
         typeof(ExtractCommand), 
         typeof(VersionCommand))]
    class Program
    {
        public static int Main(string[] args)
        {
            try
            {   
                return CommandLineApplication.Execute<Program>(args);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{ConsoleColours.Red}{ex}");
                return -1;
            }
        }
        
        private int OnExecute(CommandLineApplication app, IConsole console)
        {
            console.WriteLine($"{ConsoleColours.Red}No commands specified, please specify a command{ConsoleColours.Normal}{Environment.NewLine}");
            app.ShowHelp();
            return 1;
        }
    }
}