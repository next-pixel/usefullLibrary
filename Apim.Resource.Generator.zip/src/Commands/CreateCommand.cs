using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Apim.Resource.Generator.Common.FileHandlers;
using Apim.Resource.Generator.Common.TemplateModels;
using Apim.Resource.Generator.Creator.Models;
using Apim.Resource.Generator.Creator.TemplateCreators;
using Apim.Resource.Generator.Creator.Utilities;
using McMaster.Extensions.CommandLineUtils;

namespace Apim.Resource.Generator.Commands;

[Command(GlobalConstants.CreateName, Description = GlobalConstants.CreateDescription)]
public class CreateCommand
{
    [Required]
    [Option("--configFile <configFile>", GlobalConstants.ConfigFileDescription, CommandOptionType.SingleValue)]
    public string ConfigFile { get; set; }

    [Required]
    [Option("--outputFile <outputFile>", GlobalConstants.OutputFileDescription, CommandOptionType.SingleValue)]
    public string OutputFile { get; set; }

    public async Task OnExecuteAsync(
        CommandLineApplication app,
        IConsole console,
        CancellationToken cancellationToken)
    {
        // convert config file to CreatorConfig class
        FileReader fileReader = new();
        CreatorConfig creatorConfig = await fileReader.ConvertConfigYamlToCreatorConfigAsync(ConfigFile, OutputFile, cancellationToken);

        // validate creator config
        CreatorConfigurationValidator creatorConfigurationValidator = new(app);
        bool isValidCreatorConfig = creatorConfigurationValidator.ValidateCreatorConfig(creatorConfig);

        if (isValidCreatorConfig == true)
        {
            // required parameters have been supplied

            // initialize file helper classes
            FileWriter fileWriter = new();
            FileNameGenerator fileNameGenerator = new();
            FileNames fileNames = fileNameGenerator.GenerateFileNames(creatorConfig.apimServiceName);

            // initialize template creator classes
            APIVersionSetTemplateCreator apiVersionSetTemplateCreator = new();
            LoggerTemplateCreator loggerTemplateCreator = new();
            BackendTemplateCreator backendTemplateCreator = new();
            AuthorizationServerTemplateCreator authorizationServerTemplateCreator =new();
            ProductAPITemplateCreator productApiTemplateCreator = new();
            PolicyTemplateCreator policyTemplateCreator = new(fileReader);
            DiagnosticTemplateCreator diagnosticTemplateCreator = new();
            ReleaseTemplateCreator releaseTemplateCreator = new();
            ProductTemplateCreator productTemplateCreator = new(policyTemplateCreator);
            TagTemplateCreator tagTemplateCreator = new();
            APITemplateCreator apiTemplateCreator = new(fileReader, policyTemplateCreator, productApiTemplateCreator, diagnosticTemplateCreator, releaseTemplateCreator);
            MasterTemplateCreator masterTemplateCreator = new();

            // create templates from provided configuration
            Console.WriteLine("Creating global service policy template");
            Console.WriteLine("------------------------------------------");
            Template globalServicePolicyTemplate = creatorConfig.policy != null
                ? policyTemplateCreator.CreateGlobalServicePolicyTemplate(creatorConfig)
                : null;
            
            Console.WriteLine("Creating API version set template");
            Console.WriteLine("------------------------------------------");
            Template apiVersionSetsTemplate = creatorConfig.apiVersionSets != null
                ? apiVersionSetTemplateCreator.CreateAPIVersionSetTemplate(creatorConfig)
                : null;
            
            Console.WriteLine("Creating product template");
            Console.WriteLine("------------------------------------------");
            Template productsTemplate = creatorConfig.products != null
                ? productTemplateCreator.CreateProductTemplate(creatorConfig)
                : null;
            
            Console.WriteLine("Creating tag template");
            Console.WriteLine("------------------------------------------");
            Template tagTemplate = creatorConfig.tags != null
                ? tagTemplateCreator.CreateTagTemplate(creatorConfig)
                : null;
            
            Console.WriteLine("Creating logger template");
            Console.WriteLine("------------------------------------------");
            Template loggersTemplate = creatorConfig.loggers != null
                ? loggerTemplateCreator.CreateLoggerTemplate(creatorConfig)
                : null;
            
            Console.WriteLine("Creating backend template");
            Console.WriteLine("------------------------------------------");
            Template backendsTemplate = creatorConfig.backends != null
                ? backendTemplateCreator.CreateBackendTemplate(creatorConfig)
                : null;
            
            Console.WriteLine("Creating authorization server template");
            Console.WriteLine("------------------------------------------");
            Template authorizationServersTemplate = creatorConfig.authorizationServers != null
                ? authorizationServerTemplateCreator.CreateAuthorizationServerTemplate(creatorConfig)
                : null;
            
            // store name and whether the api will depend on the version set template each api necessary to build linked templates
            List<LinkedMasterTemplateAPIInformation> apiInformation = [];
            List<Template> apiTemplates = [];

            Console.WriteLine("Creating API templates");
            Console.WriteLine("------------------------------------------");
            foreach (APIConfig api in creatorConfig.apis)
            {
                // create api templates from provided api config - if the api config contains a supplied apiVersion, split the templates into 2 for metadata and swagger content, otherwise create a unified template
                List<Template> apiTemplateSet = await apiTemplateCreator.CreateAPITemplatesAsync(api);
                apiTemplates.AddRange(apiTemplateSet);
                // create the relevant info that will be needed to properly link to the api template(s) from the master template
                apiInformation.Add(new LinkedMasterTemplateAPIInformation()
                {
                    name = api.name,
                    isSplit = apiTemplateCreator.isSplitAPI(api),
                    dependsOnGlobalServicePolicies = creatorConfig.policy != null,
                    dependsOnVersionSets = api.apiVersionSetId != null,
                    dependsOnProducts = api.products != null,
                    dependsOnTags = api.tags != null,
                    dependsOnLoggers =
                        await masterTemplateCreator.DetermineIfAPIDependsOnLoggerAsync(api, fileReader),
                    dependsOnAuthorizationServers = api.authenticationSettings != null &&
                                                    api.authenticationSettings.oAuth2 != null &&
                                                    api.authenticationSettings.oAuth2.authorizationServerId != null,
                    dependsOnBackends =
                        await masterTemplateCreator.DetermineIfAPIDependsOnBackendAsync(api, fileReader)
                });
            }

            // create parameters file
            Template templateParameters = masterTemplateCreator.CreateMasterTemplateParameterValues(creatorConfig);

            // write templates to outputLocation
            if (creatorConfig.linked == true)
            {
                // create linked master template
                Template masterTemplate = masterTemplateCreator.CreateLinkedMasterTemplate(creatorConfig,
                    globalServicePolicyTemplate, apiVersionSetsTemplate, productsTemplate, loggersTemplate,
                    backendsTemplate, authorizationServersTemplate, tagTemplate, apiInformation, fileNames,
                    creatorConfig.apimServiceName, fileNameGenerator);
                fileWriter.WriteJSONToFile(masterTemplate,
                    string.Concat(creatorConfig.outputLocation, fileNames.linkedMaster));
                Console.WriteLine("1Writing Finished to - " + fileNames.linkedMaster);
            }

            foreach (Template apiTemplate in apiTemplates)
            {
                APITemplateResource apiResource = apiTemplate.resources.FirstOrDefault(resource =>
                    resource.type == ResourceTypeConstants.API) as APITemplateResource;

                APIConfig providedAPIConfiguration = creatorConfig.apis.FirstOrDefault(api =>
                    apiResource.name.Contains(api.name, StringComparison.Ordinal));

                // if the api version is not null the api is split into multiple templates. If the template is split and the content value has been set, then the template is for a subsequent api
                string apiFileName = fileNameGenerator.GenerateCreatorAPIFileName(providedAPIConfiguration.name, apiTemplateCreator.isSplitAPI(providedAPIConfiguration), apiResource.properties.value == null, creatorConfig.apimServiceName);
                fileWriter.WriteJSONToFile(apiTemplate, string.Concat(creatorConfig.outputLocation, apiFileName));
            }

            if (globalServicePolicyTemplate != null)
            {
                fileWriter.WriteJSONToFile(globalServicePolicyTemplate, string.Concat(creatorConfig.outputLocation, fileNames.globalServicePolicy));
            }

            if (apiVersionSetsTemplate != null)
            {
                fileWriter.WriteJSONToFile(apiVersionSetsTemplate, string.Concat(creatorConfig.outputLocation, "/apiVersionSets.json"));
            }

            if (productsTemplate != null)
            {
                fileWriter.WriteJSONToFile(productsTemplate, string.Concat(creatorConfig.outputLocation, fileNames.products));
            }

            if (loggersTemplate != null)
            {
                fileWriter.WriteJSONToFile(loggersTemplate, string.Concat(creatorConfig.outputLocation, fileNames.loggers));
            }

            if (backendsTemplate != null)
            {
                fileWriter.WriteJSONToFile(backendsTemplate, string.Concat(creatorConfig.outputLocation, fileNames.backends));
            }

            if (authorizationServersTemplate != null)
            {
                fileWriter.WriteJSONToFile(authorizationServersTemplate, string.Concat(creatorConfig.outputLocation, fileNames.authorizationServers));
            }

            if (tagTemplate != null)
            {
                fileWriter.WriteJSONToFile(tagTemplate, string.Concat(creatorConfig.outputLocation, fileNames.tags));
            }

            // write parameters to outputLocation
            fileWriter.WriteJSONToFile(templateParameters, string.Concat(creatorConfig.outputLocation, "/azuredeploy.parameters.json"));
            Console.WriteLine("Templates written to output location");
        }
    }
}