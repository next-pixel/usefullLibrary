using System.Diagnostics;
using McMaster.Extensions.CommandLineUtils;

namespace Apim.Resource.Generator.Commands;

[Command(GlobalConstants.VersionName, Description = GlobalConstants.VersionDescription)]
public class VersionCommand
{
    public int OnExecute(
        CommandLineApplication app,
        IConsole console)
    {
        var version = FileVersionInfo.GetVersionInfo(typeof(Program).Assembly.Location).ProductVersion;
        console.WriteLine($"{Environment.NewLine}{GlobalConstants.AppDescription}");
        console.WriteLine($"{Environment.NewLine}Build Version: {version}{Environment.NewLine}");
        return 0;
    }
}