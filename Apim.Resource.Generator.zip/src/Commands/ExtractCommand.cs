using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Apim.Resource.Generator.Common.FileHandlers;
using Apim.Resource.Generator.Common.TemplateModels;
using Apim.Resource.Generator.Extractor.EntityExtractors;
using McMaster.Extensions.CommandLineUtils;

namespace Apim.Resource.Generator.Commands;

[Command(GlobalConstants.ExtractName, Description = GlobalConstants.ExtractDescription)]
public class ExtractCommand
{
    [Required]
    [Option("--sourceApimName <sourceApimName>", GlobalConstants.SourceApimNameDescription, CommandOptionType.SingleValue)]

    public string SourceApimName { get; set; }

    [Required]
    [Option("--destinationApimName <destinationApimName>", GlobalConstants.DestinationApimNameDescription, CommandOptionType.SingleValue)]

    public string DestinationApimName { get; set; }

    [Required]
    [Option("--resourceGroup <resourceGroup>", GlobalConstants.ResourceGroupDescription, CommandOptionType.SingleValue)]

    public string ResourceGroup { get; set; }

    [Required]
    [Option("--fileFolder <filefolder>", GlobalConstants.FilefolderDescription, CommandOptionType.SingleValue)]
    public string FileFolder { get; set; }

    [Option("--apiName <apiName>", GlobalConstants.ApiNameDescription, CommandOptionType.SingleValue)]
    public string ApiName { get; set; }

    [Option("--linkedTemplatesBaseUrl <linkedTemplatesBaseUrl>", GlobalConstants.LinkedTemplatesBaseUrlDescription, CommandOptionType.SingleValue)]
    public string LinkedTemplatesBaseUrl { get; set; }

    [Option("--linkedTemplatesUrlQueryString <linkedTemplatesUrlQueryString>", GlobalConstants.linkedTemplatesUrlQueryStringDescription, CommandOptionType.SingleValue)]
    public string LinkedTemplatesUrlQueryString { get; set; }

    [Option("--policyXMLBaseUrl <policyXMLBaseUrl>", GlobalConstants.PolicyXMLBaseUrlDescription, CommandOptionType.SingleValue)]

    public string PolicyXmlBaseUrl { get; set; }

    public async Task OnExecuteAsync(
        CommandLineApplication app,
        IConsole console,
        CancellationToken cancellationToken)
    {
        try
        {
            Console.WriteLine("API Management Template");
            Console.WriteLine();
            Console.WriteLine("Connecting to {0} API Management Service on {1} Resource Group ...", SourceApimName,
                ResourceGroup);
            if (!string.IsNullOrEmpty(ApiName))
            {
                Console.WriteLine("Executing extraction for {0} API ...", ApiName);
            }
            else
            {
                Console.WriteLine("Executing full extraction ...");
            }

            // initialize file helper classes
            FileWriter fileWriter = new();
            FileNameGenerator fileNameGenerator = new();
            FileNames fileNames = fileNameGenerator.GenerateFileNames(SourceApimName);

            // initialize entity extractor classes
            APIExtractor apiExtractor = new(fileWriter);
            APIVersionSetExtractor apiVersionSetExtractor = new();
            AuthorizationServerExtractor authorizationServerExtractor = new();
            BackendExtractor backendExtractor = new();
            LoggerExtractor loggerExtractor = new();
            PolicyExtractor policyExtractor = new(fileWriter);
            PropertyExtractor propertyExtractor = new();
            TagExtractor tagExtractor = new();
            ProductExtractor productExtractor = new(fileWriter);
            MasterTemplateExtractor masterTemplateExtractor = new();

            // extract templates from apim service
            Template globalServicePolicyTemplate = await policyExtractor.GenerateGlobalServicePolicyTemplateAsync(SourceApimName, ResourceGroup, PolicyXmlBaseUrl, FileFolder);
            Template apiTemplate = await apiExtractor.GenerateAPIsARMTemplateAsync(SourceApimName, ResourceGroup, ApiName, PolicyXmlBaseUrl, FileFolder);
            List<TemplateResource> apiTemplateResources = [.. apiTemplate.resources];
            Template apiVersionSetTemplate = await apiVersionSetExtractor.GenerateAPIVersionSetsARMTemplateAsync(SourceApimName, ResourceGroup, ApiName, apiTemplateResources, PolicyXmlBaseUrl);
            Template authorizationServerTemplate = await authorizationServerExtractor.GenerateAuthorizationServersARMTemplateAsync(SourceApimName, ResourceGroup, ApiName, apiTemplateResources, PolicyXmlBaseUrl);
            Template loggerTemplate = await loggerExtractor.GenerateLoggerTemplateAsync(SourceApimName, ResourceGroup, ApiName, apiTemplateResources, PolicyXmlBaseUrl);
            Template productTemplate = await productExtractor.GenerateProductsARMTemplateAsync(SourceApimName, ResourceGroup, ApiName, apiTemplateResources, PolicyXmlBaseUrl, FileFolder);
            List<TemplateResource> productTemplateResources = [.. productTemplate.resources];
            Template namedValueTemplate = await propertyExtractor.GenerateNamedValuesTemplateAsync(SourceApimName, ResourceGroup, ApiName, apiTemplateResources, PolicyXmlBaseUrl);
            Template tagTemplate = await tagExtractor.GenerateTagsTemplateAsync(SourceApimName, ResourceGroup, ApiName, apiTemplateResources, productTemplateResources, PolicyXmlBaseUrl);
            List<TemplateResource> namedValueResources = [.. namedValueTemplate.resources];
            Template backendTemplate = await backendExtractor.GenerateBackendsARMTemplateAsync(SourceApimName, ResourceGroup, ApiName, apiTemplateResources, namedValueResources, PolicyXmlBaseUrl);

            // create parameters file
            Template templateParameters = masterTemplateExtractor.CreateMasterTemplateParameterValues(DestinationApimName, LinkedTemplatesBaseUrl, LinkedTemplatesUrlQueryString, PolicyXmlBaseUrl);

            // write templates to output file location
            string apiFileName = fileNameGenerator.GenerateExtractorAPIFileName(ApiName, SourceApimName);
            fileWriter.WriteJSONToFile(apiTemplate, string.Concat(FileFolder, apiFileName));
            fileWriter.WriteJSONToFile(apiVersionSetTemplate, string.Concat(FileFolder, fileNames.apiVersionSets));
            fileWriter.WriteJSONToFile(authorizationServerTemplate, string.Concat(FileFolder, fileNames.authorizationServers));
            fileWriter.WriteJSONToFile(backendTemplate, string.Concat(FileFolder, fileNames.backends));
            fileWriter.WriteJSONToFile(loggerTemplate, string.Concat(FileFolder, fileNames.loggers));
            fileWriter.WriteJSONToFile(namedValueTemplate, string.Concat(FileFolder, fileNames.namedValues));
            fileWriter.WriteJSONToFile(tagTemplate, string.Concat(FileFolder, fileNames.tags));
            fileWriter.WriteJSONToFile(productTemplate, string.Concat(FileFolder, fileNames.products));
            fileWriter.WriteJSONToFile(globalServicePolicyTemplate, string.Concat(FileFolder, fileNames.globalServicePolicy));

            if (LinkedTemplatesBaseUrl != null)
            {
                // create a master template that links to all other templates
                Template masterTemplate = masterTemplateExtractor.GenerateLinkedMasterTemplate( apiTemplate, globalServicePolicyTemplate, apiVersionSetTemplate, productTemplate, loggerTemplate, backendTemplate, authorizationServerTemplate, namedValueTemplate, tagTemplate, fileNames, apiFileName, LinkedTemplatesUrlQueryString, PolicyXmlBaseUrl);
                fileWriter.WriteJSONToFile(masterTemplate, string.Concat(FileFolder, fileNames.linkedMaster));
            }

            // write parameters to outputLocation
            fileWriter.WriteJSONToFile(templateParameters, string.Concat(FileFolder, fileNames.parameters));
            Console.WriteLine("Templates written to output location");
            Console.WriteLine("Press any key to exit process:");
#if DEBUG
            Console.ReadKey();
#endif
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error occured: " + ex.Message);
            throw;
        }
    }
}