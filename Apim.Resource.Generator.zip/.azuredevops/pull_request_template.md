|**Change Type:**| [`New Feature`][`Support`][`Uplift`]|
|-:|:-|
|**Jira Ticket:**| [{Jira Card Title}]()|
|**Repository:**| [Apim.Resource.Generator](https://dev.azure.com/ksmauels/sandbox/_git/Apim.Resource.Generator)|

## {Jira} Overview
{Summarize your changes}

## Additional Information
- {Provide additional information relevant to people reviewing the code}

### Reviewer Notes
- {Add notes for reviewers to pay attention to}

## Checklist
To be completed by the developer raising the PR, and verified by all reviewers:

- [ ] **Is this a BREAKING CHANGE?** - Has the appropriate `semver` tag been added for breaking changes (see [Versioning]())
- [ ] **Unit Tests** - Unit tests have been added for all new functionality

- **Documentation**
    - [ ] **README.md Updated** - Is the repo's README.md up to date

## Commit messages
