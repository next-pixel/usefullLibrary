|**Change Type:**|[`Release`] or [`Cherry-Pick`]|
|-:|:-|
|**Target Brand:**|`MEB`|
|**Deployment Ticket:**|[{Jira Card Title}](https://qdigital.atlassian.net/browse/{Jira_Number})|
|**Repository:**|[Direct Debit](https://dev.azure.com/qdigitalcode/DenovoBank/_git/DirectDebit)|
  
## {Jira_Number} Overview
{Summarize contents of the release}
  
## Additional Information
- {Provide additional information relevant to people reviewing the code}

## Reviewer Notes
- {Add notes for reviewers to pay attention to}

## Checklist
To be completed by the developer raising the PR, and verified by all reviewers

- **Deployment**
  - [ ] **Ticket Raised** - Has a deployment ticket already been raised for this release
- **Confluence**
  - [ ] **Release Plan** - Has this release been included on a SIT/UAT release plan
  - [ ] **Implementation Plan** - Has this release been included on the production implementation plan