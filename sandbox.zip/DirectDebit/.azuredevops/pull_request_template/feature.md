|**Change Type:**|[`Feature`]|
|-:|:-|
|**Jira Ticket:**|[{Jira Card Title}](https://qdigital.atlassian.net/browse/{Jira_Number})|
|**Confluence:**|[IC89 Direct Debit_Phase2 (Web API)](https://qdigital.atlassian.net/wiki/spaces/ITSARCH/pages/6111577766/IC89+Direct+Debit+Phase2+Web+API)|
|**Repository:**|[Direct Debit](https://dev.azure.com/qdigitalcode/DenovoBank/_git/DirectDebit)|
  
## {Jira_Number} Overview
{Summarize your changes}
  
## Additional Information
- {Provide additional information relevant to people reviewing the code}

## Common Features
- **Feature Flags**
  - {Reference any new feature flags added}
- **Configuration**
  - {Reference any changes to configuration required}
  
## Reviewer Notes
- {Add notes for reviewers to pay attention to}

## Checklist
To be completed by the developer raising the PR, and verified by all reviewers

- **Code Quality**
  - [ ] **Coverage** - Have unit tests been written to cover the additional features (See [SonarQube](https://sonarqube.boqdev.com.au/projects))
  - [ ] **Quality** - Have you ensured that you are meeting the quality requirements (See [Whitesource](https://saas-eu.whitesourcesoftware.com/Wss/WSS.html#))
- **Documentation**
  - [ ] **Confluence Updated** - Has the confluence page been updated to reflect this feature
  - [ ] **README.md Updated** - Is the README.md for this repository up to date