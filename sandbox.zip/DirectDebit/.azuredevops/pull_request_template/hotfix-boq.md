|**Change Type:**|[`Hotfix`]|
|-:|:-|
|**Target Brand:**|`BOQ`|
|**Jira Ticket:**|[{Jira Card Title}](https://qdigital.atlassian.net/browse/{Jira_Number})|
|**Repository:**|[Direct Debit](https://dev.azure.com/qdigitalcode/DenovoBank/_git/DirectDebit)|
  
## {Jira_Number} Resolution
{Summarize how you resolved the defect}
  
## Additional Information
- {Provide additional information relevant to people reviewing the code}

## Reviewer Notes
- {Add notes for reviewers to pay attention to}

## Checklist
To be completed by the developer raising the PR, and verified by all reviewers

- **Code Coverage**
  - [ ] **Coverage** - Have unit tests been updated to cover this hotfix (See [SonarQube](https://sonarqube.boqdev.com.au/projects))
  - [ ] **Quality** - Have you ensured that these changes meet the quality requirements (See [Whitesource](https://saas-eu.whitesourcesoftware.com/Wss/WSS.html#))