﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DirectDebit.UnitTests
{
    public enum TableStorageErrorCode
    {
        [TableStorageError(HttpStatusCode.NotFound, "The specified entity does not exist.")]
        EntityNotFound,

        [TableStorageError(HttpStatusCode.Conflict, "The specified entity already exists.")]
        EntityAlreadyExists
    }
}
