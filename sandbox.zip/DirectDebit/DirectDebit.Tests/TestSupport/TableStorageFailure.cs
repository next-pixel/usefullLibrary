﻿using Microsoft.Azure.Cosmos.Table;
using Microsoft.Azure.WebJobs.ServiceBus;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DirectDebit.UnitTests
{
    public abstract class TableStorageFailure
    {
        protected TableStorageFailure(Type entityType, FailTypeEnum failType, TableKey key, Exception failException) 
        {
            FailType = failType;
            Key = key;
            EntityType = entityType;
            FailException = failException;
        }

        public FailTypeEnum FailType { get; private set; }
        public TableKey Key { get; private set; }
        public Type EntityType { get; private set; }
        public Exception FailException { get; private set; }

        protected abstract bool ResolveConditional(TableEntity entity);
        public bool VerifyCondition(TableEntity entity) => ResolveConditional(entity);
    }
}
