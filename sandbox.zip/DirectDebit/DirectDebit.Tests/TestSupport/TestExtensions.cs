﻿using DirectDebitApi;
using Moq;
using Platform.Library.Authentication.Configuration;
using Platform.Library.Authentication.Guards;
using Platform.Library.Authentication.Models.Abstractions;
using Platform.Library.AzureStorage.Clients.Abstraction;
using Platform.Library.Testing.XUnit;
using Polly;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DirectDebit.UnitTests
{
    /// <summary>
    /// Extension methods to streamline tests
    /// </summary>
    internal static class TestExtensions
    {
        /// <summary>
        /// Mock the standard Authorization Settings
        /// </summary>
        /// <param name="mock"></param>
        internal static void SetupAuthorizationSettings(Mock<IStandardAuthorizationSettings> mock)
        {
            mock.Setup(x => x.CiamCertificateUrl).Returns("1");
            mock.Setup(x => x.AzureAdIssuer).Returns("2");
            mock.Setup(x => x.CiamSubscriptionKey).Returns("3");
        }

        internal static void RegisterGuardBuilderAndContext(this ContextModule contextModule)
        {
            contextModule.RegisterMockAsInterface<IMockAuthenticationContext>();
            contextModule.RegisterInstanceAsInterface<MockGuardBuilder,IGuardBuilder>(SetupGuardBuilder(contextModule));
        }

        internal static void RegisterMockTableStorage(this ContextModule contextModule, ResourceModule resourceModule)
        {
            contextModule.RegisterInstanceAsInterface<MockTableStorageClient, IAzureTableStorageClient>(SetupTableStorage(contextModule, resourceModule));
        }

        internal static MockGuardBuilder GetMockGuardBuilder(this ContextModule contextModule)
        {
            return contextModule.Resolve<IGuardBuilder>() as MockGuardBuilder;
        }

        internal static MockTableStorageClient GetMockTableStorageClient(this ContextModule contextModule)
        {
            return contextModule.Resolve<IAzureTableStorageClient>() as MockTableStorageClient;
        }

        private static MockGuardBuilder SetupGuardBuilder(ContextModule contextModule)
        {
            var guardBuilder = new MockGuardBuilder(contextModule);
            return guardBuilder;
        }

        private static MockTableStorageClient SetupTableStorage(ContextModule contextModule, ResourceModule resourceModule)
        {
            var tableStorage = new MockTableStorageClient(contextModule, resourceModule);
            return tableStorage;
        }

        internal static TableKey AsDirectDebitKey(this string rowKey)
        {
            return TableKey.Define(DirectDebitApi.InternalConstants.TableStorage.DirectDebit.PartitionKey, rowKey);
        }
    }
}
