﻿using DirectDebit.UnitTests.Validators;
using Microsoft.Azure.Cosmos.Table;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Extensions;
using Moq;
using Platform.Library.Authentication;
using Platform.Library.Authentication.Guards;
using Platform.Library.Authentication.Models.Abstractions;
using Platform.Library.AzureStorage.Clients.Abstraction;
using Platform.Library.AzureStorage.Entities;
using Platform.Library.Common.Standard.Mocking;
using Platform.Library.Testing.XUnit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DirectDebit.UnitTests
{
    public class MockTableStorageClient : IAzureTableStorageClient
    {
        private ILogger _logger = null;
        private readonly ContextModule _contextModule;
        private readonly ResourceModule _resourceModule;
        private readonly Dictionary<string, Dictionary<TableKey, TableStorageFailure>> _failures = new Dictionary<string, Dictionary<TableKey, TableStorageFailure>>();
        private Dictionary<string, Dictionary<TableKey, TableEntity>> _cache = new Dictionary<string, Dictionary<TableKey, TableEntity>>();

        internal MockTableStorageClient(ContextModule contextModule, ResourceModule resourceModule)
        {
            _contextModule = contextModule;
            _resourceModule = resourceModule;
        }

        private ILogger Logger
        {
            get
            {
                _logger ??= _contextModule.Resolve<ILogger>();
                return _logger;
            }
        }

        public void PopulateEntity<T>(string partitionKey, string rowKey, T entity)
            where T : TableEntity
        {
            PopulateEntity<T>(entity);
        }

        public void PopulateEntity<T>(T entity)
            where T : TableEntity
        {
            // Retrieve the Entity Table
            if ( !_cache.TryGetValue(typeof(T).FullName, out var entityTable))
            {
                entityTable = new Dictionary<TableKey, TableEntity>();
                _cache.Add(typeof(T).FullName, entityTable);
            }

            // Check for existence of entity
            var key = entity.AsKey();
            if (entityTable.TryGetValue(key, out var existingEntity))
            {
                throw new InvalidOperationException($"{typeof(T).Name} already exists with P:{entity.PartitionKey} / R:{entity.RowKey}");
            }

            // Just in case it isn't set
            entity.PartitionKey = key.PartitionKey;
            entity.RowKey = key.RowKey;

            entityTable.Add(key, entity);
        }

        public void PopulateEntities<T>(params T[] entities)
            where T : TableEntity
        {
            if ((entities?.Length ?? 0) > 0 )
            {
                foreach (var entity in entities)
                    PopulateEntity<T>(entity);
            }
        }

        public void PopulateEntities<T>(params string[] entityResources)
            where T : TableEntity
        {
            if ( (entityResources?.Length ?? 0) > 0 )
            {
                foreach ( var resource in entityResources )
                {
                    var entity = _resourceModule.ExtractManifestResource<T>(resource);
                    PopulateEntity<T>(entity);
                }
            }
        }

        public void DefineFailures(params TableStorageFailure[] failures)
        {
            if ((failures?.Length ?? 0) > 0)
            {
                foreach (var failure in failures)
                {
                    if (!_failures.TryGetValue(failure.EntityType.FullName, out var entityFailures))
                    {
                        entityFailures = new Dictionary<TableKey, TableStorageFailure>();
                        _failures.Add(failure.EntityType.FullName, entityFailures);
                    }

                    entityFailures.Add(failure.Key, failure);
                }
            }
        }

        public bool TryGetEntity<T>(TableKey key, out T entity)
            where T : TableEntity
        {
            entity = null;
            if (!_cache.TryGetValue(typeof(T).FullName, out var entityTable))
                return false;

            if (!entityTable.TryGetValue(key, out var tableEntity))
                return false;

            entity = (T)tableEntity;
            return true;
        }

        Task<bool> IAzureTableStorageClient.DeleteTableStorageAsync<T>(ITableEntity entity)
        {
            // Check for failures
            if ( _failures.TryGetValue(typeof(T).FullName, out var entityFailures))
            {
                if ( entityFailures.TryGetValue(entity.AsKey(), out var failure))
                {
                    if ( failure.FailType.HasFlag(FailTypeEnum.Delete) )
                    {
                        // Only exceptions are supported
                        throw failure.FailException?.WithLogging(Logger);
                    }
                }
            }

            if (!_cache.TryGetValue(typeof(T).FullName, out var entityTable))
                throw GenerateStorageException(TableStorageErrorCode.EntityNotFound, $"Entity {typeof(T).Name} has not been populated")
                    .WithLogging(Logger);

            var key = entity.AsKey();
            if (!entityTable.TryGetValue(key, out var existingEntity))
                throw GenerateStorageException(TableStorageErrorCode.EntityNotFound, $"Entity {typeof(T).Name} has not been populated")
                    .WithLogging(Logger);

            entityTable.Remove(key);
            return Task.FromResult(true);
        }

        Task<List<TResult>> IAzureTableStorageClient.GetAllAsync<TResult>(string filterCondition)
        { 
            // TODO: Add failure when implemented

            if (!_cache.TryGetValue(typeof(TResult).FullName, out var entityTable))
                throw GenerateStorageException(TableStorageErrorCode.EntityNotFound, $"Entity {typeof(TResult).Name} has not been populated")
                    .WithLogging(Logger);

            return Task.FromResult(entityTable.Values.Cast<TResult>().ToList());
        }

        Task<List<T>> IAzureTableStorageClient.GetPartitionAsync<T>(string filterCondition, int takeCount)
        {
            throw new NotImplementedException().WithLogging(Logger);
        }

        Task<T> IAzureTableStorageClient.GetSingleAsync<T>(string partitionKey, string rowKey)
        {
            // Check for failures
            if (_failures.TryGetValue(typeof(T).FullName, out var entityFailures))
            {
                if (entityFailures.TryGetValue(TableKey.Define(partitionKey, rowKey), out var failure))
                {
                    if (failure.FailType.HasFlag(FailTypeEnum.GetSingle))
                    {
                        // Only exceptions are supported
                        throw failure.FailException?.WithLogging(Logger);
                    }
                }
            }

            if (!_cache.TryGetValue(typeof(T).FullName, out var entityTable))
                throw GenerateStorageException(TableStorageErrorCode.EntityNotFound, $"Entity {typeof(T).Name} has not been populated")
                    .WithLogging(Logger);

            var key = new TableKey { PartitionKey = partitionKey, RowKey = rowKey };
            if (!entityTable.TryGetValue(key, out var entity))
                throw GenerateStorageException(TableStorageErrorCode.EntityNotFound, $"Entity not found for P:{partitionKey} / R:{rowKey}")
                    .WithLogging(Logger);

            // This is done to create a clone of the original
            return Task.FromResult((entity as T).Serialize().Deserialize<T>());
        }

        Task<bool> IAzureTableStorageClient.UpsertTableStorageAsync<T>(ITableEntity entity)
        {
            // Check for failures
            if (_failures.TryGetValue(typeof(T).FullName, out var entityFailures))
            {
                if (entityFailures.TryGetValue(entity.AsKey(), out var failure))
                {
                    if (failure.FailType.HasFlag(FailTypeEnum.Upsert))
                    {
                        // Only exceptions are supported
                        throw failure.FailException?.WithLogging(Logger);
                    }
                }
            }

            if (!_cache.TryGetValue(typeof(T).FullName, out var entityTable))
                throw GenerateStorageException(TableStorageErrorCode.EntityNotFound, $"Entity {typeof(T).Name} has not been populated")
                    .WithLogging(Logger);

            var key = entity.AsKey();
            if (!entityTable.TryGetValue(key, out var existingEntity))
                throw GenerateStorageException(TableStorageErrorCode.EntityNotFound, $"Entity not found for P:{entity.PartitionKey} / R:{entity.RowKey}")
                    .WithLogging(Logger);

            entityTable[key] = (TableEntity)entity;
            return Task.FromResult(true);
        }

        private StorageException GenerateStorageException(TableStorageErrorCode error, string message)
        {
            var attr = error.GetAttributeOfType<TableStorageErrorAttribute>();

            // Properties are internal and need to be set via reflection
            var result = new RequestResult()
            {
                HttpStatusCode = (int)attr.HttpStatusCode
            };


            return new StorageException(
                result
                    .SetInternalProperty(nameof(RequestResult.HttpStatusMessage), attr.ErrorMessage)
                    .SetInternalProperty(nameof(RequestResult.ErrorCode), error.ToString()),
                message,
                null
            );
        }
    }

    public static class MockTableStorgeClientExtensions
    {
        public static TableKey AsKey(this ITableEntity entity)
        {
            return new TableKey { PartitionKey = entity.PartitionKey, RowKey = entity.RowKey };
        }

        public static TableKey AsKey<T>(this T entity)
            where T : TableEntity
        {
            return new TableKey { PartitionKey = entity.PartitionKey, RowKey = entity.RowKey };
        }

        public static (TableKey Key, T Entity) WithKey<T>(this T entity, string partitionKey, string rowKey)
            where T : TableEntity
        {
            var key = new TableKey { PartitionKey = partitionKey, RowKey = rowKey };
            return (key, entity);
        }

        public static T WithLogging<T>(this T exception, ILogger logger)
            where T : Exception
        {
            logger.LogError(exception, exception.Message);
            return exception;
        }

        public static T SetInternalProperty<T>(this T entity, string property, object value)
        {
            var propInfo = typeof(T).GetProperty(property, BindingFlags.NonPublic | BindingFlags.Instance);
            propInfo?.SetValue(entity, value);
            return entity;
        }
    }
}
