﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DirectDebit.UnitTests
{
    public record TableKey
    {
        public static TableKey Define(string partitionKey, string rowKey)
            => new TableKey
            {
                PartitionKey = partitionKey,
                RowKey = rowKey
            };

        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
    }
}
