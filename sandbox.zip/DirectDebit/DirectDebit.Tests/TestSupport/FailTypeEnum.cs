﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DirectDebit.UnitTests
{
    [Flags]
    public enum FailTypeEnum
    {
        None = 0,
        GetSingle = 1,
        Upsert = 2,
        Delete = 4
    }
}
