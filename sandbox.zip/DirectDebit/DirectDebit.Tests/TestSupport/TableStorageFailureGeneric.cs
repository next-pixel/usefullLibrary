﻿using Microsoft.Azure.Cosmos.Table;
using Microsoft.Azure.WebJobs.ServiceBus;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DirectDebit.UnitTests
{
    public class TableStorageFailure<T> : TableStorageFailure
        where T : TableEntity
    {
        private TableStorageFailure(FailTypeEnum failType, TableKey key, Exception failException, Func<T, bool> condPredicate) 
            : base(typeof(T), failType, key, failException) 
        {
            ConditionalPredicate = condPredicate;
        }


        public static TableStorageFailure Define(FailTypeEnum failType, TableKey key, Exception failException, Func<T,bool> condPredicate = null)
        {
            return new TableStorageFailure<T>(failType, key, failException, condPredicate);
        }

        protected override bool ResolveConditional(TableEntity entity)
        {
            return ConditionalPredicate?.Invoke((T)entity)
                ?? true;
        }

        public Func<T, bool> ConditionalPredicate { get; private set; }
    }
}
