﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DirectDebit.UnitTests
{
    [AttributeUsage(AttributeTargets.Field, AllowMultiple =false)]
    public class TableStorageErrorAttribute : Attribute
    {
        public TableStorageErrorAttribute(HttpStatusCode httpStatusCode, string errorMessage)
        {
            HttpStatusCode = httpStatusCode;
            ErrorMessage = errorMessage;
        }

        public HttpStatusCode HttpStatusCode { get; private set; }
        public string ErrorMessage { get; private set; }
    }
}
