﻿using DirectDebitApi;
using Moq;
using Platform.Library.Authentication;
using Platform.Library.Authentication.Guards;
using Platform.Library.Authentication.Models.Abstractions;
using Platform.Library.Common.Standard.Mocking;
using Platform.Library.Testing.XUnit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DirectDebit.UnitTests
{
    public class MockGuardBuilder : IGuardBuilder
    {
        private readonly ContextModule _contextModule;
        private Mock<IMockAuthenticationContext> _context = null;

        public Func<string> AuthenticationContextCustomerId = () => null;

        internal MockGuardBuilder(ContextModule contextModule)
        {
            _contextModule = contextModule;
        }

        private IAuthenticationContext AuthenticationContext
        {
            get
            {
                if ( _context == null )
                {
                    _context = _contextModule.GetMock<IMockAuthenticationContext>();
                    _context.SetupGet(a => a.Temenos_cif).Returns(() => AuthenticationContextCustomerId.Invoke());
                }

                return _context.Object;
            }
        }
        public Task<IAuthenticationContext> Execute(CancellationToken? token = null, bool throwOnAuthenticationFailure = true, bool returnGenericErrorMessages = false)
        {
            return Task.FromResult(AuthenticationContext);
        }

        public IGuardBuilder WithGuard(GuardTask item)
        {
            throw new NotSupportedException("Not supported for unit tests");
        }

        public IGuardBuilder WithGuard(Func<IAuthenticationContext, bool> predicate, GuardTask item)
        {
            throw new NotImplementedException();
        }
    }
}
