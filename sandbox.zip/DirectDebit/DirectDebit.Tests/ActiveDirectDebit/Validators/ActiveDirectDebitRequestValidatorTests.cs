using DirectDebit.UnitTests.ActiveDirectDebit.Blueprint;
using DirectDebitApi.Validators;
using FluentAssertions;
using FluentAssertions.Execution;
using FluentValidation.TestHelper;
using Platform.Library.Testing.XUnit;
using Xunit;
using Xunit.Abstractions;

namespace DirectDebit.UnitTests.Validators
{
    [TestType(TestTypeEnum.UnitTest)]
    public class ActiveDirectDebitRequestValidatorTests : XUnitTestFixture
    {
        private readonly ActiveDirectDebitHandlerRequestValidator _validator;

        public ActiveDirectDebitRequestValidatorTests(ITestOutputHelper outputHelper,
            XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {
            _validator = new ActiveDirectDebitHandlerRequestValidator();
        }

        [Fact]
        public void InvalidRequestMissingArrangementId()
        {
            //Arrange
            var request = ActiveDirectDebitRequestFactory.GetValidationErrorRequest1();

            //Act
            var result = _validator.TestValidate(request);

            //Assert
            using (new AssertionScope())
            {
                result.IsValid.Should().Be(false);
                result.ShouldHaveValidationErrorFor(r => r.ArrangementId).WithErrorMessage("The request URL is missing the arrangementId");
                result.ShouldNotHaveValidationErrorFor(r => r.ActiveDirectDebit.AccountName);
                result.ShouldNotHaveValidationErrorFor(r => r.ActiveDirectDebit.AccountNumber);
                result.ShouldNotHaveValidationErrorFor(r => r.ActiveDirectDebit.BsbNumber);
                result.ShouldNotHaveValidationErrorFor(r => r.ActiveDirectDebit.DirectDebitId);
            }
        }

        [Fact]
        public void InvalidRequestMissingPropertyDirectDebitId()
        {
            //Arrange
            var request = ActiveDirectDebitRequestFactory.GetValidationErrorRequest2();

            //Act
            var result = _validator.TestValidate(request);

            //Assert
            using (new AssertionScope())
            {
                result.IsValid.Should().Be(false);
                result.ShouldHaveValidationErrorFor(r => r.ActiveDirectDebit.DirectDebitId);
                result.ShouldNotHaveValidationErrorFor(r => r.ActiveDirectDebit.AccountName);
                result.ShouldNotHaveValidationErrorFor(r => r.ActiveDirectDebit.AccountNumber);
                result.ShouldNotHaveValidationErrorFor(r => r.ActiveDirectDebit.BsbNumber);
                result.ShouldNotHaveValidationErrorFor(r => r.ArrangementId);
                result.ShouldNotHaveValidationErrorFor(r => r.TemenosCif);
            }
        }

        [Fact]
        public void InvalidRequestMissingCif()
        {
            //Arrange
            var request = ActiveDirectDebitRequestFactory.GetValidationErrorRequest3();

            //Act
            var result = _validator.TestValidate(request);

            //Assert
            using (new AssertionScope())
            {
                result.IsValid.Should().Be(false);
                result.ShouldNotHaveValidationErrorFor(r => r.ActiveDirectDebit.AccountName);
                result.ShouldNotHaveValidationErrorFor(r => r.ActiveDirectDebit.AccountNumber);
                result.ShouldNotHaveValidationErrorFor(r => r.ActiveDirectDebit.BsbNumber);
                result.ShouldNotHaveValidationErrorFor(r => r.ActiveDirectDebit.DirectDebitId);
                result.ShouldNotHaveValidationErrorFor(r => r.ArrangementId);
                result.ShouldHaveValidationErrorFor(r => r.TemenosCif).WithErrorMessage("Temenos Cif missing from context");
            }
        }

        [Fact]
        public void ValidRequest()
        {
            //Arrange
            var request = ActiveDirectDebitRequestFactory.GetDefaultHandlerRequest();

            //Act
            var result = _validator.TestValidate(request);

            //Assert
            using (new AssertionScope())
            {
                result.IsValid.Should().Be(true);
                result.ShouldNotHaveValidationErrorFor(r => r.ActiveDirectDebit.DirectDebitId);
                result.ShouldNotHaveValidationErrorFor(r => r.ActiveDirectDebit.AccountName);
                result.ShouldNotHaveValidationErrorFor(r => r.ActiveDirectDebit.AccountNumber);
                result.ShouldNotHaveValidationErrorFor(r => r.ActiveDirectDebit.BsbNumber);
                result.ShouldNotHaveValidationErrorFor(r => r.ArrangementId);
                result.ShouldNotHaveValidationErrorFor(r => r.TemenosCif);
            }
        }

        [Fact]
        public void EmptyRequestAndMissingPathParameters()
        {
            //Arrange
            var request = ActiveDirectDebitRequestFactory.GetValidationErrorRequest4();

            //Act
            var result = _validator.TestValidate(request);

            //Assert
            using (new AssertionScope())
            {
                result.IsValid.Should().Be(false);
                result.ShouldHaveValidationErrorFor(r => r.ActiveDirectDebit.DirectDebitId);
                result.ShouldHaveValidationErrorFor(r => r.ActiveDirectDebit.AccountName);
                result.ShouldHaveValidationErrorFor(r => r.ActiveDirectDebit.AccountNumber);
                result.ShouldHaveValidationErrorFor(r => r.ActiveDirectDebit.BsbNumber);
                result.ShouldHaveValidationErrorFor(r => r.ArrangementId);
                result.ShouldHaveValidationErrorFor(r => r.TemenosCif);
            }
        }

        [Fact]
        public void RequestObjectIsNull()
        {
            //Arrange
            var request = ActiveDirectDebitRequestFactory.GetValidationErrorRequest5();

            //Act
            var result = _validator.TestValidate(request);

            //Assert
            using (new AssertionScope())
            {
                result.IsValid.Should().Be(false);
                result.ShouldHaveValidationErrorFor(r => r.ActiveDirectDebit).WithErrorMessage("Active direct debit request is empty");
                result.ShouldHaveValidationErrorFor(r => r.ArrangementId);
                result.ShouldHaveValidationErrorFor(r => r.TemenosCif);
            }
        }
    }
}