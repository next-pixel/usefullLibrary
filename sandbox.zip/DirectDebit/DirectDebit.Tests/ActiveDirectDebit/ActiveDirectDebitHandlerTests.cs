using Autofac;
using AutoMapper;
using DirectDebit.UnitTests.ActiveDirectDebit.Blueprint;
using DirectDebit.UnitTests.Helpers;
using DirectDebitApi;
using DirectDebitApi.ActionHandlers;
using DirectDebitApi.Configuration;
using DirectDebitApi.Controllers;
using DirectDebitApi.Models;
using DirectDebitApi.Validators;
using FluentAssertions;
using FluentAssertions.Execution;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.FeatureManagement;
using Moq;
using Platform.Library.Authentication;
using Platform.Library.Authentication.Configuration;
using Platform.Library.Authentication.Guards;
using Platform.Library.Authentication.Models;
using Platform.Library.Authentication.Models.Abstractions;
using Platform.Library.Common;
using Platform.Library.Common.AspNetCore.Abstractions;
using Platform.Library.Common.Extensions;
using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.Communication.Extensions;
using Platform.Library.Events.Models;
using Platform.Library.Http;
using Platform.Library.Ods.Infrastructure.Data.DocumentDB.Client.Abstraction;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.Common.RequestDtos;
using Platform.Library.T24.SDK.DependencyInjection;
using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;
using Platform.Library.T24.SDK.Modules.Customer.ResponseDtos;
using Platform.Library.T24.SDK.Modules.DirectDebit.ResponseDtos;
using Platform.Library.T24.SDK.Modules.Entitlements.ResponseDtos;
using Platform.Library.T24.SDK.Modules.HomeLoan.Abstraction.ResponseDtos;
using Platform.Library.T24.SDK.Modules.HomeLoan.RequestDtos;
using Platform.Library.T24.SDK.Modules.Lookup.ResponseDtos;
using Platform.Library.Testing.XUnit;
using System.Collections.Specialized;
using System.Net;
using Xunit;
using Xunit.Abstractions;
using static DirectDebitApi.InternalConstants;

namespace DirectDebit.UnitTests.ActionHandlers
{
    [TestType(TestTypeEnum.UnitTest)]
    public class ActiveDirectDebitHandlerTests : XUnitTestFixture
    {
        private readonly DirectDebitApiController _directDebitApiController;
        private ContextModule Context => Module<ContextModule>();
        private ResourceModule Resource => Module<ResourceModule>();

        private const string Authorization = "Bearer sasbsabasbasbss";

        [ModuleInit(nameof(InitHttpModule))] private HttpModule Http => Module<HttpModule>();

        public ActiveDirectDebitHandlerTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) :
            base(outputHelper, classFixture)
        {
            _directDebitApiController = new DirectDebitApiController();
            _directDebitApiController.ControllerContext.HttpContext = new DefaultHttpContext()
            {
                Request =
                {
                    Headers =
                    {

                    }
                }
            };
        }
        protected override IEnumerable<string> AdditionalConfigurations => new List<string> { "test" };

        protected override void TestSetup()
        {
            Context.RegisterTypeAsInterfaces<Settings>();
            Context.RegisterTypeAsInterfaces<ActiveDirectDebitHandler>();
            Context.RegisterTypeAsInterfaces<HttpClientHelper>();
            Context.RegisterTypeAsInterfaces<ActiveDirectDebitHandlerRequestValidator>();

            Context.RegisterWithMsDi(services =>
            {
                services.RegisterLibrary<Startup>();
                services.RegisterT24Sdk(true);
                services.RegisterAutoMapperProfiles();
                services.RegisterAllValidators();
            });

            // Mock for Unit Tests
            Context.RegisterMockAsInterface<IStandardAuthorizationSettings>(SetupAuthorizationSettings);
            Context.RegisterMockAsInterface<IOdsDbClientFactory>();
            Context.RegisterMockAsInterface<IMockAuthenticationContext>(SetupAuthenticationContext);
            Context.RegisterMockAsInterface<IServiceBusEventPublisher>(SetupPublishEvent);
            Context.RegisterMockAsInterface<IFeatureManager>(SetupFeatureManager);

            // Delayed registration
            Context.RegisterContextMethodAsInterface<GuardBuilder, IGuardBuilder>(CreateGuardBuilder);
        }
        private Func<bool> FeatureMarketLaunch { get; set; } = () => false;

        private void SetupFeatureManager(Mock<IFeatureManager> featureManager)
        {
            featureManager.Setup(x => x.IsEnabledAsync(It.IsAny<string>())).ReturnsAsync((string func) => FeatureMarketLaunch.Invoke());
        }

        private static void SetupAuthorizationSettings(Mock<IStandardAuthorizationSettings> mock)
        {
            mock.Setup(x => x.CiamCertificateUrl).Returns("1");
            mock.Setup(x => x.AzureAdIssuer).Returns("2");
            mock.Setup(x => x.CiamSubscriptionKey).Returns("3");
        }

        private static GuardBuilder CreateGuardBuilder(IComponentContext context)
        {
            return new GuardBuilder(context.Resolve<IMockAuthenticationContext>(),
                context.Resolve<ILogger<AuthenticationContext>>());
        }

        private static void SetupAuthenticationContext(Mock<IMockAuthenticationContext> mock)
        {
            mock.Setup(x => x.RawJwtToken).Returns(Authorization);
            mock.Setup(x => x.Temenos_cif).Returns("123456");
        }

        private void SetupPublishEvent(Mock<IServiceBusEventPublisher> mock)
        {
            mock.Setup(a => a.CreateAndPublishEvent(ServiceBus.EV52CancelDirectDebitTopic, It.IsAny<EV52CancelDirectDebitEvent>(), null))
                .ReturnsAsync(true);
        }

        private void InitHttpModule()
        {
            Http.HandleMockRequestEvent += HttpModule_HandleMockRequestEvent;
        }

        private void HttpModule_HandleMockRequestEvent(object sender, HttpRequestEventArgs args)
        {
            var id = args.RequestMessage.RequestUri.AbsolutePath.Split("/").Last();
            var path = args.RequestMessage.RequestUri.AbsolutePath;
            NameValueCollection queryParams = null;

            switch (args.Method.ToString())
            {
                case TestConstants.HttpMethods.Put:
                    SetupHomeLoanSettlementEndPoint(args, path);
                    break;
                case TestConstants.HttpMethods.Post:
                    if (path.Contains("/product/loans/redraw/charges/auto/AA21328V0HVY"))
                    {
                        args.SetResponse(HttpStatusCode.OK, Resource.ExtractManifestResource<T24RequestPayload<T24AutoSettleChargesRequestDto>>("Success"), new Dictionary<string, string>());
                    }
                    else if (path.Contains("/product/loans/redraw/charges/auto/AA21328V0HVZ"))
                    {
                        args.SetResponse(HttpStatusCode.InternalServerError, new Dictionary<string, string>());
                    }
                    else
                    {
                        var response = Resource.ExtractManifestResource<T24CreateDirectDebitResponseDto>(id);
                        args.SetResponse(HttpStatusCode.OK, response,
                            new Dictionary<string, string>());
                    }
                    break;
                case TestConstants.HttpMethods.Get:
                    if (args.TryParseAfterRequestPath(T24SdkConstants.T24Paths.EntitlementsCheck, out _))
                    {
                        args.SetResponse(HttpStatusCode.OK, Resource.ExtractManifestResource<T24EntitlementsResponseDto>("ActiveDirectDebit.Success"), new Dictionary<string, string>());
                    }
                    else if (args.TryParseRequestPathQueryParameters(T24SdkConstants.T24Paths.GetAccountDetails, out queryParams))
                    {
                        var accountDetailsResponse = Resource.ExtractManifestResource<T24AccountDetailResponseDto>(queryParams.Get("arrangementId"));
                        args.SetResponse(HttpStatusCode.OK, accountDetailsResponse, new Dictionary<string, string>());
                    }
                    else if (args.TryParseRequestPathQueryParameters(T24SdkConstants.T24Paths.GetDirectDebitAccounts, out queryParams))
                    {
                        var ofiResponse = Resource.ExtractManifestResource<T24GetDirectDebitAccountResponseDto>(queryParams.Get("customerId"));
                        args.SetResponse(HttpStatusCode.OK, ofiResponse, new Dictionary<string, string>());
                    }
                    else if (args.TryParseAfterRequestPath(T24SdkConstants.T24Paths.GetCustomerProfile, out _))
                    {
                        args.SetResponse(HttpStatusCode.OK, Resource.ExtractManifestResource<T24GetCustomerProfileResponseDto>("123"), new Dictionary<string, string>());
                    }
                    else if (args.TryParseAfterRequestPath(T24SdkConstants.T24Paths.InstitutionName, out _))
                    {
                        args.SetResponse(HttpStatusCode.OK, Resource.ExtractManifestResource<T24InstitutionsNameResponseDto>("062-903"), new Dictionary<string, string>());
                    }
                    else
                    {
                        args.SetResponse(HttpStatusCode.InternalServerError, new Dictionary<string, string>());

                    }
                    break;
                default:
                    throw new NotSupportedException($"{args.Method.ToString().ToUpper()}[{args.RequestPath.AbsoluteUri}] Not supported by {nameof(HttpModule_HandleMockRequestEvent)}");
            }
        }

        private void SetupHomeLoanSettlementEndPoint(HttpRequestEventArgs args, string path)
        {
            if (path.Contains("/order/directdebits/"))
            {
                args.SetResponse(HttpStatusCode.OK, new Dictionary<string, string>());
            }
            else if (path.Contains("/product/loans/settlement/"))
            {
                args.SetResponse(HttpStatusCode.OK, Resource.ExtractManifestResource<T24UpdateHLSettlementResponseDto>("Success"), new Dictionary<string, string>());
            }
            else
            {
                args.SetResponse(HttpStatusCode.InternalServerError, new Dictionary<string, string>());
            }
        }

        public static IEnumerable<object[]> VerifyErrorCodesMemberData =>
            new[]
            {
               new object[]
                  {
                     "333333",
                     "AA21328V0BAD",
                     ActiveDirectDebitRequestFactory.GetBadRequest_AlreadyUsed(),
                     StatusCodes.Status400BadRequest,
                     InternalConstants.Error.DirectDebitInUseException,
                     false
                  },
               new object[]
                  {
                     "222222",
                     "AA21328V0HVY",
                     ActiveDirectDebitRequestFactory.GetFailedRequest(),
                     StatusCodes.Status400BadRequest,
                     InternalConstants.Error.DirectDebitNotActiveException,
                     false
                  },
               new object[]
                  {
                     "123456",
                     "AA21328V0HVY",
                     ActiveDirectDebitRequestFactory.GetFailedRequest(),
                     StatusCodes.Status400BadRequest,
                     InternalConstants.Error.DirectDebitDetailsDoNotMatch,
                     false
                  },
                new object[]
                  {
                     "1234567",
                     "AA21328V0HVZ",
                     ActiveDirectDebitRequestFactory.GetFailedRequest(),
                     StatusCodes.Status500InternalServerError,
                     InternalConstants.Error.AutoSettleChargeFailedErrorCode,
                     false
                  },
                new object[]
                  {
                     "123456",
                     "AA21328V0HVX",
                     ActiveDirectDebitRequestFactory.GetDefaultRequest(),
                     StatusCodes.Status400BadRequest,
                     CommonMessageConstants.BadInputDataErrorCode,
                     true
                  },
            };

        [Theory]
        [MemberData(nameof(VerifyErrorCodesMemberData))]
        public async Task CreateActiveDirectDebit_Response_BadRequest_Verify_Error_Codes(string cif, string arrangementId, ActiveDirectDebitRequest request, int status, string errorCode, bool isHLMarketLaunchFlag)
        {
            // Arrange
            var context = new Mock<IMockAuthenticationContext>();
            context.SetupGet(a => a.Temenos_cif).Returns(cif);

            var guardBuilder = new Mock<IGuardBuilder>();
            guardBuilder.Setup(v => v.Execute(It.IsAny<CancellationToken>(), It.IsAny<bool>(), It.IsAny<bool>()))
                .ReturnsAsync(context.Object);
            guardBuilder.Setup(v => v.WithGuard(It.IsAny<Func<IAuthenticationContext, bool>>(), It.IsAny<GuardTask>()))
                .Returns(new GuardBuilder(It.IsAny<IStandardAuthorizationSettings>(), context.Object, It.IsAny<ILogger<AuthenticationContext>>()));

            var standardGuards = new Mock<IStandardAuthorisationGuards>();

            FeatureMarketLaunch = () => isHLMarketLaunchFlag;

            // Act
            var error = async () =>
                await _directDebitApiController.CreateActiveDirectDebit(
                    Authorization,
                    request,
                    guardBuilder.Object,
                    standardGuards.Object,
                    Context.Resolve<IActionHandler<ActiveDirectDebitComposite, ActiveDirectDebitResponse>>(),
                    Context.Resolve<ILogger<DirectDebitApiController>>(),
                    arrangementId,
                    CancellationToken.None
                    );

            // Assert
            using (new AssertionScope())
            {
                await error
                .Should()
                .ThrowAsync<StandardApiException>()
                .Where(e => e.HttpStatusCode == status)
                .Where(e => e.ErrorMessage.MessageCode == errorCode);
            }
        }

        public static IEnumerable<object[]> CancelActiveDirectDebitMemberData =>
            new[]
            {
                new object[]
                {
                    "AA21328V0HVY",
                    Times.AtLeastOnce()
                    },
                new object[]
                {
                    "AA21328V0HVV",
                    Times.Never()
                }
            };

        [Theory]
        [MemberData(nameof(CancelActiveDirectDebitMemberData))]
        public async Task ActiveDirectDebit_Success_ReturnsNoContent_WhenDirectDebitIsCancelledForExternal_VerifyServiceBusEventDispatch(string arrangementId, Times invocation)
        {
            // Arrange
            var request = ActiveDirectDebitRequestFactory.GetDefaultRequest();

            var standardGuards = new Mock<IStandardAuthorisationGuards>();

            // Act
            var result = await _directDebitApiController.CreateActiveDirectDebit(
                Authorization,
                request,
                Context.Resolve<IGuardBuilder>(),
                standardGuards.Object,
                Context.Resolve<IActionHandler<ActiveDirectDebitComposite, ActiveDirectDebitResponse>>(),
                Context.Resolve<ILogger<DirectDebitApiController>>(),
                arrangementId,
                CancellationToken.None
                );

            // Assert
            using (new AssertionScope())
            {
                result.Should().BeOfType<NoContentResult>();
                Context.GetMock<IServiceBusEventPublisher>().Verify(
                mock => mock.CreateAndPublishEvent(ServiceBus.EV52CancelDirectDebitTopic, It.IsAny<EV52CancelDirectDebitEvent>(), null),
                invocation);
            }
        }
    }
}