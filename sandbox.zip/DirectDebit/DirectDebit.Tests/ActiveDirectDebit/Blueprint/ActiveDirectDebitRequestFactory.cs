﻿using Azure.Core;
using DirectDebitApi.Models;
using System.Threading;
using System;

namespace DirectDebit.UnitTests.ActiveDirectDebit.Blueprint
{
    public static class ActiveDirectDebitRequestFactory
    {
        public static ActiveDirectDebitRequest GetDefaultRequest()
        => new ActiveDirectDebitRequest
        {
            DirectDebitId = "1996458535.1",
            AccountNumber = "839645855",
            AccountName = "Comm Bank Offset",
            BsbNumber = "122-771"
        };

        public static ActiveDirectDebitRequest GetFailedRequest()
        => new ActiveDirectDebitRequest
        {
            DirectDebitId = "654.1",
            AccountNumber = "10006018",
            AccountName = "Comm Bank Offset",
            BsbNumber = "062009",
        };

        public static ActiveDirectDebitRequest GetBadRequest_AlreadyUsed()
       => new ActiveDirectDebitRequest
       {
           DirectDebitId = "5465132165.1",
           AccountNumber = "839645855",
           AccountName = "Comm Bank Offset",
           BsbNumber = "122-771",
       };

        public static ActiveDirectDebitComposite GetDefaultHandlerRequest()
        => new ActiveDirectDebitComposite
        {
            ActiveDirectDebit = new ActiveDirectDebitRequest
            {
                DirectDebitId = "1996458535.1",
                AccountNumber = "10006018",
                AccountName = "Comm Bank Offset",
                BsbNumber = "062009",
            },
            ArrangementId = "AA21328V0HVY",
            TemenosCif = "12345",
        };

        public static ActiveDirectDebitComposite GetValidationErrorRequest1()
        => new ActiveDirectDebitComposite
        {
            ActiveDirectDebit = new ActiveDirectDebitRequest
            {
                DirectDebitId = "1996458535.1",
                AccountNumber = "10006018",
                AccountName = "Comm Bank Offset",
                BsbNumber = "062009",
            },
            ArrangementId = "",
            TemenosCif = "12345",
        };

        public static ActiveDirectDebitComposite GetValidationErrorRequest2()
        => new ActiveDirectDebitComposite
        {
            ActiveDirectDebit = new ActiveDirectDebitRequest
            {
                AccountName = "Comm Bank Offset",
                AccountNumber = "10006018",
                BsbNumber = "062009"
            },
            ArrangementId = "AA21328V0HVY",
            TemenosCif = "12345",
        };

        public static ActiveDirectDebitComposite GetValidationErrorRequest3()
         => new ActiveDirectDebitComposite
         {
             ActiveDirectDebit = new ActiveDirectDebitRequest
             {
                 AccountName = "Comm Bank Offset",
                 DirectDebitId = "1996458535.1",
                 AccountNumber = "10006018",
                 BsbNumber = "062009",
             },
             ArrangementId = "AA21328V0HVY",
         };

        public static ActiveDirectDebitComposite GetValidationErrorRequest4()
        => new ActiveDirectDebitComposite
        { ActiveDirectDebit = new ActiveDirectDebitRequest() };

        public static ActiveDirectDebitComposite GetValidationErrorRequest5()
        => new ActiveDirectDebitComposite
        { ActiveDirectDebit = null };
    }
}
