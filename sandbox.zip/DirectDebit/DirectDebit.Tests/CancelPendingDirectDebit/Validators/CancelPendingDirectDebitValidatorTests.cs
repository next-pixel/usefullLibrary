﻿using DirectDebitApi;
using DirectDebitApi.Configuration;
using DirectDebitApi.Extensions;
using DirectDebitApi.Models;
using DirectDebitApi.Validators;
using FluentAssertions;
using FluentAssertions.Execution;
using FluentValidation.TestHelper;
using Platform.Library.Common;
using Platform.Library.Common.Extensions;
using Platform.Library.Testing.XUnit;
using Xunit;
using Xunit.Abstractions;

namespace DirectDebit.UnitTests.Validators
{
    [TestType(TestTypeEnum.UnitTest)]
    public class CancelPendingDirectDebitValidatorTests : XUnitTestFixture
    {
        public CancelPendingDirectDebitValidatorTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture) { }

        private ContextModule Context => Module<ContextModule>();

        protected override void TestSetup()
        {
            Context.RegisterWithMsDi(services =>
            {
                services.RegisterLibrary<Startup>();
                services.RegisterAllValidators();
            });
        }

        [Theory]
        [InlineData("123512352.2", "", false, 1)]
        [InlineData("123512352.1", "1234", true, 0)]
        [InlineData(null, null, false, 2)]
        [InlineData("", "", false, 2)]
        [InlineData("", "1234", false, 1)]
        public async Task InvalidRequest(string directDebitId, string customerId, bool expectedValid, int expectedErrors)
        {
            //Arrange
            var request = new CancelPendingDirectDebitRequest()
            {
                DirectDebitId = directDebitId,
                CustomerId = customerId
            };

            //Act
            var result = await Context.Resolve<IValidationResolver>().ValidateAsync(request, CancellationToken.None);

            //Assert
            using (new AssertionScope())
            {
                result.IsValid.Should().Be(expectedValid);
                result.Errors.Should().HaveCount(expectedErrors);
            }
        }
    }
}
