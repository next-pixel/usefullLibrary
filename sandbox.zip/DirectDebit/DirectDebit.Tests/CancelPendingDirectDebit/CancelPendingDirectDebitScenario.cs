﻿using Microsoft.Azure.Documents;
using Platform.Library.AzureStorage.Entities;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.Modules.DirectDebit.ResponseDtos;
using Platform.Library.Testing;
using Platform.Library.Testing.XUnit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace DirectDebit.UnitTests
{
    public class CancelPendingDirectDebitScenario : TestScenario
    {
        public CancelPendingDirectDebitScenario(string key, string name = null, string description = null) : base(key, name ?? key, description ?? key) { }

        public string DirectDebitId { get; set; }
        public string CustomerId { get; set; }

        public string[] PreloadedEntities { get; set; } = new[] { "Valid", "1002942977.1" };

        public TableStorageFailure[] TableStorageFailures { get; set; } = null;

        public override bool HandleHttpRequests => true;
        public Func<CancelPendingDirectDebitScenario, ResourceModule, HttpRequestEventArgs, bool> HandleMockHttpRequestEvents { get; set; } = (s, r, a) => false;

        protected override void HandleMockHttpRequestEventsHook(ResourceModule resources, HttpRequestEventArgs args)
        {
            if (!HandleMockHttpRequestEvents.Invoke(this, resources, args))
            {

                switch (args.ClientName)
                {
                    case T24SdkConstants.HttpClient.T24:

                        if (args.Method == HttpMethod.Get)
                        {
                            if (args.TryParseRequestPathQueryParameters(T24SdkConstants.T24Paths.GetDirectDebitAccounts, out var queryParameters))
                            {
                                args.SetResponse(HttpStatusCode.OK, resources.ExtractManifestResource<T24GetDirectDebitAccountResponseDto>(queryParameters["customerId"]), new Dictionary<string, string>());
                                return;
                            }
                        }
                        else if (args.Method == HttpMethod.Put)
                        {
                            if (args.TryParseAfterRequestPath(T24SdkConstants.T24Paths.UpdateDirectDebit, out var debitCardId))
                            {
                                args.SetResponse(HttpStatusCode.OK, resources.ExtractManifestResource<T24UpdateDirectDebitResponseDto>(debitCardId.EqualsIgnoreCase("1002942977.1") ? "Success" : debitCardId), new Dictionary<string, string>());
                                return;
                            }
                        }
                        break;
                }

                throw new NotSupportedException();
            }
        }

        public int ExpectedStatusCode { get; set; }
    }
}
