﻿using Autofac;
using AutoMapper;
using DirectDebitApi;
using DirectDebitApi.ActionHandlers;
using DirectDebitApi.Clients;
using DirectDebitApi.Configuration;
using DirectDebitApi.Controllers;
using DirectDebitApi.Models;
using DirectDebitApi.Validators;
using FluentAssertions;
using FluentAssertions.Execution;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using Platform.Library.Authentication.Configuration;
using Platform.Library.Authentication.Guards;
using Platform.Library.Authentication.Models;
using Platform.Library.Authentication.Models.Abstractions;
using Platform.Library.AzureStorage.Clients.Abstraction;
using Platform.Library.AzureStorage.Entities;
using Platform.Library.Common;
using Platform.Library.Common.AspNetCore.Abstractions;
using Platform.Library.Common.Extensions;
using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.Http;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.DependencyInjection;
using Platform.Library.T24.SDK.Modules.DirectDebit.ResponseDtos;
using Platform.Library.T24.SDK.Modules.Entitlements.ResponseDtos;
using Platform.Library.Testing.XUnit;
using Polly;
using System.Collections.Specialized;
using System.Net;
using Xunit;
using Xunit.Abstractions;
using static DirectDebitApi.InternalConstants.TableStorage;

namespace DirectDebit.UnitTests.ActionHandlers
{
    [TestType(TestTypeEnum.UnitTest)]
    public class CancelPendingDirectDebitHandlerTests : XUnitTestFixture
    {
        private ContextModule Context => Module<ContextModule>();
        private ResourceModule Resource => Module<ResourceModule>();
        private HttpModule Http => Module<HttpModule>();

        public CancelPendingDirectDebitHandlerTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture) { }

        protected override IEnumerable<string> AdditionalConfigurations => new List<string> { "test" };

        protected override void TestSetup()
        {
            Context.RegisterTypeAsInterfaces<Settings>();

            Context.RegisterWithMsDi(services =>
            {
                services.RegisterLibrary<Startup>();
                services.AddSingleton<IActionHandler<CancelPendingDirectDebitRequest, bool>, CancelPendingDirectDebitHandler>();

                services.RegisterT24Sdk(true);

                services
                    .RegisterAllValidators()
                    .RegisterAutoMapperProfiles();
            });

            //Context.RegisterTypeAsInterfaces<CancelPendingDirectDebitHandler>();

            // Mock for Unit Tests
            Context.RegisterMockAsInterface<IStandardAuthorizationSettings>(TestExtensions.SetupAuthorizationSettings);

            Context.RegisterMockTableStorage(Resource);
            Context.RegisterGuardBuilderAndContext();
        }

        private MockGuardBuilder MockGuardBuilder => Context.GetMockGuardBuilder();
        private MockTableStorageClient MockTableStorageClient => Context.GetMockTableStorageClient();

        public static TestScenarios<CancelPendingDirectDebitScenario> VariousScenarios => CancelPendingDirectDebitScenarios.VariousScenarios;

        [Theory]
        [MemberData(nameof(VariousScenarios))]
        public async Task CancelPendingDirectDebit_VariousResults(string key, CancelPendingDirectDebitScenario testScenario)
        {
            // Arrange
            SetTestScenario(nameof(VariousScenarios), key);
            MockGuardBuilder.AuthenticationContextCustomerId = () => testScenario.CustomerId;
            MockTableStorageClient.PopulateEntities<DirectDebitEntity>(testScenario.PreloadedEntities);
            MockTableStorageClient.DefineFailures(testScenario.TableStorageFailures);

            // Act
            Exception actualException = null;
            NoContentResult actualResponse = null;
            try
            {
                actualResponse = await new DirectDebitApiController().CancelPendingDirectDebit(
                    Context.Resolve<IActionHandler<CancelPendingDirectDebitRequest, bool>>(),
                    Context.Resolve<ILogger<DirectDebitApiController>>(),
                    Context.Resolve<IGuardBuilder>(),
                    testScenario.DirectDebitId,
                    CancellationToken.None) as NoContentResult;
            }
            catch ( Exception ex )
            {
                actualException = ex;
            }

            // Assert
            using ( new AssertionScope() )
            {
                if (testScenario.ExpectedStatusCode == 204)
                {
                    actualException.Should().BeNull();
                    actualResponse.Should().NotBeNull();
                }
                else
                {
                    actualException.Should().BeOfType<StandardApiException>();
                    if ( actualException is StandardApiException stdEx )
                    {
                        stdEx.HttpStatusCode.Should().Be(testScenario.ExpectedStatusCode, $"with message of {stdEx.ErrorMessage.UserMessageText}");
                    }
                    actualResponse.Should().BeNull();
                }
            }
        }
    }
}