﻿using Microsoft.Azure.Documents;
using Platform.Library.AzureStorage.Entities;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.Modules.DirectDebit.ResponseDtos;
using Platform.Library.Testing;
using Platform.Library.Testing.XUnit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace DirectDebit.UnitTests
{
    public static class CancelPendingDirectDebitScenarios
    {
        public static TestScenarios<CancelPendingDirectDebitScenario> VariousScenarios => TestScenarios<CancelPendingDirectDebitScenario>.Define(

            // POSITIVE 1 : SUCCESS
            new CancelPendingDirectDebitScenario("Success", "POSITIVE 1: Success", "Good path test")
            {
                DirectDebitId = "1002942977.1",
                CustomerId = "SUCCESS",
                ExpectedStatusCode = (int)HttpStatusCode.NoContent
            },

            // NEGATIVE 1 : Missing Request Data
            new CancelPendingDirectDebitScenario("MissingRequestData", "NEGATIVE 1 : Missing Request Data", "Testing the validator fails")
            {
                DirectDebitId = "",
                CustomerId = "SUCCESS",

                ExpectedStatusCode = (int)HttpStatusCode.BadRequest
            },

            // NEGATIVE 2 : Direct Debit missing
            new CancelPendingDirectDebitScenario("NoDirectDebit", "NEGATIVE 2 : Direct Debit missing", "The Direct Debit cannot be found")
            {
                DirectDebitId = "NOT EXISTS",
                CustomerId = "SUCCESS",

                ExpectedStatusCode = (int)HttpStatusCode.NotFound
            },

            // NEGATIVE 3 : Direct Debit Active
            new CancelPendingDirectDebitScenario("DirectDebitActive", "NEGATIVE 3 : Direct Debit Active", "The Direct Debit is active and cant be cancelled")
            {
                DirectDebitId = "1002942978.2",
                CustomerId = "SUCCESS",

                ExpectedStatusCode = (int)HttpStatusCode.BadRequest
            },

            // NEGATIVE 4 : Not Exist Soft Delete
            new CancelPendingDirectDebitScenario("NotExistsSoftDelete", "NEGATIVE 4 : Not Exists Soft Delete", "Attempting to soft delete the direct debit from storage fails with not exists")
            {
                DirectDebitId = "1002942977.1",
                CustomerId = "SUCCESS",

                TableStorageFailures = new[]
                {
                    TableStorageFailure<DirectDebitEntity>.Define(FailTypeEnum.Upsert, "1002942977.1".AsDirectDebitKey(), new Exception("NotExistsSoftDelete"), d => !d.ActiveRecord)
                },

                ExpectedStatusCode = (int)HttpStatusCode.InternalServerError
            },

            // NEGATIVE 5 : Soft Delete Internal Error
            new CancelPendingDirectDebitScenario("SoftDeleteInternalError", "NEGATIVE 5 : Soft Delete Internal Error", "Attempting to soft delete causes an internal error")
            {
                DirectDebitId = "1002942977.1",
                CustomerId = "SUCCESS",

                TableStorageFailures = new[]
                {
                    TableStorageFailure<DirectDebitEntity>.Define(FailTypeEnum.Upsert, "1002942977.1".AsDirectDebitKey(), new Exception("SoftDeleteInternalError"))
                },

                ExpectedStatusCode = (int)HttpStatusCode.InternalServerError
            },

            // NEGATIVE 6 : Cancel in T24 fails
            new CancelPendingDirectDebitScenario("T24CancelFail", "NEGATIVE 6 : Cancel in T24 fails", "Cancelling the direct debit in T24 fails")
            {
                DirectDebitId = "1002942977.1",
                CustomerId = "SUCCESS",

                HandleMockHttpRequestEvents = (CancelPendingDirectDebitScenario scenario, ResourceModule resources, HttpRequestEventArgs args) =>
                {
                    switch (args.ClientName)
                    {
                        case T24SdkConstants.HttpClient.T24:

                            if (args.Method == HttpMethod.Get)
                            {
                                if (args.TryParseRequestPathQueryParameters(T24SdkConstants.T24Paths.GetDirectDebitAccounts, out var queryParameters))
                                {
                                    args.SetResponse(HttpStatusCode.OK, resources.ExtractManifestResource<T24GetDirectDebitAccountResponseDto>(queryParameters["customerId"]), new Dictionary<string, string>());
                                    return true;
                                }
                            }
                            else if (args.Method == HttpMethod.Put)
                            {
                                args.SetResponse(HttpStatusCode.InternalServerError);
                                return true;
                            }
                            break;
                    }

                    throw new NotSupportedException();
                },

                ExpectedStatusCode = (int)HttpStatusCode.InternalServerError
            },

            // NEGATIVE 7 : Hard Delete fails
            new CancelPendingDirectDebitScenario("HardDeleteFails", "NEGATIVE 7 : Hard Delete fails", "The final attempt to hard delete the direct debit from storage fails")
            {
                DirectDebitId = "1002942977.1",
                CustomerId = "SUCCESS",

                TableStorageFailures = new[]
                {
                    TableStorageFailure<DirectDebitEntity>.Define(FailTypeEnum.Delete, "1002942977.1".AsDirectDebitKey(), new Exception("HardDeleteFails"))
                },

                ExpectedStatusCode = (int)HttpStatusCode.NoContent
            },

            // NEGATIVE 8 : Restore Storage Internal Error
            new CancelPendingDirectDebitScenario("RestoreStorageInternalError", "NEGATIVE 8 : Restore Storage Internal Error", "Trying to restore the storage entity results in exception (second call!)")
            {
                DirectDebitId = "1002942977.1",
                CustomerId = "SUCCESS",

                TableStorageFailures = new[]
                {
                    TableStorageFailure<DirectDebitEntity>.Define(FailTypeEnum.Delete, "1002942977.1".AsDirectDebitKey(), new Exception("RestoreStorageInternalError"), d => d.ActiveRecord)
                },

                HandleMockHttpRequestEvents = (CancelPendingDirectDebitScenario scenario, ResourceModule resources, HttpRequestEventArgs args) =>
                {
                    switch (args.ClientName)
                    {
                        case T24SdkConstants.HttpClient.T24:

                            if (args.Method == HttpMethod.Get)
                            {
                                if (args.TryParseRequestPathQueryParameters(T24SdkConstants.T24Paths.GetDirectDebitAccounts, out var queryParameters))
                                {
                                    args.SetResponse(HttpStatusCode.OK, resources.ExtractManifestResource<T24GetDirectDebitAccountResponseDto>(queryParameters["customerId"]), new Dictionary<string, string>());
                                    return true;
                                }
                            }
                            else if (args.Method == HttpMethod.Put)
                            {
                                throw new Exception("UpdateDirectDebit");
                            }
                            break;
                    }

                    throw new NotSupportedException();
                },

                ExpectedStatusCode = (int)HttpStatusCode.InternalServerError
            }
        );
    }
}
