﻿using DirectDebitApi;
using DirectDebitApi.Clients;
using DirectDebitApi.Clients.Abstractions;
using DirectDebitApi.Configuration;
using DirectDebitApi.Models;
using FluentAssertions;
using FluentAssertions.Execution;
using Moq;
using Platform.Library.Common.Standard.Models.Abstractions;
using Platform.Library.Http;
using Platform.Library.Testing.XUnit;
using System.Net;
using Xunit;
using Xunit.Abstractions;

namespace DirectDebit.UnitTests.Clients
{
    [TestType(TestTypeEnum.UnitTest)]
    public class ConsentWorkflowClientTests : XUnitTestFixture
    {
        private ContextModule Context => Module<ContextModule>();

        private ModelModule Models => Module<ModelModule>();

        private ResourceModule Resource => Module<ResourceModule>();

        [ModuleInit(nameof(InitHttpModule))] private HttpModule Http => Module<HttpModule>();

        public ConsentWorkflowClientTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture)
            : base(outputHelper, classFixture)
        {
        }

        protected override IEnumerable<string> AdditionalConfigurations => new List<string> { "test" };

        protected override void TestSetup()
        {
            Context.RegisterWithMsDi(services =>
            {
                services.RegisterAllHttpClients(
                componentSectionName: InternalConstants.Configuration.Sections.DirectDebitApi,
                defaultHeaders: null,
                inDebug:
#if DEBUG
                    true
#else
                    false
#endif
                );
            });

            Context.RegisterTypeAsInterfaces<HttpClientHelper>();
            Context.RegisterTypeAsInterfaces<ConsentWorkflowClient>();
            Context.RegisterTypeAsInterfaces<Settings>();

            Context.RegisterMockAsInterface<IStandardHeaderModel>(SetupStandardHeaderModel);
        }

        private static void SetupStandardHeaderModel(Mock<IStandardHeaderModel> mock)
        {
            mock.Setup(x => x.Authorization).Returns("Authzzz");
            mock.Setup(x => x.RequestId).Returns("RequestId");
            mock.Setup(x => x.SendingSystemId).Returns("SendingSystemId");
            mock.Setup(x => x.SendingSystemVersion).Returns("SendingSystemVersion");
            mock.Setup(x => x.InitiatingSystemId).Returns("InitiatingSystemId");
            mock.Setup(x => x.InitiatingSystemVersion).Returns("InitiatingSystemVersion");
            mock.Setup(x => x.Timestamp).Returns(DateTimeOffset.Now);
        }

        private void InitHttpModule()
        {
            Http.HandleMockRequestEvent += HttpModule_HandleMockRequestEvent;
        }

        private void HttpModule_HandleMockRequestEvent(object sender, HttpRequestEventArgs args)
        {
            var getOperationalAttributesResponse = Resource.ExtractManifestResource<GetOperationalAttributesResponse>("True");
            args.SetResponse(HttpStatusCode.OK, getOperationalAttributesResponse,
                new Dictionary<string, string>());
        }

        [Fact]
        public async Task GetOperationalAttributes_Success()
        {
            // Arrange
            var consentWorkflowClient = Context.Resolve<IConsentWorkflowClient>();
            // Act
            var result = await consentWorkflowClient.GetOperationalAttributesAsync(Context.Resolve<IStandardHeaderModel>(), CancellationToken.None);

            // Assert
            using (new AssertionScope())
            {
                result.Should().BeOfType<GetOperationalAttributesResponse>();
                Models.Compare(result).Match.Should().BeTrue();
            }
        }
    }
}
