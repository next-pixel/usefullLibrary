﻿using Platform.Library.Authentication.Models.Abstractions;
using Platform.Library.Authentication.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DirectDebit.UnitTests
{
    /// <summary>
    /// This is required since the setter of TokenLevel is internal.
    /// During registration of guard build in unit test, it thorows<Method 'set_TokenLevel' in type 'Castle,Proxies,IMockAuthenticationContextProxy_11'>
    /// </summary>
    public interface IMockAuthenticationContext : IAuthenticationContext
    {
        public new TokenLevel TokenLevel { get; set; }
    }
}
