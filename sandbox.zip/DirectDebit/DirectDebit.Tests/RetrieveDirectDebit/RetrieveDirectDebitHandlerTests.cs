﻿using Autofac;
using AutoMapper;
using DirectDebitApi;
using DirectDebitApi.ActionHandlers;
using DirectDebitApi.Configuration;
using DirectDebitApi.Controllers;
using DirectDebitApi.Mappers;
using DirectDebitApi.Models;
using FluentAssertions;
using FluentAssertions.Execution;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Moq;
using Platform.Library.Authentication.Configuration;
using Platform.Library.Authentication.Guards;
using Platform.Library.Authentication.Models;
using Platform.Library.Authentication.Models.Abstractions;
using Platform.Library.Common.AspNetCore.Abstractions;
using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.Http;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.DependencyInjection;
using Platform.Library.T24.SDK.Modules.DirectDebit.ResponseDtos;
using Platform.Library.T24.SDK.Modules.Lookup.ResponseDtos;
using Platform.Library.Testing.XUnit;
using Polly;
using System.Collections.Specialized;
using System.Net;
using Xunit;
using Xunit.Abstractions;
using static Platform.Library.AzureStorage.Constants;

namespace DirectDebit.UnitTests.ActionHandlers
{
    [TestType(TestTypeEnum.UnitTest)]
    public class RetrieveDirectDebitHandlerTests : XUnitTestFixture
    {
        private readonly DirectDebitApiController _directDebitApiController;
        private ContextModule Context => Module<ContextModule>();
        private ModelModule Models => Module<ModelModule>();
        private ResourceModule Resource => Module<ResourceModule>();
        [ModuleInit(nameof(InitHttpModule))] private HttpModule Http => Module<HttpModule>();

        public RetrieveDirectDebitHandlerTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(
            outputHelper, classFixture)
        {
            _directDebitApiController = new DirectDebitApiController();
        }
        protected override IEnumerable<string> AdditionalConfigurations => new List<string> { "test" };

        protected override void TestSetup()
        {
            Context.RegisterTypeAsInterfaces<Settings>();
            Context.RegisterTypeAsInterfaces<RetrieveDirectDebitHandler>();
            Context.RegisterTypeAsInterfaces<HttpClientHelper>();
            Context.RegisterTypeAsInterfaces<AuthenticationContext>();
            Context.RegisterInstanceAsInterface<Mapper, IMapper>(CreateMapper());
            Context.RegisterInstanceAsInterface<MemoryCache, IMemoryCache>(new MemoryCache(new MemoryCacheOptions()));

            Context.RegisterWithMsDi(services =>
            {
                services.RegisterT24Sdk(true);
            });

            // Mock for Unit Tests
            Context.RegisterMockAsInterface<IStandardAuthorizationSettings>(SetupAuthorizationSettings);
            Context.RegisterMockAsInterface<IGuardBuilder>(m => SetupGuardBuilder(m, "abc"));
        }

        private void SetupGuardBuilder(Mock<IGuardBuilder> guardBuilder, string customerId)
        {
            var context = new Mock<IMockAuthenticationContext>();
            context.SetupGet(a => a.Temenos_cif).Returns(customerId);

            guardBuilder.Setup(v => v.Execute(It.IsAny<CancellationToken>(), It.IsAny<bool>(), It.IsAny<bool>()))
                .ReturnsAsync(context.Object);
        }

        private static Mapper CreateMapper()
        {
            // Automatically registering AutoMapper.Profiles
            var mapperConfig = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new RetrieveDirectDebitMapperProfile());
            });
            return (Mapper)mapperConfig.CreateMapper();
        }

        private static void SetupAuthorizationSettings(Mock<IStandardAuthorizationSettings> mock)
        {
            mock.Setup(x => x.CiamCertificateUrl).Returns("1");
            mock.Setup(x => x.AzureAdIssuer).Returns("2");
            mock.Setup(x => x.CiamSubscriptionKey).Returns("3");
        }

        private void InitHttpModule()
        {
            Http.HandleMockRequestEvent += HttpModule_HandleMockRequestEvent;
        }

        private void HttpModule_HandleMockRequestEvent(object sender, HttpRequestEventArgs args)
        {
            switch (args.ClientName)
            {
                case T24SdkConstants.HttpClient.T24:
                    if (args.Method == HttpMethod.Get)
                    {
                        if (args.TryParseRequestPathQueryParameters(T24SdkConstants.T24Paths.GetDirectDebitAccounts, out NameValueCollection queryParams))
                        {
                            args.SetResponse(HttpStatusCode.OK, GetDirectDebits(queryParams), new Dictionary<string, string>());
                        }
                        else if (args.TryParseRequestPathQueryParameters(T24SdkConstants.T24Paths.InstitutionName, out _))
                        {
                            args.SetResponse(HttpStatusCode.OK, GetInstitutionName(args.RequestMessage.Headers), new Dictionary<string, string>());
                        }
                        else
                        {
                            args.SetResponse(HttpStatusCode.InternalServerError, new Dictionary<string, string>());
                        }
                    }
                    break;
                default:
                    throw new NotSupportedException(
                        $"{args.Method.ToString().ToUpper()}[{args.RequestPath.AbsoluteUri}] Not supported by {nameof(HttpModule_HandleMockRequestEvent)}");
            }
        }

        private T24GetDirectDebitAccountResponseDto GetDirectDebits(NameValueCollection queryParams)
        {
            var status = queryParams.Get("status");
            var customerId = queryParams.Get("customerId");

            if (!status.IsNullOrWhiteSpace())
            {
                return Resource.ExtractManifestResource<T24GetDirectDebitAccountResponseDto>(status);
            }

            return Resource.ExtractManifestResource<T24GetDirectDebitAccountResponseDto>(customerId);
        }

        private T24InstitutionsNameResponseDto GetInstitutionName(System.Net.Http.Headers.HttpRequestHeaders headers)
        {
            var bsbNumber = headers.GetValues("BsbNo").FirstOrDefault();

            return Resource.ExtractManifestResource<T24InstitutionsNameResponseDto>(bsbNumber);
        }

        [Theory]
        [InlineData("PENDING")]
        [InlineData("ACTIVE")]
        [InlineData("CANCELLED")]
        public async void RetrieveDirectDebit_FilterStatus_Success(string status)
        {
            // Arrange
            Resource.ExtractManifestResource<RetrieveDirectDebitResponse>(status);

            // Act
            var result = await _directDebitApiController.RetrieveDirectDebits(
                Context.Resolve<IActionHandler<RetrieveDirectDebitRequest, RetrieveDirectDebitResponse>>(),
                Context.Resolve<ILogger<DirectDebitApiController>>(),
               Context.Resolve<IGuardBuilder>(),
               "",
               "",
               status,
                CancellationToken.None
            );

            // Assert
            Assert.True(Models.CompareActionResult<RetrieveDirectDebitResponse>(result).Match);
        }

        [Theory]
        [InlineData("123456", "123456SUCCESS")]
        public async void RetrieveDirectDebit_AccountIdFilter_Successful(string accountId, string customerId)
        {
            // Arrange
            Resource.ExtractManifestResource<RetrieveDirectDebitResponse>(accountId);
            Context.UpdateMockSetup<IGuardBuilder>(m => SetupGuardBuilder(m, customerId));

            // Act
            var result = await _directDebitApiController.RetrieveDirectDebits(
                Context.Resolve<IActionHandler<RetrieveDirectDebitRequest, RetrieveDirectDebitResponse>>(),
                Context.Resolve<ILogger<DirectDebitApiController>>(),
                Context.Resolve<IGuardBuilder>(),
                accountId,
                "",
                "",
                CancellationToken.None
            );

            // Assert
            Assert.True(Models.CompareActionResult<RetrieveDirectDebitResponse>(result).Match);
        }

        [Theory]
        [InlineData("1001NoDD", "ERROR")]
        public async void RetrieveDirectDebit_ShouldThrowAnError(string customerId, string directDebitId)
        {
            // Arrange
            Context.UpdateMockSetup<IGuardBuilder>(m => SetupGuardBuilder(m, customerId));

            // Act
            var error = async () => await _directDebitApiController.RetrieveDirectDebits(
                Context.Resolve<IActionHandler<RetrieveDirectDebitRequest, RetrieveDirectDebitResponse>>(),
                Context.Resolve<ILogger<DirectDebitApiController>>(),
               Context.Resolve<IGuardBuilder>(),
               "",
               directDebitId,
               string.Empty,
                CancellationToken.None
            );

            // Assert
            using (new AssertionScope())
            {
                await error
                .Should()
                .ThrowAsync<StandardApiException>()
                .Where(e => e.HttpStatusCode == StatusCodes.Status403Forbidden)
                .Where(e => e.ErrorMessage.MessageCode == CommonMessageConstants.AuthorisationRoleErrorCode)
                .Where(e => e.ErrorMessage.UserMessageText == CommonMessageConstants.AuthorisationRoleErrorUserMessageText);
            }
        }
    }
}