﻿using AutoMapper;
using DirectDebitApi;
using DirectDebitApi.Mappers;
using DirectDebitApi.Models;
using FluentAssertions;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Moq;
using Platform.Library.Authentication.Models.Abstractions;
using Platform.Library.T24.SDK.Modules.DirectDebit.RequestDtos;
using Platform.Library.Testing.XUnit;
using Xunit;
using Xunit.Abstractions;

namespace DirectDebit.UnitTests.Mappers
{
    [TestType(TestTypeEnum.UnitTest)]
    public class VerifyPendingDirectDebitMapperProfileTests : XUnitTestFixture
    {
        public VerifyPendingDirectDebitMapperProfileTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) :
            base(outputHelper, classFixture)
        {
        }

        private ResourceModule Resource => Module<ResourceModule>();
        private ContextModule Context => Module<ContextModule>();

        protected override void TestSetup()
        {
            Context.RegisterMockAsInterface<IMockAuthenticationContext>(SetupAuthenticationContext);
            Context.RegisterMapperAndProfiles(
                typeof(ActiveVerifyDirectDebitMapperProfile),
                typeof(T24UpdateLoanSettlementRequestDtoMapperProfile));
        }

        protected Func<string> ContextCustomerId = () => throw new NotImplementedException();
        private void SetupAuthenticationContext(Mock<IMockAuthenticationContext> mock)
        {
            mock.Setup(x => x.Temenos_cif).Returns(() => ContextCustomerId.Invoke());
        }

        [Fact]
        public void TestMappingProfileIsValid()
        {
            var mapper = Context.Resolve<IMapper>();

            mapper.ConfigurationProvider.AssertConfigurationIsValid();
        }

        [Theory]
        [InlineData("10001234", "1002942977.2")]
        public void Map_VerifyPendingDirectDebitHandlerRequest_To_VerifyDirectDebitRequest(string customerId, string directDebitId)
        {
            // Arrange
            var mapper = Context.Resolve<IMapper>();            
            var request = Resource.ExtractManifestResource<VerifyPendingDirectDebitRequest>(customerId);
            var expected = Resource.ExtractManifestResource<VerifyPendingDirectDebitHandlerRequest>(customerId);

            ContextCustomerId = () => customerId;
            var composite = VerifyDirectDebitComposite.Define(request, Context.Resolve<IMockAuthenticationContext>(), directDebitId);
            
            // Act
            var actual = mapper.Map<VerifyPendingDirectDebitHandlerRequest>(composite);

            // Assert
            actual.Should().BeEquivalentTo(expected);
        }

        [Theory]
        [InlineData("10001234")]
        public void Map_VerifyPendingDirectDebitHandlerRequest_To_T24UpdateDirectDebitRequest(string customerId)
        {
            // Arrange
            var mapper = Context.Resolve<IMapper>();
            var request = Resource.ExtractManifestResource<UpdateDirectDebitCompositeRequest>(customerId);
            var expected = Resource.ExtractManifestResource<UpdateDirectDebitRequest>(customerId);

            // Act
            var actual = mapper.Map<UpdateDirectDebitRequest>(request);

            // Assert
            actual.Should().BeEquivalentTo(expected);
        }
    }
}