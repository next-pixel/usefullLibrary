﻿using AutoMapper;
using DirectDebitApi;
using DirectDebitApi.Models;
using FluentAssertions;
using Microsoft.FeatureManagement;
using Moq;
using Platform.Library.Common;
using Platform.Library.T24.SDK.Common.RequestDtos;
using Platform.Library.T24.SDK.Modules.HomeLoan.RequestDtos;
using Platform.Library.Testing.XUnit;
using Xunit;
using Xunit.Abstractions;

namespace DirectDebit.UnitTests.Mappers
{
    [TestType(TestTypeEnum.UnitTest)]
    public class T24UpdateLoanSettlementRequestDtoMapperProfileTests : XUnitTestFixture
    {
        public T24UpdateLoanSettlementRequestDtoMapperProfileTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) :
            base(outputHelper, classFixture)
        {
        }

        private ContextModule Context => Module<ContextModule>();

        private ResourceModule Resource => Module<ResourceModule>();
        
        protected override void TestSetup()
        {
            Context.RegisterWithMsDi(services =>
            {
                services
                    .RegisterLibrary<Startup>()
                    .RegisterAutoMapperProfiles();
            });

            Context.RegisterMockAsInterface<IFeatureManager>(SetupFeatureManager);
        }

        private Func<bool> FeatureMarketLaunch { get; set; } = () => true;

        private void SetupFeatureManager(Mock<IFeatureManager> featureManager)
        {
            featureManager.Setup(x => x.IsEnabledAsync(It.IsAny<string>())).ReturnsAsync((string func) => FeatureMarketLaunch.Invoke());
        }

        [Fact]
        public void TestMappingProfileIsValid()
        {
            var mapper = Context.Resolve<IMapper>();

            mapper.ConfigurationProvider.AssertConfigurationIsValid();
        }

        [Theory]
        [InlineData("AA21328V0HVZ", "PaymentTypeList", true)]
        [InlineData("AA21328V0HVZ", "Valid", false)]
        public void T24UpdateLoanSettlementRequestDtoMapperProfile_Map_WhenRepaymentAccountNumberIsProvided(string requestJson, string expectedResponseJsonPath, bool isMarketLaunch)
        {
            // Arrange
            var mapper = Context.Resolve<IMapper>();

            var updateCompositeRequest = Resource.ExtractManifestResource<T24UpdateLoanSettlementCompositeRequest>(requestJson);
            var expected = Resource.ExtractManifestResource<T24RequestPayload<T24UpdateLoanSettlementRequestDto>>(expectedResponseJsonPath);

            FeatureMarketLaunch = () => isMarketLaunch;

            // Act
            var actual = mapper.Map<T24RequestPayload<T24UpdateLoanSettlementRequestDto>>(updateCompositeRequest);

            // Assert
            actual.Should().BeEquivalentTo(expected);
        }
    }
}