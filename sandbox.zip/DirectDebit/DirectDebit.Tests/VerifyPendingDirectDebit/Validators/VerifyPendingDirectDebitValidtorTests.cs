﻿using DirectDebitApi.Models;
using DirectDebitApi.Validators;
using FluentValidation.TestHelper;
using Platform.Library.Testing.XUnit;
using Xunit;
using Xunit.Abstractions;

namespace DirectDebit.UnitTests.Validators
{
    [TestType(TestTypeEnum.UnitTest)]
    public class VerifyPendingDirectDebitValidtorTests : XUnitTestFixture
    {
        private readonly VerifyPendingDirectDebitValidator _validator;

        public VerifyPendingDirectDebitValidtorTests(ITestOutputHelper outputHelper,
            XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {
            _validator = new VerifyPendingDirectDebitValidator();
        }

        [Fact]
        public void InvalidRequest()
        {
            //Arrange
            var request = new VerifyPendingDirectDebitHandlerRequest();

            //Act
            var result = _validator.TestValidate(request);

            //Assert
            result.ShouldHaveValidationErrorFor(r => r.CustomerId);
        }

        [Fact]
        public void InvalidRequest2()
        {
            //Arrange
            var request = new VerifyPendingDirectDebitHandlerRequest()
            {
            };

            //Act
            var result = _validator.TestValidate(request);

            //Assert
            result.ShouldHaveValidationErrorFor(r => r.VerificationCode);
            result.ShouldHaveValidationErrorFor(r => r.ArrangementId);
            result.ShouldHaveValidationErrorFor(r => r.DirectDebitId);
            result.ShouldHaveValidationErrorFor(r => r.ArrangementId);
            result.ShouldHaveValidationErrorFor(r => r.CustomerId);
        }

        [Fact]
        public void ValidRequest()
        {
            //Arrange
            var request = new VerifyPendingDirectDebitHandlerRequest
            {
                ArrangementId = "AA2122268J4B",
                DirectDebitId = "125123.1",
                CustomerId = "124",
                VerificationCode = "328294"
            };

            //Act
            var result = _validator.TestValidate(request);

            //Assert
            result.ShouldNotHaveValidationErrorFor(r => r.CustomerId);
            result.ShouldNotHaveValidationErrorFor(r => r.DirectDebitId);
            result.ShouldNotHaveValidationErrorFor(r => r.ArrangementId);
            result.ShouldNotHaveValidationErrorFor(r => r.VerificationCode);

            result.ShouldNotHaveValidationErrorFor(r => r.CustomerId);
        }
    }
}
