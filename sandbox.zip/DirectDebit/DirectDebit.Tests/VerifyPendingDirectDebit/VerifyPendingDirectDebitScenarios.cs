﻿using DirectDebitApi.Models;
using FluentAssertions;
using Platform.Library.AzureStorage.Entities;
using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.Events.Models;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.Common.RequestDtos;
using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;
using Platform.Library.T24.SDK.Modules.Customer.ResponseDtos;
using Platform.Library.T24.SDK.Modules.DirectDebit.ResponseDtos;
using Platform.Library.T24.SDK.Modules.Entitlements.ResponseDtos;
using Platform.Library.T24.SDK.Modules.HomeLoan.RequestDtos;
using Platform.Library.Testing;
using Platform.Library.Testing.XUnit;
using System.Net;
using Error = DirectDebitApi.InternalConstants.Error;

namespace DirectDebit.UnitTests
{
    public class VerifyPendingDirectDebitScenario : TestScenario
    {
        public VerifyPendingDirectDebitScenario(string key, string name = null, string description = null) : base(key, name ?? key, description ?? key) { }

        public string CustomerId { get; set; }
        public string VerificationCode { get; set; } = "925687";
        public string AccountNumber { get; set; } = "123412345";
        public string ArrangementId { get; set; } = "AA19280X6MN8";
        public string DirectDebitId { get; set; } = "12351231.1";

        public bool PositiveTest => (ExpectedStatusCode ?? (int)HttpStatusCode.InternalServerError) < 299 || string.IsNullOrWhiteSpace(ExpectedErrorCode);

        public int? ExpectedStatusCode { get; set; }
        public string ExpectedErrorCode { get; set; }
        public bool DirectDebitEntityShouldExist { get; set; } = false;
        public Action<DirectDebitEntity> AssertDirectDebitEntity { get; set; } = (entity) => { entity.Should().BeNull(); };

        public string[] PreloadedEntities { get; set; } = new[] { "12351231.1" };
        public TableStorageFailure[] TableStorageFailures { get; set; } = null;

        public string T24GetAccountDetailsResource { get; set; } = "Valid";
        public string T24GetEntitlementResponseResource { get; set; } = "VerifyPendingDd.Success";
        public string T24UpdateEntitlementResponseResource { get; set; } = "VerifyPendingDd.Success";
        public string T24GetCustomerProfileResponseResource { get; set; } = "SUCCESS";
        public string T24UpdateDirectDebitResponseResource { get; set; } = "Success";

        public string GetOperationalAttributesResource { get; set; } = "CHREPM";

        public bool HomeLoanMarketLaunchFeatureFlag { get; set; } = false;

        public override bool HandleHttpRequests => true;

        public Func<EV52CancelDirectDebitEvent, bool> HandlePublishCancelDirectDebit { get; set; } = (cancelEvent) => true;
        public Func<VerifyPendingDirectDebitScenario, ResourceModule, HttpRequestEventArgs, bool> HandleMockHttpRequestEvents { get; set; } = (s, r, a) => false;

        protected override void HandleMockHttpRequestEventsHook(ResourceModule resources, HttpRequestEventArgs args)
        {
            if (!HandleMockHttpRequestEvents.Invoke(this, resources, args))
            {
                switch (args.ClientName)
                {
                    case T24SdkConstants.HttpClient.T24:
                        if (args.Method == HttpMethod.Get)
                        {
                            if (args.TryParseRequestPathQueryParameters(T24SdkConstants.T24Paths.GetAccountDetails, out _))
                            {
                                args.SetResponse(HttpStatusCode.OK, resources.ExtractManifestResource<T24AccountDetailResponseDto>(T24GetAccountDetailsResource), null);
                                return;
                            }
                            else if (args.TryParseAfterRequestPath(T24SdkConstants.T24Paths.EntitlementsCheck, out _))
                            {
                                args.SetResponse(HttpStatusCode.OK, resources.ExtractManifestResource<T24EntitlementsResponseDto>(T24GetEntitlementResponseResource), null);
                                return;
                            }
                            else if (args.TryParseAfterRequestPath(T24SdkConstants.T24Paths.GetCustomerProfile, out _))
                            {
                                args.SetResponse(HttpStatusCode.OK, resources.ExtractManifestResource<T24GetCustomerProfileResponseDto>(T24GetCustomerProfileResponseResource), new Dictionary<string, string>());
                                return;
                            }
                        }
                        else if (args.Method == HttpMethod.Put)
                        {
                            if (args.TryParseAfterRequestPath(T24SdkConstants.T24Paths.UpdateSettlementInstructions, out var pathAndQuery))
                            {
                                args.SetResponse(HttpStatusCode.OK, resources.ExtractManifestResource<T24EntitlementsResponseDto>(T24UpdateEntitlementResponseResource), new Dictionary<string, string>());
                                return;
                            }
                            else if (args.TryParseAfterRequestPath(T24SdkConstants.T24Paths.UpdateDirectDebit, out _))
                            {
                                args.SetResponse(HttpStatusCode.OK, resources.ExtractManifestResource<T24UpdateDirectDebitResponseDto>(T24UpdateDirectDebitResponseResource), new Dictionary<string, string>());
                                return;
                            }                         
                        }
                        else if(args.Method == HttpMethod.Post)
                        {
                            if (args.RequestMessage.RequestUri.AbsolutePath.Contains("/product/loans/redraw/charges/auto"))
                            {
                                args.SetResponse(HttpStatusCode.OK, resources.ExtractManifestResource<T24RequestPayload<T24AutoSettleChargesRequestDto>>("Success"), new Dictionary<string, string>());
                                return;
                            }
                        }
                        break;

                    case DirectDebitApi.InternalConstants.HttpClients.ConsentWorkflow:
                        if (args.Method == HttpMethod.Get)
                        {
                            args.SetResponse(HttpStatusCode.OK, resources.ExtractManifestResource<GetOperationalAttributesResponse>(GetOperationalAttributesResource), new Dictionary<string, string>());
                            return;
                        }
                        break;
                }

                throw new NotSupportedException($"{args.Method.ToString().ToUpper()}[{args.RequestPath.AbsoluteUri}] Not supported by {nameof(HandleMockHttpRequestEventsHook)}");
            }
        }
    }

    public static class VerifyPendingDirectDebitScenarios
    {
        public static TestScenarios<VerifyPendingDirectDebitScenario> VariousScenarios => TestScenarios<VerifyPendingDirectDebitScenario>.Define(

        // POSITIVE 1 : SUCCESS
        new VerifyPendingDirectDebitScenario("Success", "POSITIVE 1: Success", "Good path test")
        {
            CustomerId = "SUCCESS",

            ExpectedStatusCode = (int)HttpStatusCode.OK
        },

        // POSITIVE 2 : Failed to publish Cancel Direct Debit event
        new VerifyPendingDirectDebitScenario("FailedPublishCancelDirectDebit", "POSITIVE 2: Failed to publish Cancel Direct Debit event", "When trying to publish the event to cancel a direct debit it fails")
        {
            CustomerId = "SUCCESS",

            HandlePublishCancelDirectDebit = (cancelEvent) => throw new Exception("Failed to publish"),

            ExpectedStatusCode = (int)HttpStatusCode.OK
        },

        // POSITIVE 3 : SUCCESS with consent
        new VerifyPendingDirectDebitScenario("SuccessWithConsent", "POSITIVE 3: Success with consent", "Good path test when consent is required")
        {
            CustomerId = "SUCCESS",

            T24GetAccountDetailsResource = "RequiresConsent",

            ExpectedStatusCode = (int)HttpStatusCode.OK
        },

        // POSITIVE 4 : SUCCESS with no matching Operational Attributes
        new VerifyPendingDirectDebitScenario("SuccessWithNoMatchingOperationalAttributes", "POSITIVE 4: Success with no matching Operational Attributes", "Good path test when the operational attributes retrieved dont match")
        {
            CustomerId = "SUCCESS",

            T24GetAccountDetailsResource = "RequiresConsent",
            GetOperationalAttributesResource = "NOT-CHREPM",

            ExpectedStatusCode = (int)HttpStatusCode.OK
        },

        // NEGATIVE 1 : Bad Request
        new VerifyPendingDirectDebitScenario("BadRequest", "NEGATIVE 1: Bad Request", "Fails the initial validation")
        {
            CustomerId = "SUCCESS",
            VerificationCode = "",
            AccountNumber = "",
            DirectDebitId = "12351231.1",
            ArrangementId = "",

            ExpectedStatusCode = (int)HttpStatusCode.BadRequest,
            ExpectedErrorCode = CommonMessageConstants.BadInputDataErrorCode,

            DirectDebitEntityShouldExist = true,
            AssertDirectDebitEntity = (entity) =>
            {
                entity.Should().NotBeNull();
                if (entity != null)
                {
                    entity.Attempts.Should().Be(0);         // Attempt should be reverted
                    entity.ActiveRecord.Should().BeTrue();  // Record should still be active
                }
            }
        },

        // NEGATIVE 2 : Failed to get entitlement check
        new VerifyPendingDirectDebitScenario("FailedEntitlement", "NEGATIVE 2: Failed Entitlement Check", "Failed to get the customer entitlement check")
        {
            CustomerId = "SUCCESS",

            ExpectedStatusCode = (int)HttpStatusCode.InternalServerError,
            ExpectedErrorCode = CommonMessageConstants.CommunicationsErrorCode,

            DirectDebitEntityShouldExist = true,
            AssertDirectDebitEntity = (entity) =>
            {
                entity.Should().NotBeNull();
                if (entity != null)
                {
                    entity.Attempts.Should().Be(0);         // Attempt should be reverted
                    entity.ActiveRecord.Should().BeTrue();  // Record should still be active
                }
            },

            HandleMockHttpRequestEvents = (VerifyPendingDirectDebitScenario scenario, ResourceModule resources, HttpRequestEventArgs args) =>
            {
                // When the Entitlement check fails
                if (args.ClientName.Equals(T24SdkConstants.HttpClient.T24) && args.Method == HttpMethod.Get && args.TryParseAfterRequestPath(T24SdkConstants.T24Paths.EntitlementsCheck, out _))
                    throw new Exception("Failed Entitlement Check");

                return false;
            }
        },

        // NEGATIVE 3 : Direct Debit mot found
        new VerifyPendingDirectDebitScenario("DirectDebitNotFound", "NEGATIVE 3: Direct Debit not found", "The direct debit is not in storage")
        {
            CustomerId = "SUCCESS",

            PreloadedEntities = null,

            ExpectedStatusCode = (int)HttpStatusCode.NotFound,
            ExpectedErrorCode = CommonMessageConstants.CommunicationsErrorCode
        },

        // NEGATIVE 4 : Failed retrieve from storage
        new VerifyPendingDirectDebitScenario("FailRetrieveFromStorage", "NEGATIVE 4: Failed retrieve from storage", "Failed to retrieve the DD from storage")
        {
            CustomerId = "SUCCESS",

            TableStorageFailures = new[]
            {
                TableStorageFailure<DirectDebitEntity>.Define(FailTypeEnum.GetSingle, "12351231.1".AsDirectDebitKey(), new Exception("Failed retrieve from storage"))
            },

            ExpectedStatusCode = (int)HttpStatusCode.InternalServerError,
            ExpectedErrorCode = CommonMessageConstants.CommunicationsErrorCode,

            DirectDebitEntityShouldExist = true,
            AssertDirectDebitEntity = (entity) =>
            {
                entity.Should().NotBeNull();
                if (entity != null)
                {
                    entity.Attempts.Should().Be(0);         // Attempt should be reverted
                    entity.ActiveRecord.Should().BeTrue();  // Record should still be active
                }
            }
        },

        // NEGATIVE 5 : Upsert on Attempts fails
        new VerifyPendingDirectDebitScenario("UpsertAttemptsFail", "NEGATIVE 5: Upsert on Attempts fails", "Failed to upsert the entity to set the number of attempts")
        {
            CustomerId = "SUCCESS",

            TableStorageFailures = new[]
            {
                TableStorageFailure<DirectDebitEntity>.Define(FailTypeEnum.Upsert, "12351231.1".AsDirectDebitKey(), new Exception("Failed to upsert attempts"))
            },

            ExpectedStatusCode = (int)HttpStatusCode.InternalServerError,
            ExpectedErrorCode = CommonMessageConstants.CommunicationsErrorCode,

            DirectDebitEntityShouldExist = true,
            AssertDirectDebitEntity = (entity) =>
            {
                entity.Should().NotBeNull();
                if (entity != null)
                {
                    entity.Attempts.Should().Be(0);         // Attempt should be reverted
                    entity.ActiveRecord.Should().BeTrue();  // Record should still be active
                }
            }
        },

        // NEGATIVE 6 : Fail Last Attempt
        new VerifyPendingDirectDebitScenario("FailLastAttempt", "NEGATIVE 6: Fail Last Attempt", "You fail your last attempt")
        {
            CustomerId = "SUCCESS",
            VerificationCode = "BADCODE",
            DirectDebitId = "12351231.2",
            PreloadedEntities = new[] { "12351231.2" },

            ExpectedStatusCode = (int)HttpStatusCode.Forbidden,
            ExpectedErrorCode = Error.Codes.MaxAttemptsExceeded
        },

        // NEGATIVE 7 : Maximum Attempts already exceeded
        new VerifyPendingDirectDebitScenario("MaximumAttemptsAlreadyExeeded", "NEGATIVE 7: Maximum Attempts already exceeded", "You enter in with the number of attempts already exceeded")
        {
            CustomerId = "SUCCESS",
            DirectDebitId = "12351231.3",
            PreloadedEntities = new[] { "12351231.3" },

            ExpectedStatusCode = (int)HttpStatusCode.Forbidden,
            ExpectedErrorCode = Error.Codes.MaxAttemptsExceeded
        },

        // NEGATIVE 8 : Failed Verification Code
        new VerifyPendingDirectDebitScenario("FailedVerificationCode", "NEGATIVE 8: Failed Verification Code", "The provided verification code fails")
        {
            CustomerId = "SUCCESS",
            VerificationCode = "BADCODE",

            ExpectedStatusCode = (int)HttpStatusCode.Unauthorized,
            ExpectedErrorCode = DirectDebitApi.InternalConstants.Error.Codes.InvalidVerificationCode,

            DirectDebitEntityShouldExist = true,

            AssertDirectDebitEntity = (entity) =>
            {
                entity.Should().NotBeNull();
                if (entity != null)
                {
                    entity.Attempts.Should().Be(1);         // Attempt was valid
                    entity.ActiveRecord.Should().BeTrue();  // Record should be active
                }
            }
        },

        // NEGATIVE 9 : ArrangementID mismatch
        new VerifyPendingDirectDebitScenario("ArrangementIdMismatch", "NEGATIVE 9: ArrangmentId mismatch", "The ArrangementId doesn't match")
        {
            CustomerId = "SUCCESS",
            ArrangementId = "AA21222681EJ",

            ExpectedStatusCode = (int)HttpStatusCode.BadRequest,
            ExpectedErrorCode = CommonMessageConstants.BadInputDataErrorCode,

            DirectDebitEntityShouldExist = true,

            AssertDirectDebitEntity = (entity) =>
            {
                entity.Should().NotBeNull();
                if (entity != null)
                {
                    entity.Attempts.Should().Be(1);         // Attempt was valid
                    entity.ActiveRecord.Should().BeTrue();  // Record should be active
                }
            }
        },

        // NEGATIVE 10 : Failed to retrieve Customer Profile
        new VerifyPendingDirectDebitScenario("FailedCustomerProfile", "NEGATIVE 10: Failed to retrieve Customer Profile", "Retrieving the customer profile to get the given name fails")
        {
            CustomerId = "SUCCESS",

            ExpectedStatusCode = (int)HttpStatusCode.InternalServerError,
            ExpectedErrorCode = CommonMessageConstants.CommunicationsErrorCode,

            DirectDebitEntityShouldExist = true,

            AssertDirectDebitEntity = (entity) =>
            {
                entity.Should().NotBeNull();
                if (entity != null)
                {
                    entity.Attempts.Should().Be(0);         // Attempt should be reverted
                    entity.ActiveRecord.Should().BeTrue();  // Record should still be active
                }
            },

            HandleMockHttpRequestEvents = (VerifyPendingDirectDebitScenario scenario, ResourceModule resources, HttpRequestEventArgs args) =>
            {
                // When the Get Customer Profile fails
                if (args.ClientName.Equals(T24SdkConstants.HttpClient.T24) && args.Method == HttpMethod.Get && args.TryParseAfterRequestPath(T24SdkConstants.T24Paths.GetCustomerProfile, out _))
                {
                    args.SetResponse(HttpStatusCode.NotFound, null);
                    return true;
                }

                return false;
            }
        },

        // NEGATIVE 11 : Failed to retrieve Account Details
        new VerifyPendingDirectDebitScenario("FailedAccountDetails", "NEGATIVE 11: Failed to retrieve Account Details", "Retrieving the account details from T24")
        {
            CustomerId = "SUCCESS",

            ExpectedStatusCode = (int)HttpStatusCode.InternalServerError,
            ExpectedErrorCode = CommonMessageConstants.CommunicationsErrorCode,

            DirectDebitEntityShouldExist = true,

            AssertDirectDebitEntity = (entity) =>
            {
                entity.Should().NotBeNull();
                if (entity != null)
                {
                    entity.Attempts.Should().Be(0);         // Attempt should be reverted
                    entity.ActiveRecord.Should().BeTrue();  // Record should still be active
                }
            },

            HandleMockHttpRequestEvents = (VerifyPendingDirectDebitScenario scenario, ResourceModule resources, HttpRequestEventArgs args) =>
            {
                // When the Get Customer Profile fails
                if (args.ClientName.Equals(T24SdkConstants.HttpClient.T24) && args.Method == HttpMethod.Get && args.TryParseRequestPathQueryParameters(T24SdkConstants.T24Paths.GetAccountDetails, out _))
                {
                    args.SetResponse(HttpStatusCode.NotFound, null);
                    return true;
                }

                return false;
            }
        },

        // NEGATIVE 12 : Failed to update Direct Debit in T24
        new VerifyPendingDirectDebitScenario("FailedDirectDebitUpdateT24", "NEGATIVE 12: Failed to update Direct Debit in T24", "Failure occurred when updating direct debit in T24")
        {
            CustomerId = "SUCCESS",

            ExpectedStatusCode = (int)HttpStatusCode.InternalServerError,
            ExpectedErrorCode = CommonMessageConstants.CommunicationsErrorCode,

            DirectDebitEntityShouldExist = true,

            AssertDirectDebitEntity = (entity) =>
            {
                entity.Should().NotBeNull();
                if (entity != null)
                {
                    entity.Attempts.Should().Be(0);         // Attempt should be reverted
                    entity.ActiveRecord.Should().BeTrue();  // Record should still be active
                }
            },

            HandleMockHttpRequestEvents = (VerifyPendingDirectDebitScenario scenario, ResourceModule resources, HttpRequestEventArgs args) =>
            {
                // When the Get Customer Profile fails
                if (args.ClientName.Equals(T24SdkConstants.HttpClient.T24) && args.Method == HttpMethod.Put && args.TryParseAfterRequestPath(T24SdkConstants.T24Paths.UpdateDirectDebit, out _))
                {
                    args.SetResponse(HttpStatusCode.NotFound, null);
                    return true;
                }

                return false;
            }
        },

        // NEGATIVE 13 : Failed to Get Operational Attributes
        new VerifyPendingDirectDebitScenario("FailedGetOperationalAttributes", "NEGATIVE 13: Failed to Get Operational Attributes", "During consent checking the call to get operational attributes fails")
        {
            CustomerId = "SUCCESS",

            T24GetAccountDetailsResource = "RequiresConsent",

            ExpectedStatusCode = (int)HttpStatusCode.InternalServerError,
            ExpectedErrorCode = CommonMessageConstants.CommunicationsErrorCode,

            DirectDebitEntityShouldExist = true,

            AssertDirectDebitEntity = (entity) =>
            {
                entity.Should().NotBeNull();
                if (entity != null)
                {
                    entity.Attempts.Should().Be(0);         // Attempt should be reverted
                    entity.ActiveRecord.Should().BeTrue();  // Record should still be active
                }
            },

            HandleMockHttpRequestEvents = (VerifyPendingDirectDebitScenario scenario, ResourceModule resources, HttpRequestEventArgs args) =>
            {
                // When the Get Customer Profile fails
                if (args.ClientName.Equals(DirectDebitApi.InternalConstants.HttpClients.ConsentWorkflow) && args.Method == HttpMethod.Get)
                {
                    args.SetResponse(HttpStatusCode.NotFound, null);
                    return true;
                }

                return false;
            }
        },

        // NEGATIVE 14 : Failed to Update Direct Debit in T24 with Consent
        new VerifyPendingDirectDebitScenario("FailedUpdateDirectDebitWithConsent", "NEGATIVE 14: Failed to Update Direct Debit in T24 with Consent", "Failed to update the Direct Debit in T24 during the consent check to make it active")
        {
            CustomerId = "SUCCESS",

            T24GetAccountDetailsResource = "RequiresConsent",

            ExpectedStatusCode = (int)HttpStatusCode.InternalServerError,
            ExpectedErrorCode = CommonMessageConstants.CommunicationsErrorCode,

            DirectDebitEntityShouldExist = true,

            AssertDirectDebitEntity = (entity) =>
            {
                entity.Should().NotBeNull();
                if (entity != null)
                {
                    entity.Attempts.Should().Be(0);         // Attempt should be reverted
                    entity.ActiveRecord.Should().BeTrue();  // Record should still be active
                }
            },

            HandleMockHttpRequestEvents = (VerifyPendingDirectDebitScenario scenario, ResourceModule resources, HttpRequestEventArgs args) =>
            {
                // When the Get Customer Profile fails
                if (args.ClientName.Equals(T24SdkConstants.HttpClient.T24) && args.Method == HttpMethod.Put && args.TryParseAfterRequestPath(T24SdkConstants.T24Paths.UpdateDirectDebit, out _))
                {
                    throw new Exception("Failed update during consent");
                }

                return false;
            }
        },

        // NEGATIVE 15 : Failed to Update Settlement Instructions
        new VerifyPendingDirectDebitScenario("FailedUpdateSettlementInstructions", "NEGATIVE 15: Failed to Update Settlement Instructions", "Failed to update the settlement instructions at the end")
        {
            CustomerId = "SUCCESS",

            ExpectedStatusCode = (int)HttpStatusCode.InternalServerError,
            ExpectedErrorCode = CommonMessageConstants.CommunicationsErrorCode,

            DirectDebitEntityShouldExist = true,

            AssertDirectDebitEntity = (entity) =>
            {
                entity.Should().NotBeNull();
                if (entity != null)
                {
                    entity.Attempts.Should().Be(0);         // Attempt should be reverted
                    entity.ActiveRecord.Should().BeTrue();  // Record should still be active
                }
            },

            HandleMockHttpRequestEvents = (VerifyPendingDirectDebitScenario scenario, ResourceModule resources, HttpRequestEventArgs args) =>
            {
                // When the Get Customer Profile fails
                if (args.ClientName.Equals(T24SdkConstants.HttpClient.T24) && args.Method == HttpMethod.Put && args.TryParseAfterRequestPath(T24SdkConstants.T24Paths.UpdateSettlementInstructions, out _))
                {
                    throw new Exception("Failed update settlment instructions");
                }

                return false;
            }
        },


        // NEGATIVE 16 : Failed to Update Auto Settle Charge
        new VerifyPendingDirectDebitScenario("FailedUpdateAutoSettleCharge", "NEGATIVE 15: Failed to Update Auto Settle Charge", "Failed to update the Auto Settle Charge at the end")
        {
            CustomerId = "SUCCESS",

            ExpectedStatusCode = (int)HttpStatusCode.InternalServerError,
            ExpectedErrorCode = CommonMessageConstants.CommunicationsErrorCode,

            DirectDebitEntityShouldExist = true,

            AssertDirectDebitEntity = (entity) =>
            {
                entity.Should().NotBeNull();
                if (entity != null)
                {
                    entity.Attempts.Should().Be(0);         // Attempt should be reverted
                    entity.ActiveRecord.Should().BeTrue();  // Record should still be active
                }
            },

            HandleMockHttpRequestEvents = (VerifyPendingDirectDebitScenario scenario, ResourceModule resources, HttpRequestEventArgs args) =>
            {
                // When the Get Customer Profile fails
                if (args.ClientName.Equals(T24SdkConstants.HttpClient.T24) && args.Method == HttpMethod.Post && args.TryParseAfterRequestPath("/product/loans/redraw/charges/auto", out _))
                {
                    throw new Exception("Failed update atuo settle charge");
                }

                return false;
            }
        },


        // NEGATIVE 17 : Repayment instruction is null
        new VerifyPendingDirectDebitScenario("FailedUpdateAutoSettleCharge", "NEGATIVE 15: Failed to Update Auto Settle Charge", "Failed to update the Auto Settle Charge at the end")
        {
            CustomerId = "SUCCESS",

            ExpectedStatusCode = (int)HttpStatusCode.BadRequest,
            ExpectedErrorCode = CommonMessageConstants.BadInputDataErrorCode,

            HomeLoanMarketLaunchFeatureFlag = true,

            HandleMockHttpRequestEvents = (VerifyPendingDirectDebitScenario scenario, ResourceModule resources, HttpRequestEventArgs args) =>
            {
                // When the Entitlement check fails
                if (args.ClientName.Equals(T24SdkConstants.HttpClient.T24) && args.Method == HttpMethod.Get && args.TryParseAfterRequestPath(T24SdkConstants.T24Paths.GetAccountDetails, out _))
                {
                    args.SetResponse(HttpStatusCode.OK, resources.ExtractManifestResource<T24AccountDetailResponseDto>("AA21328V0HVX"), null);
                    return true;
                }

                return false;
            }
        }

        );
    }
}