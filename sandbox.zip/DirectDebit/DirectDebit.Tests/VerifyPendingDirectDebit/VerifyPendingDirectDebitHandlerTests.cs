﻿using AutoMapper;
using DirectDebit.UnitTests.VerifyPendingDirectDebit.TestData;
using DirectDebitApi;
using DirectDebitApi.ActionHandlers;
using DirectDebitApi.Clients;
using DirectDebitApi.Configuration;
using DirectDebitApi.Controllers;
using DirectDebitApi.Models;
using FluentAssertions;
using FluentAssertions.Execution;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.FeatureManagement;
using Moq;
using Platform.Library.Authentication.Configuration;
using Platform.Library.Authentication.Guards;
using Platform.Library.AzureStorage.Entities;
using Platform.Library.Common;
using Platform.Library.Common.AspNetCore.Abstractions;
using Platform.Library.Common.Extensions;
using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.Communication.Extensions;
using Platform.Library.Events.Models;
using Platform.Library.Http;
using Platform.Library.T24.SDK.DependencyInjection;
using Platform.Library.Testing.XUnit;
using Xunit;
using Xunit.Abstractions;
using static DirectDebitApi.InternalConstants;

namespace DirectDebit.UnitTests.ActionHandlers
{
    [TestType(TestTypeEnum.UnitTest)]
    public class VerifyPendingDirectDebitHandlerTests : XUnitTestFixture
    {
        private static class RequestIds
        {
            public const string ConsentRequired = nameof(ConsentRequired);
            public const string NoConsentRequired = nameof(NoConsentRequired);
            public const string BadRequestOpAttr = nameof(BadRequestOpAttr);
            public const string NoOpAttr = nameof(NoOpAttr);
        }

        private const string MissingDirectDebitId = nameof(MissingDirectDebitId);
        private const string ValidArrangementId = "AA19280X6MN8";
        private const string InvalidArrangementId = "AA21222681EJ";
        private const string ValidArrangementIdWithDDMandateReference = "AA21328V0BAD";
        private const string ValidArrangementIdWithDDMandateReferenceForConsent = "AA21328V1BAD";
        private const string Authorization = "Bearer sadjhsgajhagsdhjasgdkjasgdkjbasgdkjsgadkjh";

        private ContextModule Context => Module<ContextModule>();
        private ResourceModule Resource => Module<ResourceModule>();
        private HttpModule Http => Module<HttpModule>();

        public VerifyPendingDirectDebitHandlerTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture) { }

        protected override IEnumerable<string> AdditionalConfigurations => new List<string> { "test" };

        protected override void TestSetup()
        {
            Context.RegisterWithMsDi(services =>
            {
                services.RegisterLibrary<Startup>();

                services.RegisterT24Sdk(true);

                services
                    .RegisterAllHttpClients(
                        componentSectionName: InternalConstants.Configuration.Sections.DirectDebitApi,
                        defaultHeaders: null,
                        inDebug: true)
                    .RegisterAutoMapperProfiles()
                    .RegisterAllValidators();
            });

            Context.RegisterTypeAsInterfaces<Settings>();
            Context.RegisterTypeAsInterfaces<VerifyPendingDirectDebitHandler>();
            Context.RegisterTypeAsInterfaces<ConsentWorkflowClient>();
            Context.RegisterTypeAsInterfaces<DateTimePicker>();            

            // Mock for Unit Tests
            Context.RegisterMockAsInterface<IStandardAuthorizationSettings>(TestExtensions.SetupAuthorizationSettings);
            Context.RegisterMockAsInterface<IServiceBusEventPublisher>(SetupPublishEvent);
            Context.RegisterMockAsInterface<IFeatureManager>(SetupFeatureManager);

            Context.RegisterMockTableStorage(Resource);
            Context.RegisterGuardBuilderAndContext();
        }

        private MockGuardBuilder MockGuardBuilder => Context.GetMockGuardBuilder();
        private MockTableStorageClient MockTableStorageClient => Context.GetMockTableStorageClient();

        private Func<EV52CancelDirectDebitEvent, bool> PublishCancelDirectDebitResponse { get; set; } = (cancelEvent) => true;
        private void SetupPublishEvent(Mock<IServiceBusEventPublisher> mock)
        {
            mock
                .Setup(a => a.CreateAndPublishEvent(
                    ServiceBus.EV52CancelDirectDebitTopic,
                    It.IsAny<EV52CancelDirectDebitEvent>(),
                    It.IsAny<IEnumerable<(string Name, object Value)>>()))
                .ReturnsAsync((string topic, EV52CancelDirectDebitEvent cancelEvent, IEnumerable<(string Name, object Value)> additionalProperties) => PublishCancelDirectDebitResponse.Invoke(cancelEvent));
        }

        private Func<bool> FeatureMarketLaunch { get; set; } = () => false;

        private void SetupFeatureManager(Mock<IFeatureManager> featureManager)
        {
            featureManager.Setup(x => x.IsEnabledAsync(It.IsAny<string>())).ReturnsAsync((string func) => FeatureMarketLaunch.Invoke());
        }

        private DirectDebitApiController CreateController(string header = null, string headerValue = null)
        {
            var controller = new DirectDebitApiController();
            controller.ControllerContext.HttpContext = new DefaultHttpContext();

            if (!string.IsNullOrWhiteSpace(header) && !string.IsNullOrWhiteSpace(headerValue))
                controller.ControllerContext.HttpContext.Request.Headers.Add(header, headerValue);

            return controller;
        }

        public static TestScenarios VariousScenarios => VerifyPendingDirectDebitScenarios.VariousScenarios;

        [Theory]
        [MemberData(nameof(VariousScenarios))]
        public async Task VerifyPendingDirectDebit_TestScenarios_Varied(string key, VerifyPendingDirectDebitScenario scenario)
        {
            // Arrange
            SetTestScenario(nameof(VariousScenarios), key);

            var request = VerifyPendingDirectDebitRequestData.CreateVerifyPendingDDRequest(scenario);
            MockGuardBuilder.AuthenticationContextCustomerId = () => scenario.CustomerId;
            MockTableStorageClient.PopulateEntities<DirectDebitEntity>(scenario.PreloadedEntities);
            MockTableStorageClient.DefineFailures(scenario.TableStorageFailures);
            PublishCancelDirectDebitResponse = (cancelEvent) => scenario.HandlePublishCancelDirectDebit.Invoke(cancelEvent);
            FeatureMarketLaunch = () => scenario.HomeLoanMarketLaunchFeatureFlag;

            // Act
            Exception actualException = null;
            IActionResult actualResponse = null;
            try
            {
                actualResponse = await CreateController().VerifyPendingDirectDebit(
                    Context.Resolve<IActionHandler<VerifyPendingDirectDebitHandlerRequest, VerifyPendingDirectDebitHandlerResponse>>(),
                    Context.Resolve<ILogger<DirectDebitApiController>>(),
                    Context.Resolve<IGuardBuilder>(),
                    Context.Resolve<IMapper>(),
                    Authorization,
                    request,
                    scenario.DirectDebitId,
                    CancellationToken.None
                );
            }
            catch ( Exception ex )
            {
                actualException = ex;
            }

            // Assert
            using ( new AssertionScope() )
            {
                // Assert on expected test results
                if (scenario.PositiveTest)
                {
                    actualException.Should().BeNull();
                    (actualResponse as OkObjectResult).Should().NotBeNull("this end point can only return an OkResult");
                    if (actualResponse is OkObjectResult okResult)
                        okResult.StatusCode.Should().Be(scenario.ExpectedStatusCode);

                }
                else
                {
                    if (actualException is StandardApiException stdEx)
                    {
                        actualResponse.Should().BeNull();
                        stdEx.HttpStatusCode.Should().Be(scenario.ExpectedStatusCode);
                        stdEx.ErrorMessage.MessageCode.Should().Be(scenario.ExpectedErrorCode);
                    }
                    else
                    {
                        actualException.Should().BeOfType<StandardApiException>();
                    }
                }

                // Assert on expected ODS state
                MockTableStorageClient.TryGetEntity<DirectDebitEntity>(scenario.DirectDebitId.AsDirectDebitKey(), out var remainingEntity).Should().Be(scenario.DirectDebitEntityShouldExist);
                if ( scenario.DirectDebitEntityShouldExist )
                {
                    // The entity can be verified
                    scenario.AssertDirectDebitEntity?.Invoke(remainingEntity);
                }
                else
                {
                    // The entity should no longer exist
                    remainingEntity.Should().BeNull();
                }
            }
        }
    }
}