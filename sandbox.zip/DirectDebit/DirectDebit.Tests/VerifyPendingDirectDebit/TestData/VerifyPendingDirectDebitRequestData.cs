﻿using DirectDebitApi.Models;

namespace DirectDebit.UnitTests.VerifyPendingDirectDebit.TestData
{
    public class VerifyPendingDirectDebitRequestData
    {
        public static VerifyPendingDirectDebitRequest CreateVerifyPendingDDRequest(VerifyPendingDirectDebitScenario scenario) =>
            new VerifyPendingDirectDebitRequest()
            {
                VerificationCode = scenario.VerificationCode,
                ArrangementId = scenario.ArrangementId,
            };
        
        public static VerifyPendingDirectDebitRequest CreateVerifyPendingDDRequestWithDDMandateReference(string arrangementId = null, string directDebitId = null) =>
            new VerifyPendingDirectDebitRequest()
            {
                VerificationCode = "925687",
                ArrangementId = arrangementId ?? "AA21328V0BAD"
            };
    }
}
