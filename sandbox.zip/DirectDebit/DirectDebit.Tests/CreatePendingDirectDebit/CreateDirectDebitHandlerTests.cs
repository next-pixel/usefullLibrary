using Autofac;
using AutoMapper;
using Azure.Core;
using DirectDebitApi;
using DirectDebitApi.ActionHandlers;
using DirectDebitApi.Clients;
using DirectDebitApi.Configuration;
using DirectDebitApi.Controllers;
using DirectDebitApi.Mappers;
using DirectDebitApi.Models;
using DirectDebitApi.Validators;
using FluentAssertions;
using FluentAssertions.Execution;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using Moq;
using Platform.Library.Authentication.Configuration;
using Platform.Library.Authentication.Guards;
using Platform.Library.Authentication.Models;
using Platform.Library.Authentication.Models.Abstractions;
using Platform.Library.AzureStorage.Clients.Abstraction;
using Platform.Library.AzureStorage.Entities;
using Platform.Library.BaseEvent;
using Platform.Library.Common;
using Platform.Library.Common.AspNetCore.Abstractions;
using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.Communication.Extensions;
using Platform.Library.Events.Models;
using Platform.Library.Http;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.DependencyInjection;
using Platform.Library.T24.SDK.Mappers;
using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;
using Platform.Library.T24.SDK.Modules.Customer.ResponseDtos;
using Platform.Library.T24.SDK.Modules.DirectDebit.ResponseDtos;
using Platform.Library.T24.SDK.Modules.Entitlements.ResponseDtos;
using Platform.Library.Testing.XUnit;
using System.Collections.Specialized;
using System.Net;
using Xunit;
using Xunit.Abstractions;
using static DirectDebitApi.InternalConstants.TableStorage;

namespace DirectDebit.UnitTests.ActionHandlers
{
    [TestType(TestTypeEnum.UnitTest)]
    public class CreateDirectDebitHandlerTests : XUnitTestFixture
    {
        private const string SUCCESS = "Success";
        private const string FAILURE = "Failure";

        private const string authorisation =
            "eyJ0eXAiOiJKV1QiLCJraWQiOiJQRFZwMzB1dWRJa0tDWkkwWkxabzAyUVF4eTA9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJDY2MxYTk2NWMtZWMyNC00NmI5LThlMmItODM5M2Y2NTEzNTIyIiwiY3RzIjoiT0FVVEgyX1NUQVRFTEVTU19HUkFOVCIsImF1dGhfbGV2ZWwiOjIsImF1ZGl0VHJhY2tpbmdJZCI6ImRjZDBmMTc5LTUyYjQtNGUzMi1hYzc0LWNmY2VkYTIwZTYyYi03NTMzNTgiLCJpc3MiOiJodHRwczovL2Rldi5pZC5hd3MtYm9xL2FtL29hdXRoMi9yZWFsbXMvcm9vdC9yZWFsbXMvdm1hIiwidG9rZW5OYW1lIjoiYWNjZXNzX3Rva2VuIiwidG9rZW5fdHlwZSI6IkJlYXJlciIsImF1dGhHcmFudElkIjoiYVRkenhmemR6cGR2cUJ1OW1EQzFWcnRNZTMwIiwiYXVkIjoiVk1BTW9iaWxlQXBwIiwibmJmIjoxNjI3NTk5NDQ4LCJncmFudF90eXBlIjoiYXV0aG9yaXphdGlvbl9jb2RlIiwic2NvcGUiOlsibWZhLmFjY2Vzc19jb2RlLjIiLCJjdXN0b21lci5mdWxsLm5vcm1hbCJdLCJhdXRoX3RpbWUiOjE2Mjc1OTk0NDgsInJlYWxtIjoiL3ZtYSIsImV4cCI6MTYyNzU5OTc0OCwiaWF0IjoxNjI3NTk5NDQ4LCJleHBpcmVzX2luIjozMDAsImp0aSI6Ikg0d3RFQUt3OFJRaWtJSFBWSUk3RmQ3OC1lTSIsIm1mYV9tZXRob2QuMiI6IkFDQ0VTU19DT0RFIiwiaXNfc3FhX2VuYWJsZWQiOmZhbHNlLCJyZW1haW5pbmdfbG9naW5fY291bnQiOjAsInRlbWVub3NfY2lmIjoiMTIzNDU2IiwiY2l0aV9saW5raW5nX3N0YXR1cyI6IlBFTkRJTkciLCJtdXN0X2FjY2VwdF9UQ3MiOnRydWUsImlzbzMxNjZfMiI6IkFVIn0.J32DyEyZZYpaTxOdhrlcM1S8HVoQgYSOYodfoNnHfyOJXQDLDJQGvewiRHwRop6JOX_K7TRc-RGEa3fCpnceH9a49_24B8NctldPWxSozuNV6b05rMj7wNgqciZ2gO85OUheV_ie7_zbyVbRKKfIsvXwMfGuRfhy3FPQAd2ZoGueJFvosql61_7xnlv8Te1ORF0tEojxB-98m7TegjAtgIEyg0-BFals-Lf2liMWfE-mjpjCzSi5tLQr55ACMSkZbixq-pROtGz2WorvIKyqnouyl7fy8Pjnv5GCzJtmQ17AttfmzLZb2zEV4kaSPbEkdhtbmwYZH85igow704IQHg";
        private const string DirectDebitParamId = "2500"; 
        private const string ValidArrangementId = "AA2122268J4B";
        private const string InvalidForNullResponse = "111133333";

        private readonly DirectDebitApiController _directDebitApiController;

        private DirectDebitEntity _directDebitEntity;
        private ContextModule Context => Module<ContextModule>();
        private ModelModule Models => Module<ModelModule>();
        private ResourceModule Resource => Module<ResourceModule>();
        protected ServiceBusModule ServiceBus => Module<ServiceBusModule>();
        [ModuleInit(nameof(InitHttpModule))] private HttpModule Http => Module<HttpModule>();

        public CreateDirectDebitHandlerTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(
            outputHelper, classFixture)
        {
            _directDebitApiController = new DirectDebitApiController();
            _directDebitApiController.ControllerContext.HttpContext = new DefaultHttpContext()
            {
                Request =
                {
                    Headers =
                    {
                    }
                }
            };
        }

        protected override IEnumerable<string> AdditionalConfigurations => new List<string> { "test" };

        protected override void TestSetup()
        {
            Context.RegisterWithMsDi(services =>
            {
                services.RegisterBrandResolver();
                services.RegisterT24Sdk(true);
                services.RegisterAllHttpClients(
                componentSectionName: InternalConstants.Configuration.Sections.DirectDebitApi,
                defaultHeaders: null,
                inDebug:true
                );
            });

            Context.RegisterTypeAsInterfaces<Settings>();
            Context.RegisterTypeAsInterfaces<CreatePendingDirectDebitHandler>();
            Context.RegisterTypeAsInterfaces<HttpClientHelper>();
            Context.RegisterTypeAsInterfaces<AuthenticationContext>();
            Context.RegisterTypeAsInterfaces<PaymentInitiationClient>();
            Context.RegisterTypeAsInterfaces<CreatePendingDirectDebitValidator>();

            Context.RegisterMapperAndProfiles(
                s => new CreatePendingDirectDebitMapperProfile(),
                s => new EV52CancelDirectDebitEventMapperProfile(),
                s => new HomeLoanMapperProfile()
            );

            // Mock for Unit Tests
            Context.RegisterMockAsInterface<IStandardAuthorizationSettings>(SetupAuthorizationSettings);
            Context.RegisterMockAsInterface<IAzureTableStorageClient>(SetupTableStorageClient);
            Context.RegisterMockAsInterface<IConfigurationRefresherProvider>(SetupConfigurationRefresherProvider);
            Context.RegisterMockAsInterface<IGuardBuilder>(MockGuardBuilder);
            Context.RegisterMockAsInterface<IServiceBusEventPublisher>(SetupServiceBusEventPublisher);
            Context.RegisterMockAsInterface<IDateTimePicker>(SetupDateTimePicker);
            Context.RegisterMockAsInterface<IMessageReceiver>(m => SetupMessageReceiver(m));
        }

        private void SetupDateTimePicker(Mock<IDateTimePicker> dateTimePicker)
        {
            dateTimePicker.Setup(d => d.UtcNow).Returns(new DateTime(2024, 01, 01));
        }

        private void SetupMessageReceiver(Mock<IMessageReceiver> mock)
        {
            mock.Setup(x => x.CompleteAsync(It.IsAny<string>()))
                .Returns(Task.CompletedTask)
                .Verifiable();
        }

        private void MockGuardBuilder(Mock<IGuardBuilder> guardBuilder)
        {
            SetupGuardBuilder(guardBuilder, SUCCESS);
        }

        private static void SetupGuardBuilder(Mock<IGuardBuilder> guardBuilder, string cif)
        {
            var context = new Mock<IMockAuthenticationContext>();
            context.SetupGet(a => a.Temenos_cif).Returns(cif);

            guardBuilder.Setup(v => v.Execute(It.IsAny<CancellationToken>(), It.IsAny<bool>(), It.IsAny<bool>()))
                .ReturnsAsync(context.Object);
        }

        private void SetupConfigurationRefresherProvider(Mock<IConfigurationRefresherProvider> configurationRefresherProvider)
        {
            var configurationRefresher = new Mock<IConfigurationRefresher>();
            var list = new List<IConfigurationRefresher> 
            {
                configurationRefresher.Object
            };
            configurationRefresherProvider.Setup(c => c.Refreshers).Returns(list);
        }

        private static void SetupAuthorizationSettings(Mock<IStandardAuthorizationSettings> mock)
        {
            mock.Setup(x => x.CiamCertificateUrl).Returns("1");
            mock.Setup(x => x.AzureAdIssuer).Returns("2");
            mock.Setup(x => x.CiamSubscriptionKey).Returns("3");
        }


        private void SetupTableStorageClient(Mock<IAzureTableStorageClient> mock)
        {
            mock.Setup(a => a.UpsertTableStorageAsync<DirectDebitEntity>(It.IsAny<DirectDebitEntity>()))
                .ReturnsAsync(true)
                .Callback(() => { _directDebitEntity = Resource.ExtractManifestResource<DirectDebitEntity>("Create"); });
        }

        private void SetupServiceBusEventPublisher(Mock<IServiceBusEventPublisher> serviceBusEventPublisher)
        {
            serviceBusEventPublisher.Setup(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV52CancelDirectDebitEvent>(), null)).ReturnsAsync(true);
        }

        private void InitHttpModule()
        {
            Http.HandleMockRequestEvent += HttpModule_HandleT24MockRequestEvent;
        }

        private void HttpModule_HandleT24MockRequestEvent(object sender, HttpRequestEventArgs args)
        {
            switch (args.ClientName)
            {
                case T24SdkConstants.HttpClient.T24:
                    if (args.Method == HttpMethod.Get)
                    {
                        NameValueCollection queryParams = null;
                        var pathAndQuery = string.Empty;

                        if (args.TryParseAfterRequestPath(T24SdkConstants.T24Paths.EntitlementsCheck, out _))
                        {
                            args.SetResponse(HttpStatusCode.OK, Resource.ExtractManifestResource<T24EntitlementsResponseDto>("ActiveDirectDebit.Success"), new Dictionary<string, string>());
                        }
                        else if (args.TryParseRequestPathQueryParameters(T24SdkConstants.T24Paths.GetAccountDetails, out queryParams))
                        {
                            SetupGetAccountDetailEndpoint(args, queryParams);
                        }
                        else if (args.TryParseAfterRequestPath(T24SdkConstants.T24Paths.GetCustomerProfile, out _))
                        {
                            args.SetResponse(HttpStatusCode.OK, Resource.ExtractManifestResource<T24GetCustomerProfileResponseDto>("123"), new Dictionary<string, string>());
                        }
                        else if (args.TryParseRequestPathQueryParameters(T24SdkConstants.T24Paths.GetDirectDebitAccounts, out queryParams))
                        {
                            var customerId = queryParams.Get("customerId");

                            if (customerId.InIgnoreCase("ACTIVE", "NEW", SUCCESS))
                            {
                                args.SetResponse(HttpStatusCode.OK,
                                    Resource.ExtractManifestResource<T24GetDirectDebitAccountResponseDto>(SUCCESS),
                                    new Dictionary<string, string>());
                            }
                            else if (customerId == FAILURE)
                            {
                                args.SetResponse(HttpStatusCode.BadRequest,
                                       Resource.ExtractManifestResource<T24GetDirectDebitAccountResponseDto>(customerId),
                                       new Dictionary<string, string>());
                            }
                            else
                            {
                                args.SetResponse(HttpStatusCode.InternalServerError,
                                       new Dictionary<string, string>());

                            }
                        }
                        else if (args.Method == HttpMethod.Post)
                        {
                            var req = args.RequestMessage.Content.ReadAsStringAsync().Result;
                            var createRequest = req.Deserialize<T24CreateDirectDebitResponseDto>();

                            if (createRequest.Body.AccountNumber.InIgnoreCase(ValidArrangementId, "123412345"))
                            {
                                args.SetResponse(HttpStatusCode.OK,
                                        Resource.ExtractManifestResource<T24CreateDirectDebitResponse>(SUCCESS),
                                        new Dictionary<string, string>());
                            }
                            else if (createRequest.Body.AccountNumber.InIgnoreCase(InvalidForNullResponse, "111133333"))
                            {
                                args.SetResponse(HttpStatusCode.OK,
                                        Resource.ExtractManifestResource<T24CreateDirectDebitResponse>(SUCCESS),
                                        new Dictionary<string, string>());
                            }                            
                            else if (createRequest.Body.AccountNumber == "1234")
                            {
                                args.SetResponse(HttpStatusCode.BadRequest,
                                        Resource.ExtractManifestResource<T24CreateDirectDebitResponse>(FAILURE),
                                        new Dictionary<string, string>());
                            }
                            else
                            {
                                args.SetResponse(HttpStatusCode.InternalServerError, new Dictionary<string, string>());
                            }
                        }
                    }
                    else if (args.Method == HttpMethod.Post)
                    {                       
                        args.SetResponse(HttpStatusCode.OK, Resource.ExtractManifestResource<T24CreateDirectDebitResponseDto>("Success"), null);                                          
                    }
                    else
                    {
                        args.SetResponse(HttpStatusCode.InternalServerError, new Dictionary<string, string>());
                    }
                    break;
                case InternalConstants.HttpClients.PaymentInitiation:
                    if (args.Method == HttpMethod.Post)
                    {
                        var req = args.RequestMessage.Content.ReadAsStringAsync().Result;
                        var paymentReq = req.Deserialize<InitiatePaymentDirectDebitRequest>();

                        if (paymentReq.Destination.AccountNumber.InIgnoreCase(ValidArrangementId, "123412345"))
                        {
                            args.SetResponse(HttpStatusCode.OK,
                                Resource.ExtractManifestResource<InitiatePaymentDirectDebitResponse>(SUCCESS),
                                new Dictionary<string, string>());
                        }
                        else if (paymentReq.Destination.AccountNumber.InIgnoreCase(InvalidForNullResponse, "111133333"))
                        {
                            args.SetResponse(HttpStatusCode.BadRequest,
                            Resource.ExtractManifestResource<InitiatePaymentDirectDebitResponse>(FAILURE),
                            new Dictionary<string, string>());
                        }
                        else if (paymentReq.Destination.AccountNumber == "1234")
                        {
                            args.SetResponse(HttpStatusCode.BadRequest,
                            Resource.ExtractManifestResource<InitiatePaymentDirectDebitResponse>(FAILURE),
                            new Dictionary<string, string>());
                        }
                        else
                        {
                            args.SetResponse(HttpStatusCode.InternalServerError, new Dictionary<string, string>());
                        }
                    }
                    
                    break;
                default:
                    throw new NotSupportedException(
                        $"{args.Method.ToString().ToUpper()}[{args.RequestPath.AbsoluteUri}] Not supported by {nameof(HttpModule_HandleT24MockRequestEvent)}");
            }
        }

        private void SetupGetAccountDetailEndpoint(HttpRequestEventArgs args, NameValueCollection queryParams)
        {
            var requestArrangementId = queryParams.Get("arrangementId");
            switch (requestArrangementId)
            {
                case ValidArrangementId:
                    args.SetResponse(HttpStatusCode.OK, Resource.ExtractManifestResource<T24AccountDetailResponseDto>(requestArrangementId), new Dictionary<string, string>());
                    break;
                case "1234":
                    args.SetResponse(HttpStatusCode.BadRequest, new Dictionary<string, string>());
                    break;
                case InvalidForNullResponse:
                    args.SetResponse(HttpStatusCode.OK, Resource.ExtractManifestResource<T24AccountDetailResponseDto>(requestArrangementId), new Dictionary<string, string>());
                    break;
                default:
                    args.SetResponse(HttpStatusCode.InternalServerError);
                    break;
            }
        }

        [Theory]
        [InlineData(ValidArrangementId, SUCCESS, "Create")]
        public async Task CreatePendingDirectDebit_ResponseSuccess(string arrangementId, string expectedResponseJson, string expectedDirectDebitEntityJson)
        {
            // Arrange
            Resource.ExtractManifestResource<CreatePendingDirectDebitResponse>(expectedResponseJson);
            var request = Resource.ExtractManifestResource<CreatePendingDirectDebitRequest>(arrangementId);
            var directDebitExpectedEntity = Resource.ExtractManifestResource<DirectDebitEntity>(expectedDirectDebitEntityJson);

            // Act
            var action = await _directDebitApiController.CreatePendingDirectDebit(
                Context.Resolve<IActionHandler<CreatePendingDirectDebitHandlerRequest, CreatePendingDirectDebitResponse>>(),
                Context.Resolve<ILogger<DirectDebitApiController>>(),
                Context.Resolve<IGuardBuilder>(),
                Context.Resolve<IMapper>(),
                request,
                arrangementId,
                authorisation,
                CancellationToken.None
            );

            // Assert
            using(new AssertionScope())
            {
                Models.CompareActionResult<CreatePendingDirectDebitResponse>(action).Match.Should().BeTrue();

                Context.GetMock<IAzureTableStorageClient>().Verify(a => a.UpsertTableStorageAsync<DirectDebitEntity>(It.IsAny<DirectDebitEntity>()), Times.Once);
                Models.Compare(_directDebitEntity).Match.Should().BeTrue();
            }
        }


        [Theory]
        [InlineData(ValidArrangementId, FAILURE)]      
        public async Task CreatePendingDirectDebit_Fails_OFIDetailsAreInvalid(string arrangementId, string failedStatus)
        {
            // Arrange
            var request = Resource.ExtractManifestResource<CreatePendingDirectDebitRequest>(arrangementId);

            var guardBuilder = Context.GetMock<IGuardBuilder>();
            SetupGuardBuilder(guardBuilder, failedStatus);

            // Act
            Func<Task> action = async () => await _directDebitApiController.CreatePendingDirectDebit(
                Context.Resolve<IActionHandler<CreatePendingDirectDebitHandlerRequest, CreatePendingDirectDebitResponse>>(),
                Context.Resolve<ILogger<DirectDebitApiController>>(),
                guardBuilder.Object,
                Context.Resolve<IMapper>(),
                request,
                arrangementId,
                authorisation,
                CancellationToken.None
            );

            // Assert
            await action.Should()
                .ThrowAsync<StandardApiException>()
                .Where(s => s.HttpStatusCode == StatusCodes.Status400BadRequest);
        }

        [Theory]
        [InlineData(ValidArrangementId, "InvalidArrangmentId")]        
        public async Task CreatePendingDirectDebit_Fails_OnCustomerEntitlements(string requestJson, string invalidArrangementId)
        {
            // Arrange
            var request = Resource.ExtractManifestResource<CreatePendingDirectDebitRequest>(requestJson);            

            // Act
            Func <Task> action = async () => await _directDebitApiController.CreatePendingDirectDebit(
                Context.Resolve<IActionHandler<CreatePendingDirectDebitHandlerRequest, CreatePendingDirectDebitResponse>>(),
                Context.Resolve<ILogger<DirectDebitApiController>>(),
                Context.Resolve<IGuardBuilder>(),
                Context.Resolve<IMapper>(),
                request,
                invalidArrangementId,
                authorisation,
                CancellationToken.None
            );
           
            // Assert
            await action.Should()
                .ThrowAsync<StandardApiException>()
                .Where(s => s.HttpStatusCode == StatusCodes.Status403Forbidden);
       
        }

        [Theory]        
        [InlineData(InvalidForNullResponse, InvalidForNullResponse, 1, StatusCodes.Status400BadRequest)]
        public async Task CreatePendingDirectDebit_Fails_OnMicroInit(string requestJson, string invalidArrangementId, int callCount, int statusCode)
        {
            // Arrange
            var request = Resource.ExtractManifestResource<CreatePendingDirectDebitRequest>(requestJson);
            var eventData = Resource.ExtractManifestResource<EV52CancelDirectDebitEvent>("Default");

            // Act
            Func<Task> action = async () => await _directDebitApiController.CreatePendingDirectDebit(
                Context.Resolve<IActionHandler<CreatePendingDirectDebitHandlerRequest, CreatePendingDirectDebitResponse>>(),
                Context.Resolve<ILogger<DirectDebitApiController>>(),
                Context.Resolve<IGuardBuilder>(),
                Context.Resolve<IMapper>(),
                request,
                invalidArrangementId,
                authorisation,
                CancellationToken.None
            );

            var actualMessage = ServiceBus.MessageToSend<EV52CancelDirectDebitEvent>(eventData);

            // Assert
            await action.Should()
                .ThrowAsync<StandardApiException>()
                .Where(s => s.HttpStatusCode == statusCode);
            Context.GetMock<IServiceBusEventPublisher>()
                .Verify(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV52CancelDirectDebitEvent>(), null), Times.Exactly(callCount));         
            ServiceBus.SentCalls.Should().HaveCount(callCount);
            ServiceBus.CompletedCalls.Should().HaveCount(0);
            ServiceBus.DeadLetterEntries.Should().HaveCount(0);
        }

        [Theory]
        [InlineData(ValidArrangementId, FAILURE)]
        public async Task CreatePendingDirectDebit_Fails_OnInvalidCustomerProfile(string arrangementId, string cif)
        {
            // Arrange
            var request = Resource.ExtractManifestResource<CreatePendingDirectDebitRequest>(arrangementId);

            var guardBuilder = Context.GetMock<IGuardBuilder>();
            SetupGuardBuilder(guardBuilder, cif);

            // Act
            Func<Task> action = async () => await _directDebitApiController.CreatePendingDirectDebit(
                Context.Resolve<IActionHandler<CreatePendingDirectDebitHandlerRequest, CreatePendingDirectDebitResponse>>(),
                Context.Resolve<ILogger<DirectDebitApiController>>(),
                guardBuilder.Object,
                Context.Resolve<IMapper>(),
                request,
                arrangementId,
                authorisation,
                CancellationToken.None
            );

            // Assert
            await action.Should()
                .ThrowAsync<StandardApiException>()
                .Where(s => s.HttpStatusCode == StatusCodes.Status400BadRequest);
        }

        [Theory]
        [InlineData(ValidArrangementId, "1234")]
        public async Task CreatePendingDirectDebit_Fails_OnFailedInitiateMicroTransaction(string arrangementId, string accountNumber)
        {
            // Arrange
            var request = Resource.ExtractManifestResource<CreatePendingDirectDebitRequest>(arrangementId);
            request.AccountNumber = accountNumber;

            // Act
            Func<Task> action = async () => await _directDebitApiController.CreatePendingDirectDebit(
                Context.Resolve<IActionHandler<CreatePendingDirectDebitHandlerRequest, CreatePendingDirectDebitResponse>>(),
                Context.Resolve<ILogger<DirectDebitApiController>>(),
                Context.Resolve<IGuardBuilder>(),
                Context.Resolve<IMapper>(),
                request,
                arrangementId,
                authorisation,
                CancellationToken.None
            );

            // Assert
            await action.Should().ThrowAsync<StandardApiException>()
                .Where(e=>e.HttpStatusCode == StatusCodes.Status400BadRequest);
        }

        [Theory]
        [InlineData(ValidArrangementId, FAILURE)]
        public async Task CreatePendingDirectDebit_Fails_OnAccountDetails(string arrangementId, string cif)
        {
            // Arrange
            var request = Resource.ExtractManifestResource<CreatePendingDirectDebitRequest>(arrangementId);

            var guardBuilder = Context.GetMock<IGuardBuilder>();
            SetupGuardBuilder(guardBuilder, cif);

            // Act
            Func<Task> action = async () => await _directDebitApiController.CreatePendingDirectDebit(
                Context.Resolve<IActionHandler<CreatePendingDirectDebitHandlerRequest, CreatePendingDirectDebitResponse>>(),
                Context.Resolve<ILogger<DirectDebitApiController>>(),
                Context.Resolve<IGuardBuilder>(),
                Context.Resolve<IMapper>(),
                request,
                arrangementId,
                authorisation,
                CancellationToken.None
            );

            // Assert
            await action.Should()
                .ThrowAsync<StandardApiException>()
                .Where(e => e.HttpStatusCode == StatusCodes.Status400BadRequest);
        }

        [Theory]
        [InlineData(ValidArrangementId, "1234")]
        public async Task CreatePendingDirectDebit_Fails_OnT24CreatePendingDirectDebit(string arrangementId, string accountNumber)
        {
            // Arrange
            var request = Resource.ExtractManifestResource<CreatePendingDirectDebitRequest>(arrangementId);
            request.AccountNumber = accountNumber;

            // Act
            Func<Task> action = async () => await _directDebitApiController.CreatePendingDirectDebit(
                Context.Resolve<IActionHandler<CreatePendingDirectDebitHandlerRequest, CreatePendingDirectDebitResponse>>(),
                Context.Resolve<ILogger<DirectDebitApiController>>(),
                Context.Resolve<IGuardBuilder>(),
                Context.Resolve<IMapper>(),
                request,
                arrangementId,
                authorisation,
                CancellationToken.None
            );

            // Assert
            await action.Should()
                .ThrowAsync<StandardApiException>()
                .Where(e => e.HttpStatusCode == StatusCodes.Status400BadRequest);
        }
    }
}