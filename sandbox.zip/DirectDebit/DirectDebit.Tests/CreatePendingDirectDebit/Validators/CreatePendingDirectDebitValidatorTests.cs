using DirectDebitApi.Models;
using DirectDebitApi.Validators;
using FluentValidation.TestHelper;
using Platform.Library.Testing.XUnit;
using Xunit;
using Xunit.Abstractions;

namespace DirectDebit.UnitTests.Validators
{
    [TestType(TestTypeEnum.UnitTest)]
    public class CreatePendingDirectDebitValidatorTests : XUnitTestFixture
    {
        private readonly CreatePendingDirectDebitValidator _validator;

        public CreatePendingDirectDebitValidatorTests(ITestOutputHelper outputHelper,
            XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {
            _validator = new CreatePendingDirectDebitValidator();
        }

        [Fact]
        public void InvalidRequest2()
        {
            //Arrange
            var request = CreatePendingDirectDebitHandlerRequest.Define(null, null, null);

            //Act
            var result = _validator.TestValidate(request);

            //Assert            
            result.ShouldHaveValidationErrorFor(r => r.ArrangementId);      
            result.ShouldHaveValidationErrorFor(r => r.CustomerId);
            result.ShouldHaveValidationErrorFor(r => r.Request);
        }

        [Fact]
        public void ValidRequest()
        {
            //Arrange
            var request = CreatePendingDirectDebitHandlerRequest.Define(
                "124",
                "AA2122268J4B",
                new CreatePendingDirectDebitRequest
                {
                    AccountName = "Unverified OFI Account",
                    BsbNumber = "123-123",
                    AccountNumber = "123412345"
                }
            );

            //Act
            var result = _validator.TestValidate(request);

            //Assert
            result.ShouldNotHaveValidationErrorFor(r => r.Request);
            result.ShouldNotHaveValidationErrorFor(r => r.CustomerId);
            result.ShouldNotHaveValidationErrorFor(r => r.ArrangementId);

            result.ShouldNotHaveValidationErrorFor(r => r.Request.AccountName);
            result.ShouldNotHaveValidationErrorFor(r => r.Request.AccountNumber);
            result.ShouldNotHaveValidationErrorFor(r => r.Request.BsbNumber);
        }
    }
}