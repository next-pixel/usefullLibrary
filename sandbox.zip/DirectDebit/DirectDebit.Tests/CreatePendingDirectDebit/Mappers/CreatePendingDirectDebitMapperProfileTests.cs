using AutoMapper;
using DirectDebitApi.Configuration;
using DirectDebitApi.Mappers;
using DirectDebitApi.Models;
using Platform.Library.T24.SDK.Modules.DirectDebit.RequestDtos;
using Platform.Library.T24.SDK.Modules.DirectDebit.ResponseDtos;
using Platform.Library.Testing.XUnit;
using Xunit;
using Xunit.Abstractions;

namespace DirectDebit.UnitTests.Mappers
{
    [TestType(TestTypeEnum.UnitTest)]
    public class CreatePendingDirectDebitMapperProfileTests : XUnitTestFixture
    {
        public CreatePendingDirectDebitMapperProfileTests(ITestOutputHelper outputHelper,
            XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {
        }

        private ContextModule Context => Module<ContextModule>();
        private ModelModule Models => Module<ModelModule>();
        private ResourceModule Resource => Module<ResourceModule>();
        protected override IEnumerable<string> AdditionalConfigurations => new List<string> { "test" };

        protected override void TestSetup()
        {
            Context.RegisterTypeAsInterfaces<Settings>();
            Context.RegisterMapperAndProfiles(s => new CreatePendingDirectDebitMapperProfile());
        }

        [Fact]
        public void TestMappingProfileIsValid()
        {
            var mapper = Context.Resolve<IMapper>();

            mapper.ConfigurationProvider.AssertConfigurationIsValid();
        }
        
        [Fact]
        public void Map_T24CreateDirectDebitResponse_To_CreatePendingDirectDebitResponse()
        {
            var t24CreateDirectDebitResponse = Resource.ExtractManifestResource<T24CreateDirectDebitResponseDto>("Success");
            Resource.ExtractManifestResource<CreatePendingDirectDebitResponse>("Success");

            var mapper = Context.Resolve<IMapper>();

            var actual = mapper.Map<T24CreateDirectDebitResponseDto, CreatePendingDirectDebitResponse>(t24CreateDirectDebitResponse);

            Assert.True(Models.Compare(actual).Match);
        }

        [Fact]
        public void Map_CreatePendingDirectDebitHandlerRequest_To_T24CreateDirectDebitRequest()
        {
            var createPendingDirectDebitHandlerRequest = Resource.ExtractManifestResource<CreatePendingDirectDebitHandlerRequest>("Sample");
            Resource.ExtractManifestResource<T24CreateDirectDebitRequestDto>("ExpectedResponse");

            var mapper = Context.Resolve<IMapper>();

            var actual = mapper.Map<T24CreateDirectDebitRequestDto>((createPendingDirectDebitHandlerRequest, "2500"));

            Assert.True(Models.Compare(actual).Match);
        }
    }
}