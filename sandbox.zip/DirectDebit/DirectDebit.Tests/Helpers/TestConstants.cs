﻿namespace DirectDebit.UnitTests.Helpers
{
    public class TestConstants
    {
        public static class HttpMethods
        {
            public const string Delete = "DELETE";
            public const string Put = "PUT";
            public const string Post = "POST";
            public const string Get = "GET";
        }

        public static class Errors
        {
            public const string Comms = "Error occurred while attempting to communicate with Temenos system. Check if the input parameters are valid";
        }
    }
}