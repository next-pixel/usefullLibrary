using DirectDebitApi.Helpers;
using FluentAssertions;
using FluentAssertions.Execution;
using Platform.Library.Testing.XUnit;
using Xunit;
using Xunit.Abstractions;

namespace DirectDebit.UnitTests.Helpers
{
    [TestType(TestTypeEnum.UnitTest)]
    public class CodeGeneratorTests : XUnitTestFixture
    {
        public CodeGeneratorTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper,
            classFixture)
        {
        }

        [Theory]
        [InlineData(null,null, null)]
        [InlineData(null, 9999, null)]
        [InlineData(10, null, null)]
        [InlineData(21, 96543, null)]
        [InlineData(null, null, 8)]
        [InlineData(null, 9999, 8)]
        [InlineData(10, null, 8)]
        [InlineData(21, 96543433, 8)]
        [InlineData(null, 9999, 4)]
        [InlineData(9000, 9654, 4)]
        public void TestMappingProfileIsValid(int? min, int? max, int? padLength)
        {
            // Arrange
            string code = null;

            // Act
            if (min.HasValue)
            {
                if (max.HasValue)
                    code = padLength.HasValue
                        ? CodeGenerator.Generate(min.Value, max.Value, padLength.Value)
                        : CodeGenerator.Generate(min.Value, max.Value);
                else
                    code = padLength.HasValue
                        ? CodeGenerator.Generate(min.Value, padLeft: padLength.Value)
                        : CodeGenerator.Generate(min.Value);
            }
            else if (max.HasValue)
            {
                code = padLength.HasValue
                    ? CodeGenerator.Generate(max: max.Value, padLeft: padLength.Value )
                    : CodeGenerator.Generate(max: max.Value);
            }
            else
                code = padLength.HasValue
                    ? CodeGenerator.Generate(padLeft: padLength.Value)
                    : CodeGenerator.Generate();

            // Assert
            using (new AssertionScope())
            {
                code.Should().HaveLength(padLength ?? CodeGenerator.PadLength);
                Int32.TryParse(code, out var intValue).Should().BeTrue();
                intValue.Should().BeGreaterThanOrEqualTo(min ?? CodeGenerator.MinValue);
                intValue.Should().BeLessThanOrEqualTo(max ?? CodeGenerator.MaxValue);
            }
        }
    }
}