﻿using Platform.Library.Common;
using System.Runtime.InteropServices;

namespace DirectDebit.UnitTests.Helpers
{
    internal static class DateTimeExtensions
    {
        /// <summary>
        /// Converts the provided <paramref name="dateTime"/> to the local <paramref name="timeZone"/> required
        /// </summary>
        /// <param name="dateTime">The <see cref="DateTime"/> value to be converted</param>
        /// <param name="timeZone">The <see cref="TimeZoneIdentifier">time zone information</see> to use</param>
        /// <returns>A <see cref="DateTime"/> reconfigured to use the timezone provided</returns>
        internal static DateTime ToLocalTimeZone(this DateTime dateTime, TimeZoneIdentifier timeZone)
        {
            string timeZoneId = RuntimeInformation.IsOSPlatform(OSPlatform.Windows)
                ? timeZone.Windows
                : timeZone.Unix;

            TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(timeZoneId);

            return TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(dateTime, DateTimeKind.Utc), timeZoneInfo);
        }
    }
}
