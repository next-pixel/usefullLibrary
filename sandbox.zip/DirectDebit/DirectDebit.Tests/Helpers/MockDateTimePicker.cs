﻿using Platform.Library.Common;

namespace DirectDebit.UnitTests.Helpers
{
    public class MockDateTimePicker : IDateTimePicker
    {
        private readonly TimeZoneIdentifier _timeZone;
        private DateTime _dateTime;

        public MockDateTimePicker(TimeZoneIdentifier timeZone, DateTime? dateTime = null)
        {
            _timeZone = timeZone;
            _dateTime = dateTime ?? DateTime.UtcNow;
        }

        public void Set(DateTime dateTime)
        {
            _dateTime = dateTime;
        }

        public DateTime Now => _dateTime.ToLocalTimeZone(_timeZone);

        public DateTime UtcNow => _dateTime;

        public DateTime Today => _dateTime.ToLocalTimeZone(_timeZone).Date;
    }
}
