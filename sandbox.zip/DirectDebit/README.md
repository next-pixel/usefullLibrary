[![Target Framework](https://img.shields.io/badge/Target%20Framework:-net6.0-GREEN.svg?style=plastic&logo=dotnet)](https://shields.io/)
[![Quality Gate Status](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=DirectDebit&metric=alert_status&token=sqb_481942ad9eb464288cb7ffe91e484257fef68231)](https://sonarqube.boqdev.com.au/dashboard?id=DirectDebit)
[![Coverage](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=DirectDebit&metric=coverage&token=sqb_481942ad9eb464288cb7ffe91e484257fef68231)](https://sonarqube.boqdev.com.au/dashboard?id=DirectDebit)

[![Bugs](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=DirectDebit&metric=bugs&token=sqb_481942ad9eb464288cb7ffe91e484257fef68231)](https://sonarqube.boqdev.com.au/dashboard?id=DirectDebit)
[![Code Smells](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=DirectDebit&metric=code_smells&token=sqb_481942ad9eb464288cb7ffe91e484257fef68231)](https://sonarqube.boqdev.com.au/dashboard?id=DirectDebit)[![Security Hotspots](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=DirectDebit&metric=security_hotspots&token=sqb_481942ad9eb464288cb7ffe91e484257fef68231)](https://sonarqube.boqdev.com.au/dashboard?id=DirectDebit)
[![Vulnerabilities](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=DirectDebit&metric=vulnerabilities&token=sqb_481942ad9eb464288cb7ffe91e484257fef68231)](https://sonarqube.boqdev.com.au/dashboard?id=DirectDebit)


|Brand|Latest Build|
|--|--|
|**VMA**|[![Build Status](https://dev.azure.com/qdigitalcode/DenovoBank/_apis/build/status/DirectDebit?repoName=DirectDebit&branchName=master)](https://dev.azure.com/qdigitalcode/DenovoBank/_apis/build/status%2FHomeLoans%2FAPI%2FDirectDebit-VMA?repoName=DirectDebit&branchName=master)|
|**BOQ**|[![Build Status](https://dev.azure.com/qdigitalcode/DenovoBank/_apis/build/status/DirectDebit?repoName=DirectDebit&branchName=master)](https://dev.azure.com/qdigitalcode/DenovoBank/_apis/build/status%2FHomeLoans%2FAPI%2FDirectDebit-BOQ?repoName=DirectDebit&branchName=master)|
|**MEB**|[![Build Status](https://dev.azure.com/qdigitalcode/DenovoBank/_apis/build/status%2FHomeLoans%2FAPI%2FDirectDebit-MEB?repoName=DirectDebit&branchName=master)](https://dev.azure.com/qdigitalcode/DenovoBank/_build/latest?definitionId=2837&repoName=DirectDebit&branchName=master)|

# IC89 Direct Debit (Web API) 

## Description
This service provides operations relating to the verification and activation of direct debits to loan accounts.

## Confluence
Details about this component can be found on the following pages:

|||
|-:|:-|
|**Gateway:**|[A76 Direct Debit (Gateway API)](https://qdigital.atlassian.net/wiki/spaces/ITSARCH/pages/6111577692/A76+Direct+Debit+Gateway+API)|
|**Component:**|[IC89 Direct Debit Web API](https://qdigital.atlassian.net/wiki/spaces/ITSARCH/pages/6111577766/IC89+Direct+Debit+Phase2+Web+API)|
