namespace DirectDebitApi.Configuration
{
    public class TableStorageOptions
    {
        public string ConnectionString { get; set; }
        public string TableName { get; set; }
    }
}