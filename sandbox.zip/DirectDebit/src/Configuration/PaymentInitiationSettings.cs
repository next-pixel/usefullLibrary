using Platform.Library.Common.AspNetCore.StandardApi.Http;
using Platform.Library.Http;
using static DirectDebitApi.InternalConstants.Configuration;

namespace DirectDebitApi.Configuration
{
    /// <summary>
    /// Settings for payment initiation api.
    /// </summary>
    public class PaymentInitiationSettings : ClientSettings
    {
        /// <inheritdoc cref="ClientSettings.ConfigName"/>
        public override string ConfigName => Sections.PaymentInitiation;

        /// <summary>
        /// Additional headers to configure when registering client
        /// </summary>
        protected override IEnumerable<AdditionalHeader> AdditionalHeaders => ConfigHeadersBuilder.Include(StandardHeaderConstants.OcpApimSubscriptionKey, InternalApimSubscriptionKey);

        /// <summary>
        /// Path to initiate direct debit.
        /// </summary>
        public string InitiateDirectDebitPath { get; set; }
    }
}