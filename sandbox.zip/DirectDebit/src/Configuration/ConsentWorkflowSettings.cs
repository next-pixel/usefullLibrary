﻿using Platform.Library.Http;
using static DirectDebitApi.InternalConstants.Configuration;

namespace DirectDebitApi.Configuration
{
    /// <summary>
    /// Settings for consent workflow API.
    /// </summary>
    public class ConsentWorkflowSettings : ClientSettings
    {
        /// <inheritdoc cref="ClientSettings.ConfigName"/>
        public override string ConfigName => Sections.ConsentWorkflow;

        /// <summary>
        /// Path to get operational attribute.
        /// </summary>
        public string GetOperationAttributePath { get; set; }
    }
}