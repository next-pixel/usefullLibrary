﻿using DirectDebitApi.Configuration.Abstractions;
using Platform.Library.Common.AspNetCore.StandardApi.Configuration.Abstractions;
using System.Diagnostics.CodeAnalysis;

namespace DirectDebitApi.Configuration
{
    [ExcludeFromCodeCoverage]
    public class Settings : StandardApiSettings, ISettings
    {
        public Settings(IConfiguration configuration) : base(configuration)
        {
            configuration.Bind(this);
        }
                
        // Azure APIM
        public string InternalApimSubscriptionKey { get; set; }

        public string DirectDebitParamId { get; set; }

        public DirectDebitTableStorage DirectDebitTableStorage { get; set; } = new();
        public ServiceBusOptions ServiceBus { get; set; } = new();

        public DirectDebitApiSettings DirectDebitApi { get; set; } = new();
    }
}