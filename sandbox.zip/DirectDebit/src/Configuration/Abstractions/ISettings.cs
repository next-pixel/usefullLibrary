﻿using Platform.Library.Common.AspNetCore.StandardApi.Configuration.Abstractions;

namespace DirectDebitApi.Configuration.Abstractions
{
    public interface ISettings : IStandardApiSettings
    {
        string InternalApimSubscriptionKey { get; }
        DirectDebitTableStorage DirectDebitTableStorage { get; }
        string DirectDebitParamId { get; }
        ServiceBusOptions ServiceBus { get; }
        DirectDebitApiSettings DirectDebitApi { get; }
    }
}