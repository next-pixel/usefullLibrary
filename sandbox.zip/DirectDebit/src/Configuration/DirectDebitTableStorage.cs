﻿namespace DirectDebitApi.Configuration
{
    public class DirectDebitTableStorage : TableStorageOptions
    {
        
    }
}