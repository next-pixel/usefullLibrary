﻿namespace DirectDebitApi.Configuration
{
    public class DirectDebitApiSettings
    {
        public TimeSpan DirectDebitExpiryInterval { get; set; }       
        public TimeSpan DirectDebitCommunicationSendInterval { get; set; }
    }
}
