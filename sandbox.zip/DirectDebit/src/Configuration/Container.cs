﻿using Autofac;
using Autofac.Extensions.DependencyInjection;
using AutoMapper;
using DirectDebitApi.ActionHandlers;
using DirectDebitApi.Clients;
using DirectDebitApi.Configuration.Abstractions;
using DirectDebitApi.Extensions;
using DirectDebitApi.Mappers;
using DirectDebitApi.Validators;
using FluentValidation.AspNetCore;
using Microsoft.Azure.Cosmos.Table;
using Microsoft.FeatureManagement;
using Microsoft.OpenApi.Models;
using Platform.Library.Authentication;
using Platform.Library.Authentication.Guards;
using Platform.Library.Authentication.Models;
using Platform.Library.Authentication.Models.Common;
using Platform.Library.AzureStorage.Clients;
using Platform.Library.AzureStorage.Clients.Abstraction;
using Platform.Library.Common;
using Platform.Library.Common.AspNetCore.StandardApi.Logging.Enrichers;
using Platform.Library.Common.AspNetCore.StandardApi.Logging.Serilog.Filters;
using Platform.Library.Common.Extensions;
using Platform.Library.Common.Standard.Configuration.Abstractions;
using Platform.Library.Communication.Extensions;
using Platform.Library.Events;
using Platform.Library.HealthChecks;
using Platform.Library.Http;
using Platform.Library.T24.SDK.DependencyInjection;
using Serilog.Events;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using ContainerBuilder = Autofac.ContainerBuilder;

namespace DirectDebitApi.Configuration
{
    [ExcludeFromCodeCoverage]
    public static class Container
    {
        public static ILifetimeScope Configure(IServiceCollection services, IConfiguration configuration)
        {
            var rootContainerBuilder = new ContainerBuilder();
            var settings = ConfigureSettingsAndPopulateContainerBuilder(services, configuration, rootContainerBuilder);
            RegisterApplicationSpecificComponents(rootContainerBuilder, settings);

            var rootContainer = rootContainerBuilder.Build();
            var serviceContainerAccessor = InitialiseServiceLifetimeContainerAccessor(rootContainer);

            return serviceContainerAccessor.Container;
        }

        private static Settings ConfigureSettingsAndPopulateContainerBuilder(
            IServiceCollection services,
            IConfiguration configuration, 
            ContainerBuilder rootContainerBuilder)
        {
            // Settings
            var settings = new Settings(configuration);
            rootContainerBuilder.RegisterInstance(settings).AsImplementedInterfaces();

            // Configure Custom Health Checks
            services.AddHealthChecks()
                .AddSettingsHealthCheck<ISettings, SettingsValidator>();

            services.AddFeatureManagement();
            services
                .AddAzureAppConfiguration()
                .RegisterEventsLibrary()
                .RegisterAllValidators()
                .ConfigureAuthentication(
                AuthenticationType.CustomerOrAdToken,
#if DEBUG
                    true,
#else
                    false,
#endif
                    InternalConstants.Configuration.Sections.DirectDebitApi
                );

            settings.ApiMvcAdditionalOptions.MvcOptionsSetupAction = options => { }; // Configure Custom Mvc Options
            settings.ApiMvcAdditionalOptions.ApiVersioningOptionsSetupAction =
                options => { }; // Configure Custom Api Versioning Options

#if DEBUG
            // Disable authentication in local development
            settings.ApiMvcAdditionalOptions.IsStandardAuthenticationEnabled = false;
            settings.Logging.WriteToApplicationInsights = false;
            settings.Logging.WriteToConsole = true;
            settings.Logging.WriteToDebug = true;
#endif

            // Configure Services
            services.AddStandardApiMvcServices(settings);

            services.AddApplicationInsightsTelemetry(settings.Logging.ApplicationInsightsKey);
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = typeof(Startup).Namespace, Version = "v1" });
                c.CustomSchemaIds(x => x.FullName);
            });

            // Add HttpClients
            RegisterHttpClients(
                services,
#if DEBUG
                true
#else
                false
#endif
            );

            services.RegisterBrandResolver();

            services.RegisterAutoMapperProfiles();

            // Register dependencies, populate the services from the collection, and build the container.
            // Note that Populate is basically a foreach to add things into Autofac that are in the collection.
            // If you register things in Autofac BEFORE Populate then the stuff in the ServiceCollection can override those things.
            // If you register AFTER Populate those registrations can override things in the ServiceCollection. Mix and match as needed.
            rootContainerBuilder.Populate(services);
            rootContainerBuilder.RegisterStandardApiComponents(settings.ApiMvcAdditionalOptions);
            rootContainerBuilder.RegisterStandardLogging(
                settings.Logging,
                new[] { new HttpContextActionMetadataEnricher() },
                new[] { new LogCategoryAndLevelFilter("Microsoft.AspNetCore", LogEventLevel.Error) });

            return settings;
        }

        private static void RegisterHttpClients(IServiceCollection services, bool inDebug)
        {
            services.RegisterT24Sdk(
                inDebug,
                t24SubscriptionKey: null,
                InternalConstants.Configuration.Sections.DirectDebitApi
            );

            services.RegisterAllHttpClients(
                componentSectionName: InternalConstants.Configuration.Sections.DirectDebitApi,
                defaultHeaders: null,
                inDebug: inDebug
            );
        }

        private static void RegisterApplicationSpecificComponents(ContainerBuilder builder, Settings settings)
        {
            builder.RegisterType<DateTimePicker>().AsImplementedInterfaces().SingleInstance();

            // Clients
            builder.RegisterType<HttpClientHelper>().AsImplementedInterfaces();

            // Handlers
            builder.RegisterType<RetrieveDirectDebitHandler>().AsImplementedInterfaces();
            builder.RegisterType<CreatePendingDirectDebitHandler>().AsImplementedInterfaces();
            builder.RegisterType<ActiveDirectDebitHandler>().AsImplementedInterfaces();
            builder.RegisterType<VerifyPendingDirectDebitHandler>().AsImplementedInterfaces();
            builder.RegisterType<CancelPendingDirectDebitHandler>().AsImplementedInterfaces();

            // Client
            builder.RegisterType<PaymentInitiationClient>().AsImplementedInterfaces();
            builder.RegisterType<ConsentWorkflowClient>().AsImplementedInterfaces();

            // Table storage
            builder.Register((c, p) =>
            {
                var storageAccount = CloudStorageAccount.Parse(settings.DirectDebitTableStorage.ConnectionString);
                var tableClient = storageAccount.CreateCloudTableClient();
                return new AzureTableStorageClient(
                    c.Resolve<ILogger<AzureTableStorageClient>>(),
                    tableClient.GetTableReference(settings.DirectDebitTableStorage.TableName));
            })
            .As<IAzureTableStorageClient>().InstancePerLifetimeScope();

            builder.Register(x =>
            {
                return new ServiceBusEventPublisher(
                    x.Resolve<ILogger<ServiceBusEventPublisher>>(),
                    settings.ServiceBus.ConnectionString01,
                    settings.ServiceBus.ConnectionString02,
                    x.Resolve<IValidationResolver>());

            }).As<IServiceBusEventPublisher>();
        }

        private static IServiceLifetimeContainerAccessor InitialiseServiceLifetimeContainerAccessor(
            IContainer rootContainer)
        {
            var serviceContainerAccessor = rootContainer.Resolve<IServiceLifetimeContainerAccessor>();
            serviceContainerAccessor.Container = rootContainer.BeginLifetimeScope();

            return serviceContainerAccessor;
        }
    }
}