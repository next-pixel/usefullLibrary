﻿namespace DirectDebitApi.Configuration
{
    public class ServiceBusOptions
    {
        public string ConnectionString01 { get; set; }
        public string ConnectionString02 { get; set; }
    }
}
