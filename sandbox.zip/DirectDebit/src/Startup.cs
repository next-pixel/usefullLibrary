using Autofac;
using Autofac.Extensions.DependencyInjection;
using DirectDebitApi.Configuration;
using DirectDebitApi.Configuration.Abstractions;
using Platform.Library.HealthChecks;
using System.Diagnostics.CodeAnalysis;

namespace DirectDebitApi
{
    [ExcludeFromCodeCoverage]
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public ILifetimeScope ApplicationContainer { get; private set; }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime before Configure(). This sets up Autofac as
        // the service provider in place of the default ASP.NET dependency injection.
        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            ApplicationContainer = Container.Configure(services, Configuration);
            // Create the IServiceProvider based on the container.
            return new AutofacServiceProvider(ApplicationContainer);
        }

        // This method gets called by the runtime after ConfigureServices. Use this method to configure the HTTP request pipeline.
        // You can use IApplicationBuilder.ApplicationServices here if you need to resolve things from the container.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            var settings = app.ApplicationServices.GetRequiredService<ISettings>();

            app.UsePathBase("");
            app.UseStandardApiComponents(env, settings);
            app.UseAzureAppConfiguration();
            app.UseDetailedHealthChecks("/healthcheck");
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Direct Debit v1");
            });
        }
    }
}
