﻿using Azure.Core;
using System.Diagnostics.CodeAnalysis;
using static DirectDebitApi.InternalConstants.Configuration;
using static Platform.Library.T24.SDK.T24SdkConstants;

namespace DirectDebitApi
{
    [ExcludeFromCodeCoverage]
    public static class InternalConstants
    {
        public const string NullStringValue = "_Null";

        /// <summary>
        /// Definition of the systems to send back when there is an error
        /// </summary>
        public static class Systems
        {
            public const string DirectDebitApi = nameof(DirectDebitApi);
            public const string AzureTableStorage = nameof(AzureTableStorage);
            public const string ConsentWorkflow = nameof(ConsentWorkflow);
            public const string T24 = nameof(T24);
        }

        public static class Configuration
        {
            public const string InternalApimSubscriptionKey = nameof(InternalApimSubscriptionKey);

            /// <summary>
            /// Use these to create specify configuration section for downstream system
            /// </summary>
            public static class Sections
            {
                public const string PaymentInitiation = nameof(PaymentInitiation);
                public const string DirectDebitApi = nameof(DirectDebitApi);
                public const string ConsentWorkflow = nameof(ConsentWorkflow);
            }
        }

        /// <summary>
        /// Use these to create named HttpClients per downstream system
        /// </summary>
        public static class HttpClients
        {
            public const string PaymentInitiation = Sections.PaymentInitiation;
            public const string ConsentWorkflow = Sections.ConsentWorkflow;
        }

        public static class FeatureFlags
        {
            public const string Homeloans = "ff-future-development-HL";
            public const string EnableHomeLoans = "ff-enable-home-loans";
            public const string EnableHomeLoansMarketLaunch = "ff-enable-home-loans-market-launch";
        }

        public static class Cache
        {
            public const double Duration = 5;
        }

        public static class DirectDebitStatus
        {
            public const string Active = "ACTIVE";
            public const string New = "NEW";
            public const string Pending = "PENDING";
            public const string Cancelled = "CANCELLED";
        }

        public static class DateFormats
        {
            public const string IntegrationDateFormat = "yyyy-MM-dd";
        }

        public static class Headers
        {
            public const string InteractionId = "Interaction-Id";
        }

        public static class TableStorage
        {
            public const string AzureTableStorage = "Azure Table Storage";

            public static class DirectDebit
            {
                public const string PartitionKey = "DirectDebit";
            }
        }

        public static class HomeLoan
        {
            public static class ActivityId
            {
                public const string LendingUpdateRepaymentDd = "LENDING-UPDATE-REPAYMENT.DD";
                public const string LendingRedrawCharges = "LENDING-REDRAW-CHARGES";
            }

            public static readonly string[] RepaymentTypesSupportedForDirectDebit = new string[]
            {
                T24RepaymentType.Constant,                
                T24RepaymentType.ActualFees
            };

            public static class ActivityCharges
            {
                public const string SettleActivity = "LENDING-SETTLE-PR.REPAYMENT";
                public const string AutoSettleYes = "YES";
            }
        }

        public static class VerifyPendingDDConstants
        {
            public const int MaxNumOfAttempts = 3;

            public enum RestoreOrSoftDeleteDD
            {
                Restore,
                SoftDelete
            }
        }

        public static class ServiceBus
        {
            public const string EV52CancelDirectDebitEventName = "EV52CancelDirectDebit";
            public const string EV52CancelDirectDebitTopic = "t37directdebit";
            public const string SendingSystemId = "DirectDebit";
            public const string SendingSystemVersion = "v1";
        }

        public static class Error
        {
            public static class Codes
            {
                public const string MaxAttemptsExceeded = "SLDD006";
                public const string InvalidVerificationCode = "SLDD005";
            }

            public static string DirectDebitIdDoesNotExistInT24(string directDebitId, string customerId) => $"T24 does not contain direct debit {directDebitId} for customer {customerId}";
            public static string BsbNumAndAccountNumNotMatched(string directDebitId, string customerId) => $"Direct Debit for customer {customerId} with id {directDebitId} does not contain the same bsb number and account number.";

            public const string DirectDebitMismatch = "Direct Debit does not contain the same bsb and/or account number";

            public const string DirectDebitIdAlreadyUsedForSettlement = "Direct Debit Id already used for settlement";
            public const string PayloadValidationFailed = "Payload Validation Failed";

            public const string DirectDebitIsActive = "Direct Debit Id is an active record.";


            public const string ErrorOnCancelDirectDebit = "Error encountered while cancelling pending direct debit.";

            // Retrieve pending DD in table storage
            public const string PendingDDNotFound = "No such pending direct debit exists in the table storage.";

            /// <summary>Activate pending DD in T24</summary>
            public static string ErrorOnActivateDD(string message) => $"Error occurred while setting pending direct debit status to active: {message}";

            // Homeloan
            public const string ErrorOnRetrieveHLAcctDetails = "Error occurred while retrieving homeloan account details.";

            public const string ErrorOnUpdateHLSettelement = "Error occurred while updating the homeloan settlement instructions.";

            public const string ErrorOnUpdateAutoSettleCharges = "Error occurred while updating the auto settle charges.";

            // Validate Verification Code
            public const string BeyondLimit = "Number of attempts is beyond allowed limit.";
            public static string InvalidVerificationCodeText(string verificationCode) => $"Invalid Verification Code '{verificationCode}'";
            public static string VerificationCodeDoesntMatch(string expected, string actual) => $"Verification code '{actual}' does not match expected value of '{expected}'";

            public const string MaxLimitAndInvalidCode = "Invalid verification code and allowed number of attempts reached.";

            // Hard delete in table storage
            public const string ErrorOnHardDelete = "Error while hard deleting pending direct debit in table storage. Housekeeping will be done by a separate app.";

            // Verify Arrangement Id
            public const string ArrangementIdNotMatched = "Provided arrangementId doesn't match value in the storage.";

            // Get Operational Attributes error
            public const string ErrorOnFetchingOperationalAttributes = "Error occurred while retrieving operational attributes.";

            // Get customer profile error
            public const string ErrorOnRetrieveCustomerProfile = "Error occurred while retrieving customer profile.";

            public const string ErrorOnInitiateMicroTransaction = "Error occurred while initiate micro transaction.";


            //Active Direct Debit Errors
            public const string DirectDebitNotActiveException = "SLDD002";
            public const string DirectDebitDetailsDoNotMatch = "SLDD003";
            public const string DirectDebitInUseException = "SLDD004";
            public const string DirectDebitNotActiveExceptionText = "The directDebitId provided relates to a record that is not ACTIVE.";
            public const string DirectDebitDetailsDoNotMatchText = "The direct debit details provided do not match the record.";
            public const string DirectDebitInUseExceptionText = "The direct debit details provided are currently being used for repayments on the account.";
            public const string DirectDebitDoesNotExist = "Direct debit does not exist";
            public const string AutoSettleChargeFailedErrorCode = "SPCOM9999";
            public const string RepaymentInstructionNotExist = "Not enough information to proceed - repayment instruction not found";
        }

        public static class RepaymentType
        {
            //RepaymentType

            public const string RepaymentTypeExternal = "EXTERNAL";
        }

        public static class Parameters
        {
            public static class Consents
            {
                public const string PartyOwner = "OWNER";
                public const string System = "system";
                public const string RequestId = "requestId";
                public const string Chrepm = "CHREPM";
                public const string T24 = nameof(T24);
            }
        }
    }
}