﻿using DirectDebitApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.FeatureManagement.Mvc;
using Platform.Library.Authentication.Guards;
using Platform.Library.Common.AspNetCore.StandardApi.Models;
using AutoMapper;
using static DirectDebitApi.InternalConstants;
using Platform.Library.Common.AspNetCore.Abstractions;
using Platform.Library.Common.AspNetCore.StandardApi.Http;
using Platform.Library.Common.Standard.Models;
using Platform.Library.Common.Standard.Models.Abstractions;
using DirectDebitApi.Helpers;
using Platform.Library.Authentication.Models.Common;

namespace DirectDebitApi.Controllers
{
    [Route("direct-debit")]
    [ApiController]
    [ApiVersion("1.0")]
    public class DirectDebitApiController : ControllerBase
    {
        /// <summary>
        /// Returns a list of direct debits
        /// </summary>
        [HttpGet, Route("v{version:apiVersion}/view"), MapToApiVersion("1.0")]
        [Consumes("application/json")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(List<RetrieveDirectDebitResponse>), 200)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 400)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 401)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 403)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 500)]
        [FeatureGate(FeatureFlags.Homeloans)]
        [FeatureGate(FeatureFlags.EnableHomeLoans)]
        public async Task<IActionResult> RetrieveDirectDebits(
            [FromServices] IActionHandler<RetrieveDirectDebitRequest, RetrieveDirectDebitResponse> retrieveDirectDebitHandler,
            [FromServices] ILogger<DirectDebitApiController> logger,
            [FromServices] IGuardBuilder guard,
            [FromQuery] string accountId,
            [FromQuery] string directDebitId,
            [FromQuery] string status,
            CancellationToken cancellationToken)
        {
            logger.LogDebug($"Entered {nameof(RetrieveDirectDebits)}");

            var context = await guard.Execute(cancellationToken);

            var request = new RetrieveDirectDebitRequest()
            {
                CustomerId = context.Temenos_cif,
                AccountId = accountId,
                DirectDebitId = directDebitId,
                Status = status.ToStatusConvert()
            };

            var result = await retrieveDirectDebitHandler.ProcessAsync(request, null, null, cancellationToken);

            logger.LogDebug($"Exit {nameof(RetrieveDirectDebits)}");

            return Ok(result);
        }

        /// <summary>
        /// Creates pending direct debit records for validation.
        /// </summary>
        [HttpPost, Route("v{version:apiVersion}/pending/{arrangementId}"), MapToApiVersion("1.0")]
        [Consumes("application/json")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(CreatePendingDirectDebitResponse), 200)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 400)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 401)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 500)]
        [FeatureGate(FeatureFlags.Homeloans)]
        public async Task<IActionResult> CreatePendingDirectDebit(
            [FromServices] IActionHandler<CreatePendingDirectDebitHandlerRequest, CreatePendingDirectDebitResponse> createDirectDebitHandler,
            [FromServices] ILogger<DirectDebitApiController> logger,
            [FromServices] IGuardBuilder guard,
            [FromServices] IMapper mapper,
            [FromBody] CreatePendingDirectDebitRequest request,
            [FromRoute] string arrangementId,
            [FromHeader(Name = StandardHeaderConstants.Authorization)] string authorization, 
            CancellationToken cancellationToken)
        {
            logger.LogDebug($"Entered {nameof(CreatePendingDirectDebit)}");

            var context = await guard.Execute(cancellationToken);

            var handlerRequest = CreatePendingDirectDebitHandlerRequest.Define(context.Temenos_cif, arrangementId, request);

            var result = await createDirectDebitHandler.ProcessAsync(handlerRequest, null, GetRequestHeaders(authorization), cancellationToken);

            logger.LogDebug($"Exit {nameof(CreatePendingDirectDebit)}");

            return Ok(result);
        }

        /// <summary>
        /// Create an active direct debit record and update home loan settlement instructions.
        /// </summary>
        /// <param name="authorization"></param>
        /// <param name="request"></param>
        /// <param name="guard"></param>
        /// <param name="actionHandler"></param>
        /// <param name="logger"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost, Route("v{version:apiVersion}/active/{arrangementId}"), MapToApiVersion("1.0")]
        [Consumes("application/json")]
        [Produces("application/json")]
        [ProducesResponseType(204)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 400)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 401)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 404)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 415)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 500)]
        [FeatureGate(FeatureFlags.Homeloans)]
        [FeatureGate(FeatureFlags.EnableHomeLoans)]
        public async Task<IActionResult> CreateActiveDirectDebit(
            [FromHeader(Name = StandardHeaderConstants.Authorization)] string authorization,
            [FromBody] ActiveDirectDebitRequest request,
            [FromServices] IGuardBuilder guard,
            [FromServices] IStandardAuthorisationGuards standardGuard,
            [FromServices] IActionHandler<ActiveDirectDebitComposite, ActiveDirectDebitResponse> actionHandler,
            [FromServices] ILogger<DirectDebitApiController> logger,
            [FromRoute] string arrangementId,
            CancellationToken cancellationToken
        )
        {
            logger.LogDebug($"Entering {nameof(CreateActiveDirectDebit)}");

            var standardHeaders = Request?.Headers?.RetrieveStandardHeaders() as StandardHeaderModel;
            var context = await guard.Execute(cancellationToken);

            var handlerRequest = new ActiveDirectDebitComposite()
            {
                ActiveDirectDebit = request,
                ArrangementId = arrangementId,
                TemenosCif = context.Temenos_cif,
            };

            await actionHandler.ProcessAsync(handlerRequest, null, standardHeaders, cancellationToken);

            logger.LogDebug($"Exit {nameof(CreateActiveDirectDebit)}");

            return NoContent();
        }

        /// <summary>
        /// Verify a pending direct debit request
        /// </summary>
        [HttpPost, Route("v{version:apiVersion}/verify/{directDebitId}"), MapToApiVersion("1.0")]
        [Consumes("application/json")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(VerifyPendingDirectDebitHandlerResponse), 200)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 400)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 401)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 403)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 500)]
        [FeatureGate(FeatureFlags.Homeloans)]
        public async Task<IActionResult> VerifyPendingDirectDebit(
            [FromServices] IActionHandler<VerifyPendingDirectDebitHandlerRequest, VerifyPendingDirectDebitHandlerResponse> verifyPendingDirectDebitHandler,
            [FromServices] ILogger<DirectDebitApiController> logger,
            [FromServices] IGuardBuilder guard,
            [FromServices] IMapper mapper,
            [FromHeader(Name = StandardHeaderConstants.Authorization)] string authorization,
            [FromBody] VerifyPendingDirectDebitRequest request,
            [FromRoute] string directDebitId,
            CancellationToken cancellationToken)
        {
            logger.LogDebug($"Entered {nameof(VerifyPendingDirectDebit)} for Direct Debit {directDebitId}");
            var context = await guard.Execute(cancellationToken);

            var composite = VerifyDirectDebitComposite.Define(request, context, directDebitId);

            var handlerRequest = mapper.Map<VerifyPendingDirectDebitHandlerRequest>(composite);

            var result = await verifyPendingDirectDebitHandler.ProcessAsync(handlerRequest, null, GetRequestHeaders(authorization), cancellationToken);

            return Ok(result);
        }

        /// <summary>
        /// Cancel a pending direct debit record.
        /// </summary>
        [HttpDelete, Route("v{version:apiVersion}/cancel/{directDebitId}"), MapToApiVersion("1.0")]
        [Consumes("application/json")]
        [Produces("application/json")]
        [ProducesResponseType(204)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 400)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 401)]
        [ProducesResponseType(typeof(StandardErrorMessagesResponseModel), 500)]
        [FeatureGate(FeatureFlags.Homeloans)]
        public async Task<IActionResult> CancelPendingDirectDebit(
            [FromServices] IActionHandler<CancelPendingDirectDebitRequest, bool> cancelPendingDirectDebitHandler,
            [FromServices] ILogger<DirectDebitApiController> logger,
            [FromServices] IGuardBuilder guard,
            [FromRoute] string directDebitId,
            CancellationToken cancellationToken)
        {
            logger.LogDebug($"Entered {nameof(CancelPendingDirectDebit)}");

            var context = await guard.Execute(cancellationToken);

            var handlerRequest = new CancelPendingDirectDebitRequest()
            {
                DirectDebitId = directDebitId,
                CustomerId = context.Temenos_cif
            };

            var result = await cancelPendingDirectDebitHandler.ProcessAsync(handlerRequest, null, null, cancellationToken);

            logger.LogDebug($"Exit {nameof(CancelPendingDirectDebit)}");

            return NoContent();
        }

        private IStandardHeaderModel GetRequestHeaders(string authorization = null)
        {
            var headers = Request?.Headers?.RetrieveStandardHeaders();
            if ( !string.IsNullOrWhiteSpace(authorization) )
                headers.Authorization = authorization;
            return headers;
        }
    }
}