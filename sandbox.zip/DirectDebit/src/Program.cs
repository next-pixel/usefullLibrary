using Azure.Identity;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using System;
using System.Diagnostics.CodeAnalysis;

namespace DirectDebitApi
{
    [ExcludeFromCodeCoverage]
    public static class Program
    {
        public static void Main(string[] args) => CreateWebHostBuilder(args).Build().Run();

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>()
                .ConfigureAppConfiguration((hostingContext, config) =>
                {
                    var settings = config.Build();

                    var credentialOptions = new DefaultAzureCredentialOptions
                    {
                        ExcludeSharedTokenCacheCredential = true,
                        ExcludeVisualStudioCodeCredential = true
                    };
                    var credentials = new DefaultAzureCredential(credentialOptions);

                    config.AddAzureAppConfiguration(options =>
                    {
                        options.Connect(new Uri(settings["appConfigEndpoint"]), credentials)
                            .ConfigureRefresh(refresh =>
                            {
                                refresh.Register("sentinel", refreshAll: true)
                                    .SetCacheExpiration(TimeSpan.FromMinutes(Convert.ToDouble(settings["cacheDuration"])));
                            })
                            .ConfigureKeyVault(kv =>
                            {
                                kv.SetCredential(credentials);
                            })
                            .UseFeatureFlags(options =>
                            {
                                options.CacheExpirationInterval = TimeSpan.FromMinutes(Convert.ToDouble(settings["cacheDuration"]));
                                options.Label = settings["brandName"];
                            })
                            .ConfigureKeyVault(kv =>
                            {
                                kv.SetCredential(credentials);
                            });
                        options.Select(KeyFilter.Any, settings["brandName"]);
                    });
                });
    }
}
