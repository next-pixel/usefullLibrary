using AutoMapper;
using DirectDebitApi.Clients.Abstractions;
using DirectDebitApi.Configuration.Abstractions;
using DirectDebitApi.Extensions;
using DirectDebitApi.Helpers;
using DirectDebitApi.Models;
using FluentValidation;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Platform.Library.AzureStorage.Clients.Abstraction;
using Platform.Library.AzureStorage.Entities;
using Platform.Library.Common;
using Platform.Library.Common.AspNetCore.Abstractions;
using Platform.Library.Common.ErrorHandling;
using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.Common.Standard.Models.Abstractions;
using Platform.Library.Communication.Extensions;
using Platform.Library.Events.Models;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;
using Platform.Library.T24.SDK.Modules.DirectDebit.RequestDtos;
using Platform.Library.T24.SDK.Modules.DirectDebit.ResponseDtos;
using static DirectDebitApi.InternalConstants;

namespace DirectDebitApi.ActionHandlers
{
    public class CreatePendingDirectDebitHandler : BaseActionHandler<CreatePendingDirectDebitHandler,
            CreatePendingDirectDebitHandlerRequest, CreatePendingDirectDebitResponse>, IActionHandler<CreatePendingDirectDebitHandlerRequest, CreatePendingDirectDebitResponse>
    {
        private readonly IMapper _mapper;
        private readonly ILogger<CreatePendingDirectDebitHandler> _logger;
        private readonly IValidator<CreatePendingDirectDebitHandlerRequest> _validator;
        private readonly IConfigurationRefresherProvider _configurationRefresherProvider;
        private readonly IT24HomeLoanClient _t24HomeLoanClient;
        private readonly IT24CustomerClient _t24CustomerClient;
        private readonly IPaymentInitiationClient _paymentInitiationClient;
        private readonly IAzureTableStorageClient _azureTableStorageClient;
        private readonly IT24AccountClient _t24AccountClient;
        private readonly ISettings _settings;
        private readonly IDateTimePicker _dateTimePicker;
        private readonly IServiceBusEventPublisher _serviceBusEventPublisher;
        
        public CreatePendingDirectDebitHandler(
            IHttpClientFactory httpClientFactory,
            ILogger<CreatePendingDirectDebitHandler> logger,
            IMapper mapper,
            IValidator<CreatePendingDirectDebitHandlerRequest> validator,
            IT24HomeLoanClient t24HomeLoanClient,
            IT24CustomerClient t24CustomerClient,
            IPaymentInitiationClient paymentInitiationClient,
            IAzureTableStorageClient azureTableStorageClient,
            IT24AccountClient t24AccountClient,
            ISettings settings,
            IDateTimePicker dateTimePicker,
            IServiceBusEventPublisher serviceBusEventPublisher,
            IConfigurationRefresherProvider configurationRefresherProvider = null
            ) : base(httpClientFactory, logger)
        {
            _mapper = mapper.GuardNull(nameof(mapper));
            _logger = logger.GuardNull(nameof(logger));
            _validator = validator.GuardNull(nameof(validator));
            _configurationRefresherProvider = configurationRefresherProvider.GuardNull(nameof(configurationRefresherProvider));
            _t24HomeLoanClient = t24HomeLoanClient.GuardNull(nameof(t24HomeLoanClient));
            _t24CustomerClient = t24CustomerClient.GuardNull(nameof(t24CustomerClient));
            _paymentInitiationClient = paymentInitiationClient.GuardNull(nameof(paymentInitiationClient));
            _azureTableStorageClient = azureTableStorageClient.GuardNull(nameof(azureTableStorageClient));
            _t24AccountClient = t24AccountClient.GuardNull(nameof(t24AccountClient));
            _settings = settings.GuardNull(nameof(settings));
            _serviceBusEventPublisher = serviceBusEventPublisher.GuardNull(nameof(serviceBusEventPublisher));
            _dateTimePicker = dateTimePicker.GuardNull(nameof(dateTimePicker));
        }

        public override async Task<CreatePendingDirectDebitResponse> ProcessAsync(
            CreatePendingDirectDebitHandlerRequest request, IDictionary<string, string> headers,
            IStandardHeaderModel standardHeaderModel, CancellationToken cancellationToken)
        {
            _logger.LogDebug($"{nameof(CreatePendingDirectDebitHandler)}: start ${nameof(ProcessAsync)}");

            await RefreshConfiguration();

            _validator.ValidateRequestOrThrow(request);

            // 1 - Customer Entitlement Check
            await _t24AccountClient.CheckEntitlementAsync(
                request.CustomerId,
                request.ArrangementId,
                null,
                cancellationToken);

            // 2- Validate Direct debit detail.
            await ValidateOFIDetails(request, cancellationToken);

            // 3- Retrive Account Detail
            var accountDetails = await GetAccountDetails(request.ArrangementId, headers, cancellationToken);

            var customer = accountDetails.Parties.FirstOrDefault(x => x.PartyId == request.CustomerId);

            // 4- Create direct debit.
            var t24CreateDirectDebitResponse = await CreatePendingDirectDebit(request, customer?.GivenName, accountDetails, cancellationToken);

            var response = _mapper.Map<CreatePendingDirectDebitResponse>(t24CreateDirectDebitResponse);

            var code = CodeGenerator.Generate();

            // 5 - Initiate Microtransaction

            var transaction = await InitiateMicroTransaction(request, code, standardHeaderModel, cancellationToken);

            if (transaction.IsNull())
            {
                var compositeEvent = new CancelDirectDebitRequestComposite
                {
                    DirectDebitId = response.DirectDebitId,
                    StandardHeaderModel = standardHeaderModel
                };

                _logger.LogInformation($"{(nameof(CreatePendingDirectDebit))}: initiate micro transaction failed for customer {request.CustomerId}");

                var ev52MappedEvent = _mapper.Map<EV52CancelDirectDebitEvent>(compositeEvent);

                ev52MappedEvent.Payload.DirectDebitId = response.DirectDebitId;

                await _serviceBusEventPublisher.CreateAndPublishEvent(ServiceBus.EV52CancelDirectDebitTopic, ev52MappedEvent);

                throw StandardApiExceptionFactory.CreateBadRequestStandardApiException(
                  ErrorsHelper.CreateCustomErrorModel(CommonMessageConstants.BadInputDataErrorCode,
                      string.Format(CommonMessageConstants.CommunicationsErrorNotFoundUserMessageText,
                          InternalConstants.HttpClients.PaymentInitiation),
                            Error.ErrorOnInitiateMicroTransaction));
            }

            // 6- Write to Table Storage.
            await SaveToStorage(request, t24CreateDirectDebitResponse.Header.Id, code, transaction.TransactionId);
            
            _logger.LogInformation($"{nameof(CreatePendingDirectDebitHandler)}: pending direct debit creation successful for customer {request.CustomerId} with account id {request.Request.AccountNumber}");

            return response;
        }

        private async Task<T24AccountDetailBody> GetAccountDetails(
            string arrangementId,
            IDictionary<string, string> headers,
            CancellationToken cancellationToken)
        {
            var t24Response = await _t24AccountClient.GetAccountDetailsAsync(
                arrangementId,
                headers,
                cancellationToken);

            return t24Response.Body.First();
        }

        private async Task RefreshConfiguration()
        {
            if (_configurationRefresherProvider != null)
                await _configurationRefresherProvider.Refreshers.First().TryRefreshAsync();
        }

        private async Task ValidateOFIDetails(CreatePendingDirectDebitHandlerRequest request,
            CancellationToken cancellationToken)
        {
            var response =
                await _t24HomeLoanClient.GetDirectDebitAccountsAsync(request.CustomerId, null, cancellationToken);

            var isValid = !response.Body.Any() || response.Body.Any(account =>
                account.Status != InternalConstants.DirectDebitStatus.Active ||
                account.Status != InternalConstants.DirectDebitStatus.New);

            if (!isValid)
            {
                throw StandardApiExceptionFactory.CreateBadRequestStandardApiException(
                    ErrorsHelper.CreateDefaultErrorModel());
            }
        }

        private async Task<InitiatePaymentDirectDebitResponse> InitiateMicroTransaction(
            CreatePendingDirectDebitHandlerRequest request, string code, IStandardHeaderModel standardHeaderModel,
            CancellationToken cancellationToken)
        {
            var paymentInitiationRequest = _mapper.Map<InitiatePaymentDirectDebitRequest>(request);
            paymentInitiationRequest.Description = code;

            InitiatePaymentDirectDebitResponse directdebitResponse = null;
            try
            {
                return await _paymentInitiationClient.InitiateMicroTransaction(paymentInitiationRequest, standardHeaderModel, cancellationToken);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex, $"{Error.ErrorOnInitiateMicroTransaction} - {ex.Message}");
            }
            return directdebitResponse;
        }

        private async Task<T24CreateDirectDebitResponseDto> CreatePendingDirectDebit(
            CreatePendingDirectDebitHandlerRequest request,
            string customerGivenName,
            T24AccountDetailBody accountDetails,
            CancellationToken cancellationToken)
        {
            var t24CreateDirectDebitRequest = _mapper.Map<T24CreateDirectDebitRequestDto>((request, _settings.DirectDebitParamId));
            t24CreateDirectDebitRequest.DebtorName = customerGivenName;            

            return await _t24HomeLoanClient.CreateDirectDebitAsync(t24CreateDirectDebitRequest, accountDetails.AccountId, cancellationToken);
        }

        private async Task<bool> SaveToStorage(CreatePendingDirectDebitHandlerRequest request, string directDebitId, string code, string transactionId)
        {
            var currentDateTime = _dateTimePicker.UtcNow;
            var expiryDateTime = currentDateTime.Add(_settings.DirectDebitApi.DirectDebitExpiryInterval);
            var communicationSendDate = currentDateTime.Add(_settings.DirectDebitApi.DirectDebitCommunicationSendInterval);

            var entity = new DirectDebitEntity
            {
                PartitionKey = InternalConstants.TableStorage.DirectDebit.PartitionKey,
                RowKey = directDebitId,                
                CreationDateTime = currentDateTime,
                ExpiryDateTime = expiryDateTime,
                Attempts = 0,
                VerificationCode = code,
                TransactionId = transactionId,
                DirectDebitId = directDebitId,
                ActiveRecord = true,
                ArrangementId = request.ArrangementId,
                CustomerId = request.CustomerId,
                CommunicationSendDate = communicationSendDate,
                CommunicationSent = false,
            };

            return await _azureTableStorageClient.UpsertTableStorageAsync<DirectDebitEntity>(entity);
        }        
    }
}