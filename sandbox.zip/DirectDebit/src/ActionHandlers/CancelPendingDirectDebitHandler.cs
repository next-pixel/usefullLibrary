﻿using DirectDebitApi.Extensions;
using DirectDebitApi.Helpers;
using DirectDebitApi.Models;
using FluentValidation;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Platform.Library.AzureStorage.Clients.Abstraction;
using Platform.Library.AzureStorage.Entities;
using Platform.Library.Common;
using Platform.Library.Common.AspNetCore.Abstractions;
using Platform.Library.Common.ErrorHandling;
using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.Common.Standard.Models.Abstractions;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.Modules.DirectDebit.RequestDtos;
using Platform.Library.T24.SDK.Modules.DirectDebit.ResponseDtos;
using System.Net;
using static DirectDebitApi.InternalConstants;
using static DirectDebitApi.InternalConstants.VerifyPendingDDConstants;

namespace DirectDebitApi.ActionHandlers
{
    public class CancelPendingDirectDebitHandler : BaseActionHandler<CancelPendingDirectDebitHandler,CancelPendingDirectDebitRequest, bool>, IActionHandler<CancelPendingDirectDebitRequest, bool>
    {
        private readonly ILogger<CancelPendingDirectDebitHandler> _logger;
        private readonly IValidationResolver _validationResolver;
        private readonly IT24HomeLoanClient _t24HomeLoanClient;
        private readonly IAzureTableStorageClient _azureTableStorageClient;
        private readonly IConfigurationRefresherProvider _configurationRefresherProvider;

        public CancelPendingDirectDebitHandler(
            IHttpClientFactory httpClientFactory,
            ILogger<CancelPendingDirectDebitHandler> logger,
            IValidationResolver validationResolver,
            IT24HomeLoanClient t24HomeLoanClient,
            IAzureTableStorageClient azureTableStorageClient,
            IConfigurationRefresherProvider configurationRefresherProvider = null)
            : base(httpClientFactory, logger)
        {
            _logger = logger.GuardNull(nameof(logger));
            _validationResolver = validationResolver.GuardNull(nameof(validationResolver));
            _t24HomeLoanClient = t24HomeLoanClient.GuardNull(nameof(t24HomeLoanClient));
            _azureTableStorageClient = azureTableStorageClient.GuardNull(nameof(azureTableStorageClient));
            _configurationRefresherProvider = configurationRefresherProvider;
        }
        
        public override async Task<bool> ProcessAsync(CancelPendingDirectDebitRequest request, IDictionary<string, string> headers,
            IStandardHeaderModel standardHeaderModel, CancellationToken cancellationToken)
        {
            _logger.LogDebug($"{nameof(CancelPendingDirectDebitHandler)}.{nameof(ProcessAsync)} started execution for customer {request.CustomerId} with direct debit id {request.DirectDebitId}");

            await RefreshConfiguration();

            // Step 1 : Validate the request
            await _validationResolver.ValidateRequestOrThrowAsync(request, cancellationToken);

            // Step 2 : Direct Debit record check
            var response = await RetrieveAndValidateDirectDebit(request, cancellationToken);

            // Step 3 : Retrieve Pending DD from Azure Table Storage
            var pendingDDFromStorage = await RetrievePendingDDFromStorage(request.DirectDebitId);

            // Step 4 : Soft Delete from Azure Table Storage
            await RestoreOrSoftDelete(pendingDDFromStorage, RestoreOrSoftDeleteDD.SoftDelete);

            // Step 5 : Cancel Pending Direct Debit
            await CancelDirectDebit(request, pendingDDFromStorage, cancellationToken);

            // Step 6 : Hard Delete from Azure Table Storage
            await HardDeletePendingDDInTableStorage(pendingDDFromStorage);

            _logger.LogInformation($"{nameof(CancelPendingDirectDebitHandler)}.{nameof(ProcessAsync)} pending direct debit updated for customer {request.CustomerId} with direct debit id {request.DirectDebitId}");

            return true;
        }

        private async Task RefreshConfiguration()
        {
            if (_configurationRefresherProvider != null)
                await _configurationRefresherProvider.Refreshers.First().TryRefreshAsync();
        }

        private async Task<T24GetDirectDebitAccountResponseDto> RetrieveAndValidateDirectDebit(CancelPendingDirectDebitRequest request, CancellationToken cancellationToken)
        {
            var response = await _t24HomeLoanClient.GetDirectDebitAccountsAsync(request.CustomerId, null, cancellationToken);
            if (response?.Body?.FirstOrDefault(item => item.DirectDebitId.Equals(request.DirectDebitId)) is T24DirectDebitAccount ddRecord)
            {
                if (ddRecord.Status.EqualsIgnoreCase(DirectDebitStatus.Active))
                {
                    _logger.LogError(Error.DirectDebitIsActive);
                    throw StandardApiExceptionFactory.CreateBadRequestStandardApiException(
                        ErrorsHelper.CreateCustomErrorModel(CommonMessageConstants.BadInputDataErrorCode,
                        string.Format(CommonMessageConstants.CommunicationsErrorNotFoundUserMessageText,
                        T24SdkConstants.HttpClient.Temenos),
                        Error.DirectDebitIsActive));
                }

                return response;
            }

            // The Direct Debit was not found
            _logger.LogError(Error.DirectDebitIdDoesNotExistInT24(request.DirectDebitId, request.CustomerId));
            throw StandardApiExceptionFactory.CreateStandardApiException(
                (int)HttpStatusCode.NotFound,
                CommonMessageConstants.BadInputDataErrorCode,
                Error.DirectDebitDoesNotExist
            );
        }

        private async Task<DirectDebitEntity> RetrievePendingDDFromStorage(string directDebitId)
        {
            _logger.LogInformation($"Start execution of: {nameof(RetrievePendingDDFromStorage)}");

            var existingPendingDD = await _azureTableStorageClient.GetSingleAsync<DirectDebitEntity>(
                TableStorage.DirectDebit.PartitionKey, directDebitId);

            if (!existingPendingDD.IsNotNull())
            {
                // Return 400 Not Found
                _logger.LogError(Error.PendingDDNotFound);
                throw StandardApiExceptionFactory.CreateBadRequestStandardApiException(
                    ErrorsHelper.CreateCustomErrorModel(CommonMessageConstants.StandardHeaderErrorCode,
                    string.Format(CommonMessageConstants.CommunicationsErrorNotFoundUserMessageText,
                    TableStorage.AzureTableStorage),
                    Error.PendingDDNotFound));
            }

            return existingPendingDD;
        }

        private async Task<bool> RestoreOrSoftDelete(DirectDebitEntity pendingDDFromStorage,
            RestoreOrSoftDeleteDD restoreOrSoftDelete)
        {
            _logger.LogInformation($"Start execution of: {nameof(RestoreOrSoftDelete)}");

            try
            {
                pendingDDFromStorage.ActiveRecord = restoreOrSoftDelete.Equals(RestoreOrSoftDeleteDD.Restore);

                return await _azureTableStorageClient.UpsertTableStorageAsync<DirectDebitEntity>(pendingDDFromStorage);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex, $"Failed while upserting a record - {ex.Message}");

                throw StandardApiExceptionFactory.CreateStandardCommunicationException(ex);
            }
        }

        private async Task<bool> CancelDirectDebit(CancelPendingDirectDebitRequest request,
            DirectDebitEntity pendingDDFromStorage,
            CancellationToken cancellationToken)
        {
            List<Exception> exceptionsRaised = new List<Exception>();
            try
            {
                var t24UpdateDirectDebitRequest = new UpdateDirectDebitRequest
                {
                    Status = DirectDebitStatus.Cancelled,
                    DirectDebitId = request.DirectDebitId
                };

                await _t24HomeLoanClient.UpdateDirectDebitAsync(t24UpdateDirectDebitRequest, cancellationToken);

                return true;
            }
            catch(Exception ex)
            {
                exceptionsRaised.Add(ex);
            }

            try
            {
                await RestoreOrSoftDelete(pendingDDFromStorage, RestoreOrSoftDeleteDD.Restore);
            }
            catch (Exception ex)
            {
                exceptionsRaised.Add(ex);
            }

            // Handle error based on above outcome
            Exception innerException = null;
            if ( exceptionsRaised.Count > 1 )
            {
                innerException = new AggregateException(exceptionsRaised);
                _logger.LogError(innerException, $"[{nameof(CancelDirectDebit)}] Failed to both update direct debit in T24 and resotre the pending direct debit to Azure Storage: \n- {string.Join("\n- ", exceptionsRaised.Select(e => e.Message))}");
            }
            else
            {
                // If there is one exception it must be the update failing
                innerException = exceptionsRaised.First();
                _logger.LogError(innerException, $"[{nameof(CancelDirectDebit)}] Failed to update direct debit in T24: {innerException.Message}");
            }

            throw StandardApiExceptionFactory.CreateStandardCommunicationException(innerException);
        }

        private async Task<bool> HardDeletePendingDDInTableStorage(DirectDebitEntity pendingDDFromStorage)
        {
            _logger.LogDebug($"Start execution of: {nameof(HardDeletePendingDDInTableStorage)}");

            try
            {
                return await _azureTableStorageClient.DeleteTableStorageAsync<DirectDebitEntity>(pendingDDFromStorage);
            }
            catch(Exception ex)
            {
                // A separate app will do the housekeeping if this fails.
                _logger.LogError(ex, $"{Error.ErrorOnHardDelete} - {ex.Message}");
                return true;
            }
        }
    }
}
