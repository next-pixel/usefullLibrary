using AutoMapper;
using DirectDebitApi.Configuration.Abstractions;
using DirectDebitApi.Extensions;
using DirectDebitApi.Helpers;
using DirectDebitApi.Models;
using FluentValidation;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.FeatureManagement;
using Platform.Library.Common;
using Platform.Library.Common.AspNetCore.Abstractions;
using Platform.Library.Common.ErrorHandling;
using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.Common.Standard.Models.Abstractions;
using Platform.Library.Communication.Extensions;
using Platform.Library.Events.Models;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.Common.RequestDtos;
using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;
using Platform.Library.T24.SDK.Modules.DirectDebit.RequestDtos;
using Platform.Library.T24.SDK.Modules.DirectDebit.ResponseDtos;
using Platform.Library.T24.SDK.Modules.HomeLoan.RequestDtos;
using System.Net;
using static DirectDebitApi.InternalConstants;
using static DirectDebitApi.InternalConstants.HomeLoan;
using IHttpClientFactory = System.Net.Http.IHttpClientFactory;

namespace DirectDebitApi.ActionHandlers
{
    public class ActiveDirectDebitHandler :
        BaseActionHandler<ActiveDirectDebitHandler, ActiveDirectDebitComposite, ActiveDirectDebitResponse>,
        IActionHandler<ActiveDirectDebitComposite, ActiveDirectDebitResponse>
    {
        private readonly IMapper _mapper;
        private readonly ILogger<ActiveDirectDebitHandler> _logger;
        private readonly IFeatureManager _featureManager;
        private readonly IValidationResolver _validationResolver;
        private readonly IServiceBusEventPublisher _serviceBusEventPublisher;
        private readonly IConfigurationRefresherProvider _configurationRefresherProvider;
        private readonly IT24HomeLoanClient _t24HomeLoanClient;
        private readonly IT24AccountClient _t24AccountClient;
        private readonly IT24CustomerClient _t24CustomerClient;
        private readonly ISettings _settings;

        public ActiveDirectDebitHandler(
            IHttpClientFactory httpClientFactory,
            IT24HomeLoanClient t24HomeLoanClient,
            IT24AccountClient t24AccountClient,
            IT24CustomerClient t24CustomerClient,
            IMapper mapper,
            ILogger<ActiveDirectDebitHandler> logger,
            IValidationResolver validationResolver,
            ISettings settings,
            IFeatureManager featureManager,
            IServiceBusEventPublisher serviceBusEventPublisher,
            IConfigurationRefresherProvider configurationRefresherProvider = null) : base(httpClientFactory, logger)
        {
            _t24HomeLoanClient = t24HomeLoanClient.GuardNull(nameof(t24HomeLoanClient));
            _t24AccountClient = t24AccountClient.GuardNull(nameof(t24AccountClient));
            _t24CustomerClient = t24CustomerClient.GuardNull(nameof(t24CustomerClient));
            _logger = logger.GuardNull(nameof(logger));
            _mapper = mapper.GuardNull(nameof(mapper));
            _settings = settings.GuardNull(nameof(settings));
            _featureManager = featureManager.GuardNull(nameof(featureManager));
            _validationResolver = validationResolver.GuardNull(nameof(validationResolver));
            _serviceBusEventPublisher = serviceBusEventPublisher;
            _configurationRefresherProvider = configurationRefresherProvider;
        }

        public override async Task<ActiveDirectDebitResponse> ProcessAsync(ActiveDirectDebitComposite request,
            IDictionary<string, string> headers,
            IStandardHeaderModel standardHeaderModel,
            CancellationToken cancellationToken)
        {
            _logger.LogDebug($"{nameof(ActiveDirectDebitHandler)}.{nameof(ProcessAsync)} started execution for arrangement id {request.ArrangementId}");

            await _validationResolver.ValidateRequestOrThrowAsync(request, cancellationToken);

            await RefreshConfiguration();

            // 1. Check Entitlements
            await _t24AccountClient.CheckEntitlementAsync(
                                     request.TemenosCif,
                                     request.ArrangementId,
                                     null,
                                     cancellationToken);

            // 2. Direct debit validation - with special error codes
            var activeAccounts = await ValidateDirectDebitAsync(request, cancellationToken);

            // 3. Get account details
            var accountDetails = await GetAccountDetails(request, cancellationToken);

            // 4. Validate Settlement Instructions
            var directDebitMandateReference = accountDetails.Settlement?.FirstOrDefault()?.Reference?.FirstOrDefault()?.DirectDebitMandateReference;
            ValidateSettlementInstructionsOrThrow(request, activeAccounts, directDebitMandateReference);

            // 5. Get Customer Profile
            var givenName = await GetCustomerGivenName(request, cancellationToken);

            // 6. Create Active Direct Debit
            var updatedDirectDebitId = await CreateActiveDirectDebit(request, accountDetails, givenName, cancellationToken);

            // Update Settlement Instructions
            var isSettlementUpdated = await UpdateSettlementInstructions(request, updatedDirectDebitId, accountDetails, cancellationToken);

            if (!isSettlementUpdated)
            {
                // Cancel Active Direct Debit if Update settlement instructions fails
                await CancelActiveDirectDebits(request, updatedDirectDebitId, standardHeaderModel);
            }

            // 7. Update adhoc charges field values
            await UpdateAutoSettleCharge(request.ArrangementId, accountDetails, cancellationToken);


            // 8. Fetch directDebitIds with repayment type as External and cancel
            if (accountDetails.RepaymentInstruction.AnyNullSafe())
            {
                var directDebitIdsExternal = accountDetails.RepaymentInstruction
                                                .Where(repayment => repayment.RepaymentType == InternalConstants.RepaymentType.RepaymentTypeExternal)
                                                .Select(x => x.DirectDebitId)
                                                .Distinct();

                if (directDebitIdsExternal.AnyNullSafe())
                {
                    foreach (var directDebitId in directDebitIdsExternal)
                    {
                        // cancel direct debit for repayment type External
                        await CancelActiveDirectDebits(request, directDebitId, standardHeaderModel);
                    }
                }
            }

            _logger.LogInformation("{nameof(ActiveDirectDebitHandler)}.{nameof(ProcessAsync)} active direct debit created successfully for arrangement id {ArrangementId}", accountDetails.ArrangementId);

            return new ActiveDirectDebitResponse();
        }

        /// <summary>
        /// Gets the direct debit account details from T24 by directDebitId and customerId
        /// Returns special error codes if validation fails
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns>List<T24DirectDebitAccount></returns>
        private async Task<IEnumerable<T24DirectDebitAccount>> ValidateDirectDebitAsync(ActiveDirectDebitComposite request,
            CancellationToken cancellationToken)
        {
            var response = await _t24HomeLoanClient.GetDirectDebitAccountsByIdAsync(
                    request.TemenosCif,
                    request.ActiveDirectDebit.DirectDebitId,
                    cancellationToken);

            var directDebitAccounts = response.Body;

            var activeDirectDebitAccounts = directDebitAccounts
                .Where(acc => acc.Status == DirectDebitStatus.Active);

            if (!activeDirectDebitAccounts.AnyNullSafe())
            {
                // Throw 400 - SLDD002 DirectDebitNotActiveException 


                _logger.LogError(Error.DirectDebitNotActiveException);

                throw StandardApiExceptionFactory.CreateStandardApiException(
                        (int)HttpStatusCode.BadRequest,
                        Error.DirectDebitNotActiveException,
                        Error.DirectDebitNotActiveExceptionText);
            }

            if (activeDirectDebitAccounts.AnyNullSafe(x => x.AccountNumber != request.ActiveDirectDebit.AccountNumber && x.BsbNumber != request.ActiveDirectDebit.BsbNumber))
            {
                // Throw 400 - SLDD003 DirectDebitDetailsDoNotMatch 

                _logger.LogError(Error.DirectDebitDetailsDoNotMatch);

                throw StandardApiExceptionFactory.CreateStandardApiException(
                        (int)HttpStatusCode.BadRequest,
                        Error.DirectDebitDetailsDoNotMatch,
                        Error.DirectDebitDetailsDoNotMatchText);
            }

            return activeDirectDebitAccounts;
        }

        private async Task<T24AccountDetailBody> GetAccountDetails(
            ActiveDirectDebitComposite request,
            CancellationToken cancellationToken)
        {
            var t24Response = await _t24AccountClient.GetAccountDetailsAsync(
                request.ArrangementId,
                null,
                cancellationToken);

            return t24Response.Body.First();
        }

        private async Task RefreshConfiguration()
        {
            if (_configurationRefresherProvider != null)
                await _configurationRefresherProvider.Refreshers.First().TryRefreshAsync();
        }

        /// <summary>
        /// Validates repayment instructions and throws exception with special error codes in case of failure
        /// </summary>
        /// <param name="request"></param>
        /// <param name="directDebitAccounts"></param>
        /// <param name="directDebitMandateReference"></param>
        private void ValidateSettlementInstructionsOrThrow(
            ActiveDirectDebitComposite request,
            IEnumerable<T24DirectDebitAccount> directDebitAccounts,
            string directDebitMandateReference)
        {
            var matchingDirectDebitAccounts = directDebitAccounts
                .Where(acc => acc.AccountNumber == request.ActiveDirectDebit.AccountNumber &&
                              acc.BsbNumber == request.ActiveDirectDebit.BsbNumber);

            //If the record does not exist - return a 404.
            if (!matchingDirectDebitAccounts.AnyNullSafe())
            {
                _logger.LogError(Error.DirectDebitDoesNotExist);

                // Throw 400 - Not Found exception

                throw StandardApiExceptionFactory.CreateBadRequestStandardApiException(
                    ErrorsHelper.CreateCustomErrorModel(CommonMessageConstants.StandardHeaderErrorCode,
                        string.Format(CommonMessageConstants.CommunicationsErrorNotFoundUserMessageText,
                            T24SdkConstants.HttpClient.Temenos),
                        Error.DirectDebitDoesNotExist));
            }

            //If direct debit id matches DDMandateReference - return a 400.
            if (matchingDirectDebitAccounts.Any(x => x.DirectDebitId == directDebitMandateReference))
            {
                // Throw 400 - SLDD004 DirectDebitInUseExceptionText 

                _logger.LogError(Error.DirectDebitInUseExceptionText);

                throw StandardApiExceptionFactory.CreateStandardApiException(
                        (int)HttpStatusCode.BadRequest,
                        Error.DirectDebitInUseException,
                        Error.DirectDebitInUseExceptionText);
            }
        }

        private async Task<string> GetCustomerGivenName(ActiveDirectDebitComposite request,
            CancellationToken cancellationToken)
        {
            var contactDetailResponse = await _t24CustomerClient.GetContactDetailsAsync(request.TemenosCif, null, cancellationToken);
            return contactDetailResponse.GivenName;
        }

        private async Task<string> CreateActiveDirectDebit(
            ActiveDirectDebitComposite request,
            T24AccountDetailBody accountDetails,
            string givenName,
            CancellationToken cancellationToken)
        {
            // 1.Create Request object 
                var createDirectDebitRequest = new T24CreateDirectDebitRequestDto
                {
                    AccountName = request.ActiveDirectDebit.AccountName,
                    BsbNumber = request.ActiveDirectDebit.BsbNumber,
                    AccountNumber = request.ActiveDirectDebit.AccountNumber,
                    DebtorName = givenName,
                    CustomerId = request.TemenosCif,
                    ParamId = _settings.DirectDebitParamId,                 
                    Status = DirectDebitStatus.Active
                };

                // 2.Invoke Create Active Direct debit api
                var createActiveDirectDebitResponse = await _t24HomeLoanClient.CreateDirectDebitAsync(
                    createDirectDebitRequest,
                    accountDetails.AccountId,
                    cancellationToken);

            return createActiveDirectDebitResponse.Header.Id;
        }

        private async Task UpdateAutoSettleCharge(string arrangementId, T24AccountDetailBody accountDetails, CancellationToken cancellationToken)
        {
            try
            {
                if (accountDetails.Payment.AnyNullSafe(p => p.PaymentType ==  T24SdkConstants.T24RepaymentType.AdhocFee))
                {
                    var payload = _mapper.Map<T24RequestPayload<T24AutoSettleChargesRequestDto>>(accountDetails);

                    //Update Auto Settle Charge
                    await _t24HomeLoanClient.UpdateAutoSettleChargesAsync(payload, arrangementId, cancellationToken);
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{nameof(UpdateAutoSettleCharge)} failed for arrangementId {arrangementId} with error {ex.Message}");
                throw;
            }
        }

        private async Task<bool> UpdateSettlementInstructions(
            ActiveDirectDebitComposite request,
            string directDebitId,
            T24AccountDetailBody accountDetails,
            CancellationToken cancellationToken)
        {
            await _featureManager.ConditionallyValidateAccountDetails(
                validationResolver: _validationResolver,
                accountDetails: accountDetails,
                cancellationToken: cancellationToken);

            try
            {
                var updateCompositeRequest = new T24UpdateLoanSettlementCompositeRequest
                {
                    ActivityId = ActivityId.LendingUpdateRepaymentDd,
                    AccountDetails = accountDetails,
                    DirectDebitMandateReferenceId = directDebitId,
                };
                var updateRequest = _mapper.Map<T24RequestPayload<T24UpdateLoanSettlementRequestDto>>(updateCompositeRequest);

                await _t24HomeLoanClient.UpdateHomeLoanSettlementAsync(
                    request: updateRequest,
                    arrangementId: request.ArrangementId,
                    customHeaders: null,
                    cancellationToken: cancellationToken);

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{nameof(UpdateSettlementInstructions)} failed for for directDebit ids {directDebitId} with the following error {ex.Message}");
                throw;
            }
        }

        private async Task CancelActiveDirectDebits(
            ActiveDirectDebitComposite request,
            string updatedDirectDebitId,
            IStandardHeaderModel standardHeaderModel)
        {
            // Cancel Direct debits

            try
            {
                standardHeaderModel.SendingSystemId = ServiceBus.SendingSystemId;
                standardHeaderModel.SendingSystemVersion = ServiceBus.SendingSystemVersion;

                var ev52CancelDirectDebitComposite = new CancelDirectDebitRequestComposite
                {
                    DirectDebitId = request.ActiveDirectDebit.DirectDebitId,
                    StandardHeaderModel = standardHeaderModel
                };

                var ev52MappedEvent = _mapper.Map<EV52CancelDirectDebitEvent>(ev52CancelDirectDebitComposite);
                ev52MappedEvent.Payload.DirectDebitId = updatedDirectDebitId;

                await _serviceBusEventPublisher.CreateAndPublishEvent(ServiceBus.EV52CancelDirectDebitTopic, ev52MappedEvent);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Unable to publish {nameof(EV52CancelDirectDebitEvent)} to service bus - {ex.Message}");

                throw;
            }

        }
    }
}