﻿using AutoMapper;
using DirectDebitApi.Extensions;
using DirectDebitApi.Models;
using Microsoft.Extensions.Caching.Memory;
using Platform.Library.Common.AspNetCore.Abstractions;
using Platform.Library.Common.ErrorHandling;
using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.Common.Standard.Models.Abstractions;
using Platform.Library.T24.SDK;
using static DirectDebitApi.InternalConstants;

namespace DirectDebitApi.ActionHandlers
{
    public class RetrieveDirectDebitHandler : BaseActionHandler<RetrieveDirectDebitHandler, RetrieveDirectDebitRequest,
            RetrieveDirectDebitResponse>,
        IActionHandler<RetrieveDirectDebitRequest, RetrieveDirectDebitResponse>
    {
        private readonly IMapper _mapper;
        private readonly ILogger<RetrieveDirectDebitHandler> _logger;
        private readonly IT24HomeLoanClient _t24HomeLoanClient;

        public RetrieveDirectDebitHandler(
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            ILogger<RetrieveDirectDebitHandler> logger,
            IT24HomeLoanClient t24HomeLoanClient) : base(httpClientFactory, logger)
        {
            _mapper = mapper.GuardNull(nameof(mapper));
            _logger = logger.GuardNull(nameof(logger));
            _t24HomeLoanClient = t24HomeLoanClient.GuardNull(nameof(t24HomeLoanClient));
        }

        /// <summary>
        /// Returns a list of customer's direct debit records.
        /// </summary>
        public override async Task<RetrieveDirectDebitResponse> ProcessAsync(RetrieveDirectDebitRequest request,
            IDictionary<string, string> headers, IStandardHeaderModel standardHeaderModel,
            CancellationToken cancellationToken)
        {
            _logger.LogDebug($"{nameof(RetrieveDirectDebitHandler)}.{nameof(ProcessAsync)} fetching list of direct debit records for customer {request.CustomerId}");

            try
            {
                var directDebits = new RetrieveDirectDebitResponse();
                var activeDirectDebits = await _t24HomeLoanClient.GetDirectDebitAccountsAsync(request.CustomerId, request.Status, cancellationToken);

                if (request.DirectDebitId.IsNotNullOrWhiteSpace() && !activeDirectDebits.Body.Any())
                {
                    throw StandardApiExceptionFactory.CreateStandardApiException(
                        StatusCodes.Status403Forbidden,
                        CommonMessageConstants.AuthorisationRoleErrorCode,
                        CommonMessageConstants.AuthorisationRoleErrorUserMessageText);
                }

                if (activeDirectDebits.Body.Any())
                {
                    //Filter accountId if any
                    if (request.AccountId.IsNotNullOrWhiteSpace())
                    {
                        activeDirectDebits.Body = activeDirectDebits.Body.Where(x => x.DirectDebitId.Contains(request.AccountId));
                    }

                    // Remove duplicates
                    activeDirectDebits.Body = activeDirectDebits.Body.GroupBy(x => new {x.AccountNumber, x.BsbNumber})
                        .Select(group => group.FirstOrDefault()).ToArray();
                    directDebits.DirectDebits = _mapper.Map<List<RetrieveDirectDebit>>(activeDirectDebits.Body);
                }

                _logger.LogInformation($"{nameof(RetrieveDirectDebitHandler)}.{nameof(ProcessAsync)} direct debit records list retrieval successful for customer {request.CustomerId}");
                return directDebits;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error occured in {nameof(RetrieveDirectDebitHandler)}: {ex.Message}");
                throw;
            }
        }
    }
}