﻿using AutoMapper;
using DirectDebitApi.Clients.Abstractions;
using DirectDebitApi.Extensions;
using DirectDebitApi.Models;
using FluentValidation;
using Microsoft.Azure.Cosmos.Table;
using Microsoft.FeatureManagement;
using Platform.Library.AzureStorage.Clients.Abstraction;
using Platform.Library.AzureStorage.Entities;
using Platform.Library.Common;
using Platform.Library.Common.AspNetCore.Abstractions;
using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.Common.Standard.Models.Abstractions;
using Platform.Library.Communication.Extensions;
using Platform.Library.Events.Models;
using Platform.Library.Events.Models.Enum;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.Common.RequestDtos;
using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;
using Platform.Library.T24.SDK.Modules.DirectDebit.RequestDtos;
using Platform.Library.T24.SDK.Modules.HomeLoan.RequestDtos;
using System.Net;
using static DirectDebitApi.InternalConstants;
using static DirectDebitApi.InternalConstants.HomeLoan;
using static DirectDebitApi.InternalConstants.VerifyPendingDDConstants;

namespace DirectDebitApi.ActionHandlers
{
    public class VerifyPendingDirectDebitHandler :
        BaseActionHandler<VerifyPendingDirectDebitHandler, VerifyPendingDirectDebitHandlerRequest, VerifyPendingDirectDebitHandlerResponse>,
        IActionHandler<VerifyPendingDirectDebitHandlerRequest, VerifyPendingDirectDebitHandlerResponse>
    {
        private readonly IMapper _mapper;
        private readonly ILogger<VerifyPendingDirectDebitHandler> _logger;
        private readonly IT24HomeLoanClient _t24HomeLoanClient;
        private readonly IT24AccountClient _t24AccountClient;
        private readonly IAzureTableStorageClient _azureTableStorageClient;
        private readonly IServiceBusEventPublisher _serviceBusEventPublisher;
        private readonly IT24CustomerClient _t24CustomerClient;
        private readonly IConsentWorkflowClient _consentWorkflowClient;
        private readonly IDateTimePicker _dateTimePicker;
        private readonly IFeatureManager _featureManager;
        private readonly IValidationResolver _validationResolver;

        public VerifyPendingDirectDebitHandler(
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            ILogger<VerifyPendingDirectDebitHandler> logger,
            IValidationResolver validationResolver,
            IT24HomeLoanClient t24HomeLoanClient,
            IT24AccountClient t24GetAccountClient,
            IAzureTableStorageClient azureTableStorageClient,
            IServiceBusEventPublisher serviceBusEventPublisher,
            IT24CustomerClient t24CustomerClient,
            IDateTimePicker dateTimePicker,
            IFeatureManager featureManager,
            IConsentWorkflowClient consentWorkflowClient
        ) : base(httpClientFactory, logger)
        {
            _mapper = mapper.GuardNull(nameof(mapper));
            _logger = logger.GuardNull(nameof(logger));
            _validationResolver = validationResolver.GuardNull(nameof(validationResolver));
            _t24HomeLoanClient = t24HomeLoanClient.GuardNull(nameof(t24HomeLoanClient));
            _t24AccountClient = t24GetAccountClient.GuardNull(nameof(t24GetAccountClient));
            _serviceBusEventPublisher = serviceBusEventPublisher.GuardNull(nameof(serviceBusEventPublisher));
            _azureTableStorageClient = azureTableStorageClient.GuardNull(nameof(azureTableStorageClient));
            _t24CustomerClient = t24CustomerClient.GuardNull(nameof(t24CustomerClient));
            _consentWorkflowClient = consentWorkflowClient.GuardNull(nameof(consentWorkflowClient));
            _dateTimePicker = dateTimePicker.GuardNull(nameof(dateTimePicker));
            _featureManager = featureManager.GuardNull(nameof(featureManager));
        }

        public override async Task<VerifyPendingDirectDebitHandlerResponse> ProcessAsync(VerifyPendingDirectDebitHandlerRequest request, IDictionary<string, string> headers, IStandardHeaderModel standardHeaderModel, CancellationToken cancellationToken)
        {
            _logger.LogDebug("{System}.{Method} started for customer with direct debit id {DirectDebitId} and arrangementId {ArrangementId}"
                , nameof(VerifyPendingDirectDebitHandler), nameof(ProcessAsync), request.DirectDebitId, request.ArrangementId);

            await _validationResolver.ValidateRequestOrThrowAsync(request, cancellationToken);

            DirectDebitManifest manifest = null;
            string logReason = "checking entitlements";
            try
            {
                // 1. Customer Entitlements Check
                await _t24AccountClient.CheckEntitlementAsync(request.CustomerId, request.ArrangementId, null, cancellationToken);

                // Prepare the manifest of the Direct Debit to track its progress
                manifest = await PrepareDirectDebitWithManifest(request);

                // 2. Validate Verification Code
                logReason = "validating verification code";
                await ValidateVerificationCode(manifest, request, standardHeaderModel, cancellationToken);

                // 3. Retrieve Account Details
                logReason = "retrieving home loan account details";
                var getAccountDetails = await RetrieveHomeloanAccountDetails(request, manifest, headers, cancellationToken);

                // 4. Consent Workflow + 5. Get Operation Attributes

                logReason = "getting customer given name";
                var givenName = await GetCustomerGivenName(manifest, getAccountDetails, request.CustomerId, cancellationToken);

                logReason = "execuring consent workflow";
                var isConsentRequired = await ExecuteConsentWorkflowAsync(request, getAccountDetails, givenName, standardHeaderModel, manifest, cancellationToken);

                // If consentRequired == false, proceed to next steps.
                // Otherwise, return result.
                if (!isConsentRequired)
                {
                    _logger.LogDebug("Consent not required for customer {CustomerId} with direct debit id {DirectDebitId} on arrangement {ArrangementId}", request.CustomerId, request.DirectDebitId, request.ArrangementId);

                    // 6. Soft Delete Pending Direct Debit Entry (IS THIS REQUIRED AT ALL NOW?????)

                    // 7. Create Direct Debit
                    logReason = "activating direct debit in T24";
                    await ActivateDirectDebitInT24(manifest, request.DirectDebitId, cancellationToken);

                    // 8. Update Repayment Instructions + 9. Hard Delete Direct Debit Entry
                    logReason = "updating home loan settlement instructions";
                    await UpdateHLSettlementInstructions(request, getAccountDetails, manifest, cancellationToken);

                    // 8.1 Update Auto settle charge for adhoc fee payment type.
                    logReason = "updating auto settle charges.";
                    await UpdateAutoSettleCharge(request.ArrangementId, getAccountDetails, manifest, cancellationToken);

                    //10. Fetch directDebitIds with repayment type as External and cancel
                    if (getAccountDetails.RepaymentInstruction.AnyNullSafe())
                    {
                        var directDebitIdsExternal = getAccountDetails.RepaymentInstruction
                                                        .Where(repayment => repayment.RepaymentType == InternalConstants.RepaymentType.RepaymentTypeExternal)
                                                        .Select(x => x.DirectDebitId)
                                                        .Distinct();

                        if (directDebitIdsExternal.AnyNullSafe())
                        {
                            foreach (var directDebitId in directDebitIdsExternal)
                            {
                                var cancelRequest = new VerifyPendingDirectDebitHandlerRequest()
                                {
                                    DirectDebitId = directDebitId
                                };
                                // cancel direct debit for repayment type External
                                await PublishDirectDebitCancellation(cancelRequest, standardHeaderModel, cancellationToken);
                            }
                        }
                    }
                }

                _logger.LogInformation("{System}.{Method} verification completed for customer with {CustomerId} direct debit id {DirectDebitId} on arrangement {ArrangementId}", nameof(VerifyPendingDirectDebitHandler), nameof(ProcessAsync), request.CustomerId, request.DirectDebitId, request.ArrangementId);

                return new VerifyPendingDirectDebitHandlerResponse()
                {
                    ConsentRequired = isConsentRequired
                };

            }
            catch (StandardApiException)
            {
                throw;
            }
            catch (Exception ex)
            {
                // Something unexpected has happened so it hasn't been caught by anything
                // so revert the attempt
                manifest.RevertAttempt = true;
                throw _logger.LogAndRaiseStandardCommunicationError(logReason, innerException: ex);
            }
            finally
            {
                // Update table storage if it is required
                if (manifest != null)
                    await UpdateTableStorageIfRequired(manifest);
            }
        }

        private async Task<string> GetCustomerGivenName(DirectDebitManifest manifest, T24AccountDetailBody accountDetails, string customerId, CancellationToken cancellationToken)
        {
            // Use the account details to reduce the need to go to customer profile
            var customer = accountDetails.Parties?.FirstOrDefault(p => customerId.EqualsIgnoreCase(p.PartyId));
            if (!string.IsNullOrWhiteSpace(customer?.GivenName))
                return customer.GivenName;

            try
            {
                var contactDetailResponse = await _t24CustomerClient.GetContactDetailsAsync(customerId, null, cancellationToken);
                return contactDetailResponse.GivenName;
            }
            catch (StandardApiException)
            {
                manifest.RevertAttempt = true;
                throw;
            }
            catch (Exception ex)
            {
                manifest.RevertAttempt = true;
                throw _logger.LogAndRaiseStandardCommunicationError($"retrieving customer given name for {customerId}", InternalConstants.Systems.T24, ex);
            }
        }

        private async Task PublishDirectDebitCancellation(
            VerifyPendingDirectDebitHandlerRequest request,
            IStandardHeaderModel standardHeaders,
            CancellationToken cancellationToken)
        {
            try
            {
                var composite = request.DefineWithUpdatedHeaders(standardHeaders);
                var ev52MappedEvent = _mapper.Map<EV52CancelDirectDebitEvent>(composite);

                await _serviceBusEventPublisher.CreateAndPublishEvent(ServiceBus.EV52CancelDirectDebitTopic, ev52MappedEvent);

                _logger.LogInformation("{Event} published to cancel previous direct debit for customer with {CustomerId} and arrangement id - {ArrangementId} with direct debit id - {DirectDebitId}", nameof(EV52CancelDirectDebitEvent), request.CustomerId, request.ArrangementId, request.DirectDebitId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unable to publish {Event} to service bus: {Message}", nameof(EV52CancelDirectDebitEvent), ex.Message);
            }
        }

        private async Task<DirectDebitManifest> PrepareDirectDebitWithManifest(VerifyPendingDirectDebitHandlerRequest request)
        {
            var directDebitId = request.DirectDebitId;
            _logger.LogDebug("{Method} for {DirectDebitId}", nameof(PrepareDirectDebitWithManifest), request.DirectDebitId);

            DirectDebitEntity entity = null;
            try
            {
                entity = await _azureTableStorageClient.GetSingleAsync<DirectDebitEntity>(TableStorage.DirectDebit.PartitionKey, directDebitId);
            }
            catch (StorageException nfEx) when (nfEx.RequestInformation.HttpStatusCode == (int)HttpStatusCode.NotFound)
            {
                throw _logger.LogAndRaiseNotFoundException<DirectDebitEntity>(directDebitId, nfEx);
            }
            catch (StorageException stEx)
            {
                throw _logger.LogAndRaiseStorageException(stEx, $"Error retrieving direct debit with id {directDebitId}");
            }
            catch (Exception ex)
            {
                throw _logger.LogAndRaiseStandardCommunicationError($"Error retrieving direct debit with id {directDebitId}", InternalConstants.Systems.AzureTableStorage, ex);
            }

            if (entity.IsNull())
            {
                // Return 400 Not Found
                throw _logger.LogAndRaiseStandardApiException(
                    HttpStatusCode.NotFound,
                    CommonMessageConstants.BadInputDataErrorCode,
                    Error.PendingDDNotFound
                );
            }
            else if (entity.ExpiryDateTime < _dateTimePicker.UtcNow)
            {
                // It has expired so you are already going to delete it
                // No need to update the record
                return DirectDebitManifest.Prepare(entity, true);
            }
            else
            {
                entity.ActiveRecord = false;
                entity.Attempts += 1;

                try
                {
                    // Prepare the ODS record in case something goes wrong
                    await _azureTableStorageClient.UpsertTableStorageAsync<DirectDebitEntity>(entity);
                }
                catch (StorageException nfEx) when (nfEx.RequestInformation.HttpStatusCode == (int)HttpStatusCode.NotFound)
                {
                    throw _logger.LogAndRaiseNotFoundException<DirectDebitEntity>(directDebitId, nfEx);
                }
                catch (StorageException stEx)
                {
                    throw _logger.LogAndRaiseStorageException(stEx, $"Error preparing direct debit with id {directDebitId} for processing");
                }
                catch (Exception ex)
                {
                    throw _logger.LogAndRaiseStandardCommunicationError($"Error preparing direct debit with id {directDebitId} for processing", InternalConstants.Systems.AzureTableStorage, ex);
                }

                return DirectDebitManifest.Prepare(entity);
            }
        }

        /// <summary>
        /// Update or delete the <see cref="DirectDebitEntity"/> based on what happened
        /// </summary>
        /// <param name="manifest"></param>
        /// <returns></returns>
        private async Task UpdateTableStorageIfRequired(DirectDebitManifest manifest)
        {
            var action = manifest.ToBeDeleted && !manifest.RevertAttempt
                ? "Deleting"
                : "Updating";

            _logger.LogDebug("{action} ODS {nameof(DirectDebitEntity)} with id {manifest.DirectDebitId}", action, nameof(DirectDebitEntity), manifest.DirectDebitId);

            try
            {
                if (manifest.ToBeDeleted && !manifest.RevertAttempt)
                {
                    if (!await _azureTableStorageClient.DeleteTableStorageAsync<DirectDebitEntity>(manifest.Entity))
                    {
                        throw _logger.LogAndRaiseStandardCommunicationError($"{nameof(UpdateTableStorageIfRequired)} failed to delete the {nameof(DirectDebitEntity)} with id {manifest.DirectDebitId}", InternalConstants.Systems.AzureTableStorage);
                    }
                }
                else
                {
                    if (!await _azureTableStorageClient.UpsertTableStorageAsync<DirectDebitEntity>(manifest.UpdatedEntity()))
                    {
                        throw _logger.LogAndRaiseStandardCommunicationError($"{nameof(UpdateTableStorageIfRequired)} failed to update the {nameof(DirectDebitEntity)} with id {manifest.DirectDebitId}", InternalConstants.Systems.AzureTableStorage);
                    }
                }
            }
            catch (StandardApiException)
            {
                throw;
            }
            catch (StorageException nfEx) when (nfEx.RequestInformation.HttpStatusCode == (int)HttpStatusCode.NotFound)
            {
                throw _logger.LogAndRaiseNotFoundException<DirectDebitEntity>(manifest.DirectDebitId, nfEx);
            }
            catch (StorageException stEx)
            {
                throw _logger.LogAndRaiseStorageException(stEx, $"Error {action.ToLower()} direct debit with id {manifest.DirectDebitId} after processing");
            }
            catch (Exception ex)
            {
                throw _logger.LogAndRaiseStandardCommunicationError($"Error {action.ToLower()} direct debit with id {manifest.DirectDebitId} after processing", InternalConstants.Systems.AzureTableStorage, ex);
            }
        }

        private async Task<bool> ValidateVerificationCode(
            DirectDebitManifest manifest,
            VerifyPendingDirectDebitHandlerRequest request,
            IStandardHeaderModel standardHeaderModel,
            CancellationToken cancellationToken)
        {

            // 2a. IF currentDateTime > expiryDateTime the operation will:
            //     1. Publish EV52 Cancel Direct Debit_Phase2 (Event) to cancel the directDebitId provided.
            //     2. Hard delete from table storage (manifest already has it marked as to be deleted)
            //     3. Return a 403 Forbidden to the consumer.
            if (manifest.Entity.ExpiryDateTime < _dateTimePicker.UtcNow)
            {
                // Cancel the direct debit because it has expired
                await PublishDirectDebitCancellation(request, standardHeaderModel, cancellationToken);
                _logger.LogWarning($"Direct Debit with id {request.DirectDebitId} expired {manifest.Entity.ExpiryDateTime:O} and will be CANCELLED");

                throw _logger.LogAndRaiseStandardApiException(
                    HttpStatusCode.Forbidden,
                    CommonMessageConstants.AuthorisationRoleErrorCode,
                    Error.BeyondLimit
                );
            }

            // 2a. IF the arrangementId does not match the operation will return a 400 Bad Request response to the consumer.
            if (!manifest.Entity.ArrangementId.EqualsIgnoreCase(request.ArrangementId))
            {
                throw _logger.LogAndRaiseStandardApiException(
                    HttpStatusCode.BadRequest,
                    CommonMessageConstants.BadInputDataErrorCode,
                    Error.ArrangementIdNotMatched
                );
            }

            // 2a. IF attempts > 3 the operation will return a 403 Forbidden response to the consumer.
            if (manifest.Entity.Attempts > MaxNumOfAttempts)
            {
                manifest.ToBeDeleted = true;

                // Cancel the direct debit because you exceeded attempts
                await PublishDirectDebitCancellation(request, standardHeaderModel, cancellationToken);
                _logger.LogWarning("Maximum attempts ({MaxNumOfAttempts}) exceeded, pending direct Debit with id {DirectDebitId} to be CANCELLED", MaxNumOfAttempts, request.DirectDebitId);

                throw _logger.LogAndRaiseStandardApiException(
                    HttpStatusCode.Forbidden,
                    Error.Codes.MaxAttemptsExceeded,
                    Error.BeyondLimit
                );
            }

            // 2c. Verify verificationCode provided matches the verificationCode in Azure Table Storage.
            if (manifest.Entity.VerificationCode.EqualsIgnoreCase(request.VerificationCode))
            {
                _logger.LogDebug("{Method} for direct debit {DirectDebitId} SUCCEEDED", nameof(ValidateVerificationCode), request.DirectDebitId);
            }
            else
            {
                // 2c. IF attempts < 3 & verificationCode is incorrect the operation will return a 401 Unauthorized (error code SLDD005) response to the consumer.
                if (manifest.Entity.Attempts < MaxNumOfAttempts)
                {
                    throw _logger.LogAndRaiseStandardApiException(
                        HttpStatusCode.Unauthorized,
                        Error.Codes.InvalidVerificationCode,
                        Error.InvalidVerificationCodeText(request.VerificationCode)
                    );
                }
                // 2c. IF attempts = 3 & verificationCode is incorrect the operation will:
                //    - Publish EV52 Cancel Direct Debit_Phase2(Event) to cancel the directDebitId provided.
                //    - Hard delete the direct debit entry from Azure Table Storage.
                //    - Return a 403 Forbidden(error code SLDD006) response to the consumer(refer to Special Integration Error Codes Registry).
                else if (manifest.Entity.Attempts == MaxNumOfAttempts)
                {
                    manifest.ToBeDeleted = true;

                    // Cancel the direct debit because you exceeded attempts
                    await PublishDirectDebitCancellation(request, standardHeaderModel, cancellationToken);
                    _logger.LogWarning("Maximum attempts {MaxNumOfAttempts} exceeded, pending direct Debit with id {DirectDebitId} to be CANCELLED", MaxNumOfAttempts, request.DirectDebitId);

                    throw _logger.LogAndRaiseStandardApiException(
                        HttpStatusCode.Forbidden,
                        Error.Codes.MaxAttemptsExceeded,
                        Error.BeyondLimit
                    );
                }
            }

            return true;
        }

        private async Task<T24AccountDetailBody> RetrieveHomeloanAccountDetails(
            VerifyPendingDirectDebitHandlerRequest request,
            DirectDebitManifest manifest,
            IDictionary<string, string> headers,
            CancellationToken cancellationToken)
        {
            _logger.LogDebug("{Method} for arrangement {request.ArrangementId}", nameof(RetrieveHomeloanAccountDetails), request.ArrangementId);

            try
            {
                var getAccountDetails = await _t24AccountClient.GetAccountDetailsAsync(request.ArrangementId, headers, cancellationToken);
                return getAccountDetails.Body.FirstOrDefault()
                    ?? throw new InvalidOperationException($"No account details found for {request.ArrangementId}");
            }
            catch (StandardApiException)
            {
                manifest.RevertAttempt = true;
                throw;
            }
            catch (Exception ex)
            {
                manifest.RevertAttempt = true;
                throw _logger.LogAndRaiseStandardCommunicationError($"retrieving home loan account details for direct debit with id {manifest.DirectDebitId}", InternalConstants.Systems.T24, ex);
            }
        }

        private async Task ActivateDirectDebitInT24(
            DirectDebitManifest manifest,
            string directDebitId,
            CancellationToken cancellationToken)
        {
            _logger.LogDebug("{Method} for direct debit with id {DirectDebitId}", nameof(ActivateDirectDebitInT24), directDebitId);

            var updateDirectDebitCompositeRequest = new UpdateDirectDebitCompositeRequest
            {
                Status = DirectDebitStatus.Active,
                DirectDebitId = directDebitId
            };

            var t24UpdateDirectDebitRequest = _mapper.Map<UpdateDirectDebitRequest>(updateDirectDebitCompositeRequest);

            try
            {
                await _t24HomeLoanClient.UpdateDirectDebitAsync(t24UpdateDirectDebitRequest, cancellationToken);
                _logger.LogInformation("Direct debit with the direct debit Id {DirectDebitId} is updated to status {DirectDebitStatus.Active}", directDebitId, DirectDebitStatus.Active);
            }
            catch (StandardApiException)
            {
                manifest.RevertAttempt = true;
                throw;
            }
            catch (Exception ex)
            {
                manifest.RevertAttempt = true;
                throw _logger.LogAndRaiseStandardCommunicationError(Error.ErrorOnActivateDD(ex.Message), InternalConstants.Systems.T24, ex);
            }
        }

        private async Task UpdateHLSettlementInstructions(
            VerifyPendingDirectDebitHandlerRequest request,
            T24AccountDetailBody accountDetails,
            DirectDebitManifest manifest,
            CancellationToken cancellationToken)
        {
            _logger.LogDebug("Start execution of: {Method} for the direct debit {DirectDebitId}", nameof(UpdateHLSettlementInstructions), request.DirectDebitId);

            await _featureManager.ConditionallyValidateAccountDetails( 
                validationResolver: _validationResolver, 
                accountDetails: accountDetails,
                cancellationToken: cancellationToken);

            try
            {
                var updateCompositeRequest = new T24UpdateLoanSettlementCompositeRequest
                {
                    ActivityId = ActivityId.LendingUpdateRepaymentDd,
                    AccountDetails = accountDetails,
                    DirectDebitMandateReferenceId = request.DirectDebitId
                };
                var updateRequest = _mapper.Map<T24RequestPayload<T24UpdateLoanSettlementRequestDto>>(updateCompositeRequest);

                await _t24HomeLoanClient.UpdateHomeLoanSettlementAsync(
                    request: updateRequest,
                    arrangementId: accountDetails.ArrangementId,
                    customHeaders: null,
                    cancellationToken: cancellationToken);

                // Direct Debit can now be deleted from the ODS
                manifest.ToBeDeleted = true;

            }
            catch (StandardApiException)
            {
                manifest.RevertAttempt = true;
                throw;
            }
            catch (Exception ex)
            {
                manifest.RevertAttempt = true;
                throw _logger.LogAndRaiseBadRequestError(ex, Error.ErrorOnUpdateHLSettelement);
            }
        }

        private async Task UpdateAutoSettleCharge(
            string arrangmentId,
            T24AccountDetailBody accountDetails,
            DirectDebitManifest manifest,
            CancellationToken cancellationToken)
        {
            try
            {
                if (accountDetails.Payment.AnyNullSafe(p => p.PaymentType == T24SdkConstants.T24RepaymentType.AdhocFee))
                {
                    var payload = _mapper.Map<T24RequestPayload<T24AutoSettleChargesRequestDto>>(accountDetails);

                    //Update Auto Settle Charge
                    await _t24HomeLoanClient.UpdateAutoSettleChargesAsync(payload, arrangmentId, cancellationToken);
                }

            }
            catch (StandardApiException)
            {
                manifest.RevertAttempt = true;
                throw;
            }
            catch (Exception ex)
            {
                manifest.RevertAttempt = true;
                throw _logger.LogAndRaiseBadRequestError(ex, Error.ErrorOnUpdateAutoSettleCharges);
            }
        }

        /// <summary>4. Consent Workflow</summary>
        private async Task<bool> ExecuteConsentWorkflowAsync(
            VerifyPendingDirectDebitHandlerRequest request,
            T24AccountDetailBody accountDetails,
            string givenName,
            IStandardHeaderModel standardHeaderModel,
            DirectDebitManifest manifest,
            CancellationToken cancellationToken)
        {
            _logger.LogDebug("{Method} for direct debit with id {DirectDebitId}", nameof(ExecuteConsentWorkflowAsync), manifest.DirectDebitId);

            // IF methodOfOperation == ALLTOSIGN && (parties.partyrole = OWNER) > 1 the operation will continue to Get Operational Attributes
            bool isConsentRequired = false;
            if (SigningInstructionsEnum.ALLTOSIGN.ToString().Equals(accountDetails.MethodOfOperation)
                && (accountDetails?.Parties?.Count(x => Parameters.Consents.PartyOwner.EqualsIgnoreCase(x.PartyRole)) ?? 0) > 1)
            {
                // Go to 5. Get Operational Attributes
                isConsentRequired = await GetConsentRequiredAsync(standardHeaderModel, manifest, cancellationToken);

                // If consentRequired == true, update debit record status to ACTIVE in T24,
                // hard-delete direct debit entry from Azure Table Storage, and return result.
                // Otherwise, return false.
                if (isConsentRequired)
                    await UpdateActiveDirectAndPerformHardDeleteOnConsentRequired(request.DirectDebitId, manifest, cancellationToken);
            }
            else
            {
                // Consent Workflow
                //  IF methodOfOperation == ALLTOSIGN && (parties.partyrole = OWNER) > 1 the operation will continue to Get Operational Attributes
                //  IF methodOfOperation == ALLTOSIGN && (parties.partyRole = OWNER) == 1 the operation will continue to Soft Delete Pending Direct Debit Entry.
                //  IF methodOfOperation == ANYTOSIGN || null the operation will continue to Soft Delete Pending Direct Debit Entry.

                manifest.ToBeDeleted = true;
            }

            return isConsentRequired;
        }

        /// <summary>
        /// 5. Get Operational Requirements (which means determining if the consent it required)
        /// </summary>
        /// <param name="standardHeaderModel"></param>
        /// <param name="manifest"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        private async Task<bool> GetConsentRequiredAsync(
            IStandardHeaderModel standardHeaderModel,
            DirectDebitManifest manifest,
            CancellationToken cancellationToken)
        {
            _logger.LogDebug("{Method} for direct debit with id {DirectDebitId}", nameof(GetConsentRequiredAsync), manifest.DirectDebitId);

            try
            {
                // 5. Get Operational Attribute
                var consentResponses = await _consentWorkflowClient.GetOperationalAttributesAsync(standardHeaderModel, cancellationToken);

                // 5.a Get requirements for requestId == CHREPM
                var requirements = consentResponses
                    .GetOperationAttributes?
                    .FirstOrDefault(a => InternalConstants.Parameters.Consents.Chrepm.EqualsIgnoreCase(a.RequestId));

                // Check if consentRequired is true
                return requirements?.ConsentRequired
                    ?? false;
            }
            catch (StandardApiException)
            {
                manifest.RevertAttempt = true;
                throw;
            }
            catch (Exception ex)
            {
                manifest.RevertAttempt = true;
                throw _logger.LogAndRaiseStandardCommunicationError(Error.ErrorOnFetchingOperationalAttributes, InternalConstants.Systems.ConsentWorkflow, ex);
            }
        }

        private async Task UpdateActiveDirectAndPerformHardDeleteOnConsentRequired(string directDebitId, DirectDebitManifest manifest, CancellationToken cancellationToken)
        {
            _logger.LogDebug("{Method} for direct debit with id {DirectDebitId}", nameof(UpdateActiveDirectAndPerformHardDeleteOnConsentRequired), directDebitId);

            var updateDirectDebitCompositeRequest = new UpdateDirectDebitCompositeRequest
            {
                Status = DirectDebitStatus.Active,
                DirectDebitId = directDebitId
            };
            var t24UpdateDirectDebitRequest = _mapper.Map<UpdateDirectDebitRequest>(updateDirectDebitCompositeRequest);

            try
            {
                await _t24HomeLoanClient.UpdateDirectDebitAsync(t24UpdateDirectDebitRequest, cancellationToken);
                manifest.ToBeDeleted = true;
            }
            catch (StandardApiException)
            {
                manifest.RevertAttempt = true;
                throw;
            }
            catch (Exception ex)
            {
                manifest.RevertAttempt = true;
                throw _logger.LogAndRaiseStandardCommunicationError(Error.ErrorOnActivateDD(ex.Message), InternalConstants.Systems.T24, ex);
            }
        }
    }
}