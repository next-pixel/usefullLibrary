﻿using Platform.Library.AzureStorage.Entities;

namespace DirectDebitApi
{
    /// <summary>
    /// A record of changes made to the Direct Debit that needs 
    /// to be reflected in the ODS once operations are completed
    /// </summary>
    public class DirectDebitManifest
    {
        private DirectDebitManifest(DirectDebitEntity entity, bool toBeDeleted)
        {
            Entity = entity;
            ToBeDeleted = toBeDeleted;
        }

        /// <summary>
        /// Prepare a manifest for the <see cref="DirectDebitEntity"/>
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public static DirectDebitManifest Prepare(DirectDebitEntity entity, bool toBeDeleted = false)
        {
            return new DirectDebitManifest(entity, toBeDeleted);
        }

        /// <summary>Exposing the primary key to make it easier</summary>
        public string DirectDebitId => Entity.DirectDebitId;

        /// <summary>
        /// <see cref="DirectDebitEntity"/> being tracked
        /// </summary>
        public DirectDebitEntity Entity { get; private set; }

        /// <summary>Indicate if this constitutes an attempt</summary>
        public bool RevertAttempt { get; set; }

        /// <summary>Indicates that the direct debit can be deleted from the ODS</summary>
        public bool ToBeDeleted { get; set; }

        /// <summary>Does the direct debit record require updating</summary>
        public bool RequiresUpdating => RevertAttempt && !ToBeDeleted;

        /// <summary>Retrieve the updated entity (only if it requires updating)</summary>
        /// <returns></returns>
        public DirectDebitEntity UpdatedEntity()
        {
            // Was the attempt failed due to us
            if (RevertAttempt)
                Entity.Attempts -= 1;

            // Make the record active again
            Entity.ActiveRecord = true;

            return Entity;
        }

    }
}
