﻿namespace DirectDebitApi.Helpers
{
    public static class DirectDebitStatusExtension
    {
        /// <summary>
        /// Converts status from New to Pending and vice versa. Otherwise, return as is.
        /// T24 stores it as NEW, but we need to show it as PENDING.
        /// </summary>
        /// <param name="status"></param>
        /// <returns></returns>
        public static string ToStatusConvert(this string status)
        {
            return status switch
            {
                InternalConstants.DirectDebitStatus.Pending => InternalConstants.DirectDebitStatus.New,
                InternalConstants.DirectDebitStatus.New => InternalConstants.DirectDebitStatus.Pending,
                _ => status
            };
        }
    }
}
