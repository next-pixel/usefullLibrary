﻿using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.T24.SDK;

namespace DirectDebitApi.Helpers
{
    public static class ErrorsHelper
    {
        public static ErrorMessageModel CreateDefaultErrorModel(string system = T24SdkConstants.HttpClient.Temenos)
        => new ErrorMessageModel
        {
            MessageCode = CommonMessageConstants.StandardHeaderErrorCode,
            UserMessageText = string.Format(CommonMessageConstants.CommunicationsErrorNotFoundUserMessageText,
                    system)
        };


        public static ErrorMessageModel CreateCustomErrorModel(string messageCode, 
            string userMessageText, string supportMessageText)
        => new ErrorMessageModel
        {
            MessageCode = messageCode,
            UserMessageText = userMessageText,
            SupportMessageText = supportMessageText,
            Timestamp = DateTimeOffset.UtcNow
        };
    }
}


