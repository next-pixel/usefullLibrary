using System;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;

namespace DirectDebitApi.Helpers
{
    /// <summary>
    /// Extension method to <see cref="Generate(int, int, int, char)"/> a code
    /// </summary>
    public static class CodeGenerator
    {
        public const int MinValue = 0;
        public const int MaxValue = 999999;
        public const int PadLength = 6;
        public const char PadChar = '0';

        private static RandomNumberGenerator _randomNumberGenerator = RandomNumberGenerator.Create();

        /// <summary>
        /// Generate a cryptographically safe random code
        /// </summary>
        /// <param name="min"></param>
        /// <param name="max"></param>
        /// <param name="padLeft"></param>
        /// <param name="paddingChar"></param>
        /// <returns></returns>
        public static string Generate(int min = MinValue, int max = MaxValue, int padLeft = PadLength, char paddingChar = PadChar)
        {
            byte[] data = new byte[4];
            _randomNumberGenerator.GetBytes(data);
            
            return ((BitConverter.ToUInt32(data, 0) % (max-min)) + min).ToString().PadLeft(padLeft, paddingChar);
        }
    }
}