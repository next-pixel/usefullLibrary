﻿using DirectDebitApi.Models;
using FluentValidation;

namespace DirectDebitApi.Validators
{
    public class CancelPendingDirectDebitRequestValidator : AbstractValidator<CancelPendingDirectDebitRequest>
    {
        public CancelPendingDirectDebitRequestValidator()
        {
            RuleFor(request => request.CustomerId).NotEmpty();
            RuleFor(request => request.DirectDebitId).NotEmpty();
        }
    }
}
