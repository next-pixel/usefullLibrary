﻿using DirectDebitApi.Configuration.Abstractions;
using FluentValidation;

namespace DirectDebitApi.Validators
{
    public class SettingsValidator : AbstractValidator<ISettings>
    {
        public SettingsValidator()
        {
            RuleFor(s => s.InternalApimSubscriptionKey).NotEmpty();
            RuleFor(s => s.ServiceBus).NotNull().DependentRules(() =>
            {
                RuleFor(r => r.ServiceBus.ConnectionString01).NotEmpty();
                RuleFor(r => r.ServiceBus.ConnectionString02).NotEmpty();
            });
            RuleFor(s => s.DirectDebitTableStorage).NotNull().DependentRules(() =>
            {
                RuleFor(r => r.DirectDebitTableStorage.TableName).NotEmpty();
                RuleFor(r => r.DirectDebitTableStorage.ConnectionString).NotEmpty();
            });
        }
    }
}
