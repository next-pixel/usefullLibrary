using Azure.Core;
using DirectDebitApi.Models;
using FluentValidation;
using Microsoft.AspNetCore.Server.HttpSys;

namespace DirectDebitApi.Validators
{
    public class CreatePendingDirectDebitValidator : AbstractValidator<CreatePendingDirectDebitHandlerRequest>
    {
        public CreatePendingDirectDebitValidator()
        {
            RuleFor(request => request.CustomerId).NotEmpty();

            RuleFor(request => request.ArrangementId).NotNull();            

            RuleFor(request => request.Request).NotNull()
             .ChildRules(ofi =>
             {
                 ofi.RuleFor(p => p.AccountName).NotEmpty();
                 ofi.RuleFor(p => p.AccountNumber).NotEmpty();
                 ofi.RuleFor(p => p.BsbNumber).NotEmpty();
             });
        }
    }
    
}