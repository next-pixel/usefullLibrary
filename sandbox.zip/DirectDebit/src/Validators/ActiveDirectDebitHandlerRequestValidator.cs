using DirectDebitApi.Models;
using FluentValidation;
using Microsoft.Azure.Documents.SystemFunctions;

namespace DirectDebitApi.Validators
{
    public class ActiveDirectDebitHandlerRequestValidator : AbstractValidator<ActiveDirectDebitComposite>
    {
        public ActiveDirectDebitHandlerRequestValidator()
        {
            RuleFor(r => r.ActiveDirectDebit).NotNull().WithMessage("Active direct debit request is empty")
              .ChildRules(req =>
                {
                    req.RuleFor(x => x.DirectDebitId).NotEmpty();
                    req.RuleFor(x => x.AccountName).NotEmpty();
                    req.RuleFor(x => x.AccountNumber).NotEmpty();
                    req.RuleFor(x => x.BsbNumber).NotEmpty();
                });
            RuleFor(c => c.ArrangementId).NotEmpty().WithMessage("The request URL is missing the arrangementId");
            RuleFor(c => c.TemenosCif).NotEmpty().WithMessage("Temenos Cif missing from context");
        }
    }
}

