﻿using DirectDebitApi.Models;
using FluentValidation;

namespace DirectDebitApi.Validators
{
    public class VerifyPendingDirectDebitValidator : AbstractValidator<VerifyPendingDirectDebitHandlerRequest>
    {
        public VerifyPendingDirectDebitValidator()
        {
            RuleFor(request => request.VerificationCode).NotEmpty();
            RuleFor(request => request.CustomerId).NotEmpty();
            RuleFor(request => request.ArrangementId).NotEmpty();
            RuleFor(request => request.DirectDebitId).NotEmpty();
        }
    }
}
