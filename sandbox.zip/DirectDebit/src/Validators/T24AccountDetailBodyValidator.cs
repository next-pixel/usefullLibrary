﻿using FluentValidation;
using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;

namespace DirectDebitApi.Validators
{
    /// <summary>
    /// Validator for <seealso cref="T24AccountDetailBody"/>
    /// </summary>
    public class T24AccountDetailBodyValidator : AbstractValidator<T24AccountDetailBody>
    {
        public T24AccountDetailBodyValidator()
        {
            RuleFor(x => x.RepaymentInstruction)
                .NotNull();
        }
    }
}