﻿using FluentValidation;
using FluentValidation.Results;
using Platform.Library.Common;
using Platform.Library.Common.ErrorHandling;
using Platform.Library.Common.Standard.ErrorHandling;
using System.Text;
using static DirectDebitApi.InternalConstants;

namespace DirectDebitApi.Extensions
{
    /// <summary>
    /// Exetension methods to support the <see cref="IValidationResolver"/>
    /// </summary>
    public static class ValidationExtensions
    {
        /// <summary>
        /// Validates the <paramref name="request"/> using the <paramref name="resolver"/>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="resolver"></param>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static async Task ValidateRequestOrThrowAsync<T>(this IValidationResolver resolver, T request, CancellationToken cancellationToken = default)
        {
            var results = await resolver.ValidateAsync<T>(request, cancellationToken);

            if (!results.IsValid)
            {
                string errors = GetPrintableValidationErrors(results.Errors);
                throw StandardApiExceptionFactory.CreateBadRequestStandardApiException(
                    new ErrorMessageModel
                    {
                        MessageCode = CommonMessageConstants.BadInputDataErrorCode,
                        UserMessageText = string.Concat(Error.PayloadValidationFailed, errors)
                    });
            }
        }

        /// <summary>
        /// Validates the <paramref name="request"/> using the <paramref name="resolver"/>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="validator"></param>
        /// <param name="request"></param>
        public static void ValidateRequestOrThrow<T>(this IValidator<T> validator, T request)
        {
            var results = validator.Validate(request);

            if (!results.IsValid)
            {
                string errors = GetPrintableValidationErrors(results.Errors);
                throw StandardApiExceptionFactory.CreateBadRequestStandardApiException(
                    new ErrorMessageModel
                    {
                        MessageCode = CommonMessageConstants.BadInputDataErrorCode,
                        UserMessageText = string.Concat(Error.PayloadValidationFailed, errors)
                    });
            }
        }

        private static string GetPrintableValidationErrors(IList<ValidationFailure> validationErrors)
        {
            var errorString = new StringBuilder();
            foreach (var error in validationErrors)
            {
                errorString.Append(error);
            }

            return errorString.ToString();
        }
    }
}
