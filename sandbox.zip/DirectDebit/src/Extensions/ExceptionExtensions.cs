﻿using DirectDebitApi.Helpers;
using Microsoft.Azure.Cosmos.Table;
using Platform.Library.Common.ErrorHandling;
using Platform.Library.Common.Standard.ErrorHandling;
using System.Net;
using static DirectDebitApi.InternalConstants;

namespace DirectDebitApi
{
    /// <summary>
    /// Extension methods to support the raising of exceptions
    /// </summary>
    public static class ExceptionExtensions
    {
        /// <summary>
        /// Log and raise a <see cref="StandardApiException"/> to be returned and thrown from the calling location
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="statusCode"></param>
        /// <param name="code"></param>
        /// <param name="errorMessage"></param>
        /// <param name="supportMessage"></param>
        /// <param name="innerException"></param>
        /// <returns></returns>
        public static StandardApiException LogAndRaiseStandardApiException(this ILogger logger, HttpStatusCode statusCode, string code, string errorMessage, string supportMessage = null, Exception innerException = null)
        {
            var errorModel = new ErrorMessageModel
            {
                MessageCode = code,
                UserMessageText = errorMessage,
                SupportMessageText = supportMessage ?? errorMessage,
                Exception = innerException
            };

            logger.LogError(errorModel);

            return new StandardApiException
            {
                HttpStatusCode = (int)statusCode,
                ErrorMessage = errorModel
            };
        }

        public static StandardApiException LogAndRaiseNotFoundException<T>(this ILogger logger, string identifier, StorageException innerException, string system = InternalConstants.Systems.DirectDebitApi)
            where T : TableEntity
        {
            return logger.LogAndRaiseStandardApiException(
                HttpStatusCode.NotFound,
                CommonMessageConstants.CommunicationsErrorCode,
                string.Format(CommonMessageConstants.CommunicationsErrorNotFoundUserMessageText, system),
                $"There required {typeof(T).Name} was not found in azure storage: {innerException.Message}",
                innerException
            );
        }

        public static StandardApiException LogAndRaiseStorageException(this ILogger logger, StorageException innerException, string reason)
        {
            return logger.LogAndRaiseStandardApiException(
                HttpStatusCode.InternalServerError,
                CommonMessageConstants.CommunicationsErrorCode,
                CommonMessageConstants.CommunicationsErrorNotFoundUserMessageText,
                CommonMessageConstants.CommunicationsErrorSupportMessageTemplate
                    .Replace("{System}", InternalConstants.Systems.AzureTableStorage)
                    .Replace("{Purpose}", reason),
                innerException
            );
        }

        public static StandardApiException LogAndRaiseBadRequestError(this ILogger logger, Exception innerException, string reason)
        {
            return logger.LogAndRaiseStandardApiException(
                HttpStatusCode.BadRequest,
                CommonMessageConstants.BadInputDataErrorCode,
                null,
                null,
                innerException
            );
        }

        public static StandardApiException LogAndRaiseStandardCommunicationError(this ILogger logger, string reason, string system = InternalConstants.Systems.DirectDebitApi, Exception innerException = null)
        {
            return logger.LogAndRaiseStandardApiException(
                HttpStatusCode.InternalServerError, 
                CommonMessageConstants.CommunicationsErrorCode,
                CommonMessageConstants.CommunicationsErrorNotFoundUserMessageText,
                CommonMessageConstants.CommunicationsErrorSupportMessageTemplate
                    .Replace("{System}",system)
                    .Replace("{Purpose}", reason),
                innerException
            );
        }
    }
}
