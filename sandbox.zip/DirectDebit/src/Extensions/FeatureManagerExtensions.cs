﻿using DirectDebitApi.Validators;
using Microsoft.FeatureManagement;
using Platform.Library.Common;
using Platform.Library.Common.ErrorHandling;
using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;
using static DirectDebitApi.InternalConstants;

namespace DirectDebitApi
{
    /// <summary>
    /// Extensions class for <seealso cref="IFeatureManager"/>.
    /// </summary>
    internal static class FeatureManagerExtensions
    {
        /// <summary>
        /// Validates the account details.
        /// </summary>
        /// <param name="featureManager">The feature manager as an instance of <seealso cref="IFeatureManager"/>.</param>
        /// <param name="validationResolver">The validation resolver as an instance of <seealso cref="IValidationResolver"/>.</param>
        /// <param name="accountDetails">The account details as an instance of <seealso cref="T24AccountDetailBody"/>.</param>
        /// <param name="cancellationToken">The cancellation token as an instance of <seealso cref="CancellationToken"/>.</param>
        internal static async Task ConditionallyValidateAccountDetails(this IFeatureManager featureManager,
            IValidationResolver validationResolver,
            T24AccountDetailBody accountDetails,
            CancellationToken cancellationToken)
        {
            var isHomeLoanMarketLaunchEnabled = await featureManager.IsEnabledAsync(FeatureFlags.EnableHomeLoansMarketLaunch);
            if (isHomeLoanMarketLaunchEnabled)
            {
                var requestValidationResult = await validationResolver.ValidateAsync(
                    instance: accountDetails,
                    cancellationToken: cancellationToken);

                if (!requestValidationResult.IsValid)
                {
                    throw StandardApiExceptionFactory.CreateStandardApiException(
                            StatusCodes.Status400BadRequest,
                            CommonMessageConstants.BadInputDataErrorCode,
                            Error.RepaymentInstructionNotExist);
                }
            }
        }
    }
}