﻿using Platform.Library.T24.SDK.Modules.Lookup.ResponseDtos;

namespace DirectDebitApi.Extensions
{
    public static class T24InstitutionsNameResponseExtensions
    {
        public static string ExtractInstituteName(this T24InstitutionsNameResponseDto t24InstitutionsNameResponseDto)
        {
            return t24InstitutionsNameResponseDto.Body?.FirstOrDefault()?.InstitutionName ?? string.Empty;
        }
    }
}
