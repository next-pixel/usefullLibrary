using AutoMapper;
using DirectDebitApi.Models;
using Microsoft.FeatureManagement;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.Extensions;
using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;
using Platform.Library.T24.SDK.Modules.HomeLoan.RequestDtos;
using static DirectDebitApi.InternalConstants;
using static DirectDebitApi.InternalConstants.HomeLoan;

namespace DirectDebitApi.Mappers.ValueResolvers
{
    public class T24LoanSettlementValueResolver : IValueResolver<T24UpdateLoanSettlementCompositeRequest, T24UpdateLoanSettlementRequestDto, T24UpdateLoanSettlementRequest>
    {
        private readonly IFeatureManager _featureManager;

        public T24LoanSettlementValueResolver(IFeatureManager featureManager)
        {
            _featureManager = featureManager.GuardNull(nameof(featureManager));
        }

        /// <summary>
        /// To resolve 'T24UpdateLoanSettlementRequest' when 'ff-enable-home-loans-market-launch' is enabled
        /// </summary>
        /// <param name="source">Instance of <see cref="T24UpdateLoanSettlementCompositeRequest"/></param>
        /// <param name="destination">Instance of <see cref="T24UpdateLoanSettlementRequestDto"/></param>
        /// <param name="settlement">destination member <see cref="T24UpdateLoanSettlementRequest"/></param>
        /// <param name="context">Resolution context</param>
        /// <returns>Mapped T24UpdateLoanSettlementRequest from repayment instructions when 'ff-enable-home-loans-market-launch' is enabled</returns>
        public T24UpdateLoanSettlementRequest Resolve(T24UpdateLoanSettlementCompositeRequest source, T24UpdateLoanSettlementRequestDto destination, T24UpdateLoanSettlementRequest settlement, ResolutionContext context)
        {
            // mapping of paymentTypeList property is behind home loan market launch feature flag
            var isHomeLoanMarketLaunchEnabled = _featureManager.IsEnabledAsync(InternalConstants.FeatureFlags.EnableHomeLoansMarketLaunch).Result;

            var repaymentInstructionList = isHomeLoanMarketLaunchEnabled ? source.AccountDetails.RepaymentInstruction : null;

            var paymentTypeAndSettlementReferencePairs = UpsertPaymentAndSettlementDefaultValue(source.DirectDebitMandateReferenceId);

            var t24UpdateSettlementRequest = source.AccountDetails.Settlement.GetT24UpdateSettlementRequest(
                validPayInSettlementPaymentTypes: RepaymentTypesSupportedForDirectDebit,
                paymentTypeAndSettlementReferencePairs: paymentTypeAndSettlementReferencePairs,
                repaymentInstructions: repaymentInstructionList
                );

            return t24UpdateSettlementRequest;
        }
                
        private static IDictionary<string, T24AccountDetailsSettlementReference> UpsertPaymentAndSettlementDefaultValue(string directDebitMandateReferenceId)
        {
            // For supported payment types, assign the DirectDebitMandateReference to the directDebitId and the PayinAccount & PayinActivity to empty string
            var paymentTypeAndSettlementReferencePairs = RepaymentTypesSupportedForDirectDebit.ToDictionary(
                x => x,
                x => new T24AccountDetailsSettlementReference()
                {
                    PayinAccount = string.Empty,
                    PayinActivity = string.Empty,
                    DirectDebitMandateReference = directDebitMandateReferenceId
                });

            // Add ADHOCFEE with null PayinAccount & DirectDebitMandateReference and PayinActivity set to empty string
            paymentTypeAndSettlementReferencePairs.Add(
                T24SdkConstants.T24RepaymentType.AdhocFee,
                new T24AccountDetailsSettlementReference()
                {
                    PayinAccount = InternalConstants.NullStringValue,
                    PayinActivity = string.Empty,
                    DirectDebitMandateReference = InternalConstants.NullStringValue,
                });

            // Add CHARGE with null PayinAccount & DirectDebitMandateReference and PayinActivity set to empty string
            paymentTypeAndSettlementReferencePairs.Add(
                T24SdkConstants.T24RepaymentType.Charge,
                new T24AccountDetailsSettlementReference()
                {
                    PayinAccount = InternalConstants.NullStringValue,
                    PayinActivity = string.Empty,
                    DirectDebitMandateReference = InternalConstants.NullStringValue,
                });

            return paymentTypeAndSettlementReferencePairs;
        }
    }
}