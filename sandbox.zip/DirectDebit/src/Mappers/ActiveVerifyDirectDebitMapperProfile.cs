﻿using AutoMapper;
using DirectDebitApi.Models;
using Platform.Library.Azure.ServiceBus.Extensions.Extensions;
using Platform.Library.Events.Models;
using Platform.Library.T24.SDK.Modules.DirectDebit.RequestDtos;

namespace DirectDebitApi.Mappers
{
    public class ActiveVerifyDirectDebitMapperProfile : Profile
    {
        public ActiveVerifyDirectDebitMapperProfile()
        {

            CreateMap<DirectDebitIdComposite, EV52CancelDirectDebitEvent>()
                .ForMember(d => d.Payload, opt => opt.MapFrom(s => s))
                .ForMember(d => d.Metadata, opt => opt.MapFrom(s => s.StandardHeaders.MapMetadata()));

            CreateMap<DirectDebitIdComposite, DirectDebitPayload>()
                .ForMember(d => d.DirectDebitId, opt => opt.MapFrom(s => s.DirectDebitId));

            CreateMap<VerifyDirectDebitComposite, VerifyPendingDirectDebitHandlerRequest>()
                .ForMember(d => d.CustomerId, opt => opt.MapFrom(s => s.CustomerId))
                .ForMember(d => d.DirectDebitId, opt => opt.MapFrom(s => s.DirectDebitId))
                .ForMember(d => d.VerificationCode, opt => opt.MapFrom(s => s.ApiRequest.VerificationCode))
                .ForMember(d => d.ArrangementId, opt => opt.MapFrom(s => s.ApiRequest.ArrangementId));

            CreateMap<UpdateDirectDebitCompositeRequest, UpdateDirectDebitRequest>()
                .ForPath(dest => dest.CustomerId, opt => opt.Ignore())
                .ForPath(dest => dest.AccountName, opt => opt.Ignore())
                .ForPath(dest => dest.BsbNumber, opt => opt.Ignore())
                .ForPath(dest => dest.Status, opt => opt.MapFrom(src => src.Status))
                .ForPath(dest => dest.AccountNumber, opt => opt.Ignore())
                .ForPath(dest => dest.DirectDebitId, opt => opt.MapFrom(src => src.DirectDebitId))
                .ForPath(dest => dest.DebtorName, opt => opt.Ignore());                

            CreateMap<RequestWithHeadersComposite<VerifyPendingDirectDebitHandlerRequest>, EV52CancelDirectDebitEvent>()
                .ForPath(dest => dest.Payload.DirectDebitId, opt => opt.MapFrom(src => src.Request.DirectDebitId))
                .ForMember(dest => dest.Metadata, opt => opt.MapFrom(src => src.StandardHeaders.MapMetadata()))
                .ForPath(dest => dest.Metadata.EventName, opt => opt.MapFrom(src => InternalConstants.ServiceBus.EV52CancelDirectDebitEventName))
                .ForPath(x => x.Metadata.AssemblyQualifiedName, y => y.MapFrom(z => typeof(EV52CancelDirectDebitEvent).AssemblyQualifiedName));
        }
    }
}