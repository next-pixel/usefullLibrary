﻿using AutoMapper;
using DirectDebitApi.Helpers;
using DirectDebitApi.Models;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.Modules.DirectDebit.RequestDtos;
using Platform.Library.T24.SDK.Modules.DirectDebit.ResponseDtos;
using System.Globalization;

namespace DirectDebitApi.Mappers
{
    public class CreatePendingDirectDebitMapperProfile : Profile
    {
        public CreatePendingDirectDebitMapperProfile()
        {
            CreateMap<CreatePendingDirectDebitHandlerRequest, InitiatePaymentDirectDebitRequest>()
                .ForPath(dest => dest.Destination.AccountBsb, opt => opt.MapFrom(src => src.Request.BsbNumber))
                .ForPath(dest => dest.Destination.AccountNumber,
                    opt => opt.MapFrom(src => src.Request.AccountNumber))
                .ForPath(dest => dest.Destination.AccountName,
                    opt => opt.MapFrom(src => src.Request.AccountName))
                .ForMember(dest => dest.Description, opt => opt.MapFrom(src => Guid.NewGuid()));

            CreateMap<T24CreateDirectDebitResponse, CreatePendingDirectDebitResponse>()
                .ForMember(dest => dest.InstitutionName, opt => opt.MapFrom(src => src.DebtorBank))
                .ForMember(dest => dest.DirectDebitId, opt => opt.Ignore())
                .ForMember(dest => dest.AccountName, opt => opt.MapFrom(src => src.AccountName))
                .ForMember(dest => dest.BsbNumber, opt => opt.MapFrom(src => src.BsbNumber))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.Status.ToStatusConvert()))
                .ForMember(dest => dest.AccountNumber, opt => opt.MapFrom(src => src.AccountNumber));

            CreateMap<T24CreateDirectDebitResponseDto, CreatePendingDirectDebitResponse>()
                .ForPath(dest => dest.AccountName, opt => opt.MapFrom(src => src.Body.AccountName))
                .ForPath(dest => dest.AccountNumber, opt => opt.MapFrom(src => src.Body.AccountNumber))
                .ForPath(dest => dest.BsbNumber, opt => opt.MapFrom(src => src.Body.BsbNumber))
                .ForPath(dest => dest.InstitutionName, opt => opt.MapFrom(src => src.Body.DebtorBank))
                .ForPath(dest => dest.Status, opt => opt.MapFrom(src => src.Body.Status.ToStatusConvert()))
                .ForPath(dest => dest.DirectDebitId, opt => opt.MapFrom(src => src.Header.Id));

            CreateMap<(CreatePendingDirectDebitHandlerRequest handlerRequest, string directDebitParamId), T24CreateDirectDebitRequestDto>()
                .ForPath(dest => dest.CustomerId, opt => opt.MapFrom(src => src.handlerRequest.CustomerId))
                .ForPath(dest => dest.AccountName, opt => opt.MapFrom(src => src.handlerRequest.Request.AccountName))
                .ForPath(dest => dest.BsbNumber, opt => opt.MapFrom(src => src.handlerRequest.Request.BsbNumber))
                .ForPath(dest => dest.AccountNumber, opt => opt.MapFrom(src => src.handlerRequest.Request.AccountNumber))
                .ForPath(dest => dest.DebtorName, opt => opt.Ignore())              
                .ForPath(dest => dest.ParamId, opt => opt.MapFrom(src => src.directDebitParamId))
                .ForPath(dest => dest.Status, opt => opt.MapFrom(src => InternalConstants.DirectDebitStatus.New));
        }
    }
}