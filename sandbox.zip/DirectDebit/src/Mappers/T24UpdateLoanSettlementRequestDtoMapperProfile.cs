﻿using AutoMapper;
using DirectDebitApi.Mappers.ValueResolvers;
using DirectDebitApi.Models;
using Platform.Library.T24.SDK.Common.RequestDtos;
using Platform.Library.T24.SDK.Modules.HomeLoan.RequestDtos;

namespace DirectDebitApi.Mappers
{
    public class T24UpdateLoanSettlementRequestDtoMapperProfile : Profile
    {
        public T24UpdateLoanSettlementRequestDtoMapperProfile()
        {
            CreateMap<T24UpdateLoanSettlementCompositeRequest, T24RequestPayload<T24UpdateLoanSettlementRequestDto>>()
                .ForMember(dest => dest.Header, opt => opt.Ignore())
                .ForMember(dest => dest.Body, opt => opt.MapFrom(src => src));
                
            CreateMap<T24UpdateLoanSettlementCompositeRequest, T24UpdateLoanSettlementRequestDto>()
                .ForMember(dest => dest.Settlement, opt => opt.MapFrom<T24LoanSettlementValueResolver>())
                .ForMember(dest => dest.Parties, opt => opt.MapFrom(src => src.AccountDetails.Parties))
                .ForMember(dest => dest.ProductId, opt => opt.MapFrom(src => src.AccountDetails.ProductId))
                .ForMember(dest => dest.ActivityId, opt => opt.MapFrom(src => src.ActivityId));
        }
    }
}