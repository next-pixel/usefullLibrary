﻿using AutoMapper;
using DirectDebitApi.Helpers;
using DirectDebitApi.Models;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.Modules.DirectDebit.ResponseDtos;
using System.Globalization;

namespace DirectDebitApi.Mappers
{
    public class RetrieveDirectDebitMapperProfile : Profile
    {
        public RetrieveDirectDebitMapperProfile()
        {
            CreateMap<T24DirectDebitAccount, RetrieveDirectDebit>()
                .ForMember(dest => dest.DirectDebitId, opt => opt.MapFrom(src => src.DirectDebitId))
                .ForMember(dest => dest.BsbNumber, opt => opt.MapFrom(src => src.BsbNumber))
                .ForMember(dest => dest.AccountNumber, opt => opt.MapFrom(src => src.AccountNumber))
                .ForMember(dest => dest.AccountName, opt => opt.MapFrom(src => src.AccountName))
                .ForMember(dest => dest.InstitutionName, opt => opt.MapFrom(src => src.DebtorBank))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.Status.ToStatusConvert()))
                .ForMember(dest => dest.CreateDate, opt => opt.MapFrom(src => ExtractDate(src.CreateDate, 0)))
                .ForMember(dest => dest.ExpiryDate, opt => opt.MapFrom(src => ExtractDate(src.CreateDate, 5)));
        }

        private DateTime? ExtractDate(string date, int additionalDays)
        {
            return date.IsNullOrWhiteSpace() ? null : DateTime.ParseExact(date,
                        T24SdkConstants.DateFormats.DefaultT24Format,
                        CultureInfo.InvariantCulture).AddDays(additionalDays);
        }
    }
}
