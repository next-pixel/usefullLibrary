﻿using AutoMapper;
using Platform.Library.T24.SDK.Common.RequestDtos;
using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;
using Platform.Library.T24.SDK.Modules.HomeLoan.RequestDtos;

namespace DirectDebitApi.Mappers
{
    public class T24AutoSettleChargesRequestDtoMapperProfile : Profile
    {
        public T24AutoSettleChargesRequestDtoMapperProfile()
        {
            CreateMap<T24AccountDetailBody, T24RequestPayload<T24AutoSettleChargesRequestDto>>()
               .ForMember(dest => dest.Header, opt => opt.Ignore())
               .ForPath(dest => dest.Body.Product, opt => opt.MapFrom(src => src.ProductId))
               .ForPath(dest => dest.Body.Activity, opt => opt.MapFrom(src => InternalConstants.HomeLoan.ActivityId.LendingRedrawCharges))
               .ForPath(dest => dest.Body.ActivityCharges, opt => opt.MapFrom(
                   src => new List<ActivityCharge>()
                           {
                                new ActivityCharge()
                                {
                                    AutoSettle = InternalConstants.HomeLoan.ActivityCharges.AutoSettleYes,
                                    SettleActivity = InternalConstants.HomeLoan.ActivityCharges.SettleActivity
                                }
                   }));
        }
    }
}
