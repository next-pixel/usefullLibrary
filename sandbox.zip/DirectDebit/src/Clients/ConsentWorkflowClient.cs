﻿using DirectDebitApi.Clients.Abstractions;
using DirectDebitApi.Configuration;
using DirectDebitApi.Helpers;
using DirectDebitApi.Models;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Options;
using Platform.Library.Common.AspNetCore.StandardApi.Http;
using Platform.Library.Common.ErrorHandling;
using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.Common.Standard.Models.Abstractions;
using Platform.Library.Http.Abstractions;
using System.Net;
using static DirectDebitApi.InternalConstants;
using static DirectDebitApi.InternalConstants.Parameters;

namespace DirectDebitApi.Clients
{
    public class ConsentWorkflowClient : IConsentWorkflowClient
    {
        private readonly IHttpClientHelper _httpClientHelper;
        private readonly ConsentWorkflowSettings _consentWorkflowSettings;
        private readonly ILogger<ConsentWorkflowClient> _logger;

        public ConsentWorkflowClient(
            IHttpClientHelper httpClientHelper,
            IOptions<ConsentWorkflowSettings> consentWorkflowSettings,
            ILogger<ConsentWorkflowClient> logger)
        {
            _httpClientHelper = httpClientHelper.GuardNull(nameof(httpClientHelper));
            _consentWorkflowSettings = consentWorkflowSettings.GuardNull(nameof(consentWorkflowSettings));
            _logger = logger.GuardNull(nameof(logger));
        }

        public async Task<GetOperationalAttributesResponse> GetOperationalAttributesAsync(
            IStandardHeaderModel standardHeaders,
            CancellationToken cancellationToken)
        {

            var customHeaders = new Dictionary<string, string>()
            {
                {StandardHeaderConstants.Authorization, standardHeaders.Authorization}
            };

            var queryParameters = new Dictionary<string, string>
            {
                { Consents.System, Consents.T24 },
                { Consents.RequestId, Consents.Chrepm }
            };

            var uri = QueryHelpers.AddQueryString(
                    _consentWorkflowSettings.GetOperationAttributePath,
                    queryParameters);

            var httpResponse = await _httpClientHelper.GetAsync(
                HttpClients.ConsentWorkflow,
                uri,
                customHeaders,
                standardHeaders,
                cancellationToken);

            if (httpResponse.StatusCode == HttpStatusCode.BadRequest)
            {
                var errorMessage = httpResponse.ReasonPhrase;

                try
                {
                    var errorContent = await httpResponse.Content?.ReadAsStringAsync(cancellationToken);
                    if (errorContent.IsNotNull())
                    {
                        var errorMessageModel = errorContent.Deserialize<ErrorMessageModel>();
                        errorMessage = $"{httpResponse.ReasonPhrase} | Code: {errorMessageModel?.MessageCode} | Message: {errorMessageModel.UserMessageText}";
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, $"Error getting {nameof(ErrorMessageModel)} from HTTP response content.");
                }

                _logger.LogError(ErrorMessageModelFactory.CreateErrorMessageModel(
                    httpResponse.StatusCode.ToString(),
                    errorMessage));

                // Throw default 400 exception
                throw StandardApiExceptionFactory.CreateBadRequestStandardApiException(
                    ErrorsHelper.CreateDefaultErrorModel(HttpClients.ConsentWorkflow));
            }

            if (!httpResponse.IsSuccessStatusCode)
            {
                // Log response and convert to standard communication error
                _logger.LogError(ErrorMessageModelFactory.CreateErrorMessageModel(
                    httpResponse.StatusCode.ToString(),
                    httpResponse.ReasonPhrase));
                throw StandardApiExceptionFactory.CreateStandardCommunicationException();
            }

            var content = await httpResponse.Content.ReadAsStringAsync(cancellationToken);

            var response = content.Deserialize<GetOperationalAttributesResponse>();

            _logger.LogInformation($"Operational attributes fetched from T24 for system - {Consents.T24}, requestId - {Consents.Chrepm}");

            return response;
        }
    }
}