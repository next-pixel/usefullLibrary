using DirectDebitApi.Clients.Abstractions;
using DirectDebitApi.Configuration;
using DirectDebitApi.Helpers;
using DirectDebitApi.Models;
using Microsoft.Extensions.Options;
using Platform.Library.Common.AspNetCore.StandardApi.Http;
using Platform.Library.Common.ErrorHandling;
using Platform.Library.Common.Standard.Models.Abstractions;
using Platform.Library.Http.Abstractions;
using System.Net;

namespace DirectDebitApi.Clients
{
    public class PaymentInitiationClient : IPaymentInitiationClient
    {
        private readonly IHttpClientHelper _httpClientHelper;
        private readonly PaymentInitiationSettings _paymentInitiationSettings;
        private readonly ILogger<PaymentInitiationClient> _logger;

        public PaymentInitiationClient(
            IHttpClientHelper httpClientHelper,
            IOptions<PaymentInitiationSettings> paymentInitiationSettings, 
            ILogger<PaymentInitiationClient> logger)
        {
            _httpClientHelper = httpClientHelper.GuardNull(nameof(httpClientHelper));
            _paymentInitiationSettings = paymentInitiationSettings.GuardNull(nameof(paymentInitiationSettings));
            _logger = logger.GuardNull(nameof(logger));
        }

        public async Task<InitiatePaymentDirectDebitResponse> InitiateMicroTransaction(
            InitiatePaymentDirectDebitRequest request, 
            IStandardHeaderModel standardHeaders,
            CancellationToken cancellationToken)
        {
            _logger.LogDebug($"{nameof(PaymentInitiationClient)}.{nameof(InitiateMicroTransaction)} - started execution for account number {request.Destination.AccountNumber}");

            var customHeaders = new Dictionary<string, string>()
            {
                {InternalConstants.Headers.InteractionId, Guid.NewGuid().ToString()},
                {StandardHeaderConstants.Authorization, standardHeaders.Authorization},
            };

            var httpResponse = await _httpClientHelper.PostAsync(
                InternalConstants.HttpClients.PaymentInitiation,
                _paymentInitiationSettings.InitiateDirectDebitPath,
                request,
                customHeaders,
                standardHeaders,
                cancellationToken);

            if (httpResponse.StatusCode == HttpStatusCode.BadRequest)
            {
                _logger.LogError(ErrorMessageModelFactory.CreateErrorMessageModel(
                    httpResponse.StatusCode.ToString(),
                    httpResponse.ReasonPhrase));

                // Throw default 400 exception
                throw StandardApiExceptionFactory.CreateBadRequestStandardApiException(
                    ErrorsHelper.CreateDefaultErrorModel(InternalConstants.HttpClients.PaymentInitiation));
            }

            if (!httpResponse.IsSuccessStatusCode)
            {
                // Log response and convert to standard communication error
                _logger.LogError(ErrorMessageModelFactory.CreateErrorMessageModel(
                    httpResponse.StatusCode.ToString(),
                    httpResponse.ReasonPhrase));
                throw StandardApiExceptionFactory.CreateStandardCommunicationException();
            }

            var content = await httpResponse.Content.ReadAsStringAsync();

            var response = JsonConvert.DeserializeObject<InitiatePaymentDirectDebitResponse>(content);

            _logger.LogInformation($"{nameof(PaymentInitiationClient)}.{nameof(InitiateMicroTransaction)} - payment initiation successful for account number {request.Destination.AccountNumber}");

            return response;
        }
    }
}