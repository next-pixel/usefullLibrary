using System.Threading;
using System.Threading.Tasks;
using DirectDebitApi.Models;
using Platform.Library.Common.Standard.Models.Abstractions;

namespace DirectDebitApi.Clients.Abstractions
{
    public interface IPaymentInitiationClient
    {
        Task<InitiatePaymentDirectDebitResponse> InitiateMicroTransaction(
            InitiatePaymentDirectDebitRequest request,
            IStandardHeaderModel standardHeaders,
            CancellationToken cancellationToken);
    }
}