﻿using DirectDebitApi.Models;
using Platform.Library.Common.Standard.Models.Abstractions;

namespace DirectDebitApi.Clients.Abstractions
{
    public interface IConsentWorkflowClient
    {
        Task<GetOperationalAttributesResponse> GetOperationalAttributesAsync(
            IStandardHeaderModel standardHeaders,
            CancellationToken cancellationToken);
    }
}
