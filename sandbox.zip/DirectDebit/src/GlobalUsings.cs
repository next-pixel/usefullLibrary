﻿global using System;
global using System.Collections.Generic;
global using Newtonsoft.Json;
global using System.Text.Json;
global using System.Text.Json.Serialization;

global using MSJson = System.Text.Json.Serialization;