﻿using Platform.Library.Common.Standard.Models.Abstractions;

namespace DirectDebitApi.Models
{
    /// <summary>
    /// A composite 
    /// </summary>
    public class DirectDebitIdComposite
    {
        private DirectDebitIdComposite() { }

        public static DirectDebitIdComposite Define(string directDebitId, IStandardHeaderModel standardHeaders)
        {
            return new DirectDebitIdComposite
            {
                DirectDebitId = directDebitId,
                StandardHeaders = standardHeaders
            };
        }

        public string DirectDebitId { get; private set; }

        public IStandardHeaderModel StandardHeaders { get; private set; }
    }
}
