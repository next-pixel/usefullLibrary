﻿using MsJson = System.Text.Json.Serialization;
using NsJson = Newtonsoft.Json;

namespace DirectDebitApi.Models
{
    /// <summary>
    /// Verified accounts response
    /// </summary>
    public class RetrieveDirectDebitResponse
    {
        /// <summary>
        /// Gets or sets direct debit id
        /// </summary>
        [JsonProperty("directDebits")]
        [JsonPropertyName("directDebits")]
        public List<RetrieveDirectDebit> DirectDebits { get; set; } = new();
    }

    public class RetrieveDirectDebit
    {
        /// <summary>
        /// Gets or sets direct debit id
        /// </summary>
        [JsonProperty("directDebitId")]
        [JsonPropertyName("directDebitId")]
        public string DirectDebitId { get; set; }

        /// <summary>
        /// Gets or sets bsb number
        /// </summary>
        [JsonProperty("bsbNumber")]
        [JsonPropertyName("bsbNumber")]
        public string BsbNumber { get; set; }

        /// <summary>
        /// Gets or sets account number
        /// </summary>
        [JsonProperty("accountNumber")]
        [JsonPropertyName("accountNumber")]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets account name
        /// </summary>
        [JsonProperty("accountName")]
        [JsonPropertyName("accountName")]
        public string AccountName { get; set; }

        /// <summary>
        /// Gets or sets institution name
        /// </summary>
        [JsonProperty("institutionName")]
        [JsonPropertyName("institutionName")]
        public string InstitutionName { get; set; }

        /// <summary>
        /// Gets or sets status
        /// </summary>
        [JsonProperty("status")]
        [JsonPropertyName("status")]
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets create date
        /// </summary>
        [JsonProperty("createDate", NullValueHandling = NullValueHandling.Ignore)]
        [JsonPropertyName("createDate")]
        [System.Text.Json.Serialization.JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        [NsJson.JsonConverter(typeof(NsJson.Converters.DateOnlyConverter))]
        [MsJson.JsonConverter(typeof(DateOnlyConverter))]
        public DateTime? CreateDate { get; set; }

        /// <summary>
        /// Gets or sets expiry date
        /// </summary>
        [JsonProperty("expiryDate", NullValueHandling = NullValueHandling.Ignore)]
        [JsonPropertyName("expiryDate")]
        [System.Text.Json.Serialization.JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        [NsJson.JsonConverter(typeof(NsJson.Converters.DateOnlyConverter))]
        [MsJson.JsonConverter(typeof(DateOnlyConverter))]
        public DateTime? ExpiryDate { get; set; }
    }
}
