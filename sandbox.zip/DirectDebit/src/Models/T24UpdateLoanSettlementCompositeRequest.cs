﻿using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;

namespace DirectDebitApi.Models
{
    public class T24UpdateLoanSettlementCompositeRequest
    {
        public T24AccountDetailBody AccountDetails { get; set; }

        public string ActivityId { get; set; }

        public string DirectDebitMandateReferenceId { get; set; }
    }
}
