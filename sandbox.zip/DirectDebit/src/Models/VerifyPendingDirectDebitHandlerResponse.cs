﻿namespace DirectDebitApi.Models
{
    public class VerifyPendingDirectDebitHandlerResponse
    {
        [JsonProperty("consentRequired")]
        [JsonPropertyName("consentRequired")]
        public bool ConsentRequired { get; set; }
    }
}
