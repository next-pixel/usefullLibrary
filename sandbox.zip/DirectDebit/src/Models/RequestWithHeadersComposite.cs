﻿using Platform.Library.Common.Standard.Models.Abstractions;
using System.Diagnostics;
using System.Reflection;

namespace DirectDebitApi.Models
{
    /// <summary>
    /// Extension methods to make it easier to instantiate the <see cref="RequestWithHeadersComposite{T}"/>
    /// </summary>
    public static class RequestWithHeadersExtensions
    {
        /// <summary>
        /// Return a composite of the <paramref name="request"/> including <paramref name="headers">standard headers</paramref>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="request"></param>
        /// <param name="headers"></param>
        /// <returns></returns>
        public static RequestWithHeadersComposite<T> DefineWithUpdatedHeaders<T>(this T request, IStandardHeaderModel headers)
            where T : class
        {
            return RequestWithHeadersComposite<T>.Define(request, headers);
        }
    }

    /// <summary>
    /// Defines a composite object for passing both the request and its headers
    /// </summary>
    public class RequestWithHeadersComposite<T>
        where T : class
    {
        private RequestWithHeadersComposite() { }

        /// <summary>
        /// Define a composite object for the provided request and its headers
        /// </summary>
        /// <param name="request"></param>
        /// <param name="headers"></param>
        /// <returns></returns>
        internal static RequestWithHeadersComposite<T> Define(T request, IStandardHeaderModel headers)
        {
            return new RequestWithHeadersComposite<T>
            { 
                Request = request, 
                StandardHeaders = UpdatedHeaders(headers)
            };
        }

        /// <summary>The request being passed</summary>
        public T Request { get; private set; }
        
        /// <summary>The standard headers for this request</summary>
        public IStandardHeaderModel StandardHeaders { get; private set; }

        /// <summary>
        /// We are updating the standard headers to include this applications sending information
        /// </summary>
        /// <param name="headers"></param>
        /// <returns></returns>
        private static IStandardHeaderModel UpdatedHeaders(IStandardHeaderModel headers)
        {
            var versionInfo = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location);

            headers.SendingSystemId = versionInfo.ProductName;
            headers.SendingSystemVersion = versionInfo.FileVersion;

            return headers;
        }
    }
}
