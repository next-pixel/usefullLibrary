namespace DirectDebitApi.Models
{
    public class InitiatePaymentDirectDebitRequest
    {
        [JsonProperty("destination")]
        [JsonPropertyName("destination")]
        public DestinationDirectDebit Destination { get; set; }

        [JsonProperty("description")]
        [JsonPropertyName("description")]
        public string Description { get; set; }
    }
}