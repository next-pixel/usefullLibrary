﻿using Platform.Library.Common.Standard.Models;

namespace DirectDebitApi.Models
{
    public class VerifyPendingDirectDebitHandlerRequest
    {
        public string CustomerId { get; set; }

        public string DirectDebitId { get; set; }

        public string VerificationCode { get; set; }

        public string ArrangementId { get; set; }
    }
}
