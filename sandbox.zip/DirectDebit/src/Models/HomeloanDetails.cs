namespace DirectDebitApi.Models
{
    public class HomeloanDetails
    {
        [JsonProperty("arrangementId")]
        [JsonPropertyName("arrangementId")]
        public string ArrangementId { get; set; }

        [JsonProperty("accountId")]
        [JsonPropertyName("accountId")]
        public string AccountId { get; set; }
    }
}