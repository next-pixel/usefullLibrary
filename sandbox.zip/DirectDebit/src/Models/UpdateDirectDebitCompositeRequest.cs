﻿namespace DirectDebitApi.Models
{
    public class UpdateDirectDebitCompositeRequest
    {
        /// <summary>
        /// Update Direct Debit Request Status
        /// </summary>
        [JsonProperty("status")]
        [JsonPropertyName("status")]
        public string Status { get; set; }

        /// <summary>
        /// Update Direct Debit Request Status
        /// </summary>
        [JsonProperty("directDebitId")]
        [JsonPropertyName("directDebitId")]
        public string DirectDebitId { get; set; }
    }
}
