namespace DirectDebitApi.Models
{
    public class CreatePendingDirectDebitResponse
    {
        
        [JsonProperty("directDebitId")]
        [JsonPropertyName("directDebitId")]
        public string DirectDebitId { get; set; }

        [JsonProperty("accountName")]
        [JsonPropertyName("accountName")]
        public string AccountName { get; set; }

        [JsonProperty("bsbNumber")]
        [JsonPropertyName("bsbNumber")]
        public string BsbNumber { get; set; }

        [JsonProperty("accountNumber")]
        [JsonPropertyName("accountNumber")]
        public string AccountNumber { get; set; }

        [JsonProperty("institutionName")]
        [JsonPropertyName("institutionName")]
        public string InstitutionName { get; set; }

        [JsonProperty("status")]
        [JsonPropertyName("status")]
        public string Status { get; set; }
    }
}