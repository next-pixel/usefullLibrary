namespace DirectDebitApi.Models
{
    public class CreatePendingDirectDebitHandlerRequest
    {
        /// <summary>
        /// This shouldn't really be public but the handler requires it
        /// </summary>
        public CreatePendingDirectDebitHandlerRequest() {}

        public static CreatePendingDirectDebitHandlerRequest Define(string customerId, string arrangementId, CreatePendingDirectDebitRequest request)
        {
            return new CreatePendingDirectDebitHandlerRequest
            { 
                CustomerId = customerId, 
                ArrangementId = arrangementId, 
                Request = request 
            };
        }

        [JsonPropertyName("customerId")]
        [JsonProperty("customerId")]
        public string CustomerId { get; set; }
        [JsonPropertyName("arrangementId")]
        [JsonProperty("arrangementId")]
        public string ArrangementId { get; set; }
        [JsonPropertyName("request")]
        [JsonProperty("request")]
        public CreatePendingDirectDebitRequest Request { get; set; }
    }
}