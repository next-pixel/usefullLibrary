﻿using Platform.Library.Common.Standard.Models.Abstractions;

namespace DirectDebitApi.Models
{
    public class CancelDirectDebitRequestComposite
    {
        public IStandardHeaderModel StandardHeaderModel { get; set; }

        public string DirectDebitId { get; set; }
    }
}
