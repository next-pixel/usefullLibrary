namespace DirectDebitApi.Models
{
    public class DestinationDirectDebit
    {
        [JsonProperty("accountNumber")]
        [JsonPropertyName("accountNumber")]
        public string AccountNumber { get; set; }

        [JsonProperty("accountBSB")]
        [JsonPropertyName("accountBSB")]
        public string AccountBsb { get; set; }

        [JsonProperty("accountName")]
        [JsonPropertyName("accountName")]
        public string AccountName { get; set; }
    }
}