﻿namespace DirectDebitApi.Models
{
    public class CancelPendingDirectDebitRequest
    {
        [JsonProperty("directDebitId")]
        [JsonPropertyName("directDebitId")]
        public string DirectDebitId { get; set; }

        [JsonProperty("customerId")]
        [JsonPropertyName("customerId")]
        public string CustomerId { get; set; }
    }
}
