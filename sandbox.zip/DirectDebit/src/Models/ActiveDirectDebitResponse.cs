namespace DirectDebitApi.Models
{
    public class ActiveDirectDebitResponse
    {

    }
}