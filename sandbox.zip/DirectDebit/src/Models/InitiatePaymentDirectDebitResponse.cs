namespace DirectDebitApi.Models
{
    public class InitiatePaymentDirectDebitResponse
    {
        [JsonProperty("transactionId")]
        [JsonPropertyName("transactionId")]
        public string TransactionId { get; set; }

        [JsonProperty("transactionStatus")]
        [JsonPropertyName("transactionStatus")]
        public string TransactionStatus { get; set; }

        [JsonProperty("executionDate")]
        [JsonPropertyName("executionDate")]
        public string ExecutionDate { get; set; }

        [JsonProperty("paymentType")]
        [JsonPropertyName("paymentType")]
        public string PaymentType { get; set; }
    }
}