﻿namespace DirectDebitApi.Models
{
    public class VerifyPendingDirectDebitRequest
    {
        [JsonProperty("arrangementId")]
        [JsonPropertyName("arrangementId")]
        public string ArrangementId { get; set; }

        [JsonProperty("verificationCode")]
        [JsonPropertyName("verificationCode")]
        public string VerificationCode { get; set; }
    }
}
