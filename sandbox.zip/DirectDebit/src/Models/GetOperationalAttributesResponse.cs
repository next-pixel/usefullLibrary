﻿using JsonIgnore = System.Text.Json.Serialization.JsonIgnoreAttribute;

namespace DirectDebitApi.Models
{
    public class GetOperationalAttributesResponse
    {
        [JsonProperty(PropertyName = "operationalAttributes", NullValueHandling = NullValueHandling.Ignore)]
        [JsonPropertyName("operationalAttributes")]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public List<GetOperationAttributes> GetOperationAttributes { get; set; }
    }

    public class GetOperationAttributes
    {
        [JsonProperty(PropertyName = "requestId")]
        [JsonPropertyName("requestId")]
        public string RequestId { get; set; }

        [JsonProperty(PropertyName = "requestName")]
        [JsonPropertyName("requestName")]
        public string RequestName { get; set; }

        [JsonProperty(PropertyName = "requestDescription")]
        [JsonPropertyName("requestDescription")]
        public string RequestDescription { get; set; }

        [JsonProperty(PropertyName = "consentRequired")]
        [JsonPropertyName("consentRequired")]
        public bool ConsentRequired { get; set; }

        [JsonProperty(PropertyName = "expiryPeriod", NullValueHandling = NullValueHandling.Ignore)]
        [JsonPropertyName("expiryPeriod")]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public int? ExpiryPeriod { get; set; }
    }
}
