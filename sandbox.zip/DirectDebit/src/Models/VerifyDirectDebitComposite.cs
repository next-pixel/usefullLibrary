﻿using Platform.Library.Authentication.Models.Abstractions;

namespace DirectDebitApi.Models
{
    /// <summary>
    /// Composite request data for Verify Direct Debit
    /// </summary>
    public class VerifyDirectDebitComposite
    {
        private VerifyDirectDebitComposite() { }

        /// <summary>
        /// Define the composite to use for making the request
        /// </summary>
        /// <param name="request"></param>
        /// <param name="context"></param>
        /// <param name="directDebitId"></param>
        /// <returns></returns>
        public static VerifyDirectDebitComposite Define(VerifyPendingDirectDebitRequest request, IAuthenticationContext context, string directDebitId)
        {
            return new VerifyDirectDebitComposite
            {
                ApiRequest = request,
                CustomerId = context.Temenos_cif,
                DirectDebitId = directDebitId
            };
        }

        /// <summary>Request coming from the Api</summary>
        public VerifyPendingDirectDebitRequest ApiRequest { get; private set; }
        
        /// <summary>CustomerId in context for this call</summary>
        public string CustomerId { get; private set; }

        /// <summary>Direct Debit identified for this call</summary>
        public string DirectDebitId { get; private set; }
    }
}
