﻿namespace DirectDebitApi.Models
{
    public class RetrieveDirectDebitRequest
    {
        /// <summary>
        /// Customer's Id
        /// </summary>
        [JsonProperty("customerId")]
        [JsonPropertyName("customerId")]
        public string CustomerId { get; set; }

        /// <summary>
        /// T24 account identifier.
        /// </summary>
        [JsonProperty("accountId")]
        [JsonPropertyName("accountId")]
        public string AccountId { get; set; }

        /// <summary>
        /// T24 direct debit identifier.
        /// </summary>
        [JsonProperty("status")]
        [JsonPropertyName("status")]
        public string Status { get; set; }

        /// <summary>
        /// T24 direct debit identifier.
        /// </summary>
        [JsonProperty("directDebitId")]
        [JsonPropertyName("directDebitId")]
        public string DirectDebitId { get; set; }
    }
}
