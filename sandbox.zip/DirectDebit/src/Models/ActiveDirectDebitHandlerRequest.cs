﻿using Platform.Library.Authentication.Models.Abstractions;
using Platform.Library.Common.Standard.Models.Abstractions;

namespace DirectDebitApi.Models
{
    public class ActiveDirectDebitComposite
    {
        public ActiveDirectDebitRequest ActiveDirectDebit { get; set; }
        public string ArrangementId { get; set; }
        public string TemenosCif { get; set; }
    }
}
