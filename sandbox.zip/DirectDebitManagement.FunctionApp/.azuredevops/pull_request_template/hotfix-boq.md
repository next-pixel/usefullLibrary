|**Change Type:**|[`Hotfix`]|
|-:|:-|
|**Target Brand:**|`BOQ`|
|**Jira Ticket:**|[{Jira Card Title}](https://qdigital.atlassian.net/browse/{Jira_Number})|
|**Repository:**|[DirectDebitManagement.FunctionApp](https://dev.azure.com/qdigitalcode/DenovoBank/_git/DirectDebitManagement.FunctionApp)|
  
## {Jira_Number} Resolution
{Summarize how you resolved the defect}
  
## Additional Information
- {Provide additional information relevant to people reviewing the code}

## Reviewer Notes
- {Add notes for reviewers to pay attention to}

## Checklist
To be completed by the developer raising the PR, and verified by all reviewers
*(Please use `[:x:]` ( :x: ) to indicate no and `[X]` ( :ballot_box_with_check: ) to indicate yes*

- **Code Coverage**
  - [ ] **Coverage** - Have unit tests been updated to cover this hotfix (See [SonarQube](https://sonarqube.boqdev.com.au/projects))
  - [ ] **Quality** - Have you ensured that these changes meet the quality requirements (See [Whitesource](https://saas-eu.whitesourcesoftware.com/Wss/WSS.html#))
  
  ## Commit Messages
  -