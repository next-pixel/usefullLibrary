﻿using DirectDebitManagementFunctionApp.Configuration;
using DirectDebitManagementFunctionApp.Configuration.Abstractions;
using DirectDebitManagementFunctionApp.Functions;
using DirectDebitManagementFunctionApp.Handlers;
using DirectDebitManagementFunctionApp.Handlers.Abstractions;
using FluentAssertions;
using FluentAssertions.Execution;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Moq;
using Platform.Library.AzureStorage;
using Platform.Library.AzureStorage.Entities;
using Platform.Library.Common;
using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.Http;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.DependencyInjection;
using Platform.Library.T24.SDK.Modules.Customer.ResponseDtos;
using Platform.Library.Testing.XUnit;
using System.Net;
using Xunit;
using Xunit.Abstractions;

namespace DirectDebitManagementFunctionApp.UnitTests
{
    [TestType(TestTypeEnum.UnitTest)]
    public class ClearOverduePendingDirectDebitActionTests : XUnitTestFixture
    {
        public ClearOverduePendingDirectDebitActionTests(ITestOutputHelper outputHelper, XUnitClassFixture xUnitClassFixture) :
            base(outputHelper, xUnitClassFixture)
        {
        }

        // Quick Reference
        protected ContextModule Context => Module<ContextModule>();
        protected ResourceModule Resource => Module<ResourceModule>();
        [ModuleInit(nameof(InitHttpModule))]
        protected HttpModule Http => Module<HttpModule>();
        public ILogger Logger => Context.Resolve<ILogger>();

        private bool? _anyExceptionOccuredDuringDeletion = null;

        // Initialize any modules
        private void InitHttpModule()
        {
            Http.HandleMockRequestEvent += HttpModule_HandleMockRequestEvent;
        }

        private void HttpModule_HandleMockRequestEvent(object sender, HttpRequestEventArgs args)
        {
            args.TryParseAfterRequestPath(T24SdkConstants.T24Paths.UpdateDirectDebit, out string id);
            switch (args.ClientName)
            {
                case T24SdkConstants.HttpClient.T24:

                    if (args.Method == HttpMethod.Put)
                    {
                        if (id.InIgnoreCase("1002942977.52", "1002942977.12", "1002942977.8", "1002942977.4"))
                        {
                            args.SetResponse(HttpStatusCode.OK, "{}", null);
                        }
                        else if(id.InIgnoreCase("111112"))
                        {
                            var response = Resource.ExtractManifestResource<T24ErrorResponseDto>("RecordNotUpdated");
                            args.SetResponse(HttpStatusCode.BadRequest, response, null);
                        }
                        else if (id.InIgnoreCase("111111"))
                        {
                            var response = Resource.ExtractManifestResource<T24ErrorResponseDto>("BadRequest");
                            args.SetResponse(HttpStatusCode.BadRequest, response, null);
                        }
                        else
                        {
                            args.SetResponse(HttpStatusCode.InternalServerError, null);
                        }
                        return;
                    }
                    break;

                default:
                    throw new NotSupportedException($"{args.Method.ToString().ToUpper()}[{args.RequestPath.AbsoluteUri}] Not supported by {nameof(HttpModule_HandleMockRequestEvent)}");
            }

            throw new NotSupportedException($"HttpClient '{args.ClientName}' is not supported by {nameof(HttpModule_HandleMockRequestEvent)}");
        }

        // Perform Test Setup
        protected override void TestSetup()
        {
            Context.RegisterTypeAsInterfaces<ClearOverdueDirectDebitAction>();
            Context.RegisterTypeAsInterfaces<HttpClientHelper>();
            Context.RegisterTypeAsInterfaces<Settings>();

            Context.RegisterWithMsDi(s =>
            {
                s.RegisterT24Sdk(true);
                s.RegisterBrandResolver();
            });

            Context.RegisterMockAsInterface<IHttpContextAccessor>(SetupHttpContextAccessor);
            Context.RegisterMockAsInterface<IDateTimePicker>(SetupDateTimePicker);
            Context.RegisterMockAsInterface<IAzureCloudTableClient>(x => SetUpIAzureCloudTableClient(x));
        }

        private void SetupDateTimePicker(Mock<IDateTimePicker> dateTimePicker)
        {
            dateTimePicker.Setup(d => d.UtcNow).Returns(new DateTime(2024, 01, 01));
        }

        private void SetupHttpContextAccessor(Mock<IHttpContextAccessor> mock)
        {
            mock.Setup(x => x.HttpContext).Returns(new DefaultHttpContext()).Verifiable();
        }

        private void SetUpIAzureCloudTableClient(Mock<IAzureCloudTableClient> mock, bool isSuccess = true, string result = "Default")
        {
            if (isSuccess)
            {
                var directDebits = Resource.ExtractManifestResource<List<DirectDebitEntity>>(result, "Entry1");
                mock.Setup(x =>
                        x.GetPartitionAsync<DirectDebitEntity>
                            (It.IsAny<string>(), It.IsAny<int>()).Result)
                    .Returns(directDebits).Verifiable();
            }
            else
            {
                mock.Setup(x =>
                        x.GetPartitionAsync<DirectDebitEntity>
                            (It.IsAny<string>(), It.IsAny<int>()).Result)
                    .Throws(new NullReferenceException());
            }
        }

        private void SetupAzureCloudTableDeleteOperation(Mock<IAzureCloudTableClient> azureCloudTableClient, bool success)
        {
            if (success)
            {
                azureCloudTableClient.Setup(a => a.DeleteTableStorageAsync(It.IsAny<DirectDebitEntity>()))
                .ReturnsAsync(true)
                .Callback(() => _anyExceptionOccuredDuringDeletion = false);
            }
            else
            {
                azureCloudTableClient.Setup(a => a.DeleteTableStorageAsync(It.IsAny<DirectDebitEntity>()))
                .ThrowsAsync(new Exception())
                .Callback( () => _anyExceptionOccuredDuringDeletion = true);
            }
        }

        /// <summary>
        /// Test for <seealso cref="ClearOverdueDirectDebitAction.ProcessAsync"/> success scenarios, all DD records are removed from table storage
        /// </summary>
        [Theory]
        [InlineData(12)]
        public async Task ClearOverdueDirectDebitAction_Success_DeletesEnteriesFromTableStorage(int expectedEntryToBeDeleted)
        {
            // Arrange
            var function = new ClearOverduePendingDirectDebitFunction(Context.Resolve<IClearOverdueDirectDebitAction>());

            // Act
            var action = async () => await function.Run(null, Logger);

            // Assert
            await action.Should().NotThrowAsync();

            using (new AssertionScope())
            {
                Mock.VerifyAll();
                Context.GetMock<IAzureCloudTableClient>().Verify(a => a.DeleteTableStorageAsync(It.IsAny<DirectDebitEntity>()), Times.Exactly(expectedEntryToBeDeleted));
            }
        }

        /// <summary>
        /// Test for <seealso cref="ClearOverdueDirectDebitAction.ProcessAsync"/> when error occured while fetching dd record from table storage
        /// then DD is not deleted from table storage and expects 500 internal server error
        /// </summary>
        [Fact]
        public async Task ClearOverdueDirectDebitAction_ErrorWhileFetchingDDFromTableStorage_ExpectesInternalServerError()
        {
            // Arrange
            Context.UpdateMockSetup<IAzureCloudTableClient>(x => SetUpIAzureCloudTableClient(x, false));

            var actionHandler = new ClearOverdueDirectDebitAction(
                Context.Resolve<ISettings>(),
                Context.GetMock<IAzureCloudTableClient>().Object,
                Context.Resolve<IT24HomeLoanClient>(),
                Context.Resolve<IDateTimePicker>(),
                Context.Resolve<ILogger<ClearOverdueDirectDebitAction>>());

            // Act
            var action = async () => await actionHandler.ProcessAsync();

            // Assert
            var exception = await action.Should().ThrowAsync<StandardApiException>();

            using (new AssertionScope())
            {
                var exceptionSubject = exception.Subject.First();
                exceptionSubject.HttpStatusCode.Should().Be(500);

                Mock.VerifyAll();
                Context.GetMock<IAzureCloudTableClient>().Verify(a => a.UpsertTableStorageAsync(It.IsAny<DirectDebitEntity>()), Times.Never);
                Context.GetMock<IAzureCloudTableClient>().Verify(a => a.DeleteTableStorageAsync(It.IsAny<DirectDebitEntity>()), Times.Never);
            }
        }

        /// <summary>
        /// Test for <seealso cref="ClearOverdueDirectDebitAction.ProcessAsync"/> when T24 returns bad request or internal server error
        /// then DD is not deleted from table storage
        /// </summary>
        [Theory]
        [InlineData("BadRequest")]
        [InlineData("InternalServerError")]
        public async Task ClearOverdueDirectDebitAction_RequestFailedFromT24_ExpectesNoException(string requestFileName)
        {
            // Arrange
            Context.UpdateMockSetup<IAzureCloudTableClient>(x => SetUpIAzureCloudTableClient(x, true, requestFileName));

            var actionHandler = new ClearOverdueDirectDebitAction(
                Context.Resolve<ISettings>(),
                Context.Resolve<IAzureCloudTableClient>(),
                Context.Resolve<IT24HomeLoanClient>(),
                Context.Resolve<IDateTimePicker>(),
                Context.Resolve<ILogger<ClearOverdueDirectDebitAction>>()
            );

            // Act
            await actionHandler.ProcessAsync();

            // Assert
            using (new AssertionScope())
            {
                Mock.VerifyAll();
                Context.GetMock<IAzureCloudTableClient>().Verify(a => a.UpsertTableStorageAsync(It.IsAny<DirectDebitEntity>()), Times.Exactly(2));
                Context.GetMock<IAzureCloudTableClient>().Verify(a => a.DeleteTableStorageAsync(It.IsAny<DirectDebitEntity>()), Times.Never);
            }
        }

        /// <summary>
        /// Test for <seealso cref="ClearOverdueDirectDebitAction.ProcessAsync"/> when direct debit record is already updated, T24 returns bad request 
        /// then DD is deleted from table storage
        /// </summary>
        [Theory]
        [InlineData("RecordAlreadyUpdated", 3)]
        public async Task ClearOverdueDirectDebitAction_RecordAlreadyUpdatedInT24_T24ReturnsBadRequest_DeletesEntryFromTableStorage(string requestFileName, int expectedEntryToBeDeleted)
        {
            // Arrange
            Context.UpdateMockSetup<IAzureCloudTableClient>(x => SetUpIAzureCloudTableClient(x, true, requestFileName));
            Context.UpdateMockSetup<IAzureCloudTableClient>(x => SetupAzureCloudTableDeleteOperation(x, true));

            var actionHandler = new ClearOverdueDirectDebitAction(
                Context.Resolve<ISettings>(),
                Context.Resolve<IAzureCloudTableClient>(),
                Context.Resolve<IT24HomeLoanClient>(),
                Context.Resolve<IDateTimePicker>(),
                Context.Resolve<ILogger<ClearOverdueDirectDebitAction>>()
            );

            // Act
            await actionHandler.ProcessAsync();

            // Assert
            using(new AssertionScope())
            {
                Mock.VerifyAll();
                Context.GetMock<IAzureCloudTableClient>().Verify(a => a.DeleteTableStorageAsync(It.IsAny<DirectDebitEntity>()), Times.Exactly(expectedEntryToBeDeleted));
                _anyExceptionOccuredDuringDeletion.Should().BeFalse();
            }
        }

        /// <summary>
        /// Test for <seealso cref="ClearOverdueDirectDebitAction.ProcessAsync"/> when error occured during DD delete operation from table storage.
        /// </summary>
        [Theory]
        [InlineData(12)]
        public async Task  ClearOverdueDirectDebitAction_DeletesEntryFromTableStorageFailed_LogsException(int expectedEntryToBeDeleted)
        {
            // Arrange
            Context.UpdateMockSetup<IAzureCloudTableClient>(x => SetupAzureCloudTableDeleteOperation(x, false));

            var actionHandler = new ClearOverdueDirectDebitAction(
                Context.Resolve<ISettings>(),
                Context.Resolve<IAzureCloudTableClient>(),
                Context.Resolve<IT24HomeLoanClient>(),
                Context.Resolve<IDateTimePicker>(),
                Context.Resolve<ILogger<ClearOverdueDirectDebitAction>>()
            );

            // Act
            await actionHandler.ProcessAsync();

            // Assert
            using(new AssertionScope())
            {
                Mock.VerifyAll();
                Context.GetMock<IAzureCloudTableClient>().Verify(a => a.DeleteTableStorageAsync(It.IsAny<DirectDebitEntity>()), Times.Exactly(expectedEntryToBeDeleted));
                _anyExceptionOccuredDuringDeletion.Should().BeTrue();
            }
        }
    }
}