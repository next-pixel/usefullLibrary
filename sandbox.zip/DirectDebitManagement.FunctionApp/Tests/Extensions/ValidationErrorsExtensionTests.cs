﻿using FluentValidation.Results;
using DirectDebitManagementFunctionApp.Extensions;
using Platform.Library.Testing.XUnit;
using System.Collections.Generic;
using System.ComponentModel;
using Xunit;
using Xunit.Abstractions;

namespace DirectDebitManagementFunctionApp.UnitTests.Extensions
{
    /// <summary>
    /// Test class for errors extension test.
    /// </summary>
    [TestType(TestTypeEnum.UnitTest)]
    public class ValidationErrorsExtensionTests : XUnitTestFixture
    {
        private readonly IList<ValidationFailure> validationErrors;

        /// <summary>
        /// Constructor for <see cref="ValidationErrorsExtensionTests"/>.
        /// </summary>
        /// <param name="outputHelper">Output helper.</param>
        /// <param name="classFixture">Class fixture.</param>
        public ValidationErrorsExtensionTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) :
            base(outputHelper, classFixture)
        {
            validationErrors = new List<ValidationFailure>();
        }

        /// <summary>
        /// Test validation errors when validation errors is not empty.
        /// </summary>
        [Fact]
        [Description("When payload is invalid then validation errors are not empty.")]
        public void GetPrintableValidationErrors_WhenValidationErrorsNotEmpty_ErrorsInPrintableFormat()
        {
            validationErrors.Add(new ValidationFailure("Payload Error", "Payload Validation Failed"));

            var result = validationErrors.GetPrintableValidationErrors();
            
            Assert.Equal("Payload Validation Failed", result);
        }

        /// <summary>
        /// Test validation errors when validation errors is empty.
        /// </summary>
        [Fact]
        [Description("When payload is valid then validation errors is empty.")]
        public void GetPrintableValidationErrors_WhenPayloadIsValid_NoErrors()
        {   
            var result = validationErrors.GetPrintableValidationErrors();

            Assert.Equal(string.Empty, result);
        }
    }
}