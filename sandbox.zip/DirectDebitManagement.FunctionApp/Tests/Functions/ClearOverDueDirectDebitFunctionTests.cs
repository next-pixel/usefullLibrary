﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using Moq;
using DirectDebitManagementFunctionApp.Functions;
using DirectDebitManagementFunctionApp.UnitTests.Helper;
using Platform.Library.HealthChecks.Azure.Functions;
using Xunit;

namespace DirectDebitManagementFunctionApp.UnitTests.Functions
{
    public class ClearOverdueDirectDebitFunctionTests
    {
        
        private readonly Mock<IFunctionAppHealthChecksExecutor> _mockFunctionAppHealthChecksExecutor;
        private readonly Dictionary<string, StringValues> _httpQuery;
        private const string HttpBody = "";

        public ClearOverdueDirectDebitFunctionTests()
        {
            var mockRepository = new MockRepository(MockBehavior.Loose);
            _mockFunctionAppHealthChecksExecutor = mockRepository.Create<IFunctionAppHealthChecksExecutor>();
            _httpQuery = new Dictionary<string, StringValues>();
        }

        private HealthCheck CreateHealthCheck()
        {
            IActionResult result = new AcceptedResult
            {
                StatusCode = 200
            };
            _mockFunctionAppHealthChecksExecutor.Setup(x =>
                x.ExecuteAsync(It.IsAny<HttpRequest>(),
                    new CancellationToken())).ReturnsAsync(result);
            return new HealthCheck(
                _mockFunctionAppHealthChecksExecutor.Object);
        }


        [Fact]
        public async Task HealthCheckFunction_StateUnderTest_ExpectedBehavior()
        {
            //Arrange
            var healthCheck = CreateHealthCheck();

            // Act
            var resultObject = await healthCheck.RunAsync(
                HttpMockMessageHelper.HttpRequestSetup(_httpQuery, HttpBody),
                new CancellationToken()) as AcceptedResult;

            //Assert
            Assert.Equal(200, resultObject?.StatusCode);
        }
    }
}