﻿using DirectDebitManagementFunctionApp.Configuration;
using DirectDebitManagementFunctionApp.UnitTests.Helper;
using DirectDebitManagementFunctionApp.Validators;
using Library.Azure.ServiceBus;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using Platform.Library.Events.Models;
using Platform.Library.Http;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.DependencyInjection;
using Platform.Library.Testing.XUnit;
using System.ComponentModel;
using System.Net;
using System.Text;
using Xunit;
using Xunit.Abstractions;

namespace DirectDebitManagementFunctionApp.Handlers
{
    [TestType(TestTypeEnum.UnitTest)]
    public class CancelDirectDebitActionTests : XUnitTestFixture
    {
        private ResourceModule Resource => Module<ResourceModule>();

        private readonly IMessageHandler<EV52CancelDirectDebitEvent> cancelDirectDebitAction;
        public CancelDirectDebitActionTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture)
           : base(outputHelper, classFixture)
        {
            cancelDirectDebitAction = Context.Resolve<IMessageHandler<EV52CancelDirectDebitEvent>>();
        }

        // Quick Reference
        protected ContextModule Context => Module<ContextModule>();

        [ModuleInit(nameof(InitHttpModule))]
        protected HttpModule Http => Module<HttpModule>();

        public ILogger Logger => Context.Resolve<ILogger>();

        /// <summary>
        /// Initialize http modules.
        /// </summary>
        private void InitHttpModule()
        {
            Http.HandleMockRequestEvent += HttpModule_HandleMockRequestEvent;
        }

        /// <summary>
        /// Handle http module's mock request.
        /// </summary>
        /// <param name="sender">Sender.</param>
        /// <param name="args">Arguments.</param>
        /// <exception cref="NotSupportedException"></exception>
        private void HttpModule_HandleMockRequestEvent(object sender, HttpRequestEventArgs args)
        {
            var id = args.RequestMessage.RequestUri.AbsolutePath.Split("/").Last();
            switch (args.ClientName)
            {
                case T24SdkConstants.HttpClient.T24:

                    if (args.Method == HttpMethod.Put)
                    {
                        switch (id)
                        {
                            case "111111":
                                args.SetResponse(HttpStatusCode.OK, "{}", null);
                                return;
                            case "111112":
                                args.SetResponse(HttpStatusCode.InternalServerError, new Dictionary<string, string>());
                                return;
                            case "111113":
                                args.SetResponse(HttpStatusCode.BadRequest, new Dictionary<string, string>());
                                return;
                            default:
                                args.SetResponse(HttpStatusCode.ExpectationFailed, "{}", null);
                                return;
                        }
                    }
                    break;

                default:
                    throw new NotSupportedException($"{args.Method.ToString().ToUpper()}[{args.RequestPath.AbsoluteUri}] Not supported by {nameof(HttpModule_HandleMockRequestEvent)}");
            }

            throw new NotSupportedException($"HttpClient '{args.ClientName}' is not supported by {nameof(HttpModule_HandleMockRequestEvent)}");
        }

        /// <summary>
        /// Perform test setup.
        /// </summary>
        protected override void TestSetup()
        {
            Context.RegisterTypeAsInterfaces<HttpClientHelper>();
            Context.RegisterTypeAsInterfaces<CancelDirectDebitPayloadValidator>();
            Context.RegisterTypeAsInterfaces<Settings>();

            Context.RegisterWithMsDi(services =>
            {
                services.RegisterT24Sdk(true);
            });

            Context.RegisterTypeAsInterfaces<CancelDirectDebitAction>();
            Context.RegisterMockAsInterface<IMessageReceiver>(SetupMessageReceiver);
            Context.RegisterMockAsInterface<IHttpContextAccessor>(SetupHttpContextAccessor);
        }
        private void SetupMessageReceiver(Mock<IMessageReceiver> mock)
        {
            mock.Setup(x => x.DeadLetterAsync(It.IsAny<string>(), It.IsAny<IDictionary<string, object>>()))
                .Verifiable();

            mock.Setup(x => x.CompleteAsync(It.IsAny<string>()))
                .Returns(Task.CompletedTask)
                .Verifiable();
        }

        /// <summary>
        /// Setup http context accessor.
        /// </summary>
        /// <param name="httpContextAccessor">Http context accessor.</param>
        private void SetupHttpContextAccessor(Mock<IHttpContextAccessor> httpContextAccessor)
        {
            httpContextAccessor.Setup(x => x.HttpContext).Returns(new DefaultHttpContext()).Verifiable();
        }

        /// <summary>
        /// Get message from json file.
        /// </summary>
        /// <param name="fileName">File name.</param>
        /// <param name="directDebitId">Direct debit id.</param>
        /// <returns>Message.</returns>
        private static Message GetMessage(string fileName, string directDebitId)
        {
            var payloads = ResourceHelper.GetResourceObject<IList<EV52CancelDirectDebitEvent>>(fileName);
            var intendedPayload = payloads.FirstOrDefault(p => p.Payload.DirectDebitId == directDebitId);

            var payloadInBytes = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(intendedPayload));
            Message message = new Message(body: payloadInBytes);

            return message;
        }

      
        [Fact]
        [Description("CancelDirectDebitAction_Success executes as expected")]
        public async Task CancelDirectDebitAction_Success()
        {
            // Arrange          
            var messageReceiver = Context.Resolve<IMessageReceiver>();
            var logger = Context.Resolve<ILogger>();
            var message = GetMessage("List.DirectDebitCancelEvent.Default", "111111");

            //Act
            await cancelDirectDebitAction.ProcessMessageAsync(message, messageReceiver, logger, CancellationToken.None);
          
            //Assert
            Context.GetMock<IMessageReceiver>().Verify(x => x.CompleteAsync(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        [Description("T24 Response is null then DLQ is called")]
        public async Task CancelDirectDebitAction_WhenT24ResponseIsNull_DLQIsCalled()
        {
            //Arrange
            var message = GetMessage("List.DirectDebitCancelEvent.Default", "111113");
            var messageReceiver = Context.Resolve<IMessageReceiver>();
            var logger = Context.Resolve<ILogger>();           

            //Act
            await cancelDirectDebitAction.ProcessMessageAsync(message, messageReceiver, logger, CancellationToken.None);

            // Assert
            Context.GetMock<IMessageReceiver>().Verify(x => x.DeadLetterAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()),
                Times.Once);
        }

        [Fact]
        [Description("When payload is invalid then DLQ is called")]
        public async Task CancelDirectDebitAction_WhenPayloadIsInvalid_DLQIsCalled()
        {
            //Arrange
            var message = GetMessage("List.DirectDebitCancelEvent.Error", string.Empty);
            var messageReceiver = Context.Resolve<IMessageReceiver>();
            var logger = Context.Resolve<ILogger>();

            //Act
            await cancelDirectDebitAction.ProcessMessageAsync(message, messageReceiver, logger, CancellationToken.None);

            // Assert
            Context.GetMock<IMessageReceiver>().Verify(x => x.DeadLetterAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()),
                Times.Once);
        }

    }
}
