﻿using DirectDebitManagementFunctionApp.Helpers;
using FluentAssertions;
using FluentAssertions.Execution;
using Platform.Library.Testing.XUnit;
using Xunit;
using Xunit.Abstractions;
using static DirectDebitManagementFunctionApp.Constants.PendingDirectDebitConstants;

namespace DirectDebitManagement.FunctionApp.UnitTests.Helper
{
    [TestType(TestTypeEnum.UnitTest)]
    public class AzureStorageUtillityHelperTests : XUnitTestFixture
    {
        public AzureStorageUtillityHelperTests(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {
        }

        public static TheoryData<string, string, string, string> OverdueScenario =>
            new TheoryData<string, string, string, string>
            {
                {
                    "2024-01-04T00:00:00.0000000Z",
                    "(PartitionKey eq 'DirectDebit') and (ExpiryDateTime le datetime'2024-01-04T00:00:00.0000000Z')",
                    "(PartitionKey eq 'DirectDebit') and (Attempts ge 3)",
                    "(PartitionKey eq 'DirectDebit') and (ActiveRecord eq false)"
                }
            };

        [Theory]
        [MemberData(nameof(OverdueScenario))]
        public void GetOverdueScenarioWithFilterQueries_When_DateIsPassed_Then_AllFiltersQueriesAreReturned(string currentDateStr, string expiryDateFilter, string invalidDirectDebitFilter, string inactiveDirectDebitfilter)
        {
            //Arrange
            var testDate = DateTime.Parse(currentDateStr);

            //Act
            var overdueScenarioWithFilterQueries = AzureStorageUtillityHelper.GetOverdueScenarioWithFilterQueries(testDate);

            //Assert
            using (new AssertionScope())
            {
                overdueScenarioWithFilterQueries.Should().NotBeNull();

                var filterKeys = overdueScenarioWithFilterQueries.Keys;
                filterKeys.Should().Contain(OverDueCriteria.Expired);
                filterKeys.Should().Contain(OverDueCriteria.Invalid);
                filterKeys.Should().Contain(OverDueCriteria.Inactive);

                overdueScenarioWithFilterQueries[OverDueCriteria.Expired].Should().BeEquivalentTo(expiryDateFilter);
                overdueScenarioWithFilterQueries[OverDueCriteria.Invalid].Should().BeEquivalentTo(invalidDirectDebitFilter);
                overdueScenarioWithFilterQueries[OverDueCriteria.Inactive].Should().BeEquivalentTo(inactiveDirectDebitfilter);
            }
        }
    }
}