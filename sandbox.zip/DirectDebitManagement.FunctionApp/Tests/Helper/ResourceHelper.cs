﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Newtonsoft.Json;

namespace DirectDebitManagementFunctionApp.UnitTests.Helper
{
    public static class ResourceHelper
    {
        /// <summary>
        ///     Used to load an embedded resource from a filename in the Resources folder and JSON cast it to the correct Type.
        /// </summary>
        /// <param name="filename">filename in the resources folder</param>
        /// <returns></returns>
        public static string GetStringResource(string filename)
        {
            var result = GetStream(filename);
            return result.ReadToEnd();
        }

        /// <summary>
        ///     Used to load an embedded resource from a filename in the Resources folder and JSON cast it to the correct Type.
        /// </summary>
        /// <typeparam name="T">expected type the filename will represent</typeparam>
        /// <param name="filename">filename in the resources folder</param>
        /// <returns></returns>
        public static T GetResourceObject<T>(string filename)
        {
            T result;

            using (var sr = GetStream(filename))
            {
                var serializer = new JsonSerializer();
                result = (T)serializer.Deserialize(sr, typeof(T));
            }

            return result;
        }

        public static StreamReader GetStream(string filename)
        {
            var assembly = Assembly.GetExecutingAssembly();
            var resourceNames = new List<string>(assembly.GetManifestResourceNames());

            filename = filename.Replace(@"/", ".");
            filename = resourceNames.FirstOrDefault(r => r.Contains(filename));

            if (filename == null)
                throw new FileNotFoundException("Resource not found");

            var result = new StreamReader(assembly.GetManifestResourceStream(filename) ?? throw new InvalidOperationException());

            return result;
        }
    }
}
