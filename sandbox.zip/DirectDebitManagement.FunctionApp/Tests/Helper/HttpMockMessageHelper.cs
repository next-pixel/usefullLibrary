﻿using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using Moq;
using Newtonsoft.Json;

namespace DirectDebitManagementFunctionApp.UnitTests.Helper
{
    public static class HttpMockMessageHelper
    {
        public static HttpResponseMessage Success =>
            new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK
            };

        public static HttpResponseMessage WithContent<T>(this HttpResponseMessage response, T obj)
        {
            response.Content = new StringContent(JsonConvert.SerializeObject(obj));
            return response;
        }

        public static HttpResponseMessage BadRequest =>
            new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.BadRequest
            };

        public static HttpRequest HttpRequestSetup(Dictionary<string, StringValues> query, string body)
        {
            var reqMock = new Mock<HttpRequest>();

            reqMock.Setup(req => req.Query).Returns(new QueryCollection(query));
            var stream = new MemoryStream();
            var writer = new StreamWriter(stream);
            writer.Write(body);
            writer.Flush();
            stream.Position = 0;
            reqMock.Setup(req => req.Body).Returns(stream);
            return reqMock.Object;
        }
    }
}
