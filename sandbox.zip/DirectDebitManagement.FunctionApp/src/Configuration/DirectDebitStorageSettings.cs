﻿using Platform.Library.AzureStorage;
using System;
using System.Collections.Generic;
using System.Text;

namespace DirectDebitManagementFunctionApp.Configuration
{
    public class DirectDebitStorageSettings : AzureCloudTableSettings
    {
        public const string SectionName = "HomeLoans:TableStorage:DirectDebits";
        public DirectDebitStorageSettings() : base()
        {
        }
    }
}
