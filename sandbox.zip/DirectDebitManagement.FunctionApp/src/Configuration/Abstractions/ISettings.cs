﻿using System;

namespace DirectDebitManagementFunctionApp.Configuration.Abstractions
{
    public interface ISettings
    {
        string InternalApimSubscriptionKey { get; }

        UseMockSettings UseMocks { get; }

        int HttpRetries { get; }

        DirectDebitStorageSettings DirectDebitTableStorage { get; set; }

        DirectDebitOptions DirectDebit { get; set; }

        ServiceBusOptions ServiceBus { get; set; }
    }

    public class UseMockSettings
    {
        public bool T24 { get; set; }
        public bool T24FutureDev { get; set; }
    }
}