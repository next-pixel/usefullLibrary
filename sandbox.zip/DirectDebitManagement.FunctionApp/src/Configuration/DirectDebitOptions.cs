﻿namespace DirectDebitManagementFunctionApp.Configuration
{
    public class DirectDebitOptions
    {
        public int TableFetchCount { get; set; }
        public string CronDuration { get; set; }
    }
}
