﻿using DirectDebitManagementFunctionApp.Configuration.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DirectDebitManagementFunctionApp.Configuration
{
    /// <summary>
    /// Servicebus options.
    /// </summary>
    public class ServiceBusOptions
    {
        /// <summary>
        /// Gets or sets connection string for 1st region.
        /// </summary>
        public string ConnectionString01 { get; set; }

        /// <summary>
        /// Gets or sets Connection string for 2nd region.
        /// </summary>
        public string ConnectionString02 { get; set; }
    }
}
