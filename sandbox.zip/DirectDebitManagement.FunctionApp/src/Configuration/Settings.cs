﻿using System;
using System.Diagnostics.CodeAnalysis;
using DirectDebitManagementFunctionApp.Configuration.Abstractions;
using Library.Azure.Functions.Extensions.Configuration;
using Microsoft.Extensions.Configuration;
using Platform.Library.Common.Standard.Configuration;

namespace DirectDebitManagementFunctionApp.Configuration
{
    [ExcludeFromCodeCoverage]
    public class Settings : StandardFunctionSettings, ISettings
    {
        public Settings(IConfiguration configuration) : base(configuration)
        {
            configuration.GuardNull(nameof(configuration));
            configuration.Bind(this);
        }

        public DirectDebitStorageSettings DirectDebitTableStorage { get; set; } = new DirectDebitStorageSettings();

        public string InternalApimSubscriptionKey { get; set; }

        public UseMockSettings UseMocks { get; set; } = new UseMockSettings();
        
        public int HttpRetries { get; set; }

        /// <summary>
        /// Gets or sets service bus options.
        /// </summary>
        public ServiceBusOptions ServiceBus { get; set; } = new ServiceBusOptions();

        public DirectDebitOptions DirectDebit { get; set; } = new DirectDebitOptions();
    }
}