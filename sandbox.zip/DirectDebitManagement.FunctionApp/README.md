[![Target Framework](https://img.shields.io/badge/Target%20Framework:-net6.0-GREEN.svg?style=plastic&logo=dotnet)](https://shields.io/)
[![Quality Gate Status](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=DirectDebitManagement.FunctionApp&metric=alert_status&token=sqb_7c216a4bb9cfda09cb115df10259ed39d33140c2)](https://sonarqube.boqdev.com.au/dashboard?id=DirectDebitManagement.FunctionApp)
[![Coverage](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=DirectDebitManagement.FunctionApp&metric=coverage&token=sqb_7c216a4bb9cfda09cb115df10259ed39d33140c2)](https://sonarqube.boqdev.com.au/dashboard?id=DirectDebitManagement.FunctionApp)
[![Vulnerabilities](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=DirectDebitManagement.FunctionApp&metric=vulnerabilities&token=sqb_7c216a4bb9cfda09cb115df10259ed39d33140c2)](https://sonarqube.boqdev.com.au/dashboard?id=DirectDebitManagement.FunctionApp)

**Pending Direct Debit Housekeeping:**

|Brand|Latest Build|
|--|--|
|**VMA**|[![Build Status](https://dev.azure.com/qdigitalcode/DenovoBank/_apis/build/status%2FHomeLoans%2FSubscriber%2FDirectDebitManagement.FunctionApp-VMA?repoName=DirectDebitManagement.FunctionApp&branchName=master)](https://dev.azure.com/qdigitalcode/DenovoBank/_build/latest?definitionId=1495&repoName=DirectDebitManagement.FunctionApp&branchName=master)|
|**BOQ**|[![Build Status](https://dev.azure.com/qdigitalcode/DenovoBank/_apis/build/status%2FHomeLoans%2FSubscriber%2FDirectDebitManagement.FunctionApp-BOQ?repoName=DirectDebitManagement.FunctionApp&branchName=master)](https://dev.azure.com/qdigitalcode/DenovoBank/_build/latest?definitionId=1496&repoName=DirectDebitManagement.FunctionApp&branchName=master)|
|**MEB**|[![Build Status](https://dev.azure.com/qdigitalcode/DenovoBank/_apis/build/status%2FHomeLoans%2FSubscriber%2FDirectDebitManagement.FunctionApp-MEB?repoName=DirectDebitManagement.FunctionApp&branchName=master)](https://dev.azure.com/qdigitalcode/DenovoBank/_build/latest?definitionId=2822&repoName=DirectDebitManagement.FunctionApp&branchName=master)|

## IC92 Direct Debit Management_Phase2 (Function App)
The Direct Debit Management (Function App) provides Home Loan direct debit capabilities to clean up Azure Table Storage and T24.

## Confluence
Details about this component can be found on the following pages:

|||
|-:|:-|
|**Gateway:**|[A61 Home Loan Repayments_Phase2 (Gateway API)](https://qdigital.atlassian.net/wiki/spaces/ITSARCH/pages/6145410568/IC92+Direct+Debit+Management+Phase2+Function+App)|
|**Component:**|[IC92 Direct Debit Management_Phase2 (Function App)](https://qdigital.atlassian.net/wiki/spaces/ITSARCH/pages/6145410568/IC92+Direct+Debit+Management+Phase2+Function+App)|

## Features
- Provides Home Loan direct debit capabilities to clean up Azure Table Storage and T24.

# Getting Started
Add a local.settings.json file to run the azure function in your local dev machine
```
{
  "IsEncrypted": false,
  "Values": {
    "AzureWebJobsStorage": "UseDevelopmentStorage=true",
    "FUNCTIONS_WORKER_RUNTIME": "dotnet",
    "brandName": "VMA",
    "appConfigEndpoint": "https://ac-denovo-hlt-edc-01.azconfig.io"
  }
}
```
