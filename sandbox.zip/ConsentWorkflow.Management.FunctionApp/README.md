[![Target Framework](https://img.shields.io/badge/Target%20Framework:-net6.0-GREEN.svg?style=plastic&logo=dotnet)](https://shields.io/)
[![Quality Gate Status](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=ConsentWorkflow.Management.FunctionApp&metric=alert_status&token=0288f7521d09de2a7ac7861610a4b3e202c2e5ce)](https://sonarqube.boqdev.com.au/dashboard?id=ConsentWorkflow.Management.FunctionApp)
[![Coverage](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=ConsentWorkflow.Management.FunctionApp&metric=coverage&token=0288f7521d09de2a7ac7861610a4b3e202c2e5ce)](https://sonarqube.boqdev.com.au/dashboard?id=ConsentWorkflow.Management.FunctionApp)

[![Bugs](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=ConsentWorkflow.Management.FunctionApp&metric=bugs&token=0288f7521d09de2a7ac7861610a4b3e202c2e5ce)](https://sonarqube.boqdev.com.au/dashboard?id=ConsentWorkflow.Management.FunctionApp)
[![Code Smells](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=ConsentWorkflow.Management.FunctionApp&metric=code_smells&token=0288f7521d09de2a7ac7861610a4b3e202c2e5ce)](https://sonarqube.boqdev.com.au/dashboard?id=ConsentWorkflow.Management.FunctionApp)
[![Vulnerabilities](https://sonarqube.boqdev.com.au/api/project_badges/measure?project=ConsentWorkflow.Management.FunctionApp&metric=vulnerabilities&token=0288f7521d09de2a7ac7861610a4b3e202c2e5ce)](https://sonarqube.boqdev.com.au/dashboard?id=ConsentWorkflow.Management.FunctionApp)

|Brand|Latest Build|
|-----|--|
| **VMA** |[![Build Status](https://dev.azure.com/qdigitalcode/DenovoBank/_apis/build/status/HomeLoans/Subscriber/ConsentWorkflow.Management.FunctionApp-VMA?repoName=ConsentWorkflow.Management.FunctionApp&branchName=master)](https://dev.azure.com/qdigitalcode/DenovoBank/_build/latest?definitionId=2145&repoName=ConsentWorkflow.Management.FunctionApp&branchName=master)|
| **BOQ** |[![Build Status](https://dev.azure.com/qdigitalcode/DenovoBank/_apis/build/status/HomeLoans/Subscriber/ConsentWorkflow.Management.FunctionApp-BOQ?repoName=ConsentWorkflow.Management.FunctionApp&branchName=master)](https://dev.azure.com/qdigitalcode/DenovoBank/_build/latest?definitionId=2146&repoName=ConsentWorkflow.Management.FunctionApp&branchName=master)|
| **MEB** |[![Build Status](https://dev.azure.com/qdigitalcode/DenovoBank/_apis/build/status/HomeLoans/Subscriber/ConsentWorkflow.Management.FunctionApp-MEB?repoName=ConsentWorkflow.Management.FunctionApp&branchName=master)](https://dev.azure.com/qdigitalcode/DenovoBank/_build/latest?definitionId=2857&repoName=ConsentWorkflow.Management.FunctionApp&branchName=master)|

# ConsentWorkflowMgmt.Subscriber

## Description
Subscribes to the Consent Created Event to publish consent requests to the ODS and pending request comms.
- Publish consent requests to ODS and pending comms
- Time trigger function that expires pending consent requests 

## Confluence
Details about this component can be found on the following pages which include the service and the specific service operation 

|||
|--|--|
|**Component:**|[IC97 Consent Workflow Management Phase 2 (Function App)](https://qdigital.atlassian.net/wiki/spaces/ITSARCH/pages/6264979457/IC97+Consent+Workflow+Management+Phase2+Function+App)|

### Doing Development work
While working on a feature or a hotfix create branches out of master. The naming convention is `feature/<ticket>-<branch-name>` or `fix/<ticket>-<branch-name>`. Make sure the name of the branch is in lower case. When these branches are pushed they will trigger dev pipeline.

### How to release code for brands
To release brand specific code create branches for the brands from master. The naming convention is `release-<brand>/<release-version>`

Examples:
|Example|Branch Name|
||-|:-|
|Completing a feature for jira ticket NOVO2-1234|`feature/novo2-1234-quick-summary`|
|Feature release version 1.00 of home loans to VMA|`release-vma/homeloan1-00`|
|Feature release version 1.03 of home loans to BOQ|`release-boq/homeloan1-03`|
|Complete Hotfix defect for jira ticket NOVO2-2345|`fix/novo2-2345-fix-something`|
|Release Hotfix for hjira ticket NOVO2-2345 to VMA|`hotfix-vma/novo2-2345-fix-something`|

### TECH DEBT
Please endevour to resolve some of this tech debt with the existing work that you do

|Area|Reference|Action|
|:-|:-|:-|

|Configuration|Startup|Need to update to use `.DefineConfiguration` instead|