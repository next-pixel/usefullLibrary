﻿global using ConsentWorkflowManagementFunctionApp;
global using Platform.Library.Ods.Core.OdsDB.DataModel;
global using Platform.Library.Events.Models;
global using Microsoft.Extensions.Logging;
global using Moq;
global using Newtonsoft.Json;
global using Platform.Library.BaseEvent;
global using Platform.Library.Testing.XUnit;
global using System.Net;
global using Xunit;
global using Xunit.Abstractions;
global using static ConsentWorkflowManagementFunctionApp.Constants;

// Common Aliases
global using EventModels = Platform.Library.Events.Models;
global using EventEnums = Platform.Library.Events.Models.Enum;
global using OdsModels = Platform.Library.Ods.Core.OdsDB.DataModel;
global using OdsSubModels = Platform.Library.Ods.Core.OdsDB.DataModel.SubModels;
global using OdsConsent = Platform.Library.Ods.Core.OdsDB.DataModel.SubModels.Consent;
global using OdsConsentEnums = Platform.Library.Ods.Core.OdsDB.DataModel.SubModels.Consent.Enumerations;