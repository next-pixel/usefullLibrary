﻿using FluentAssertions;
using FluentAssertions.Execution;
using Platform.Library.Common.AspNetCore.StandardApi.Http;
using Platform.Library.Http;
using static ConsentWorkflowManagementFunctionApp.Constants.HttpClients;

namespace ConsentWorkflowMgmt.UnitTests
{
    [TestType(TestTypeEnum.UnitTest)]
    public class CustomHeadersHelperTest : XUnitTestFixture
    {
        private const string ApimSubscriptionKey = "assagsadkgjsdksjdg";
        private const string TokenValue = "12345";
        private const string RequestId = "1111";

        private ContextModule Context => Module<ContextModule>();

        public CustomHeadersHelperTest(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {
        }

        protected override void TestSetup()
        {
            Context.RegisterMockAsInterface<IAzureServiceTokenProviderClient>(SetupASPClient);
            Context.RegisterTypeAsInterfaces<Settings>();
        }

        private void SetupASPClient(Mock<IAzureServiceTokenProviderClient> mock)
        {
            mock.Setup(x => x.GetAccessTokenAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>())).ReturnsAsync(TokenValue);
        }

        [Fact]
        public void GetCustomHeaders_GetHeader_NoErrors()
        {
            var settings = Context.Resolve<ISettings>();
            settings.AzureAd.ResourceId = "AzureAd";
            var headers = StandardHeaderExtensions
                .GetStandardHeaders(RequestId)
                .AsCustomHeaders()
                .AcceptsJson()
                .WithAzureAdTokenHeader(Context.Resolve<IAzureServiceTokenProviderClient>(), settings.AzureAd.ResourceId);

            using (new AssertionScope())
            {
                headers.Should().NotBeNull();
                if (headers != null)
                {
                    headers[StandardHeaderConstants.RequestId].Should().Be(RequestId);
                    headers[StandardHeaderConstants.Accept].Should().Be(MetaData.Accept);
                    headers[StandardHeaderConstants.SendingSystemId].Should().Be(nameof(ConsentWorkflowManagementFunctionApp));
                    headers[StandardHeaderConstants.SendingSystemVersion].Should().Be(MetaData.SendingSystemVersion);
                    headers[StandardHeaderConstants.InitiatingSystemId].Should().Be(MetaData.InitiatingSystemId);
                    headers[StandardHeaderConstants.InitiatingSystemVersion].Should().Be(MetaData.InitiatingSystemVersion);
                    headers[StandardHeaderConstants.Timestamp].Should().NotBe(DateTimeOffset.MinValue.ToString(HttpClients.MetaData.DateTimeFormat));
                    headers[StandardHeaderConstants.Authorization].Should().Be($"Bearer {TokenValue}");
                }
            }
        }
    }
}
