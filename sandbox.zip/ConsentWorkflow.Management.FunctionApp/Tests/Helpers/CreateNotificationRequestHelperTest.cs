﻿using Platform.Library.Common;

namespace ConsentWorkflowMgmt.UnitTests
{
    [TestType(TestTypeEnum.UnitTest)]
    public class CreateNotificationRequestHelperTest : BaseConfigTest
    {
        public ModelModule Models => Module<ModelModule>();
        protected ContextModule Context => Module<ContextModule>();
        protected ResourceModule Resources => Module<ResourceModule>();
        protected ServiceBusModule ServiceBus => Module<ServiceBusModule>();

        public CreateNotificationRequestHelperTest(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture) { }

        protected override void TestSetup()
        {
            Context.RegisterWithMsDi(services => services.RegisterBrandResolver());
        }

        [Fact]
        public void GetNotificationCreateRequest_WhenRequestIsSuccess()
        {
            // Arrange
            Resources.ExtractManifestResource<CreateNotificationRequest>("SuccessNotification");

            // Act
            var createNotificationRequest = Context.Resolve<IBrandResolver>().GetNotificationCreateRequest(
                ConsentStatus.APPROVED.ToString().ToLowerInvariant(), 
                "123", 
                "Mr bond", 
                CommTypes.ConsentResutedCategory
            );

            // Assert
            Assert.True(Models.Compare(createNotificationRequest).Match);
        }

        [Fact]
        public void GetNotificationCreateRequest_WhenRequestIsNotSuccess()
        {
            // Arrange
            Resources.ExtractManifestResource<CreateNotificationRequest>("ErrorNotification");

            // Act
            var createNotificationRequest = Context.Resolve<IBrandResolver>().GetNotificationCreateRequest(
                ConsentStatus.APPROVED.ToString().ToLowerInvariant(),
                "123",
                "Mr bond",
                CommTypes.ConsentResutedCategory,
                false
            );

            // Assert
            Assert.True(Models.Compare(createNotificationRequest).Match);
        }
    }
}