﻿namespace ConsentWorkflowMgmt.UnitTests
{
    /// <summary>
    /// Extension methods to support <see cref="Consent"/> testing
    /// </summary>
    public static class ConsentHelper
    {
        /// <summary>
        /// Update a <see cref="Consent"/> to have the provided <paramref name="status"/>
        /// </summary>
        /// <param name="consent"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        public static Consent WithStatus(this Consent consent, ConsentStatus status)
        {
            consent.Status = status.ToString();
            return consent;
        }

        /// <summary>
        /// A default <see cref="Consent"/> to use for testing
        /// </summary>
        public static Consent DefaultConsent => new Consent
        {
            ConsentId = "123",
            Parties = new List<OdsSubModels.PartyConsent>
                {
                    new OdsSubModels.PartyConsent
                    {
                        CustomerId = "456",
                        Role = OdsConsentEnums.ConsentCustomerRole.REQUESTOR,
                        Response = OdsConsentEnums.ConsentResponseStatus.PENDING
                    }
                },
            ExpiryDateTime = DateTime.UtcNow.AddDays(-1)
        };
    }
}