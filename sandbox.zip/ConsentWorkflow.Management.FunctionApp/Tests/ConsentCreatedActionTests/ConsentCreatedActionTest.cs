using AutoMapper;
using Denovo.Library.Account.Extensions;
using Library.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Extensions.Caching.Memory;
using Platform.Library.Common;
using Platform.Library.Communication.Extensions;
using Platform.Library.Http;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.DependencyInjection;
using Platform.Library.T24.SDK.Mappers;
using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;
using Platform.Library.T24.SDK.Modules.Customer.ResponseDtos;
using Platform.Library.T24.SDK.Modules.Lookup.ResponseDtos;
using Platform.Library.T24.SDK.Modules.Scheduled.ResponseDtos;

namespace ConsentWorkflowMgmt.UnitTests.Actions
{
    [TestType(TestTypeEnum.UnitTest)]
    public class ConsentCreatedActionTest : BaseConfigTest
    { 
        private IBaseEvent<Ev32CommunicationPreparedPayload> preparedE32Event = null;

        protected ContextModule Context => Module<ContextModule>();
        protected ResourceModule Resources => Module<ResourceModule>();
        protected ServiceBusModule ServiceBus => Module<ServiceBusModule>();

        public ConsentCreatedActionTest(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {
        }

        protected override void TestSetup()
        {
            base.TestSetup();

            // Types
            Context.RegisterTypeAsInterfaces<Settings>();
            Context.RegisterTypeAsInterfaces<BpaySettings>();
            Context.RegisterTypeAsInterfaces<HomeLoansMgmtSettings>();
            Context.RegisterTypeAsInterfaces<DirectDebitSettings>();
            Context.RegisterTypeAsInterfaces<HomeLoansRepaymentsSettings>();
            Context.RegisterTypeAsInterfaces<PaymentInitiationSettings>();
            Context.RegisterInstanceAsInterface<MemoryCache, IMemoryCache>(new MemoryCache(new MemoryCacheOptions()));
            Context.RegisterTypeAsInterfaces<ConsentCreatedAction<EV68ConsentCreatedEvent>>();
            Context.RegisterTypeAsInterfaces<Settings>();
            Context.RegisterTypeAsInterfaces<DenovoAccountHelper>();

            // Delayed registration
            Context.RegisterWithMsDi(services =>
            {
                services.RegisterLibrary<Startup>()
                        .RegisterT24Sdk(
                            true,
                            null,
                            ConsentWorkflowManagementFunctionApp.Constants.Configuration.FunctionApp
                        );
                services.RegisterBrandResolver();
                services.RegisterApplicationDependencies()
                        .RegisterHttpClients()
                        .RegisterActionHandlers()
                        .RegisterAutoMapperProfiles();
            });

            // Mocks
            Context.RegisterMockAsInterface<IMessageReceiver>(SetupMessageReceiver);
            Context.RegisterMockAsInterface<IServiceBusEventPublisher>(SetupServiceBusEventPublisher);
            Context.RegisterMockAsInterface<IOdsConsentsRepository>(SetupOdsConsentsRepository);
            Context.RegisterMockAsInterface<IAzureServiceTokenProviderClient>(SetupAzureServiceProviderClient);
        }

        private void SetupOdsConsentsRepository(Mock<IOdsConsentsRepository> mock)
        {
            mock.Setup(o => o.AddAsync(It.IsAny<Consent>(), It.IsAny<string>()))
                .ReturnsAsync((Consent c, string pk) => { return OdsRepositoryMockResponse.Invoke(); });
        }

        private void SetupAzureServiceProviderClient(Mock<IAzureServiceTokenProviderClient> azureServiceProviderClient)
        {
            azureServiceProviderClient.Setup(a => a.GetAccessTokenAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>()))
                .ReturnsAsync("sampletoken");
        }

        private Func<Consent> OdsRepositoryMockResponse { get; set; } = () => null;

        private void SetupServiceBusEventPublisher(Mock<IServiceBusEventPublisher> serviceBusEventPublisher)
        {
            serviceBusEventPublisher.Setup(x => x.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV32CommunicationPreparedEvent>(), It.IsAny<IEnumerable<(string Name, object Value)>>()))
                .ReturnsAsync(true)
                .Callback<string, IBaseEvent<Ev32CommunicationPreparedPayload>, IEnumerable<(string, object)>>((topicName, preparedEvent, additionalProperties) => preparedE32Event = preparedEvent);
        }

        private void SetupMessageReceiver(Mock<IMessageReceiver> mock)
        {
            mock.Setup(x => x.DeadLetterAsync(It.IsAny<string>(), It.IsAny<IDictionary<string, object>>()))
                .Verifiable();

            mock.Setup(x => x.CompleteAsync(It.IsAny<string>()))
                .Returns(Task.CompletedTask)
                .Verifiable();
        }

        [ModuleInit(nameof(InitHttpModule))] protected HttpModule Http => Module<HttpModule>();
        private void InitHttpModule()
        {
            Http.HandleMockRequestEvent += HttpModule_HandleMockRequestEvent;
        }

        private void HttpModule_HandleMockRequestEvent(object sender, HttpRequestEventArgs args)
        {
            switch (args.ClientName)
            {
                case T24SdkConstants.HttpClient.T24:
                    if (args.RequestPath.AbsolutePath.Contains("transfers/scheduled"))
                    {
                        var arrangementId = args.RequestPath.ParseQueryString().Get("arrangementId");

                        switch (arrangementId)
                        {
                            case "AA36897FX":
                                args.SetResponse(HttpStatusCode.OK, Resources.ExtractManifestResource<T24StandingOrderResponseDto>("GetAccountDetails"), null);
                                break;
                            case "II36897FX":
                                args.SetResponse(HttpStatusCode.OK, Resources.ExtractManifestResource<T24StandingOrderResponseDto>("GetInstitutions"), null);
                                break;
                            case "BB36897FX":
                                args.SetResponse(HttpStatusCode.OK, Resources.ExtractManifestResource<T24StandingOrderResponseDto>("GetBpayBiller"), null);
                                break;
                            case "BB36897FE":
                                args.SetResponse(HttpStatusCode.OK, Resources.ExtractManifestResource<T24StandingOrderResponseDto>("GetBpayBiller.Error"), null);
                                break;
                        }
                    }
                    else if ( args.RequestPath.AbsolutePath.Contains("institutionName"))
                        args.SetResponse(HttpStatusCode.OK, Resources.ExtractManifestResource<T24InstitutionsNameResponseDto>("Success"), null);
                    else if ( args.RequestPath.AbsolutePath.Contains("getAccountDetails"))
                        args.SetResponse(HttpStatusCode.OK, Resources.ExtractManifestResource<T24AccountDetailResponseDto>("Success"), null);
                    else
                        args.SetResponse(HttpStatusCode.OK, Resources.ExtractManifestResource<T24GetCustomerProfileResponseDto>("1400005434"), null);
                    return;
                case HttpClients.NotificationCentre:
                    var reqBody = args.RequestMessage.Content?.ReadAsStringAsync().Result;
                    var customerId = string.IsNullOrWhiteSpace(reqBody)
                        ? null
                        : JsonConvert.DeserializeObject<CreateNotificationRequest>(reqBody).CustomerId;


                    if (args.Method == HttpMethod.Post)
                    {

                        if (customerId == "1400005434" || customerId == "1400009283")
                        {
                            args.SetResponse(HttpStatusCode.OK, true, new Dictionary<string, string>());
                        }
                        else
                        {
                            args.SetResponse(HttpStatusCode.InternalServerError, new Dictionary<string, string>());
                        }
                        return;
                    }
                    break;
                case HttpClients.Bpay:
                    if (args.Method == HttpMethod.Get)
                    {
                        var billerId = args.RequestPath.Segments.LastOrDefault();
                     
                        if (billerId == "98765432")
                        {
                            args.SetResponse(HttpStatusCode.OK, Resources.ExtractManifestResource<BpayBillerCodeResponse>("Success"), new Dictionary<string, string>());
                        }
                        else
                        {
                            args.SetResponse(HttpStatusCode.InternalServerError, new Dictionary<string, string>());
                        }
                        return;
                    }
                    break;
            }

            throw new NotSupportedException($"[{args.ClientName}]{args.Method.ToString().ToUpper()}{args.RequestPath.AbsoluteUri} Not supported by {nameof(HttpModule_HandleMockRequestEvent)}");
        }

        public static IEnumerable<object[]> ConsentCreatedScenarios =>
            new[]
            {
                // Success
                new object[]
                {
                    "Normal",
                    new Consent(),
                    Times.Exactly(2)
                },

                // Failure
                new object[]
                {
                    "Normal",
                    null,
                    Times.Once()
                },
            };

        [Theory]
        [MemberData(nameof(ConsentCreatedScenarios))]
        public async void ConsentCreated_Mixed_CreatesComms(string scenario, Consent odsResponse, Times publishCount)
        {
            // Arrange
            OdsRepositoryMockResponse = () => { return odsResponse; };

            var msgReceiver = Context.Resolve<IMessageReceiver>();
            var message = ServiceBus.MessageToSend<EV68ConsentCreatedEvent, EV68ConsentCreatedPayload>(scenario);
            var handler = Context.Resolve<IMessageHandler<EV68ConsentCreatedEvent>>();

            // Act
            await handler.ProcessMessageAsync(message, msgReceiver, Context.Resolve<ILogger>(), new CancellationToken());

            // Assert
            Context.GetMock<IServiceBusEventPublisher>().Verify(m => m.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV32CommunicationPreparedEvent>(), It.IsAny<IEnumerable<(string Name, object Value)>>()), publishCount);
            Assert.Equal("Consent Workflow Management Communication", preparedE32Event.Payload.CommType);
        }
        
        [Theory]
        [InlineData("Scheduled.GetAccountDetails")]
        [InlineData("Scheduled.GetInstitutions")]
        [InlineData("Scheduled.GetBpayBiller")]
        [InlineData("Scheduled.GetBpayBiller.Error")]
        public async void ConsentCreated_ScheduledPayment_ConsentProcessor(string eventScenario)
        {
            // Arrange
            var msgReceiver = Context.Resolve<IMessageReceiver>();
            var message = ServiceBus.MessageToSend<EV68ConsentCreatedEvent, EV68ConsentCreatedPayload>(eventScenario);
            var handler = Context.Resolve<IMessageHandler<EV68ConsentCreatedEvent>>();

            // Act
            await handler.ProcessMessageAsync(message, msgReceiver, Context.Resolve<ILogger>(), new CancellationToken());

            // Assert
            Context.GetMock<IMessageReceiver>().Verify(m => m.CompleteAsync(It.IsAny<string>()), Times.Once);
            
        }
    }
}
