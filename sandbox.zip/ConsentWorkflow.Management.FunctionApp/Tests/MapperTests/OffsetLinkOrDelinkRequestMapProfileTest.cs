﻿using AutoMapper;
using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;

namespace ConsentWorkflowMgmt.UnitTests.Mappers
{
    [TestType(TestTypeEnum.UnitTest)]
    public class OffsetLinkOrDelinkRequestMapProfileTest : XUnitTestFixture
    {
        private ContextModule Context => Module<ContextModule>();
        private ModelModule Models => Module<ModelModule>();

        private ResourceModule Resource => Module<ResourceModule>();


        public OffsetLinkOrDelinkRequestMapProfileTest(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {
        }

        protected override void TestSetup()
        {
            Context.RegisterMapperAndProfiles(s => new OffsetLinkOrDelinkRequestMapProfile());
        }

        [Fact]
        public void TestMappingProfileIsValid()
        {
            var mapper = Context.Resolve<IMapper>();

            mapper.ConfigurationProvider.AssertConfigurationIsValid();
        }

        [Theory]
        [InlineData("AA21328V0HVY", "Link.Offset", "Link.ExpectedRequest")]
        [InlineData("AA21328V0HVY", "Delink.Offset", "Delink.ExpectedRequest")]
        public void Map_Consent_To_OffsetLinkOrDelinkRequest(string arrangementId, string requestFileName, string expectedResponseFileName)
        {
            // Arrange
            Resource.ExtractManifestResource<OffsetLinkOrDelinkRequest>(expectedResponseFileName);

            var consent = Resource.ExtractManifestResource<Consent>(requestFileName);
            var t24AccountDetailResponse = Resource.ExtractManifestResource<T24AccountDetailResponseDto>(arrangementId);
            var offsetLinkOrDelinkCompositeRequest = OffsetLinkOrDelinkCompositeRequest.Define(consent, t24AccountDetailResponse.Body.First());

            var mapper = Context.Resolve<IMapper>();

            // Act
            var offsetLinkOrDelinkRequest = mapper.Map<OffsetLinkOrDelinkRequest>(offsetLinkOrDelinkCompositeRequest);

            // Assert
            Assert.True(Models.Compare(offsetLinkOrDelinkRequest).Match);
        }
    }
}
