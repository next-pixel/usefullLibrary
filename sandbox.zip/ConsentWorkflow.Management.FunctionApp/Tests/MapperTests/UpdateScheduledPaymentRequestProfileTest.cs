﻿using AutoMapper;

namespace ConsentWorkflowMgmt.UnitTests.Mappers
{
    [TestType(TestTypeEnum.UnitTest)]
    public class UpdateScheduledPaymentRequestProfileTest : XUnitTestFixture
    {
        private ContextModule Context => Module<ContextModule>();
        private ModelModule Models => Module<ModelModule>();

        private ResourceModule Resource => Module<ResourceModule>();


        public UpdateScheduledPaymentRequestProfileTest(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {
        }

        protected override void TestSetup()
        {
            Context.RegisterMapperAndProfiles(s => new UpdateScheduledPaymentMapProfile());
        }

        [Fact]
        public void TestMappingProfileIsValid()
        {
            var mapper = Context.Resolve<IMapper>();

            mapper.ConfigurationProvider.AssertConfigurationIsValid();
        }

        [Theory]
        [InlineData("UpdateScheduledPaymentRequestNoOfTransfers.Approved", "ExpectedRequest")]
        public void Map_Consent_To_UpdateScheduledPaymentsRequest(string requestDetails, string expectedRequest)
        {
            // Arrange
            var consent = Resource.ExtractManifestResource<Consent>(requestDetails);
            Resource.ExtractManifestResource<UpdateScheduledPaymentsRequest>(expectedRequest);

            var mapper = Context.Resolve<IMapper>();

            // Act
            var updateScheduledPaymentsRequest = mapper.Map<UpdateScheduledPaymentsRequest>(consent);

            // Assert
            Assert.True(Models.Compare(updateScheduledPaymentsRequest).Match);
        }
    }
}
