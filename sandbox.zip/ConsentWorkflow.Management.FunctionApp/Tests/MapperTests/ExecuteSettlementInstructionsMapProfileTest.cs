﻿using AutoMapper;

namespace ConsentWorkflowMgmt.UnitTests.Mappers
{
    [TestType(TestTypeEnum.UnitTest)]
    public class ExecuteSettlementInstructionsMapProfileTest : XUnitTestFixture
    {
        private ContextModule Context => Module<ContextModule>();
        private ModelModule Models => Module<ModelModule>();

        private ResourceModule Resource => Module<ResourceModule>();


        public ExecuteSettlementInstructionsMapProfileTest(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {
        }

        protected override void TestSetup()
        {
            Context.RegisterMapperAndProfiles(s => new ExecuteSettlementInstructionsMapProfile());
        }

        [Fact]
        public void TestMappingProfileIsValid()
        {
            var mapper = Context.Resolve<IMapper>();

            mapper.ConfigurationProvider.AssertConfigurationIsValid();
        }

        [Fact]
        public void Map_Consent_To_ExecuteSettlementInstructionsRequest()
        {
            // Arrange
            var consent = Resource.ExtractManifestResource<Consent>("ExecuteSettlementInstructionsRequest.Int.Approved");
            Resource.ExtractManifestResource<ExecuteSettlementInstructionsRequest>("ExpectedRequest");

            var mapper = Context.Resolve<IMapper>();

            // Act
            var executeSettlementInstructionsRequest = mapper.Map<ExecuteSettlementInstructionsRequest>(consent);

            // Assert
            Assert.True(Models.Compare(executeSettlementInstructionsRequest).Match);
        }
    }
}
