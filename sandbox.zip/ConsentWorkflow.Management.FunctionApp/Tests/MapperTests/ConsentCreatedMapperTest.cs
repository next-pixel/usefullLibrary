﻿using System.Runtime.InteropServices;
using AutoMapper;
using FluentAssertions;
using Platform.Library.Events.Models.Enum;
using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;
using Platform.Library.T24.SDK.Modules.Lookup.ResponseDtos;
using Platform.Library.T24.SDK.Modules.Scheduled.ResponseDtos;

namespace ConsentWorkflowMgmt.UnitTests.Mappers
{
    [TestType(TestTypeEnum.UnitTest)]
    public class ConsentCreatedMapperTest : XUnitTestFixture
    {
        private ResourceModule Resource => Module<ResourceModule>();

        public ConsentCreatedMapperTest(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {
        }

        protected ContextModule Context => Module<ContextModule>(); 
        public ModelModule Models => Module<ModelModule>();

        protected override void TestSetup()
        {
            Context.RegisterMapperAndProfiles(s => new ConsentCreatedRequestMapProfile());
        }

        [Fact]
        public void TestMappingProfileIsValid()
        {
            var mapper = Context.Resolve<IMapper>();

            mapper.ConfigurationProvider.AssertConfigurationIsValid();
        }

        [Theory]
        [InlineData("Normal.Mapping", "NormalMappingExpected")]
        [InlineData("RequiredFieldsOnly", "RequiredFieldsOnlyExpected")]
        public void Map_EV68ConsentCreated_To_ConsentCreatedRequest_Normal(string scenario, string expected)
        {
            // Arrange
            Resource.ExtractManifestResource<Consent>(expected);
            var messageContent = Resource.ExtractManifestResource<EV68ConsentCreatedEvent>(scenario);
            var compositeMessage = new ConsentCreatedComposite
            {
                Payload = messageContent.Payload
            };

            var mapper = Context.Resolve<IMapper>();

            // Act
            var consent = mapper.Map<Consent>(compositeMessage);
 
            // Assert
            Models.Compare(consent).Match.Should().BeTrue();;
        }

        [Theory]
        [InlineData("Normal.Mapping", "GetAccountDetails", "ScheduledExpected")]
        [InlineData("Scheduled.WeeklyFrequency", "GetAccountDetails.Weekly", "WeeklyExpected")]
        [InlineData("Scheduled.FortnightlyFrequency", "GetAccountDetails.Fortnightly", "FortnightlyExpected")]
        [InlineData("Scheduled.DailyFrequency", "GetAccountDetails.Daily", "DailyExpected")]
        public void Map_EV68ConsentCreated_To_ConsentCreatedRequest_ScheduledPayment(string payloadType, string storderResponse, string result)
        {
            // Arrange
            Resource.ExtractManifestResource<Consent>(result);
            var messageContent = Resource.ExtractManifestResource<EV68ConsentCreatedEvent>(payloadType);
            var compositeMessage = new ConsentCreatedComposite
            {
                Payload = messageContent.Payload,
                StandingOrderResponse = Resource.ExtractManifestResource<T24StandingOrderResponseDto>(storderResponse),
                GetInstitutionResponse = Resource.ExtractManifestResource<T24InstitutionsNameResponseDto>("Success"),
                AccountDetailsResponse = Resource.ExtractManifestResource<T24AccountDetailResponseDto>("Success"),
                BpayBillerCodeResponse = Resource.ExtractManifestResource<BpayBillerCodeResponse>("Success")
            };

            var mapper = Context.Resolve<IMapper>();

            // Act
            var consent = mapper.Map<Consent>(compositeMessage);
 
            // Assert
            Models.Compare(consent).Match.Should().BeTrue();
        }

        [Fact]
        public void Map_PaymentTypeEnum_InvalidValue()
        {
            //arrange
            ConsentPaymentTypeEnum enumConsent = ConsentPaymentTypeEnum._Unknown;
            //act
            Action act = () => { enumConsent.Convert(); };
            
            //assert
            act.Should().Throw<NotSupportedException>();
        }
        
        [Fact]
        public void Map_EV68ConsentCreated_NoParties_MappingFails()
        {
            //arrange
            var messageContent = Resource.ExtractManifestResource<EV68ConsentCreatedEvent>("NoParties");
            var compositeMessage = new ConsentCreatedComposite
            {
                Payload = messageContent.Payload
            };
            
            var mapper = Context.Resolve<IMapper>();

            //act
            Action act = () => { mapper.Map<Consent>(compositeMessage); };
            
            //assert
            act.Should().Throw<AutoMapperMappingException>();
        }
        
        [Theory]
        [InlineData("invalid")]
        [InlineData(null)]
        public void Map_PaymentOrderProduct_InvalidValue(string productValue)
        {
            //arrange
            string product = productValue;
            //act
            Action act = () => { product.ConvertToOdsPaymentType(); };
            
            //assert
            act.Should().Throw<NotSupportedException>();
        }
    }
}
