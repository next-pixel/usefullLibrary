﻿using AutoMapper;

namespace ConsentWorkflowMgmt.UnitTests.Mappers
{
    [TestType(TestTypeEnum.UnitTest)]
    public class ActiveDirectDebitCreateRequestMapProfileTest : XUnitTestFixture
    {
        private ContextModule Context => Module<ContextModule>();
        private ModelModule Models => Module<ModelModule>();

        private ResourceModule Resource => Module<ResourceModule>();


        public ActiveDirectDebitCreateRequestMapProfileTest(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {
        }

        protected override void TestSetup()
        {
            Context.RegisterMapperAndProfiles(s => new ActiveDirectDebitCreateRequestMapProfile());
        }

        [Fact]
        public void TestMappingProfileIsValid()
        {
            var mapper = Context.Resolve<IMapper>();

            mapper.ConfigurationProvider.AssertConfigurationIsValid();
        }

        [Fact]
        public void Map_Consent_To_ActiveDirectDebitCreateRequest()
        {
            // Arrange
            var consent = Resource.ExtractManifestResource<Consent>("ActiveDirectDebitCreateRequest.Approved");
            Resource.ExtractManifestResource<ActiveDirectDebitCreateRequest>("ExpectedRequest");

            var mapper = Context.Resolve<IMapper>();

            // Act
            var activeDirectDebitCreateRequest = mapper.Map<ActiveDirectDebitCreateRequest>(consent);

            // Assert
            Assert.True(Models.Compare(activeDirectDebitCreateRequest).Match);
        }
    }
}
