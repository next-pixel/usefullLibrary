﻿using AutoMapper;

namespace ConsentWorkflowMgmt.UnitTests.Mappers
{
    [TestType(TestTypeEnum.UnitTest)]
    public class InitiatePaymentRequestMapProfileTest : XUnitTestFixture
    {
        private ContextModule Context => Module<ContextModule>();
        private ModelModule Models => Module<ModelModule>();

        private ResourceModule Resource => Module<ResourceModule>();


        public InitiatePaymentRequestMapProfileTest(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {
        }

        protected override void TestSetup()
        {
            Context.RegisterMapperAndProfiles(s => new InitiatePaymentRequestMapProfile());
        }

        [Fact]
        public void TestMappingProfileIsValid()
        {
            var mapper = Context.Resolve<IMapper>();

            mapper.ConfigurationProvider.AssertConfigurationIsValid();
        }

        [Fact]
        public void Map_Consent_To_InitiatePaymentRequest()
        {
            // Arrange
            var consent = Resource.ExtractManifestResource<Consent>("Payment.Approved");
            Resource.ExtractManifestResource<InitiatePaymentRequest>("ExpectedRequest");

            var mapper = Context.Resolve<IMapper>();

            // Act
            var initiatePaymentRequest = mapper.Map<InitiatePaymentRequest>(consent);

            // Assert
            Assert.True(Models.Compare(initiatePaymentRequest).Match);
        }
    }
}
