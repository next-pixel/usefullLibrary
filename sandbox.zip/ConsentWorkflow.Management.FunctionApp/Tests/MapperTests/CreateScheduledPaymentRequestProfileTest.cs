﻿using AutoMapper;

namespace ConsentWorkflowMgmt.UnitTests.Mappers
{
    [TestType(TestTypeEnum.UnitTest)]
    public class CreateScheduledPaymentRequestProfileTest : XUnitTestFixture
    {
        private ContextModule Context => Module<ContextModule>();
        private ModelModule Models => Module<ModelModule>();

        private ResourceModule Resource => Module<ResourceModule>();


        public CreateScheduledPaymentRequestProfileTest(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {
        }

        protected override void TestSetup()
        {
            Context.RegisterMapperAndProfiles(s => new CreateScheduledPaymentMapProfile());
        }

        [Fact]
        public void TestMappingProfileIsValid()
        {
            var mapper = Context.Resolve<IMapper>();

            mapper.ConfigurationProvider.AssertConfigurationIsValid();
        }

        [Theory]
        [InlineData("MappingDetails", "ExpectedRequest")]
        public void Map_Consent_To_CreateScheduledPaymentsRequest(string requestDetails, string expectedRequest)
        {
            // Arrange
            var createScheduledPaymentDetails = Resource.ExtractManifestResource<CreateScheduledPaymentDetails>(requestDetails);
            Resource.ExtractManifestResource<CreateScheduledPaymentsRequest>(expectedRequest);

            var mapper = Context.Resolve<IMapper>();

            // Act
            var createScheduledPaymentsRequest = mapper.Map<CreateScheduledPaymentsRequest>((createScheduledPaymentDetails));

            // Assert
            Assert.True(Models.Compare(createScheduledPaymentsRequest).Match);
        }
    }
}
