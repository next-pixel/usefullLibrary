﻿using System.Linq.Expressions;
using Library.Azure.ServiceBus;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.ServiceBus.Core;
using Platform.Library.Common;
using Platform.Library.Communication.Extensions;
using Platform.Library.Http;
using Platform.Library.T24.SDK.DependencyInjection;

namespace ConsentWorkflowMgmt.UnitTests.Actions
{
    [TestType(TestTypeEnum.UnitTest)]
    public class ConsentUpdateActionTest : XUnitTestFixture
    {
        private ContextModule Context => Module<ContextModule>();
        private ResourceModule Resources => Module<ResourceModule>();
        private ServiceBusModule ServiceBus => Module<ServiceBusModule>();
        
        public ConsentUpdateActionTest(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {

        }

        protected override void TestSetup()
        {
            base.TestSetup();
            
            Context.RegisterWithMsDi(services =>
            {
                services.RegisterT24Sdk(true, null, Configuration.FunctionApp);
                
                services.RegisterBrandResolver();

                services
                    .RegisterApplicationDependencies()
                    .RegisterHttpClients()
                    .RegisterActionHandlers();
            });
            
            Context.RegisterMockAsInterface<IMessageReceiver>(SetupMessageReceiver);
            Context.RegisterMockAsInterface<IServiceBusEventPublisher>(SetupServiceBusEventPublisher);
            Context.RegisterMockAsInterface<IOdsConsentsRepository>(SetupOdsConsentsRepository);
            Context.RegisterMockAsInterface<IAzureServiceTokenProviderClient>(SetupAzureServiceProviderClient);

            Context.RegisterTypeAsInterfaces<Settings>();
            Context.RegisterTypeAsInterfaces<CommunicationMapper>();
            Context.RegisterTypeAsInterfaces<ConsentUpdatedAction<EV69ConsentUpdatedEvent>>();
            
        }
        
        private void SetupMessageReceiver(Mock<IMessageReceiver> mock)
        {
            mock.Setup(x => x.DeadLetterAsync(It.IsAny<string>(), It.IsAny<IDictionary<string, object>>()))
                .Verifiable();

            mock.Setup(x => x.CompleteAsync(It.IsAny<string>()))
                .Returns(Task.CompletedTask)
                .Verifiable();
        }
        
        private void SetupOdsConsentsRepository(Mock<IOdsConsentsRepository> odsConsentsRepository)
        {
            odsConsentsRepository.Setup(o => o.SearchOdsForEntitiesAsync(It.IsAny<Expression<Func<Consent, bool>>>(), It.IsAny<FeedOptions>()))
                .ReturnsAsync((Expression<Func<Consent,bool>> expr, FeedOptions feed) => { return OdsConsentRepositoryResponse.Invoke(); });

            odsConsentsRepository
                .Setup(o => o.UpdateAsync(It.IsAny<Consent>()));
        }
        
        private Func<List<Consent>> OdsConsentRepositoryResponse { get; set; } = () => { return null; };

        private void SetupServiceBusEventPublisher(Mock<IServiceBusEventPublisher> serviceBusEventPublisher)
        {
            serviceBusEventPublisher.Setup(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV70ConsentResulted>(), null))
                .ReturnsAsync(true);
        }
        
        private void SetupAzureServiceProviderClient(Mock<IAzureServiceTokenProviderClient> azureServiceProviderClient)
        {
            azureServiceProviderClient.Setup(a => a.GetAccessTokenAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>()))
                .ReturnsAsync("sampletoken");
        }
        
        public static IEnumerable<object[]> ConsentUpdatedScenarios =>
            new[]
            {
                new object[]
                {
                    "Approver.Approved",
                    Times.Once()
                },
                new object[]
                {
                    "Approver.Declined",
                    Times.Once()
                },
                new object[]
                {
                    "Requestor.Cancelled",
                    Times.Once()
                },
            };

        [Theory]
        [MemberData(nameof(ConsentUpdatedScenarios))]
        public async void ConsentUpdatedAction(string scenario, Times publishCount)
        {
            //Arrange
            OdsConsentRepositoryResponse = () => new[] { Resources.ExtractManifestResource<Consent>(scenario) }.ToList();

            var msgReceiver = Context.Resolve<IMessageReceiver>();
            var message = ServiceBus.MessageToSend<EV69ConsentUpdatedEvent, EV69ConsentUpdatedPayload>(scenario);
            var handlerAction = Context.Resolve<IMessageHandler<EV69ConsentUpdatedEvent>>();
            
            //Act
            await handlerAction.ProcessMessageAsync(message, msgReceiver, Context.Resolve<ILogger>(), CancellationToken.None);
            
            //Assert
            Context.GetMock<IServiceBusEventPublisher>().Verify(m => m.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV70ConsentResulted>(), It.IsAny<IEnumerable<(string Name, object Value)>>()), publishCount);
            Context.GetMock<IMessageReceiver>().Verify(m => m.CompleteAsync(It.IsAny<string>()), Times.Once);
        }
    }
}
