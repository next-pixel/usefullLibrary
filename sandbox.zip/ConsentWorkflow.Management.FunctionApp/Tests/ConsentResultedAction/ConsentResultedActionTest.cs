using AutoMapper;
using Library.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using Platform.Library.Communication.Extensions;
using Platform.Library.Http;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;
using Platform.Library.T24.SDK.Modules.Customer.ResponseDtos;
using System.Linq.Expressions;

namespace ConsentWorkflowMgmt.UnitTests.Actions
{
    [TestType(TestTypeEnum.UnitTest)]
    public class ConsentResultedActionTest : BaseConfigTest
    {
        protected ContextModule Context => Module<ContextModule>();
        protected ResourceModule Resources => Module<ResourceModule>();
        protected ServiceBusModule ServiceBus => Module<ServiceBusModule>();

        public ConsentResultedActionTest(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {
        }

        protected override void TestSetup()
        {
            base.TestSetup();

            Context.RegisterWithMsDi(services =>
            {
                services.RegisterServices();
                services.RegisterAutoMapperProfiles();
            });

            Context.RegisterMockAsInterface<IMessageReceiver>(SetupMessageReceiver);
            Context.RegisterMockAsInterface<IServiceBusEventPublisher>(SetupServiceBusEventPublisher);
            Context.RegisterMockAsInterface<IOdsConsentsRepository>(SetupOdsConsentsRepository);
            Context.RegisterMockAsInterface<IAzureServiceTokenProviderClient>(SetupAzureServiceProviderClient);

            Context.RegisterTypeAsInterfaces<Settings>();
        }

        private void SetupServiceBusEventPublisher(Mock<IServiceBusEventPublisher> serviceBusEventPublisher)
        {
            serviceBusEventPublisher.Setup(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV32CommunicationPreparedEvent>(), null))
                .ReturnsAsync(true);

            serviceBusEventPublisher.Setup(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV52CancelDirectDebitEvent>(), null))
              .ReturnsAsync(true);
        }

        private void SetupAzureServiceProviderClient(Mock<IAzureServiceTokenProviderClient> azureServiceProviderClient)
        {
            azureServiceProviderClient.Setup(a => a.GetAccessTokenAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>()))
                .ReturnsAsync("sampletoken");
        }

        private void SetupOdsConsentsRepository(Mock<IOdsConsentsRepository> mock)
        {
            mock.Setup(o => o.AddAsync(It.IsAny<Consent>(), It.IsAny<string>()))
                .ReturnsAsync((Consent c, string pk) => OdsRepositoryAddResponse.Invoke());

            mock.Setup(o => o.SearchOdsForEntitiesAsync(It.IsAny<Expression<Func<Consent,bool>>>(), It.IsAny<Microsoft.Azure.Documents.Client.FeedOptions>()))
                .ReturnsAsync((Expression<Func<Consent,bool>> expr, Microsoft.Azure.Documents.Client.FeedOptions feed) => OdsRepositoryResponse.Invoke());
        }

        private Func<Consent> OdsRepositoryAddResponse { get; set; } = () => { return null; };

        private Func<List<Consent>> OdsRepositoryResponse { get; set; } = () => { return null; };

        private Func<IEnumerable<string>> HttpClientsCausingExceptions { get; set; } = () => { return Enumerable.Empty<string>(); };

        private void SetupMessageReceiver(Mock<IMessageReceiver> mock)
        {
            mock.Setup(x => x.DeadLetterAsync(It.IsAny<string>(), It.IsAny<IDictionary<string, object>>()))
                .Verifiable();

            mock.Setup(x => x.CompleteAsync(It.IsAny<string>()))
                .Returns(Task.CompletedTask)
                .Verifiable();
        }

        [ModuleInit(nameof(InitHttpModule))] protected HttpModule Http => Module<HttpModule>();
        private void InitHttpModule()
        {
            Http.HandleMockRequestEvent += HttpModule_HandleMockRequestEvent;
        }

        private void HttpModule_HandleMockRequestEvent(object sender, HttpRequestEventArgs args)
        {
            if (HttpClientsCausingExceptions.Invoke().ContainsIgnoreCase(args.ClientName))
                throw new Exception("Test Exception");

            var reqBody = args.RequestMessage.Content?.ReadAsStringAsync().Result;
            var httpMethod = args.Method;

            switch (args.ClientName)
            {
                case T24SdkConstants.HttpClient.T24:
                    if ( args.RequestPath.AbsolutePath.Contains("getAccountDetails"))
                        args.SetResponse(HttpStatusCode.OK, new T24AccountDetailResponseDto { Body = new List<T24AccountDetailBody> { new T24AccountDetailBody { AvailableBalance = "450", } } }, null);
                    else
                        args.SetResponse(HttpStatusCode.OK, new T24GetCustomerProfileResponseDto { Body = new GetCustomerProfileBody { GivenName = "Mr bond" } }, null);

                    return;
                case HttpClients.PaymentInitiation:
                    SetupInitiatePaymentMockServer(args, reqBody);
                    return;
                case HttpClients.HomeLoanMgmtApi:
                    SetupHomeLoanManagementMockServer(args, reqBody);
                    return;
                case HttpClients.HomeLoanRepaymentsApi:
                    SetupHomeLoanRepaymentMockServer(args, reqBody);
                    return;
                case HttpClients.DirectDebitApi:
                    SetupDirectDebitMockServer(args, reqBody);
                    return;
                case HttpClients.NotificationCentre:
                    SetupNotificationCenterMockServer(args, reqBody);
                    return;
                case HttpClients.ScheduledPaymentsApi:
                    SetupScheduledPaymentsMockServer(args, reqBody);
                    return;
            }

            throw new NotSupportedException($"[{args.ClientName}]{args.Method.ToString().ToUpper()}{args.RequestPath.AbsoluteUri} Not supported by {nameof(HttpModule_HandleMockRequestEvent)}");
        }

        private void SetupDirectDebitMockServer(HttpRequestEventArgs args, string reqBody)
        {
            var activeDirectDebitCreateRequest = reqBody.Deserialize<ActiveDirectDebitCreateRequest>();

            if (args.Method == HttpMethod.Post)
            {
                if (activeDirectDebitCreateRequest.DirectDebitId == "1996567539.1")
                {
                    args.SetResponse(
                        HttpStatusCode.OK,
                        true,
                        new Dictionary<string, string>());
                }
                else
                {
                    args.SetResponse(HttpStatusCode.BadRequest, new Dictionary<string, string>());
                }
            }
            else
                throw new NotSupportedException($"{nameof(SetupDirectDebitMockServer)} does not support {args.Method} call to {args.RequestPath.AbsoluteUri}");
        }

        private void SetupScheduledPaymentsMockServer(HttpRequestEventArgs args, string reqBody)
        {
            if (InteractionAndSessionIdHeaderNotFound(args))
            {
                args.SetResponse(HttpStatusCode.InternalServerError, new Dictionary<string, string>());
                return;
            }

            if (args.Method == HttpMethod.Post)
            {
                var createScheduledPaymentsRequest = reqBody.Deserialize<CreateScheduledPaymentsRequest>();
                var path = args.RequestMessage.RequestUri.AbsolutePath;

                if (createScheduledPaymentsRequest != null && createScheduledPaymentsRequest.Amount != 2000 && path.Contains("scheduled"))
                {
                    args.SetResponse(
                        HttpStatusCode.OK,
                        true,
                        new Dictionary<string, string>());
                }
                else
                {
                    args.SetResponse(HttpStatusCode.BadRequest, new Dictionary<string, string>());
                }

            }
            else if (args.Method == HttpMethod.Put)
            {
                var updateScheduledPaymentsRequest = reqBody.Deserialize<UpdateScheduledPaymentsRequest>();
                var path = args.RequestMessage.RequestUri.AbsolutePath;

                if (updateScheduledPaymentsRequest != null && updateScheduledPaymentsRequest.Amount == 1212 && path.Contains("scheduled/21332122"))
                {
                    args.SetResponse(
                        HttpStatusCode.OK,
                        true,
                        new Dictionary<string, string>());
                }
                else
                {
                    args.SetResponse(HttpStatusCode.BadRequest, new Dictionary<string, string>());
                }
            }
            else if (args.Method == HttpMethod.Delete)
            {
                var path = args.RequestMessage.RequestUri.AbsolutePath;

                if (reqBody == null && path.Contains("scheduled/213321"))
                {
                    args.SetResponse(
                        HttpStatusCode.OK,
                        true,
                        new Dictionary<string, string>());
                }
                else
                {
                    args.SetResponse(HttpStatusCode.BadRequest, new Dictionary<string, string>());
                }
            }
            else
                throw new NotSupportedException($"{nameof(SetupScheduledPaymentsMockServer)} does not support {args.Method} call to {args.RequestPath.AbsoluteUri}");
        }

        private static bool InteractionAndSessionIdHeaderNotFound(HttpRequestEventArgs args)
        {
            args.RequestMessage.Headers.TryGetValues(ConsentWorkflowManagementFunctionApp.Constants.CustomHeaders.InteractionId, out var interactionIds);
            args.RequestMessage.Headers.TryGetValues(ConsentWorkflowManagementFunctionApp.Constants.CustomHeaders.SessionId, out var sessionIds);

            if (!interactionIds.Any() || !interactionIds.Any())
            {
                return true;
            }

            return false;
        }

        private static void SetupNotificationCenterMockServer(HttpRequestEventArgs args, string reqBody)
        {
            var notificationCreateRequest = reqBody.Deserialize<CreateNotificationRequest>();
            if (args.Method == HttpMethod.Post)
            {
                if (notificationCreateRequest.CustomerId == "1300051580" || notificationCreateRequest.CustomerId == "1")
                {
                    args.SetResponse(
                        HttpStatusCode.OK,
                        true,
                        new Dictionary<string, string>());
                }
                else
                {
                    args.SetResponse(HttpStatusCode.BadRequest, new Dictionary<string, string>());
                }
            }
            else
                throw new NotSupportedException($"{nameof(SetupNotificationCenterMockServer)} does not support {args.Method} call to {args.RequestPath.AbsoluteUri}");
        }

        private static void SetupHomeLoanRepaymentMockServer(HttpRequestEventArgs args, string reqBody)
        {
            var executeSettlementInstructionsRequest = reqBody.Deserialize<ExecuteSettlementInstructionsRequest>();

            if (args.Method == HttpMethod.Post)
            {
                if (executeSettlementInstructionsRequest.ConsentDetails.ConsentId == "7")
                {
                    args.SetResponse(
                        HttpStatusCode.OK,
                        true,
                        new Dictionary<string, string>());
                }
                else
                {
                    args.SetResponse(HttpStatusCode.BadRequest, new Dictionary<string, string>());
                }
            }
            else
                throw new NotSupportedException($"{nameof(SetupHomeLoanRepaymentMockServer)} does not support {args.Method} call to {args.RequestPath.AbsoluteUri}");
        }

        private static void SetupHomeLoanManagementMockServer(HttpRequestEventArgs args, string reqBody)
        {
            var offsetLinkOrDelinkRequest = reqBody.Deserialize<OffsetLinkOrDelinkRequest>();

            if (args.Method == HttpMethod.Patch)
            {
                if (offsetLinkOrDelinkRequest.ConsentDetails.ConsentId == "8")
                {
                    args.SetResponse(
                        HttpStatusCode.OK,
                        true,
                        new Dictionary<string, string>());
                }
                else
                {
                    args.SetResponse(HttpStatusCode.BadRequest, new Dictionary<string, string>());
                }
            }
            else
                throw new NotSupportedException($"{nameof(SetupHomeLoanManagementMockServer)} does not support {args.Method} call to {args.RequestPath.AbsoluteUri}");
        }

        private static void SetupInitiatePaymentMockServer(HttpRequestEventArgs args, string reqBody)
        {
            if (InteractionAndSessionIdHeaderNotFound(args))
            {
                args.SetResponse(HttpStatusCode.InternalServerError, new Dictionary<string, string>());
                return;
            }

            var paymentRequest = reqBody.Deserialize<InitiatePaymentRequest>();

            if (args.Method == HttpMethod.Post)
            {
                if (paymentRequest.ConsentDetails.ConsentId == "9")
                {
                    args.SetResponse(
                        HttpStatusCode.OK,
                        true,
                        new Dictionary<string, string>());
                }
                else
                {
                    args.SetResponse(HttpStatusCode.BadRequest, new Dictionary<string, string>());
                }
            }
            else
                throw new NotSupportedException($"{nameof(SetupInitiatePaymentMockServer)} does not support {args.Method} call to {args.RequestPath.AbsoluteUri}");
        }

        [Theory]
        [InlineData("Unapproved",ConsentStatus.CANCELLED)]
        [InlineData("Unapproved",ConsentStatus.EXPIRED)]
        [InlineData("Unapproved",ConsentStatus.DECLINED)]
        public async void ConsentResultedAction_UnapprovedConsentRequest_NotificationEventPublishedSuccessfully(string scenario, ConsentStatus consentStatus)
        {
            // Arrange
            OdsRepositoryResponse = () => new[] { Resources.ExtractManifestResource<Consent>("Unapproved").WithStatus(consentStatus) }.ToList();

            var handlerAction = Context.Resolve<IMessageHandler<EV70ConsentResulted>>();
            var messageReciever = Context.Resolve<IMessageReceiver>();
            var message = ServiceBus.MessageToSend<EV70ConsentResulted,EV70ConsentResultedPayload>(scenario);
            
            // Act
            await handlerAction.ProcessMessageAsync(message, messageReciever, Context.Resolve<ILogger>(), CancellationToken.None, null);

            Context.GetMock<IServiceBusEventPublisher>().Verify(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV32CommunicationPreparedEvent>(), null), Times.Exactly(4));
            Context.GetMock<IMessageReceiver>().Verify(s => s.CompleteAsync(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async void ConsentResultedAction_UnapprovedConsentRequest_NotificationCentreThrowsException()
        {
            // Arange
            OdsRepositoryResponse = () => new[] { Resources.ExtractManifestResource<Consent>("Unapproved.NotificationCentre.Exception").WithStatus(ConsentStatus.CANCELLED) }.ToList();

            var handlerAction = Context.Resolve<IMessageHandler<EV70ConsentResulted>>();
            var messageReciever = Context.Resolve<IMessageReceiver>();
            var message = ServiceBus.MessageToSend<EV70ConsentResulted,EV70ConsentResultedPayload>("Unapproved");

            // Act
            await handlerAction.ProcessMessageAsync(message, messageReciever, Context.Resolve<ILogger>(), CancellationToken.None, null);

            // Assert
            Context.GetMock<IServiceBusEventPublisher>().Verify(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV32CommunicationPreparedEvent>(), null), Times.Never);
        }

        [Theory]
        [InlineData("Payment.Approved", "Payment.Approved")]
        [InlineData("Offset.Approved", "Offset.Approved")]
        [InlineData("ExecuteSettlementInstructionsRequest.Repayment.Approved", "ExecuteSettlementInstructionsRequest.Approved")]
        [InlineData("ExecuteSettlementInstructionsRequest.Int.Approved", "ExecuteSettlementInstructionsRequest.Approved")]
        [InlineData("CreateScheduledPaymentRequestEndDate.Approved", "CreateScheduledPaymentRequest.Approved")]
        [InlineData("CreateScheduledPaymentRequestNoOfTransfers.Approved", "CreateScheduledPaymentRequest.Approved")]
        [InlineData("CreateScheduledPaymentRequest.OnlyStartDate.Approved", "CreateScheduledPaymentRequest.Approved")]
        [InlineData("UpdateScheduledPaymentRequestEndDate.Approved", "UpdateScheduledPaymentRequest.Approved")]
        [InlineData("UpdateScheduledPaymentRequestNoOfTransfers.Approved", "UpdateScheduledPaymentRequest.Approved")]
        [InlineData("DeleteScheduledPaymentRequest.Approved", "DeleteScheduledPaymentRequest.Approved")]
        public async void ConsentResultedAction_ApprovedConsentRequest_NotificationEventPublishedSuccessfully(string requestPath, string messagePath)
        {
            // Arrange
            OdsRepositoryResponse = () => new[] { Resources.ExtractManifestResource<Consent>(requestPath) }.ToList();

            var handlerAction = Context.Resolve<IMessageHandler<EV70ConsentResulted>>();
            var messageReciever = Context.Resolve<IMessageReceiver>();
            var message = ServiceBus.MessageToSend<EV70ConsentResulted, EV70ConsentResultedPayload>(messagePath);

            // Act
            await handlerAction.ProcessMessageAsync(message, messageReciever, Context.Resolve<ILogger>(), CancellationToken.None, null);

            // Assert
            Context.GetMock<IServiceBusEventPublisher>().Verify(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV32CommunicationPreparedEvent>(), null), Times.Exactly(4));
            Assert.Equal(4, Context.GetMock<IServiceBusEventPublisher>().Invocations.Count);
            Context.GetMock<IMessageReceiver>().Verify(s => s.CompleteAsync(It.IsAny<string>()), Times.Once);
            
        }

        [Theory]
        [InlineData("CreateScheduledPaymentRequest.MandatoryDetailsMissing.Approved", "CreateScheduledPaymentRequest.Approved")]
        public async void ConsentResultedAction_ApprovedConsentRequest_MandatoryFieldsMissing_NotificationNotPublished(string requestPath, string messagePath)
        {
            // Arrange
            OdsRepositoryResponse = () => new[] { Resources.ExtractManifestResource<Consent>(requestPath) }.ToList();

            var handlerAction = Context.Resolve<IMessageHandler<EV70ConsentResulted>>();
            var messageReciever = Context.Resolve<IMessageReceiver>();
            var message = ServiceBus.MessageToSend<EV70ConsentResulted, EV70ConsentResultedPayload>(messagePath);

            // Act
            await handlerAction.ProcessMessageAsync(message, messageReciever, Context.Resolve<ILogger>(), CancellationToken.None, null);

            // Assert
            Context.GetMock<IServiceBusEventPublisher>().Verify(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV32CommunicationPreparedEvent>(), null), Times.Never);
            Context.GetMock<IMessageReceiver>().Verify(s => s.DeadLetterAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Once);

        }

        [Theory]
        [InlineData("ActiveDirectDebitCreateRequest.Approved", "ExecuteSettlementInstructionsRequest.Approved",5)]      
        public async void ConsentResultedAction_ApprovedConsentRequest_NotificationEventPublishedSuccessfullyWithDirectDebit(string requestPath, string messagePath,int expectedCount)
        {
            // Arrange
            OdsRepositoryResponse = () => new[] { Resources.ExtractManifestResource<Consent>(requestPath) }.ToList();

            var handlerAction = Context.Resolve<IMessageHandler<EV70ConsentResulted>>();
            var messageReciever = Context.Resolve<IMessageReceiver>();
            var message = ServiceBus.MessageToSend<EV70ConsentResulted, EV70ConsentResultedPayload>(messagePath);

            // Act
            await handlerAction.ProcessMessageAsync(message, messageReciever, Context.Resolve<ILogger>(), CancellationToken.None, null);

            // Assert
            Context.GetMock<IServiceBusEventPublisher>().Verify(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV32CommunicationPreparedEvent>(), null), Times.Exactly(4));
            Context.GetMock<IServiceBusEventPublisher>().Verify(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV52CancelDirectDebitEvent>(), null), Times.Once);
            Assert.Equal(expectedCount, Context.GetMock<IServiceBusEventPublisher>().Invocations.Count);
            Context.GetMock<IMessageReceiver>().Verify(s => s.CompleteAsync(It.IsAny<string>()), Times.Once);

        }

        [Theory]
        [InlineData("Payment.Approved", "Payment.Approved", new[] { HttpClients.PaymentInitiation }, 2, true,1)]
        [InlineData("Offset.Approved", "Offset.Approved", new[] { HttpClients.HomeLoanMgmtApi }, 2, true,1)]
        [InlineData("ExecuteSettlementInstructionsRequest.Repayment.Approved", "ExecuteSettlementInstructionsRequest.Approved", new[] { HttpClients.HomeLoanRepaymentsApi }, 2, true,1)]
        [InlineData("ExecuteSettlementInstructionsRequest.Int.Approved", "ExecuteSettlementInstructionsRequest.Approved", new[] { HttpClients.HomeLoanRepaymentsApi }, 2, true,1)]        
        [InlineData("CreateScheduledPaymentRequestEndDate.Approved", "CreateScheduledPaymentRequest.Approved", new[] { T24SdkConstants.HttpClient.T24 }, 0, false,0)]
        [InlineData("CreateScheduledPaymentRequestNoOfTransfers.Approved", "CreateScheduledPaymentRequest.Approved", new[] { HttpClients.ScheduledPaymentsApi }, 2, true,1)]
        [InlineData("UpdateScheduledPaymentRequestEndDate.Approved", "UpdateScheduledPaymentRequest.Approved", new[] { HttpClients.ScheduledPaymentsApi }, 2, true,1)]
        [InlineData("UpdateScheduledPaymentRequestNoOfTransfers.Approved", "UpdateScheduledPaymentRequest.Approved", new[] { HttpClients.ScheduledPaymentsApi }, 2, true,1)]
        [InlineData("DeleteScheduledPaymentRequest.Approved", "DeleteScheduledPaymentRequest.Approved", new[] { HttpClients.ScheduledPaymentsApi }, 2, true,1)]
        public async void ConsentResultedAction_ApprovedConsentRequest_HttpClientCausingExceptions(string requestPath, string messagePath, string[] failingClients, int expectedInvocations, bool shouldComplete, int expectedExecutionTime)
        {
            // Arrange
            OdsRepositoryResponse = () => new[] { Resources.ExtractManifestResource<Consent>(requestPath) }.ToList();
            HttpClientsCausingExceptions = () => failingClients;

            var handlerAction = Context.Resolve<IMessageHandler<EV70ConsentResulted>>();
            var messageReciever = Context.Resolve<IMessageReceiver>();
            var message = ServiceBus.MessageToSend<EV70ConsentResulted, EV70ConsentResultedPayload>(messagePath);

            // Act
            await handlerAction.ProcessMessageAsync(message, messageReciever, Context.Resolve<ILogger>(), CancellationToken.None, null);

            // Assert
            Context.GetMock<IServiceBusEventPublisher>().Verify(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV32CommunicationPreparedEvent>(), null), Times.Exactly(expectedInvocations));
            Assert.Equal(expectedInvocations, Context.GetMock<IServiceBusEventPublisher>().Invocations.Count);
            Context.GetMock<IMessageReceiver>().Verify(s => s.CompleteAsync(It.IsAny<string>()), Times.Exactly(expectedExecutionTime));
        }


        [Theory]      
        [InlineData("ActiveDirectDebitCreateRequest.Approved", "ExecuteSettlementInstructionsRequest.Approved", new[] { HttpClients.DirectDebitApi }, 2, 3)]       
        public async void ConsentResultedAction_ApprovedConsentRequest_HttpClientCausingExceptionsWithDirectDebit(string requestPath, string messagePath, string[] failingClients, int expectedInvocations,int expectedServiceBusEevent)
        {
            // Arrange
            OdsRepositoryResponse = () => new[] { Resources.ExtractManifestResource<Consent>(requestPath) }.ToList();
            HttpClientsCausingExceptions = () => failingClients;

            var handlerAction = Context.Resolve<IMessageHandler<EV70ConsentResulted>>();
            var messageReciever = Context.Resolve<IMessageReceiver>();
            var message = ServiceBus.MessageToSend<EV70ConsentResulted, EV70ConsentResultedPayload>(messagePath);

            // Act
            await handlerAction.ProcessMessageAsync(message, messageReciever, Context.Resolve<ILogger>(), CancellationToken.None, null);

            // Assert
            Context.GetMock<IServiceBusEventPublisher>().Verify(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV32CommunicationPreparedEvent>(), null), Times.Exactly(expectedInvocations));
            Context.GetMock<IServiceBusEventPublisher>().Verify(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV52CancelDirectDebitEvent>(), null), Times.Once);
            Assert.Equal(expectedServiceBusEevent, Context.GetMock<IServiceBusEventPublisher>().Invocations.Count);
            Context.GetMock<IMessageReceiver>().Verify(s => s.CompleteAsync(It.IsAny<string>()), Times.Once);
        }

        [Theory]
        [InlineData("Payment.Approved.Error", "Payment.Approved")]
        [InlineData("Offset.Approved.Error", "Offset.Approved")]
        [InlineData("ExecuteSettlementInstructionsRequest.Repayment.Approved.Error", "ExecuteSettlementInstructionsRequest.Approved")]
        [InlineData("ExecuteSettlementInstructionsRequest.Int.Approved.Error", "ExecuteSettlementInstructionsRequest.Approved")]
        [InlineData("ActiveDirectDebitCreateRequest.Approved.Error", "ExecuteSettlementInstructionsRequest.Approved")]
        [InlineData("CreateScheduledPaymentRequest.Approved.Error", "CreateScheduledPaymentRequest.Approved")]
        [InlineData("UpdateScheduledPaymentRequest.Approved.Error", "UpdateScheduledPaymentRequest.Approved")]
        [InlineData("DeleteScheduledPaymentRequest.Approved.Error", "DeleteScheduledPaymentRequest.Approved")]
        public async void ConsentResultedAction_ApprovedConsentRequest_DownstreamApiThrowsException_PushNotificationPublished_SmsNotificationNotSuccessfully(string consentPath, string messagePath)
        {
            // Arrange
            OdsRepositoryResponse = () => new[] { Resources.ExtractManifestResource<Consent>(consentPath) }.ToList();

            var handlerAction = Context.Resolve<IMessageHandler<EV70ConsentResulted>>();
            var messageReciever = Context.Resolve<IMessageReceiver>();
            var message = ServiceBus.MessageToSend<EV70ConsentResulted, EV70ConsentResultedPayload>(messagePath);

            // Act
            await handlerAction.ProcessMessageAsync(message, messageReciever, Context.Resolve<ILogger>(), CancellationToken.None, null);

            // Assert
            Context.GetMock<IServiceBusEventPublisher>().Verify(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV32CommunicationPreparedEvent>(), null), Times.Exactly(2));            
            Context.GetMock<IMessageReceiver>().Verify(s => s.CompleteAsync(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async void ConsentResultedAction_RequestTypeInvalid_NotificationEventNotPublished()
        {
            // Arrange
            OdsRepositoryResponse = () => new[] { Resources.ExtractManifestResource<Consent>("RequestTypeInvalid") }.ToList();

            var handlerAction = Context.Resolve<IMessageHandler<EV70ConsentResulted>>();
            var messageReciever = Context.Resolve<IMessageReceiver>();
            var message = ServiceBus.MessageToSend<EV70ConsentResulted, EV70ConsentResultedPayload>("InvalidRequestType.Approved");

            // Act
            await handlerAction.ProcessMessageAsync(message, messageReciever, Context.Resolve<ILogger>(), CancellationToken.None, null);

            Context.GetMock<IServiceBusEventPublisher>().Verify(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV32CommunicationPreparedEvent>(), null), Times.Never);
            Context.GetMock<IMessageReceiver>().Verify(s => s.DeadLetterAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        }
    }
}
