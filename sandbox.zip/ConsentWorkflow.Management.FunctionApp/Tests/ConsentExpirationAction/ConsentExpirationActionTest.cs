﻿using Microsoft.Azure.Documents.Client;
using Platform.Library.Common;
using Platform.Library.Communication.Extensions;
using Platform.Library.T24.SDK.DependencyInjection;
using System.Linq.Expressions;

namespace ConsentWorkflowMgmt.UnitTests.Actions
{
    [TestType(TestTypeEnum.UnitTest)]
    public class ConsentExpirationActionTest : XUnitTestFixture
    {
        private ContextModule Context => Module<ContextModule>();

        public ConsentExpirationActionTest(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {
        }

        protected override void TestSetup()
        {
            base.TestSetup();

            Context.RegisterWithMsDi(services =>
            {
                services.RegisterT24Sdk(
                    true, 
                    ConsentWorkflowManagementFunctionApp.Constants.Configuration.FunctionApp
                );

                services.RegisterBrandResolver();

                services
                    .RegisterApplicationDependencies()
                    .RegisterHttpClients()
                    .RegisterActionHandlers();
            });

            Context.RegisterMockAsInterface<IServiceBusEventPublisher>(SetupServiceBusEventPublisher);
            Context.RegisterMockAsInterface<IOdsConsentsRepository>(SetupOdsConsentsRepository);

            Context.RegisterTypeAsInterfaces<Settings>();

            Context.RegisterMapperAndProfiles(
                s => new InitiatePaymentRequestMapProfile(),
                s => new ActiveDirectDebitCreateRequestMapProfile(),
                s => new ExecuteSettlementInstructionsMapProfile(),
                s => new OffsetLinkOrDelinkRequestMapProfile()
            );
        }

        private void SetupOdsConsentsRepository(Mock<IOdsConsentsRepository> odsConsentsRepository)
        {
            odsConsentsRepository.Setup(o => o.SearchOdsForEntitiesAsync(It.IsAny<Expression<Func<Consent, bool>>>(), It.IsAny<FeedOptions>()))
                .ReturnsAsync((Expression<Func<Consent,bool>> expr, FeedOptions feed) => { return OdsConsentRepositoryResponse.Invoke(); });

            odsConsentsRepository
                .Setup(o => o.UpdateAsync(It.IsAny<Consent>()));
        }

        private Func<List<Consent>> OdsConsentRepositoryResponse { get; set; } = () => { return null; };

        private void SetupServiceBusEventPublisher(Mock<IServiceBusEventPublisher> serviceBusEventPublisher)
        {
            serviceBusEventPublisher.Setup(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV70ConsentResulted>(), null))
                .ReturnsAsync(true);
        }

        [Fact]
        public async void ConsentExpirationAction_UpdateConsentAndPublishEv70_Successful()
        {
            // Arrange
            OdsConsentRepositoryResponse = () => { return new[] { ConsentHelper.DefaultConsent }.ToList(); };

            var handlerAction = Context.Resolve<IConsentExpirationAction>();

            // Act
            await handlerAction.ProcessAsync();

            // Assert
            Context.GetMock<IOdsConsentsRepository>().Verify(o => o.UpdateAsync(It.IsAny<Consent>()), Times.Once);
            Context.GetMock<IServiceBusEventPublisher>().Verify(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV70ConsentResulted>(), null), Times.Once);
        }

        [Fact]
        public async void ConsentExpirationAction_UpdateConsentAndPublishEv70_NoConsentsFetchedFromODS()
        {
            // Arrange 
            var handlerAction = Context.Resolve<IConsentExpirationAction>();

            // Act
            await handlerAction.ProcessAsync();

            // Assert
            Context.GetMock<IOdsConsentsRepository>().Verify(o => o.UpdateAsync(It.IsAny<Consent>()), Times.Never);
            Context.GetMock<IServiceBusEventPublisher>().Verify(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV70ConsentResulted>(), null), Times.Never);
        }

        [Fact]
        public async void ConsentExpirationAction_SearchConsentsThrowsException_UpdateNotSuccessfulOnOds_Ev70NotPublished()
        {
            // Arrange
            OdsConsentRepositoryResponse = () => { throw new Exception(); };
            var handlerAction = Context.Resolve<IConsentExpirationAction>();

            // Act
            await handlerAction.ProcessAsync();

            Context.GetMock<IOdsConsentsRepository>().Verify(o => o.UpdateAsync(It.IsAny<Consent>()), Times.Never);
            Context.GetMock<IServiceBusEventPublisher>().Verify(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV70ConsentResulted>(), null), Times.Never);
        }

        [Fact]
        public async void ConsentExpirationAction_UpdateConsentFailed_Ev70NotPublished()
        {
            // Arrange
            OdsConsentRepositoryResponse = () => { throw new Exception(); };
            var handlerAction = Context.Resolve<IConsentExpirationAction>();

            // Act
            await handlerAction.ProcessAsync();

            // Assert
            Context.GetMock<IServiceBusEventPublisher>().Verify(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV70ConsentResulted>(), null), Times.Never);
        }
    }
}
