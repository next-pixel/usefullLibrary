﻿using FluentAssertions;
using FluentAssertions.Execution;

namespace ConsentWorkflowMgmt.UnitTests.ExtensionTests
{
    public class ConsentExtensionsTests
    {
        [Theory]
        [InlineData(TestEnum1.None, true)]
        [InlineData(TestEnum1.FIRST, true)]
        [InlineData(TestEnum1.SECOND, true)]
        [InlineData(TestEnum1.THIRD, false)]
        public void ConvertEnumTest(TestEnum1 inputEnum, bool shouldSucceed)
        {
            // Arrange

            // Act
            Func<TestEnum2> act = () => inputEnum.ConvertEnum<TestEnum1, TestEnum2>();

            // Assert
            using (new AssertionScope())
            {
                if (shouldSucceed)
                {
                    act.Should().NotThrow<Exception>();
                    act.Invoke().ToString().MatchesEnumValue(inputEnum).Should().BeTrue();
                }
                else
                {
                    act.Should().Throw<InvalidCastException>();
                }
            }
        }

        public enum TestEnum1
        {
            None,
            FIRST,
            SECOND,
            THIRD
        }

        public enum TestEnum2
        {
            None,
            SECOND,
            FIRST
        }
    }
}
