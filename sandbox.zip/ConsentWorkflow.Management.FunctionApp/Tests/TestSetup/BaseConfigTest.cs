﻿using AutoMapper;
using Platform.Library.Communication.Extensions;
using Platform.Library.Http;

namespace ConsentWorkflowMgmt.UnitTests
{
    public abstract class BaseConfigTest : XUnitTestFixture
    {
        protected BaseConfigTest(ITestOutputHelper outputHelper, XUnitClassFixture classFixture) : base(outputHelper, classFixture)
        {
        }

        private void SetupAzureServiceProviderClient(Mock<IAzureServiceTokenProviderClient> azureServiceProviderClient)
        {
            azureServiceProviderClient.Setup(a => a.GetAccessTokenAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>()))
                .ReturnsAsync("sampletoken");
        }

        private void SetupServiceBusEventPublisher(Mock<IServiceBusEventPublisher> serviceBusEventPublisher)
        {
            serviceBusEventPublisher.Setup(s => s.CreateAndPublishEvent(It.IsAny<string>(), It.IsAny<EV32CommunicationPreparedEvent>(), null))
                .ReturnsAsync(true);
        }

        private IMapper GetMapper()
        {
            var mapperConfig = new MapperConfiguration(cfg =>
            {
                var profiles = new List<Profile>
                {
                    new ConsentCreatedRequestMapProfile(),
                    new ActiveDirectDebitCreateRequestMapProfile(),
                    new ExecuteSettlementInstructionsMapProfile(),
                    new InitiatePaymentRequestMapProfile(),
                    new OffsetLinkOrDelinkRequestMapProfile(),
                };

                cfg.AddProfiles(profiles);
            });

            return (AutoMapper.Mapper)mapperConfig.CreateMapper();
        }
    }
}
