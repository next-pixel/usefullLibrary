# Please select a template
Select the appropriate template from **Add a template** 
- **feature** - Use this when adding new features
- **defect** - Use this when fixing defects found during TST/SIT/UAT
- **hotfix** - Use this when resolving a production issue that should go out as a hot fix

:warning: Don't forget to remove this and everything before it
