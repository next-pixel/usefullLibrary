﻿using AutoMapper;

namespace ConsentWorkflowManagementFunctionApp
{

    /// <summary>
    /// <see cref="AutoMapper"/> profile for <see cref="UpdateScheduledPaymentMapProfile"/>
    /// </summary>

    public class UpdateScheduledPaymentMapProfile : Profile
    {
        public UpdateScheduledPaymentMapProfile()
        {
            CreateMap<OdsModels.Consent, UpdateScheduledPaymentsRequest>()
                .ForMember(dest => dest.Amount, opt => opt.MapFrom(src => src.RequestDetails.Payments.Amount))
                .ForMember(dest => dest.Frequency, opt => opt.MapFrom(src => src.RequestDetails.Payments.Frequency))
                .ForMember(dest => dest.StartDate, opt => opt.MapFrom(src => src.RequestDetails.Payments.StartDate))
                .ForMember(dest => dest.EndDate, opt => opt.MapFrom(src => src.RequestDetails.Payments.EndDate))
                .ForMember(dest => dest.NoOfTransfers, opt => opt.MapFrom(src => Convert.ToString(src.RequestDetails.Payments.NoOfTransfers)))
                .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.RequestDetails.Payments.Description));
        }
    }
}  
