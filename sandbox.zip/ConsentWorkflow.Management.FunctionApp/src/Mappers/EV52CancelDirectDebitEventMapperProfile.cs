﻿using AutoMapper;
using ConsentWorkflowManagementFunctionApp.Models;
using Platform.Library.Azure.ServiceBus.Extensions.Extensions;
using Platform.Library.Events.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsentWorkflowManagementFunctionApp.Mappers
{
    public class EV52CancelDirectDebitEventMapperProfile : Profile
    {
        public EV52CancelDirectDebitEventMapperProfile()
        {
            CreateMap<EV52CancelDirectDebitCompositeEvent, EV52CancelDirectDebitEvent>()
                .ForPath(dest => dest.Payload.DirectDebitId, opt => opt.MapFrom(src => src.DirectDebitId))
                .ForMember(dest => dest.Metadata, opt => opt.MapFrom(src => src.StandardHeaderModel.MapMetadata()))
                .ForPath(dest => dest.Metadata.EventName, opt => opt.MapFrom(src => ServiceBus.EV52CancelDirectDebitEventName))
                .ForPath(x => x.Metadata.AssemblyQualifiedName, y => y.MapFrom(z => typeof(EV52CancelDirectDebitEvent).AssemblyQualifiedName));
        }
    }
}
