﻿using AutoMapper;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// <see cref="AutoMapper"/> profile for <see cref="ActiveDirectDebitCreateRequest"/>
    /// </summary>
    public class ActiveDirectDebitCreateRequestMapProfile : Profile
    {
        public ActiveDirectDebitCreateRequestMapProfile()
        {
            CreateMap<OdsModels.Consent, ActiveDirectDebitCreateRequest>()
            .ForMember(dest => dest.BsbNumber, opt => opt.MapFrom(src => src.RequestDetails.RepaymentInstructions.RepaymentAccount.BsbNumber))
            .ForMember(dest => dest.AccountNumber, opt => opt.MapFrom(src => src.RequestDetails.RepaymentInstructions.RepaymentAccount.AccountNumber))
            .ForMember(dest => dest.AccountName, opt => opt.MapFrom(src => src.RequestDetails.RepaymentInstructions.RepaymentAccount.AccountName))
            .ForMember(dest => dest.DirectDebitId, opt => opt.MapFrom(src => src.RequestDetails.RepaymentInstructions.RepaymentAccount.DirectDebitId));
        }
    }
}