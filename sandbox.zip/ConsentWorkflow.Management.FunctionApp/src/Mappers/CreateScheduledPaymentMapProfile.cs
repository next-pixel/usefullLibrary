﻿using AutoMapper;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// <see cref="AutoMapper"/> profile for <see cref="CreateScheduledPaymentMapProfile"/>
    /// </summary>
    public class CreateScheduledPaymentMapProfile : Profile
    {
        public CreateScheduledPaymentMapProfile()
        {
            CreateMap<CreateScheduledPaymentDetails, CreateScheduledPaymentsRequest>()
                .ForMember(dest => dest.Amount, opt => opt.MapFrom(src => src.Amount))
                .ForMember(dest => dest.Frequency, opt => opt.MapFrom(src => src.Frequency))
                .ForMember(dest => dest.StartDate, opt => opt.MapFrom(src => src.StartDate))
                .ForMember(dest => dest.EndDate, opt => opt.MapFrom(src => src.EndDate))
                .ForMember(dest => dest.NoOfTransfers, opt => opt.MapFrom(src => Convert.ToString(src.NoOfTransfers)))
                .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.Description))
                .ForMember(dest => dest.AccountBalance, opt => opt.MapFrom(src => src.AccountBalance))
                .ForMember(dest => dest.ScheduledPaymentDestination, opt => opt.MapFrom(src => GetScheduledPaymentDestination(src)))
                .ForMember(dest => dest.ScheduledPaymentSource, opt => opt.MapFrom(src => GetScheduledPaymentSource(src)));
        }

        private static CreateScheduledPaymentSource GetScheduledPaymentSource(CreateScheduledPaymentDetails consentDetails)
        {
            return new CreateScheduledPaymentSource
            {
                CustomerName = consentDetails.SourceCustomerName,  
                AccountNumber = consentDetails.SourceAccountNumber,
                AccountBSB = consentDetails.SourceBsbNumber
            };
        }

        private static CreateScheduledPaymentDestination GetScheduledPaymentDestination(CreateScheduledPaymentDetails consentDetails)
        {
            return new CreateScheduledPaymentDestination
            {
                Type = consentDetails.DestinationType,
                BeneficiaryId = consentDetails.DestinationBeneficiaryId,
                CustomerName = consentDetails.DestinationBeneficiaryName,
                ArrangementId = consentDetails.DestinationArrangementId,
                AccountNumber = consentDetails.DestinationAccountNumber,
                AccountBSB = consentDetails.DestinationBsbNumber,
                BPayBillercode = consentDetails.DestinationBPayBillerCode,
                BPayCrn = consentDetails.DestinationBPayCrn,
            };
        }
    }
}
