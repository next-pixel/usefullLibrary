﻿using Platform.Library.BaseEvent;
using Platform.Library.Communication.Extensions;
using Platform.Library.Communication.Extensions.Models;
using static Platform.Library.Communication.Extensions.Constants;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Mapper for communication events
    /// </summary>
    public class CommunicationMapper : ICommunicationMapper
    {
        public EventModels.EV32CommunicationPreparedEvent CreateConsentWorkflowManagementEv32CommunicationEvent(string systemId, string recipientId, string customerId, string customerFirstName, string channelType, string bodyText, string title, string link)
        {
            return CreateEv32CommunicationEvent(systemId, recipientId, customerId, customerFirstName, null, CommTypes.ConsentWorkflowManagement, channelType, bodyText, title, link);
        }

        private static EventModels.EV32CommunicationPreparedEvent CreateEv32CommunicationEvent(
            string systemId,
            string recipientId,
            string customerId,
            string customerName,
            string eventId,
            string communicationType,
            string channelType,
            string bodyText,
            string title = null,
            string link = null)
        {
            List<EventModels.Attribute> attributes = null;
            if (channelType == CommunicationChannel.Email)
            {
                attributes = new List<EventModels.Attribute>
                    {
                        new EventModels.Attribute
                        {
                            Key = NotificationCentre.CustomerNameConst,
                            Value = customerName,
                        },
                    };
            }

            return new EventModels.EV32CommunicationPreparedEvent()
            {
                Payload = new EventModels.Ev32CommunicationPreparedPayload()
                {
                    Recipients = new List<string>() { recipientId },
                    Cif = customerId,
                    Channel = channelType,
                    MessageClass = NotificationCentre.MessageClass,
                    EventId = eventId,
                    CommType = communicationType,
                    BodyText = bodyText,
                    Title = title,
                    Link = link,
                    Attributes = attributes,
                },
                Metadata = EventMetadataHelper.CreateNewMetadata(new EV32CommunicationPreparedEventMetaDataContent(systemId)),
            };
        }

        public EventModels.EV70ConsentResulted MapEv70ConsentResultedEvent(OdsModels.Consent consent)
        {
            return new EventModels.EV70ConsentResulted
            {
                Metadata = GetEv70StandardMetaData(),
                Payload = new EventModels.EV70ConsentResultedPayload
                {
                    ConsentId = consent.ConsentId,
                    Status = consent.Status,
                },
            };
        }
        private Metadata GetEv70StandardMetaData()
        {
            return new Metadata
            {
                MessageId = Guid.NewGuid().ToString(),
                AssemblyQualifiedName = typeof(EventModels.EV70ConsentResulted).AssemblyQualifiedName,
                RequestId = Guid.NewGuid().ToString(),
                EventName = nameof(EventModels.EV70ConsentResulted),
                SendingSystemId = nameof(ConsentExpirationFunction),
                SendingSystemVersion = "v1.0",
                InitiatingSystemId = nameof(ConsentExpirationFunction),
                InitiatingSystemVersion = "v1.0",
                Timestamp = DateTimeOffset.UtcNow,
            };
        }

        public class EV32CommunicationPreparedEventMetaDataContent : IEventMetadataContent
        {
            public EV32CommunicationPreparedEventMetaDataContent(string systemId)
            {
                AssemblyQualifiedName = typeof(EventModels.EV32CommunicationPreparedEvent).AssemblyQualifiedName;
                EventName = nameof(EventModels.EV32CommunicationPreparedEvent);
                SystemId = systemId;
                SystemVersion = "V1.0";
            }
        }
    }
}
