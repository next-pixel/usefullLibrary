﻿using AutoMapper;
using Platform.Library.Events.Models.Enum;
using Platform.Library.T24.SDK.Modules.HomeLoan;
using Platform.Library.T24.SDK.Modules.HomeLoan.RequestDtos;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// <see cref="AutoMapper"/> profile for <see cref="ExecuteSettlementInstructionsRequest"/>
    /// </summary>
    public class ExecuteSettlementInstructionsMapProfile : Profile
    {
        public ExecuteSettlementInstructionsMapProfile()
        {
            CreateMap<OdsModels.Consent, ExecuteSettlementInstructionsRequest>()
            .ForMember(dest => dest.ArrangementId, opt => opt.MapFrom(src => src.AccountDetails.ArrangementId))
            .ForMember(dest => dest.ProductId, opt => opt.MapFrom(src => src.AccountDetails.ProductId))
            .ForMember(dest => dest.FlowOption, opt => opt.MapFrom(src => GetRepaymentFlowOption(src.RequestDetails.RepaymentInstructions.FlowOption)))
            .ForMember(dest => dest.RepaymentAccountNumber, opt => opt.MapFrom(src => src.RequestDetails.RepaymentInstructions.RepaymentAccount.AccountNumber))
            .ForMember(dest => dest.PaymentSchedule, opt => opt.MapFrom(src => src.RequestDetails.RepaymentInstructions))
            .ForMember(dest => dest.RepaymentAmount, opt => opt.MapFrom(src => src.RequestDetails.RepaymentInstructions))
            .ForMember(dest => dest.ConsentDetails, opt => opt.MapFrom(src => src));

            CreateMap<OdsSubModels.RepaymentInstruction, PaymentSchedule>()
            .ForMember(dest => dest.DueDate, opt => opt.MapFrom(src => src.PaymentDueOn))
            .ForMember(dest => dest.RepaymentFrequency, opt => opt.MapFrom(src => GetRepaymentFrequency(src.RepaymentFrequency)))
            .ForMember(dest => dest.DayInterval, opt => opt.MapFrom(src => src.DayInterval));

            CreateMap<OdsSubModels.RepaymentInstruction, T24RepaymentRequestDto>()
                .ForMember(dest => dest.RepaymentOption, opt => opt.MapFrom(src => GetRepaymentOption(src.RepaymentOption)))
                .ForMember(dest => dest.Amount, opt => opt.MapFrom(src => GetRepaymentInstructionAmount(src)))                
                .ForMember(dest => dest.MinimumRepayment, opt => opt.MapFrom(src => src.MinimumRepayment));

            CreateMap<OdsModels.Consent, ConsentDetails>()
                .ForMember(dest => dest.ConsentId, opt => opt.MapFrom(src => src.ConsentId))
                .ForMember(dest => dest.RequestNote, opt => opt.Ignore());
        }

        private static RepaymentFrequency GetRepaymentFrequency(OdsConsentEnums.RepaymentFrequency repaymentFrequency)
        {
            return repaymentFrequency.ConvertEnum<OdsConsentEnums.RepaymentFrequency, RepaymentFrequency>();
        }

        private static FlowOption GetRepaymentFlowOption(OdsConsentEnums.FlowOption flowOption)
        {
            return flowOption.ConvertEnum<OdsConsentEnums.FlowOption, FlowOption>();
        }

        private static T24HomeLoanRepaymentOption GetRepaymentOption(OdsConsentEnums.RepaymentOption repaymentOption)
        {
            return repaymentOption.ConvertEnum<OdsConsentEnums.RepaymentOption, T24HomeLoanRepaymentOption>();
        }

        private static decimal? GetRepaymentInstructionAmount(OdsSubModels.RepaymentInstruction src)
        {           
            return src.RepaymentOption switch
            {
                OdsConsentEnums.RepaymentOption.EXTRA => Convert.ToDecimal(src.ExtraAmount),
                OdsConsentEnums.RepaymentOption.FIXED => Convert.ToDecimal(src.FixedAmount),
                _ => null
            };                     
        }
    }
}