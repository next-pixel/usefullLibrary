using AutoMapper;
using Platform.Library.Events.Models.Enum;
using Platform.Library.Events.Models.SubModels.Consent;
using Platform.Library.Ods.Core.OdsDB.DataModel.SubModels.Consent;
using Platform.Library.T24.SDK.Modules.Scheduled.ResponseDtos;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// <see cref="AutoMapper"/> profile for <see cref="OdsModels.Consent"/>
    /// </summary>
    public class ConsentCreatedRequestMapProfile : Profile
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsentCreatedRequestMapProfile"/> class.
        /// </summary>
        public ConsentCreatedRequestMapProfile()
        {
            // offset comms mapping
            CreateMap<ConsentCreatedComposite, OdsModels.Consent>()
                .ForMember(dest => dest.RequestType, opt => opt.MapFrom(src => src.Payload.RequestType.ToString()))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => ConsentStatus.PENDING.ToString()))
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Payload.ConsentId))
                .ForMember(dest => dest.ConsentId, opt => opt.MapFrom(src => src.Payload.ConsentId))
                .ForMember(dest => dest.Parties, opt => opt.MapFrom(src => MapPartiesFromPayload(src.Payload.Parties)))
                .ForMember(dest => dest.Requestor, opt => opt.MapFrom(src => MapRequestorFromPayload(src.Payload.Requestor)))
                .ForMember(dest => dest.LastActionedDateTime, opt => opt.MapFrom(src => src.Payload.LastActionedDateTime.DateTime))
                .ForMember(dest => dest.RequestDateTime, opt => opt.MapFrom(src => src.Payload.RequestDateTime.DateTime))
                .ForMember(dest => dest.ExpiryDateTime, opt => opt.MapFrom(src => src.Payload.ExpiryDateTime.DateTime))
                .ForMember(dest => dest.AccountDetails, opt => opt.MapFrom(src => MapAccountDetailsFromPayload(src.Payload.AccountDetails)))
                .ForMember(dest => dest.RequestDetails, opt => opt.MapFrom(src => MapRequestDetailsFromPayload(src)))
                .ForMember(dest => dest.PaymentDetails, opt => opt.MapFrom(src => MapConsentPaymentFromStandingOrder(src)))
                .ForMember(dest => dest.ResultedDateTime, opt => opt.Ignore())
                .ForMember(dest => dest.ETag, opt => opt.Ignore());
        }

        private static List<OdsSubModels.PartyConsent> MapPartiesFromPayload(List<ConsentSubModels.ConsentParty> payloadParties)
        {
            var parties = new List<OdsSubModels.PartyConsent>();
            if (payloadParties != null && payloadParties.Any())
            {
                foreach (var entry in payloadParties)
                {
                    parties.Add(new OdsSubModels.PartyConsent
                    {
                        CustomerId = entry.CustomerId,
                        FirstName = entry.FirstName,
                        LastName = entry.LastName,
                        Role = entry.Role.ConvertEnum<ConsentCustomerRoleEnum, OdsConsentEnums.ConsentCustomerRole>(),
                        Response = entry.Response.ConvertEnum<ConsentResponseStatusEnum, OdsConsentEnums.ConsentResponseStatus>(),
                        ResponseDateTime = entry.ResponseDateTime?.DateTime,
                    });
                }
            }
            else
            {
                throw new AutoMapperMappingException($"ConsentParty.{payloadParties?.ToString() ?? "NULL"} is not supported by {nameof(ConsentCreatedRequestMapProfile)}");
            }

            return parties;
        }

        private static OdsSubModels.Requestor MapRequestorFromPayload(ConsentSubModels.Requestor payloadRequestor)
        {
            var requestor = new OdsSubModels.Requestor
            {
                CustomerId = payloadRequestor.CustomerId,
                FirstName = payloadRequestor.FirstName,
                LastName = payloadRequestor.LastName,
            };

            return requestor;
        }

        private static List<OdsSubModels.LinkedArrangement> MapLinkedArrangementsFromPayload(List<ConsentSubModels.LinkedArrangement> payloadLinkedArrangements)
        {
            var linkedArrangements = new List<OdsSubModels.LinkedArrangement>();

            if (payloadLinkedArrangements != null && payloadLinkedArrangements.Any())
            {
                foreach (var entry in payloadLinkedArrangements)
                {
                    linkedArrangements.Add(new OdsSubModels.LinkedArrangement
                    {
                        ArrangementId = entry.ArrangementId,
                        AccountId = entry.AccountId,
                        AccountName = entry.AccountName,
                        AccountNumber = entry.AccountNumber,
                        BsbNumber = entry.BsbNumber,
                        ProductId = entry.ProductId,
                        ProductDescription = entry.ProductDescription,
                        OffsetIndicator = entry.OffsetIndicator,
                    });
                }
            }

            return linkedArrangements;
        }

        private static OdsSubModels.RepaymentInstruction MapRepaymentInstructionsFromPayload(ConsentSubModels.RepaymentInstructions payloadRepaymentInstructions, bool mapDayInterval = false)
        {
            OdsSubModels.RepaymentInstruction repaymentInstructions = null;

            if (payloadRepaymentInstructions != null)
            {
                repaymentInstructions = new OdsSubModels.RepaymentInstruction
                {
                    RepaymentFrequency = payloadRepaymentInstructions.RepaymentFrequency.ConvertEnum<RepaymentFrequencyEnum, OdsConsentEnums.RepaymentFrequency>(),
                    MinimumRepayment = decimal.ToDouble(payloadRepaymentInstructions.MinimumRepayment),
                    FixedAmount = decimal.ToDouble(payloadRepaymentInstructions.FixedAmount),
                    ExtraAmount = decimal.ToDouble(payloadRepaymentInstructions.ExtraAmount),
                    RepaymentOption = payloadRepaymentInstructions.RepaymentOption.ConvertEnum<RepaymentOptionEnum, OdsConsentEnums.RepaymentOption>(),
                    NextPayment = decimal.ToDouble(payloadRepaymentInstructions.NextPayment),
                    PaymentDueOn = payloadRepaymentInstructions.PaymentDueOn?.DateTime,
                    FlowOption = payloadRepaymentInstructions.FlowOption.ConvertEnum<FlowOptionEnum, OdsConsentEnums.FlowOption>(),
                };

                if (mapDayInterval)
                    repaymentInstructions.DayInterval = Convert.ToInt32(payloadRepaymentInstructions.DayInterval);

                if (payloadRepaymentInstructions.RepaymentAccount != null)
                {
                    var repaymentAccountFromPayload = payloadRepaymentInstructions.RepaymentAccount;

                    repaymentInstructions.RepaymentAccount = new OdsSubModels.RepaymentAccount
                    {
                        AccountName = repaymentAccountFromPayload.AccountName,
                        AccountNumber = repaymentAccountFromPayload.AccountNumber,
                        BsbNumber = repaymentAccountFromPayload.BsbNumber,
                        DirectDebitId = repaymentAccountFromPayload.DirectDebitId,
                        InstitutionName = repaymentAccountFromPayload.InstitutionName,
                    };
                }
            }

            return repaymentInstructions;
        }

        private static OdsSubModels.Payment MapConsentPaymentFromPayload(ConsentSubModels.ConsentPayment payloadConsentPaymentDetails)
        {
            OdsSubModels.Payment consentPayment = null;

            if (payloadConsentPaymentDetails != null)
            {
                consentPayment = new OdsSubModels.Payment
                {
                    StandingOrderId = payloadConsentPaymentDetails.StandingOrderId,
                    StandingOrderAction = payloadConsentPaymentDetails.StandingOrderAction.AsOdsStandingOrderAction(),
                    Amount = decimal.ToDouble(payloadConsentPaymentDetails.Amount),
                    AccountBalance = decimal.ToDouble(payloadConsentPaymentDetails.AccountBalance),
                    Description = payloadConsentPaymentDetails.Description,
                    When = payloadConsentPaymentDetails.When.ConvertToPaymentSchedule(),
                    Frequency = payloadConsentPaymentDetails.Frequency.ConvertToPaymentFrequency(),
                    StartDate = payloadConsentPaymentDetails.StartDate?.DateTime,
                    EndDate = payloadConsentPaymentDetails.EndDate?.DateTime,
                    NoOfTransfers = payloadConsentPaymentDetails.NoOfTransfers,
                    Reference = payloadConsentPaymentDetails.Reference,
                    ControlFlowId = payloadConsentPaymentDetails.ControlFlowId,
                };

                if (payloadConsentPaymentDetails.Destination != null)
                {
                    var paymentDestination = payloadConsentPaymentDetails.Destination;

                    consentPayment.Destination = new OdsSubModels.Destination
                    {
                        BeneficiaryId = paymentDestination.BeneficiaryId,
                        BeneficiaryName = paymentDestination.BeneficiaryName,
                        ArrangementId = paymentDestination.ArrangementId,
                        AccountId = paymentDestination.AccountId,
                        AccountNumber = paymentDestination.AccountNumber,
                        AccountName = paymentDestination.AccountName,
                        BsbNumber = paymentDestination.BsbNumber,
                        BPayBillerCode = paymentDestination.BPayBillerCode,
                        BPayCrn = paymentDestination.BPayCrn,
                        BillerName = paymentDestination.BillerName,
                        InstitutionName = paymentDestination.InstitutionName,
                        PayId = paymentDestination.PayId,
                        PayIdType = paymentDestination.PayIdType,
                        PayIdOwnerName = paymentDestination.PayIdOwnerName,
                        PayIdAliasName = paymentDestination.PayIdAliasName,
                        Type = paymentDestination.Type.Convert()
                    };
                }
            }

            return consentPayment;
        }

        private static OdsSubModels.Payment MapConsentPaymentFromStandingOrder(ConsentCreatedComposite consentComposite)
        {
            OdsSubModels.Payment consentPayment = null;

            if (consentComposite is { StandingOrderResponse: { } })
            {
                var pendingTransaction = consentComposite.StandingOrderResponse.Body.FirstOrDefault()?.PendingTransactions.FirstOrDefault();

                if (pendingTransaction is null)
                {
                    throw new AutoMapperMappingException($"Pending Transaction is NULL for Standing Order with ID: {consentComposite.Payload.RequestDetails.Payment.StandingOrderId}");
                }

                consentPayment = new OdsSubModels.Payment
                {
                    StandingOrderId = pendingTransaction.StandingOrderId,
                    Amount = Convert.ToDouble(pendingTransaction.Amount),
                    When = PaymentScheduleExtensions.MapPaymentScheduleFromStandingOrderFrequency(pendingTransaction.CurrentFrequency),
                    Frequency = PaymentFrequencyExtensions.MapPaymentFrequencyFromStandingOrderFrequency(pendingTransaction.CurrentFrequency),
                    StartDate = Convert.ToDateTime(pendingTransaction.StartDate),
                    EndDate = DateTime.TryParse(pendingTransaction.EndDate, out var endDate) ? endDate : null,//endDate can be 'never'
                    NoOfTransfers = int.TryParse(pendingTransaction.NoOfUpcomingPayments, out var noOfUpcomingTransfers) ? noOfUpcomingTransfers : null,// noOfUpcomingPayments can be 'indefinite'
                    Description = pendingTransaction.DestinationPaymentDesc
                };

                consentPayment.Destination = new OdsSubModels.Destination
                {
                    InstitutionName = consentComposite.GetInstitutionResponse?.Body.FirstOrDefault()?.InstitutionName,
                    AccountName = pendingTransaction.DestinationAccountName,
                    BPayCrn = pendingTransaction.BeneficiaryOtId,
                    BillerName = consentComposite.BpayBillerCodeResponse?.ShortName,
                    ArrangementId = consentComposite.AccountDetailsResponse?.Body.FirstOrDefault()?.ArrangementId,
                    AccountId = consentComposite.AccountDetailsResponse?.Body.FirstOrDefault()?.AccountId,
                    BeneficiaryName = pendingTransaction.BeneficiaryName,
                    Type = pendingTransaction.PaymentOrderProduct.ConvertToOdsPaymentType()
                };

                MapDestinationAccountDetails(pendingTransaction, consentPayment.Destination, consentComposite);
            }
            
            return consentPayment;
        }

        private static void MapDestinationAccountDetails(T24PendingTransaction pendingTransaction, OdsSubModels.Destination destination, ConsentCreatedComposite consentComposite)
        {
            switch (pendingTransaction.PaymentOrderProduct)
            {
                case PaymentOrderProducts.VMAINTSTO:
                case PaymentOrderProducts.VMAPARWITI:
                    destination.AccountNumber = pendingTransaction.CounterPartyAccountId;
                    destination.BsbNumber = consentComposite.AccountDetailsResponse.Body.FirstOrDefault()?.BsbNumber;
                    break;
                case PaymentOrderProducts.VMABECSSTO:
                case PaymentOrderProducts.VMAPARWITO:
                    destination.AccountNumber = pendingTransaction.BeneficiaryAccountId;
                    destination.BsbNumber = pendingTransaction.AccountWithBankClearingCode;
                    break;
                case PaymentOrderProducts.VMABPAYSTO:
                    destination.BPayBillerCode = pendingTransaction.BeneficiaryAccountId;
                    break;
                default:
                    throw new AutoMapperMappingException($"PaymentOrderProduct.{pendingTransaction.PaymentOrderProduct ?? "NULL"} is not supported by {nameof(ConsentCreatedRequestMapProfile)}");
            }
        }

        private static OdsSubModels.AccountDetail MapAccountDetailsFromPayload(ConsentSubModels.AccountDetails payloadAccountDetails)
        {
            var accountDetails = new OdsSubModels.AccountDetail
            {
                ArrangementId = payloadAccountDetails.ArrangementId,
                BundleArrangementId = payloadAccountDetails.BundleArrangementId,
                AccountId = payloadAccountDetails.AccountId,
                AccountName = payloadAccountDetails.AccountName,
                AccountNumber = payloadAccountDetails.AccountNumber,
                BsbNumber = payloadAccountDetails.BsbNumber,
                ProductId = payloadAccountDetails.ProductId,
                ProductDescription = payloadAccountDetails.ProductDescription,
                SigningInstructions = payloadAccountDetails.SigningInstructions.ConvertEnum<SigningInstructionsEnum, OdsConsentEnums.SigningInstructions>(),
                OffsetIndicator = payloadAccountDetails.OffsetIndicator,
                AccountLocked = payloadAccountDetails.AccountLocked,
                LinkedArrangements = MapLinkedArrangementsFromPayload(payloadAccountDetails.LinkedArrangements),
                RepaymentInstructions = MapRepaymentInstructionsFromPayload(payloadAccountDetails.RepaymentInstructions),
            };

            return accountDetails;
        }

        private static OdsSubModels.RequestDetail MapRequestDetailsFromPayload(ConsentCreatedComposite consent)
        {
            var requestDetails = new OdsSubModels.RequestDetail
            {
                Offsets = GetMappedOffsets(consent.Payload.RequestDetails.Offsets),
                Payments = MapConsentPaymentFromPayload(consent.Payload.RequestDetails.Payment),
                RepaymentInstructions = MapRepaymentInstructionsFromPayload(consent.Payload.RequestDetails.RepaymentInstructions, true),
                RequestNote = consent.Payload.RequestDetails.RequestNote,
            };

            return requestDetails;
        }

        private static OffsetsDetails GetMappedOffsets(Offsets requestOffsets)
        {
            return requestOffsets?.OffsetAction == null
              ? null
              : new OdsConsent.OffsetsDetails
              {
                  OffsetAction = MapOffsetAction(requestOffsets?.OffsetAction),
                  LinkedArrangements = MapLinkedArrangementsFromPayload(requestOffsets.LinkedArrangements)
              };
        }

        private static OdsConsentEnums.OffsetAction MapOffsetAction(EventEnums.OffsetActionEnum? enumValue)
        {
            return enumValue switch
            {
                EventEnums.OffsetActionEnum.LINK => OdsConsentEnums.OffsetAction.LINK,
                EventEnums.OffsetActionEnum.DELINK => OdsConsentEnums.OffsetAction.DELINK,
                _ => throw new NotSupportedException($"{nameof(EventEnums.OffsetActionEnum)}.{(enumValue.HasValue ? enumValue.Value : "NULL")} is not supported by {nameof(MapOffsetAction)}")
            };
        }
    }
}