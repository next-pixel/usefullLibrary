﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Interface for the <see cref="CommunicationMapper"/>
    /// </summary>
    public interface ICommunicationMapper
    {
        /// <summary>
        /// Creates a <see cref="EV32CommunicationPreparedEvent"/> with given bodyText, title and link.
        /// </summary>
        EventModels.EV32CommunicationPreparedEvent CreateConsentWorkflowManagementEv32CommunicationEvent(string systemId, string recipientId, string customerId, string customerFirstName, string channelType, string bodyText, string title, string link);

        /// <summary>
        /// Creates a <see cref="EV70ConsentResulted"/> with consent.
        /// </summary>
        /// <param name="consent">Consent.</param>
        /// <returns>Ev70 Consent resulted object.</returns>
        EventModels.EV70ConsentResulted MapEv70ConsentResultedEvent(OdsModels.Consent consent);
    }
}
