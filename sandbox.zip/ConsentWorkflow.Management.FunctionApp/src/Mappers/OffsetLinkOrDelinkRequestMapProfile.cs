﻿using AutoMapper;
using Platform.Library.Events.Models.SubModels.Consent;
using Platform.Library.Ods.Core.OdsDB.DataModel.SubModels;
using Platform.Library.Ods.Core.OdsDB.DataModel.SubModels.Consent.Enumerations;
using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;
using LinkedArrangement = Platform.Library.Ods.Core.OdsDB.DataModel.SubModels.LinkedArrangement;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// <see cref="AutoMapper"/> profile for <see cref="OffsetLinkOrDelinkRequest"/>
    /// </summary>
    public class OffsetLinkOrDelinkRequestMapProfile : Profile
    {
        public OffsetLinkOrDelinkRequestMapProfile()
        {
            CreateMap<OffsetLinkOrDelinkCompositeRequest, OffsetLinkOrDelinkRequest>()
                .ForMember(dest => dest.ArrangementId, opt => opt.MapFrom(src => src.AccountDetails.ArrangementId))
                .ForMember(dest => dest.ProductId, opt => opt.MapFrom(src => src.AccountDetails.ProductId))
                .ForMember(dest => dest.Offsets, opt => opt.MapFrom(src => GetLinkedOrDelinkedOffsetsAccounts(src.Consent.RequestDetails.Offsets)))
                .ForMember(dest => dest.ConsentDetails, opt => opt.MapFrom(src => src.Consent));

            CreateMap<OdsModels.Consent, ConsentDetails>()
                .ForMember(dest => dest.ConsentId, opt => opt.MapFrom(src => src.ConsentId))
                .ForMember(dest => dest.RequestNote, opt => opt.Ignore());
        }

        private static List<string> GetLinkedOrDelinkedOffsetsAccounts(OdsConsent.OffsetsDetails offsets)
        {
            return (offsets.IsNotNull() && offsets.LinkedArrangements.AnyNullSafe())
                    ? offsets.LinkedArrangements.Select(o => o.ArrangementId).ToList()
                    : new(); 
        }
    }
}