﻿using AutoMapper;
using Platform.Library.Events.Models.Enum;
using Platform.Library.T24.SDK.Common;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// <see cref="AutoMapper"/> profile for <see cref="InitiatePaymentRequest"/>
    /// </summary>
    public class InitiatePaymentRequestMapProfile : Profile
    {
        public InitiatePaymentRequestMapProfile()
        {
            CreateMap<OdsModels.Consent, InitiatePaymentRequest>()
                .ForMember(dest => dest.Source, opt => opt.MapFrom(src => src.AccountDetails))
                .ForMember(dest => dest.Destination, opt => opt.MapFrom(src => src.RequestDetails.Payments.Destination))
                .ForMember(dest => dest.Amount, opt => opt.MapFrom(src => src.RequestDetails.Payments.Amount))
                .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.RequestDetails.Payments.Description))
                .ForMember(dest => dest.Reference, opt => opt.MapFrom(src => src.RequestDetails.Payments.Reference))
                .ForMember(dest => dest.ControlFlowId, opt => opt.MapFrom(src => src.RequestDetails.Payments.ControlFlowId))
                .ForMember(dest => dest.AccountBalance, opt => opt.Ignore())
                .ForMember(dest => dest.ConsentDetails, opt => opt.MapFrom(src => src));

            CreateMap<OdsSubModels.AccountDetail, PaymentSource>()
                .ForMember(dest => dest.ArrangementId, opt => opt.MapFrom(src => src.ArrangementId))
                .ForMember(dest => dest.AccountName, opt => opt.MapFrom(src => src.AccountName))
                .ForMember(dest => dest.AccountBSB, opt => opt.MapFrom(src => src.BsbNumber))
                .ForMember(dest => dest.AccountNumber, opt => opt.MapFrom(src => src.AccountNumber));

            CreateMap<OdsSubModels.Destination, PaymentDestination>()
                .ForMember(dest => dest.Type, opt => opt.MapFrom(src => src.Type))
                .ForMember(dest => dest.BeneficiaryId, opt => opt.MapFrom(src => src.BeneficiaryId))
                .ForMember(dest => dest.BeneficiaryName, opt =>
                {
                    // Only map when doing manual entries without BeneficiaryId or PayId
                    opt.PreCondition(src => (src.Type.In(OdsSubModels.Consent.PaymentType.DIRECT_ENTRY, OdsSubModels.Consent.PaymentType.BPAY) && string.IsNullOrWhiteSpace(src.BeneficiaryId))
                                            || (src.Type == OdsSubModels.Consent.PaymentType.NPP && string.IsNullOrWhiteSpace(src.BeneficiaryId) && string.IsNullOrWhiteSpace(src.PayId)));
                    opt.MapFrom(src => src.BeneficiaryName);
                })
                .ForMember(dest => dest.AccountNumber, opt =>
                {
                    // Only map when INTERNAL or both BeneficiaryId & PayId are null
                    opt.PreCondition(src => src.Type == OdsSubModels.Consent.PaymentType.INTERNAL || (string.IsNullOrWhiteSpace(src.BeneficiaryId) && string.IsNullOrWhiteSpace(src.PayId)));
                    opt.MapFrom(src => src.AccountNumber);
                })
                .ForMember(dest => dest.AccountBSB, opt =>
                {
                    // Only map when doing manual entries without BeneficiaryId or PayId
                    opt.PreCondition(src => (src.Type == OdsSubModels.Consent.PaymentType.DIRECT_ENTRY && string.IsNullOrWhiteSpace(src.BeneficiaryId))
                                            || (src.Type == OdsSubModels.Consent.PaymentType.NPP && string.IsNullOrWhiteSpace(src.BeneficiaryId) && string.IsNullOrWhiteSpace(src.PayId)));
                    opt.MapFrom(src => src.BsbNumber);
                })
                .ForMember(dest => dest.BpayBillerCode, opt =>
                {
                    // Only map when BPAY
                    opt.PreCondition(src => src.Type == OdsSubModels.Consent.PaymentType.BPAY);
                    opt.MapFrom(src => src.BPayBillerCode);
                })
                .ForMember(dest => dest.BpayCrn, opt =>
                {
                    // Only map when BPAY
                    opt.PreCondition(src => src.Type == OdsSubModels.Consent.PaymentType.BPAY);
                    opt.MapFrom(src => src.BPayCrn);
                })
                .ForMember(dest => dest.PayId, opt =>
                {
                    // Can only ever be mapped when NPP
                    opt.PreCondition(src => src.Type == OdsSubModels.Consent.PaymentType.NPP);
                    opt.MapFrom(src => src.PayId);
                })
                .ForMember(dest => dest.PayIdType, opt =>
                {
                    // Only map when NPP and PayId provided
                    opt.PreCondition(src => src.Type == OdsSubModels.Consent.PaymentType.NPP && !string.IsNullOrWhiteSpace(src.PayId));
                    opt.MapFrom(src => src.PayIdType);
                })
                .ForMember(dest => dest.PayIdOwnerName, opt =>
                {
                    // Only map when NPP and PayId provided
                    opt.PreCondition(src => src.Type == OdsSubModels.Consent.PaymentType.NPP && !string.IsNullOrWhiteSpace(src.PayId));
                    opt.MapFrom(src => src.PayIdOwnerName);
                })
                .ForMember(dest => dest.PayIdAliasName, opt =>
                {
                    // Only map when NPP and PayId provided
                    opt.PreCondition(src => src.Type == OdsSubModels.Consent.PaymentType.NPP && !string.IsNullOrWhiteSpace(src.PayId));
                    opt.MapFrom(src => src.PayIdAliasName);
                });

            CreateMap<OdsModels.Consent, ConsentDetails>()
                .ForMember(dest => dest.ConsentId, opt => opt.MapFrom(src => src.ConsentId))
                .ForMember(dest => dest.RequestNote, opt => opt.Ignore());
        }
    }
}
