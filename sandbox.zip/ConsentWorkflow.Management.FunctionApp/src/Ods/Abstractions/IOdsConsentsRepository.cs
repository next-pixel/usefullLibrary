﻿using Platform.Library.Ods.Core.Interfaces;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Interface for ODS consents repository.
    /// </summary>
    public interface IOdsConsentsRepository : IRepository<OdsModels.Consent>
    {
    }
}
