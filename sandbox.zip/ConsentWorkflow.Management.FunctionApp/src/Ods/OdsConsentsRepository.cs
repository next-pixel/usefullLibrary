﻿using Platform.Library.Ods.Infrastructure.Data.DocumentDB.Client.Abstraction;
using Platform.Library.Ods.Infrastructure.Data.Repository;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Ods consents repository.
    /// </summary>
    public class OdsConsentsRepository : OdsDbRepository<OdsModels.Consent>, IOdsConsentsRepository
    {
        private readonly ISettings _settings;

        /// <summary>
        /// Initializes a new instance of the <see cref="OdsConsentsRepository"/> class.
        /// </summary>
        /// <param name="odsDbClientFactory">Ods Db client factory.</param>
        /// <param name="settings">Settings.</param>
        public OdsConsentsRepository(IOdsDbClientFactory odsDbClientFactory, ISettings settings)
            : base(odsDbClientFactory)
        {
            _settings = settings;
        }
    }
}
