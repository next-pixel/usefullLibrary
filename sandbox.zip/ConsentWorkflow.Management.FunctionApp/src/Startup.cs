﻿using ConsentWorkflowManagementFunctionApp;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Azure.WebJobs.ServiceBus;
using Microsoft.Extensions.DependencyInjection;
using Platform.Library.Common;
using System.Diagnostics.CodeAnalysis;

[assembly: FunctionsStartup(typeof(Startup))]

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Startup class.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class Startup : FunctionsStartup
    {
        /// <summary>
        /// Configuration App Configuration
        /// </summary>
        /// <param name="builder"></param>
        public override void ConfigureAppConfiguration(IFunctionsConfigurationBuilder builder)
        {
            builder.DefineConfiguration();
        }

        /// <summary>
        /// Configuring host builder
        /// </summary>
        /// <param name="builder"></param>
        /// <exception cref="NotImplementedException"></exception>
        public override void Configure(IFunctionsHostBuilder builder)
        {
            builder.Services
                .RegisterServices()
                .AddHealthChecks();

            // configure ServiceBus behaviour
            builder.Services.Configure(delegate (ServiceBusOptions options)
            {
                // setting auto complete to false to handle messages manually
                options.MessageHandlerOptions.AutoComplete = false;
            });
        }
    }
}