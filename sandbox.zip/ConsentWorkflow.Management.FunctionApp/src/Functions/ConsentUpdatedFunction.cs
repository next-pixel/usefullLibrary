using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Azure.WebJobs;
using System.Diagnostics.CodeAnalysis;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Handles consent resulted events.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class ConsentUpdatedFunction
    {
        private readonly IMessageHandler<EventModels.EV69ConsentUpdatedEvent> _consentUpdatedActionHandler;

        public ConsentUpdatedFunction(IMessageHandler<EventModels.EV69ConsentUpdatedEvent> consentUpdatedActionHandler)
        {
            _consentUpdatedActionHandler  = consentUpdatedActionHandler.GuardNull(nameof(consentUpdatedActionHandler));
        }

        /// <summary>
        /// Run method to handle consent resulted events.
        /// </summary>
        /// <param name="message">Message.</param>
        /// <param name="messageReceiver">Message reciever.</param>
        /// <param name="consentUpdatedActionHandler">Consent resulted action handler.</param>
        /// <param name="logger">Logger.</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <returns></returns>
        [Disable("IsStagingSlot")]
        [FunctionName(nameof(ConsentUpdatedFunction))]
        public async Task Run(
            [ServiceBusTrigger(
            ServiceBus.Topics.Consent,
            ServiceBus.Subscriptions.ConsentUpdated,
            Connection = ServiceBus.Config.ConnectionString)]
            Message message,
            MessageReceiver messageReceiver,
            ILogger logger,
            CancellationToken cancellationToken)
        {

            logger.LogDebug("{FunctionName} received message {MessageId}", nameof(ConsentUpdatedFunction), message.MessageId);
            await _consentUpdatedActionHandler.ProcessMessageAsync(message, messageReceiver, logger, cancellationToken);
            logger.LogInformation("{FunctionName} completed processing {MessageId}", nameof(ConsentUpdatedFunction), message.MessageId);
        }
    }
}
