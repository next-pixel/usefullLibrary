using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Azure.WebJobs;
using System.Diagnostics.CodeAnalysis;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Handles consent resulted events.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class ConsentResultedFunction
    {
        private readonly IMessageHandler<EventModels.EV70ConsentResulted> _consentResultedActionHandler;

        public ConsentResultedFunction(IMessageHandler<EventModels.EV70ConsentResulted> consentResultedActionHandler)
        {
            _consentResultedActionHandler = consentResultedActionHandler.GuardNull(nameof(consentResultedActionHandler));
        }

        /// <summary>
        /// Run method to handle consent resulted events.
        /// </summary>
        /// <param name="message">Message.</param>
        /// <param name="messageReceiver">Message reciever.</param>
        /// <param name="consentResultedActionHandler">Consent resulted action handler.</param>
        /// <param name="logger">Logger.</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <returns></returns>
        [Disable("IsStagingSlot")]
        [FunctionName(nameof(ConsentResultedFunction))]
        public async Task Run(
            [ServiceBusTrigger(
            ServiceBus.Topics.Consent,
            ServiceBus.Subscriptions.ConsentResulted,
            Connection = ServiceBus.Config.ConnectionString)]
            Message message,
            MessageReceiver messageReceiver,
            ILogger logger,
            CancellationToken cancellationToken)
        {

            logger.LogDebug("{FunctionName} received message {MessageId}", nameof(ConsentResultedFunction), message.MessageId);
            await _consentResultedActionHandler.ProcessMessageAsync(message, messageReceiver, logger, cancellationToken);
            logger.LogInformation("{FunctionName} completed processing {MessageId}", nameof(ConsentResultedFunction), message.MessageId);
        }
    }
}
