﻿using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Azure.WebJobs;
using System.Diagnostics.CodeAnalysis;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Consent Created Function.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class ConsentCreatedFunction
    {
        private readonly IMessageHandler<EventModels.EV68ConsentCreatedEvent> _consentCreatedActionHandler;

        public ConsentCreatedFunction(IMessageHandler<EventModels.EV68ConsentCreatedEvent> consentCreatedActionHandler)
        {
            _consentCreatedActionHandler = consentCreatedActionHandler.GuardNull(nameof(consentCreatedActionHandler));
        }

        /// <summary>
        /// Consent Created Service Bus Trigger Function.
        /// </summary>
        /// <param name="message">Message Body.</param>
        /// <param name="messageReceiver">Message Receiver.</param>
        /// <param name="consentCreatedActionHandler">Consent created action handler.</param>
        /// <param name="logger">Logger.</param>
        /// <param name="cancellationToken">Cancellation Token.</param>
        /// <returns>Task Operation.</returns>
        [FunctionName(nameof(ConsentCreatedFunction))]
        [Disable("IsStagingSlot")]
        public async Task Run(
            [ServiceBusTrigger(
            ServiceBus.Topics.Consent,
            ServiceBus.Subscriptions.ConsentCreated,
            Connection = ServiceBus.Config.ConnectionString)]
            Message message,
            MessageReceiver messageReceiver,
            ILogger logger,
            CancellationToken cancellationToken)
        {
            logger.LogDebug("{FunctionName} received message {MessageId}", typeof(ConsentCreatedFunction), message.MessageId);
            await _consentCreatedActionHandler.ProcessMessageAsync(message, messageReceiver, logger, cancellationToken);
            logger.LogInformation("{FunctionName} completed processing {MessageId}", typeof(ConsentCreatedFunction), message.MessageId);
        }
    }
}
