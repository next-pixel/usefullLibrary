using Microsoft.Azure.WebJobs;
using System.Diagnostics.CodeAnalysis;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Consents expiration function.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class ConsentExpirationFunction
    {
        private readonly IConsentExpirationAction _consentExpirationAction;

        public ConsentExpirationFunction(IConsentExpirationAction consentExpirationAction)
        {
            _consentExpirationAction = consentExpirationAction.GuardNull(nameof(consentExpirationAction));
        }

        /// <summary>
        /// Run method for <see cref="ConsentExpirationFunction"/>.
        /// </summary>
        /// <param name="timer">Timer.</param>
        /// <param name="logger">Logger.</param>
        /// <param name="consentExpirationAction">Consent expiration action handler.</param>
        [Disable("IsStagingSlot")]
        [FunctionName(nameof(ConsentExpirationFunction))]
        public async Task Run(
            [TimerTrigger("%ConsentExpirationCronDuration%")] TimerInfo timer,
            ILogger logger)
        {

            logger.LogDebug("{FunctionName} execution started {StartTime}", nameof(ConsentExpirationFunction), DateTime.Now);
            await _consentExpirationAction.ProcessAsync();
            logger.LogInformation("{FunctionName} execution succeeded {EndTime}", nameof(ConsentExpirationFunction), DateTime.Now);
        }
    }
}
