using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Platform.Library.HealthChecks.Azure.Functions;
using System.Diagnostics.CodeAnalysis;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Health Check end point
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class HealthCheck
    {
        private readonly IFunctionAppHealthChecksExecutor _healthChecksExecutor;

        public HealthCheck(IFunctionAppHealthChecksExecutor healthChecksExecutor)
        {
            _healthChecksExecutor = healthChecksExecutor;
        }

        [FunctionName("HealthCheck")]
        public async Task<IActionResult> RunAsync(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "healthcheck")] HttpRequest request,
            CancellationToken cancellationToken)
        {
            return await _healthChecksExecutor.ExecuteAsync(request, cancellationToken);
        }
    }
}