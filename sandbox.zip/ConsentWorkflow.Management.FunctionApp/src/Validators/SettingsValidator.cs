﻿using FluentValidation;

namespace ConsentWorkflowManagementFunctionApp
{
    public class SettingsValidator : AbstractValidator<ISettings>
    {
        public SettingsValidator()
        {
            // Top level prpoerties
            RuleFor(s => s.ApimSubscriptionKey).NotEmpty();
            RuleFor(s => s.ConsentExpirationCronDuration).NotEmpty();
        }
    }
}
