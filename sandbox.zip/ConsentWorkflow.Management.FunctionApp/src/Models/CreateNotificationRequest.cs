﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Create notification request model.
    /// </summary>
    public class CreateNotificationRequest
    {
        /// <summary>
        /// Gets or sets customer id.
        /// </summary>
        [JsonProperty("customerId")]
        [JsonPropertyName("customerId")]
        public string CustomerId { get; set; }

        /// <summary>
        /// Gets or sets notification title.
        /// </summary>
        [JsonProperty("title")]
        [JsonPropertyName("title")]
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets notification body.
        /// </summary>
        [JsonProperty("body")]
        [JsonPropertyName("body")]
        public string Body { get; set; }

        /// <summary>
        /// Gets or sets notification category.
        /// </summary>
        [JsonProperty("category")]
        [JsonPropertyName("category")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether notification is actionable or not.
        /// </summary>
        [JsonProperty("actionable")]
        [JsonPropertyName("actionable")]
        public bool Actionable { get; set; }

        /// <summary>
        /// Gets or sets notification link text.
        /// </summary>
        [JsonProperty("linktext")]
        [JsonPropertyName("linktext")]
        public string Linktext { get; set; }

        /// <summary>
        /// Gets or sets notification link uri.
        /// </summary>
        [JsonProperty("linkuri")]
        [JsonPropertyName("linkuri")]
        public string Linkuri { get; set; }

        /// <summary>
        /// Gets or sets notification actionable context.
        /// </summary>
        [JsonProperty("actionableContext")]
        [JsonPropertyName("actionableContext")]
        public string ActionableContext { get; set; }
    }
}
