namespace ConsentWorkflowManagementFunctionApp
{
    public class BpayBillerCodeResponse
    {
        [JsonProperty("billerCode")]
        [JsonPropertyName("billerCode")]
        public string BillerCode { get; set; }
        
        [JsonProperty("shortName")]
        [JsonPropertyName("shortName")]
        public string ShortName { get; set; }
        
        [JsonProperty("longName")]
        [JsonPropertyName("longName")]
        public string LongName { get; set; }
        
        [JsonProperty("industryANZSICCode")]
        [JsonPropertyName("industryANZSICCode")]
        public string IndustryANZSICCode { get; set; }
        
        [JsonProperty("variableCrnIndicator")]
        [JsonPropertyName("variableCrnIndicator")]
        public string VariableCrnIndicator { get; set; }
        
        [JsonProperty("validCrnLengths")]
        [JsonPropertyName("validCrnLengths")]
        public List<int> ValidCrnLengths { get; set; }
        
        [JsonProperty("acceptedPaymentMethods")]
        [JsonPropertyName("acceptedPaymentMethods")]
        public List<string> AcceptedPaymentMethods { get; set; }
    }

}