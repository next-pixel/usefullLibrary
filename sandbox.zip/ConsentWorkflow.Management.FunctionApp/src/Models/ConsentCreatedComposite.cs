using Platform.Library.Events.Models;
using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;
using Platform.Library.T24.SDK.Modules.Lookup.ResponseDtos;
using Platform.Library.T24.SDK.Modules.Scheduled.ResponseDtos;

namespace ConsentWorkflowManagementFunctionApp
{
    public class ConsentCreatedComposite
    {
        public EV68ConsentCreatedPayload Payload { get; set; }
        
        public T24StandingOrderResponseDto StandingOrderResponse { get; set; }
        
        public T24AccountDetailResponseDto AccountDetailsResponse { get; set; }
        
        public T24InstitutionsNameResponseDto GetInstitutionResponse { get; set; }
        
        public BpayBillerCodeResponse BpayBillerCodeResponse { get; set; }
    }
}