﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Offset link or delink request model.
    /// </summary>
    public class OffsetLinkOrDelinkRequest
    {
        /// <summary>
        /// Gets or sets arrangment id.
        /// </summary>
        [JsonProperty("arrangementId")]
        [JsonPropertyName("arrangementId")]
        public string ArrangementId { get; set; }

        /// <summary>
        /// Gets or sets product id.
        /// </summary>
        [JsonProperty("productId")]
        [JsonPropertyName("productId")]
        public string ProductId { get; set; }

        /// <summary>
        /// Gets or sets offsets.
        /// </summary>
        [JsonProperty("offsets")]
        [JsonPropertyName("offsets")]
        public List<string> Offsets { get; set; }

        /// <summary>
        /// Gets or sets offsets.
        /// </summary>
        [JsonProperty("consentDetails")]
        [JsonPropertyName("consentDetails")]
        /// <summary>
        /// Gets or sets consent details.
        /// </summary>
        public ConsentDetails ConsentDetails { get; set; }
    }
}
