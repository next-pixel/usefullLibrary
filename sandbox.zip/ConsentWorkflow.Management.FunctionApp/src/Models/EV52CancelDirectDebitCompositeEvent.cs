﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsentWorkflowManagementFunctionApp.Models
{
    public class EV52CancelDirectDebitCompositeEvent
    {
        public IStandardHeaderModel StandardHeaderModel { get; set; }

        public string DirectDebitId { get; set; }
    }
}
