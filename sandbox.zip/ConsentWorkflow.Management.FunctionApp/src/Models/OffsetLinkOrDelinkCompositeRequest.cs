﻿using Platform.Library.Ods.Core.OdsDB.DataModel;
using Platform.Library.T24.SDK.Modules.Accounts.ResponseDtos;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Offset link or delink composite request model.
    /// </summary>
    public class OffsetLinkOrDelinkCompositeRequest
    {
        private OffsetLinkOrDelinkCompositeRequest(Consent consent, T24AccountDetailBody accountDetails)
        {
            Consent = consent;
            AccountDetails = accountDetails;
        }

        public static OffsetLinkOrDelinkCompositeRequest Define(Consent consent, T24AccountDetailBody accountDetails)
        {
            return new OffsetLinkOrDelinkCompositeRequest(consent, accountDetails);
        }

        /// <summary>
        /// Gets or sets consent.
        /// </summary>
        public Consent Consent { get; private set; }

        /// <summary>
        /// Gets or sets account details.
        /// </summary>
        public T24AccountDetailBody AccountDetails { get; private set; }
    }
}
