﻿using Platform.Library.T24.SDK.Common;

namespace ConsentWorkflowManagementFunctionApp
{
    public class PaymentDestination
    {
        /// <summary>
        /// Gets or sets payment type
        /// </summary>
        [JsonProperty("type")]
        [JsonPropertyName("type")]
        public PaymentTypesEnum Type { get; set; }

        /// <summary>
        /// Gets or sets beneficiary id
        /// </summary>
        [JsonProperty("beneficiaryId")]
        [JsonPropertyName("beneficiaryId")]
        public string BeneficiaryId { get; set; }

        /// <summary>
        /// Gets or sets beneficiary name
        /// </summary>
        [JsonProperty("beneficiaryName")]
        [JsonPropertyName("beneficiaryName")]
        public string BeneficiaryName { get; set; }

        /// <summary>
        /// Gets or sets arrangement id
        /// </summary>
        [JsonProperty("arrangementId")]
        [JsonPropertyName("arrangementId")]
        public string ArrangementId { get; set; }

        /// <summary>
        /// Gets or sets account number
        /// </summary>
        [JsonProperty("accountNumber")]
        [JsonPropertyName("accountNumber")]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets account bsb
        /// </summary>
        [JsonProperty("accountBSB")]
        [JsonPropertyName("accountBSB")]
        public string AccountBSB { get; set; }

        /// <summary>
        /// Gets or sets bpay biller code
        /// </summary>
        [JsonProperty("bPayBillerCode")]
        [JsonPropertyName("bPayBillerCode")]
        public string BpayBillerCode { get; set; }

        /// <summary>
        /// Gets or sets bpay crn
        /// </summary>
        [JsonProperty("bPayCrn")]
        [JsonPropertyName("bPayCrn")]
        public string BpayCrn { get; set; }

        /// <summary>
        /// Gets or sets payid
        /// </summary>
        [JsonProperty("payId")]
        [JsonPropertyName("payId")]
        public string PayId { get; set; }

        /// <summary>
        /// Gets or sets payid type
        /// </summary>
        [JsonProperty("payIdType")]
        [JsonPropertyName("payIdType")]
        public string PayIdType { get; set; }

        /// <summary>
        /// Gets or sets payid owner name
        /// </summary>
        [JsonProperty("payIdOwnerName")]
        [JsonPropertyName("payIdOwnerName")]
        public string PayIdOwnerName { get; set; }

        /// <summary>
        /// Gets or sets payid alias name
        /// </summary>
        [JsonProperty("payIdAliasName")]
        [JsonPropertyName("payIdAliasName")]
        public string PayIdAliasName { get; set; }
    }
}
