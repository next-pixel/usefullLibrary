﻿using Platform.Library.Ods.Core.OdsDB.DataModel.SubModels.Consent;

namespace ConsentWorkflowManagementFunctionApp
{
    public class CreateScheduledPaymentDestination
    {
        [JsonProperty("type")]
        [JsonPropertyName("type")]
        public PaymentType Type { get; set; }

        [JsonProperty("beneficiaryId")]
        [JsonPropertyName("beneficiaryId")]
        public string BeneficiaryId { get; set; }

        [JsonProperty("customerName")]
        [JsonPropertyName("customerName")]
        public string CustomerName { get; set; }

        [JsonProperty("arrangementId")]
        [JsonPropertyName("arrangementId")]
        public string ArrangementId { get; set; }

        [JsonProperty("accountNumber")]
        [JsonPropertyName("accountNumber")]
        public string AccountNumber { get; set; }

        [JsonProperty("accountBSB")]
        [JsonPropertyName("accountBSB")]
        public string AccountBSB { get; set; }

        [JsonProperty("bPayBillercode")]
        [JsonPropertyName("bPayBillercode")]
        public string BPayBillercode { get; set; }

        [JsonProperty("bPayCrn")]
        [JsonPropertyName("bPayCrn")]
        public string BPayCrn { get; set; }
    }
}
