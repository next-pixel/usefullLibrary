﻿namespace ConsentWorkflowManagementFunctionApp
{ 
    /// <summary>
    /// Model class for consent details.
    /// </summary>
    public class ConsentDetails
    {
        /// <summary>
        /// Gets or sets consent id.
        /// </summary>
        public string ConsentId { get; set; }

        /// <summary>
        /// Gets or sets request note.
        /// </summary>
        public string RequestNote { get; set; }
    }
}
