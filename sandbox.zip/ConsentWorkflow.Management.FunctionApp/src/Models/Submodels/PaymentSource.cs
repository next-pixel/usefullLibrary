﻿namespace ConsentWorkflowManagementFunctionApp
{
    public class PaymentSource
    {
        [JsonProperty("arrangementId")]
        [JsonPropertyName("arrangementId")]
        public string ArrangementId { get; set; }

        [JsonProperty("accountName")]
        [JsonPropertyName("accountName")]
        public string AccountName { get; set; }

        [JsonProperty("accountBSB")]
        [JsonPropertyName("accountBSB")]
        public string AccountBSB { get; set; }

        [JsonProperty("accountNumber")]
        [JsonPropertyName("accountNumber")]
        public string AccountNumber { get; set; }
    }
}
