﻿namespace ConsentWorkflowManagementFunctionApp
{
    public class CreateScheduledPaymentSource
    {
        [JsonProperty("customerName")]
        [JsonPropertyName("customerName")]
        public string CustomerName { get; set; }

        [JsonProperty("accountNumber")]
        [JsonPropertyName("accountNumber")]
        public string AccountNumber { get; set; }

        [JsonProperty("accountBSB")]
        [JsonPropertyName("accountBSB")]
        public string AccountBSB { get; set; }
    }
}
