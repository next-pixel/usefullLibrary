﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Initiate payment request.
    /// </summary>
    public class InitiatePaymentRequest
    {
        /// <summary>
        /// Gets or sets payment source.
        /// </summary>
        [JsonProperty("source")]
        [JsonPropertyName("source")]
        public PaymentSource Source { get; set; }

        /// <summary>
        /// Gets or sets payment destination.
        /// </summary>
        [JsonProperty("destination")]
        [JsonPropertyName("destination")]
        public PaymentDestination Destination { get; set; }

        /// <summary>
        /// Gets or sets amount.
        /// </summary>
        [JsonProperty("amount")]
        [JsonPropertyName("amount")]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets account balance.
        /// </summary>
        [JsonProperty("accountBalance")]
        [JsonPropertyName("accountBalance")]
        public decimal AccountBalance { get; set; }

        /// <summary>
        /// Gets or sets payment description.
        /// </summary>
        [JsonProperty("description")]
        [JsonPropertyName("description")]
        public string Description { get; set; }

        /// <summary>
        /// Payer-supplied reference for the payment (NPP Compliance).
        /// </summary>
        [JsonProperty("reference")]
        [JsonPropertyName("reference")]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets control flow id.
        /// </summary>
        [JsonProperty("controlFlowId")]
        [JsonPropertyName("controlFlowId")]
        public string ControlFlowId { get; set; }

        /// <summary>
        /// Gets or sets consent details.
        /// </summary>
        [JsonProperty("consentDetails")]
        [JsonPropertyName("consentDetails")]
        public ConsentDetails ConsentDetails { get; set; }
    }
}
