﻿using Platform.Library.T24.SDK.Modules.HomeLoan.RequestDtos;
using NsJson = Newtonsoft.Json;

namespace ConsentWorkflowManagementFunctionApp
{
    public class ExecuteSettlementInstructionsRequest
    {
        [JsonProperty("arrangementId")]
        [JsonPropertyName("arrangementId")]
        public string ArrangementId { get; set; }

        [JsonProperty("productId")]
        [JsonPropertyName("productId")]
        public string ProductId { get; set; }

        [JsonProperty("flowOption")]
        [JsonPropertyName("flowOption")]
        public FlowOption FlowOption { get; set; }

        [JsonProperty("repaymentAccountNumber")]
        [JsonPropertyName("repaymentAccountNumber")]
        public string RepaymentAccountNumber { get; set; }

        [JsonProperty("paymentSchedule")]
        [JsonPropertyName("paymentSchedule")]
        public PaymentSchedule PaymentSchedule { get; set; }

        [JsonProperty("repaymentAmount")]
        [JsonPropertyName("repaymentAmount")]
        public T24RepaymentRequestDto RepaymentAmount { get; set; }

        [JsonProperty("consentDetails")]
        [JsonPropertyName("consentDetails")]
        public ConsentDetails ConsentDetails { get; set; }
    }

    public class PaymentSchedule
    {
        [JsonProperty("dueDate", NullValueHandling = NullValueHandling.Ignore)]
        [JsonPropertyName("dueDate")]
        [MsJson.JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        [NsJson.JsonConverter(typeof(NsJson.Converters.DateOnlyConverter))]
        [MsJson.JsonConverter(typeof(DateOnlyConverter))]
        public DateTime? DueDate { get; set; }

        [JsonProperty("repaymentFrequency", DefaultValueHandling = DefaultValueHandling.Ignore)]
        [JsonPropertyName("repaymentFrequency")]
        [MsJson.JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public RepaymentFrequency RepaymentFrequency { get; set; }

        [JsonProperty("dayInterval", NullValueHandling = NullValueHandling.Ignore)]
        [JsonPropertyName("dayInterval")]
        [MsJson.JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public int? DayInterval { get; set; }
    }
}