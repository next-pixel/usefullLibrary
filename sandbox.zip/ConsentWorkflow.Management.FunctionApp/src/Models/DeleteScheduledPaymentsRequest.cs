﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Scheduled Payments request model.
    /// </summary>
    public class DeleteScheduledPaymentsRequest
    {
        /// <summary>
        /// The standing order ID.
        /// </summary>
        [JsonProperty(PropertyName = "standingOrderId")]
        [JsonPropertyName("standingOrderId")]
        public string StandingOrderId { get; set; }
    }
}
