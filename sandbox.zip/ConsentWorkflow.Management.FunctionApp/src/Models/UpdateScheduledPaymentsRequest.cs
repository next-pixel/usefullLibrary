﻿using Platform.Library.Ods.Core.OdsDB.DataModel.SubModels.Consent.Enumerations;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Scheduled Payments request model.
    /// </summary>
    public class UpdateScheduledPaymentsRequest
    {
        /// <summary>
        /// Amount to be paid.
        /// </summary>
        [JsonProperty(PropertyName = "amount")]
        [JsonPropertyName("amount")]
        public double Amount { get; set; }

        /// <summary>
        /// Frequency with which payments are to be made per these instructions.
        /// </summary>
        [JsonProperty(PropertyName = "frequency")]
        [JsonPropertyName("frequency")]
        public PaymentFrequency Frequency { get; set; }

        /// <summary>
        /// Date the payment instructions are to start. Format YYYY-MM-DD.
        /// </summary>
        [JsonProperty(PropertyName = "startDate")]
        [JsonPropertyName("startDate")]
        [System.Text.Json.Serialization.JsonConverter(typeof(DateOnlyConverter))]
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Date the payments instructions are to end. Format YYYY-MM-DD.
        /// </summary>
        [JsonProperty(PropertyName = "endDate")]
        [JsonPropertyName("endDate")]
        [System.Text.Json.Serialization.JsonConverter(typeof(DateOnlyConverter))]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Number of payments to be made per these instructions.
        /// </summary>
        [JsonProperty(PropertyName = "noOfTransfers")]
        [JsonPropertyName("noOfTransfers")]
        public string NoOfTransfers { get; set; }

        /// <summary>
        /// Description of the payment.
        /// </summary>
        [JsonProperty(PropertyName = "description")]
        [JsonPropertyName("description")]
        public string Description { get; set; }

    }
}
