﻿using Platform.Library.Ods.Core.OdsDB.DataModel.SubModels.Consent;
using Platform.Library.Ods.Core.OdsDB.DataModel.SubModels.Consent.Enumerations;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Scheduled Payments request model.
    /// </summary>
    public class CreateScheduledPaymentDetails
    {
        public string SourceCustomerName { get; set; }
        public string SourceAccountNumber { get; set; }
        public string SourceBsbNumber { get; set; }
        public PaymentType DestinationType { get; set; }
        public string DestinationBeneficiaryId { get; set; }
        public string DestinationBeneficiaryName { get; set; }
        public string DestinationArrangementId { get; set; }
        public string DestinationBsbNumber { get; set; }
        public string DestinationAccountNumber { get; set; }
        public string DestinationBPayBillerCode { get; set; }
        public string DestinationBPayCrn { get; set; }
        public double Amount { get; set; }
        public PaymentFrequency Frequency { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int? NoOfTransfers { get; set; }
        public string AccountBalance { get; set; }
        public string Description { get; set; }
    }
}
