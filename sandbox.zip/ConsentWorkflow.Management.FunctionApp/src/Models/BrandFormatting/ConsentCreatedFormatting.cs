﻿using Platform.Library.Common;

namespace ConsentWorkflowManagementFunctionApp
{
    public class ConsentCreatedFormatting : BaseFormattingResolver
    {
        public ConsentCreatedFormatting(IBrandDefinition brandDefinition) : base(brandDefinition, FormattingConstants.ConsentCreated) { }

        public string SuccessNotificationTitle => GetSectionProperty();
        public string SuccessNotificationBody => GetSectionProperty();
        public string ErrorNotificationTitle => GetSectionProperty();
        public string ErrorNotificationBody => GetSectionProperty();

        public string SuccessPushTitle => GetSectionProperty();
        public string SuccessPushBody => GetSectionProperty();

        public string ErrorPushTitle => GetSectionProperty();
        public string ErrorPushBody => GetSectionProperty();

        public string NotificationLinkText => GetSectionProperty();

        public string SMSBody(string givenName) => GetSectionProperty(nameof(SMSBody), givenName);

        public string SMSLinkUriCreated => GetLink();
        public string PushLinkUriCreated => GetLink();
        public string NotificationLinkUriCreated => GetLink();
    }
}
