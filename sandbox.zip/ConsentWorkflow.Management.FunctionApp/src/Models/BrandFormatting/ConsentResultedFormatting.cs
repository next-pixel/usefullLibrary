﻿using Platform.Library.Common;

namespace ConsentWorkflowManagementFunctionApp
{
    public class ConsentResultedFormatting : BaseFormattingResolver
    {
        public ConsentResultedFormatting(IBrandDefinition brandDefinition) : base(brandDefinition, FormattingConstants.ConsentResulted) { }

        public string SuccessNotificationTitle(string consentStatus) => GetSectionProperty(nameof(SuccessNotificationTitle), consentStatus);
        public string SuccessNotificationBody(string consentStatus) => GetSectionProperty(nameof(SuccessNotificationBody), consentStatus);
        public string ErrorNotificationTitle => GetSectionProperty();
        public string ErrorNotificationBody => GetSectionProperty();

        public string SuccessPushTitle(string consentStatus) => GetSectionProperty(nameof(SuccessPushTitle), consentStatus.ToLowerInvariant());
        public string SuccessPushBody(string consentStatus) => GetSectionProperty(nameof(SuccessPushBody), consentStatus.ToLowerInvariant());

        public string ErrorPushTitle => GetSectionProperty();
        public string ErrorPushBody => GetSectionProperty();

        public string NotificationLinkText => GetSectionProperty();

        public string SMSBody(string givenName, string consentStatus) => GetSectionProperty(nameof(SMSBody), givenName, consentStatus);

        public string NotificationLinkUriResulted => GetLink();
        public string PushLinkUriResulted => GetLink();
    }
}
