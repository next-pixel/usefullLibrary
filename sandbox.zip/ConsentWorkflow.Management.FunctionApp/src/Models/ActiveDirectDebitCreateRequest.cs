﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Direct debit create request.
    /// </summary>
    public class ActiveDirectDebitCreateRequest
    {
        [JsonProperty("directDebitId")]
        [JsonPropertyName("directDebitId")]
        public string DirectDebitId { get; set; }

        [JsonProperty("bsbNumber")]
        [JsonPropertyName("bsbNumber")]
        public string BsbNumber { get; set; }

        [JsonProperty("accountNumber")]
        [JsonPropertyName("accountNumber")]
        public string AccountNumber { get; set; }

        [JsonProperty("accountName")]
        [JsonPropertyName("accountName")]
        public string AccountName { get; set; }
    }
}
