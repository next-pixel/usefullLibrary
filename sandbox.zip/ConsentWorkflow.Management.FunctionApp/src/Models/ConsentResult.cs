﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    ///  Model to show if consent update event needs publishing.
    /// </summary>
    public class ConsentResult
    {
        private ConsentResult(bool toPublish, OdsModels.Consent consent, Exception exception)
        {
            ToPublish = toPublish;
            Consent = consent;
            Exception = exception;
        }

        public static ConsentResult NoUpdate(OdsModels.Consent consent) => new ConsentResult(false, consent, null);

        public static ConsentResult RequiresPublishing(OdsModels.Consent consent) => new ConsentResult(true, consent, null);

        public static ConsentResult Failure(OdsModels.Consent consent, Exception ex) => new ConsentResult(false, consent, ex);

        public bool ToPublish { get; private set; }
        public OdsModels.Consent Consent { get; private set; }
        public Exception Exception { get; private set; }
    }
}
