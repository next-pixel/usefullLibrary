﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Enum for consent status.
    /// </summary>
    public enum ConsentStatus
    {
        /// <summary>Expired</summary>
        EXPIRED,

        /// <summary>Pending</summary>
        PENDING,

        /// <summary>Cancelled/summary>
        CANCELLED,

        /// <summary>Declined</summary>
        DECLINED,

        /// <summary>Approved</summary>
        APPROVED
    }
}
