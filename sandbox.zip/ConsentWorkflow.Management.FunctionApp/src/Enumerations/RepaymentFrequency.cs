﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Enum for Repayment Frequency
    /// </summary>
    [MsJson.JsonConverter(typeof(JsonStringEnumConverter))]
    public enum RepaymentFrequency
    {
        /// <summary>
        /// The default value for the enumeration.
        /// </summary>
        None,

        /// <summary>
        /// Monthly payment frequency.
        /// </summary>
        MONTHLY,

        /// <summary>
        /// Fortnightly payment frequency.
        /// </summary>
        FORTNIGHTLY,

        /// <summary>
        /// Weekly payment frequency. 
        /// </summary>
        WEEKLY
    }
}