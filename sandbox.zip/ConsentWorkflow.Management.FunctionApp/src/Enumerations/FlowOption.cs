﻿using Platform.Library.Extensions;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Enum for Flow Option
    /// </summary>
    [MsJson.JsonConverter(typeof(JsonDenovoStringEnumConverter))]
    public enum FlowOption
    {
        /// <summary>
        /// The default value for the enumeration.
        /// </summary>
        _Unknown,

        /// <summary>
        /// Flow option for Account
        /// </summary>
        ACCOUNT,

        /// <summary>
        /// Flow option for Account and Schedule
        /// </summary>
        SCHEDAMOUNT,

        /// <summary>
        /// Flow option for Amount
        /// </summary>
        AMOUNT,

        /// <summary>
        /// Flow option for Schedule
        /// </summary>
        SCHEDULE
    }
}
