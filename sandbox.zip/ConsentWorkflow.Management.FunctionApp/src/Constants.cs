using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("ConsentWorkflowMgmt.UnitTests")]
namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Constants.
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// Configuration sections referenced
        /// </summary>
        public static class Configuration
        {
            /// <summary>Indicates this function app's configuration section</summary>
            public const string FunctionApp = "ConsentWorkflowMgmtFuncApp";

            /// <summary>Home Loan Management Client Settings</summary>
            public const string LoanManagementApi = nameof(LoanManagementApi);

            /// <summary>Notificaiton Centre Client Settings</summary>
            public const string NotificationCentre = nameof(NotificationCentre);

            /// <summary>Home Loan Repayments Client Settings</summary>
            public const string LoanRepaymentsApi = nameof(LoanRepaymentsApi);

            /// <summary>Payment Initiation Client Settings</summary>
            public const string PaymentInitiation = nameof(PaymentInitiation);

            /// <summary>Direct Debit Client Settings</summary>
            public const string DirectDebitApi = nameof(DirectDebitApi);
            
            /// <summary>Bpay Client Settings</summary>
            public const string Bpay = nameof(Bpay);

            /// <summary>Scheduled Payments Client Settings</summary>
            public const string ScheduledPaymentsApi = nameof(ScheduledPaymentsApi);

            /// <summary>Subscription key to use calling APIs via APIM</summary>
            public const string InternalApimSubscriptionKey = nameof(InternalApimSubscriptionKey);
        }

        public static class CommTypes
        {
            public const string ConsentCreated = "Consent Created";
            public const string ConsentResutedCategory = "Consent Resulted Communication";
            public const string ConsentWorkflowManagement = "Consent Workflow Management Communication";
        }

        public static class NotificationCentre
        {
            public static string CustomerId = "customerId";
            public const string NotificationActionContext = null;
            public const bool NotificationActionable = false;
            public const string MessageClass = "servicing.info";
            public const string CustomerNameConst = "preferredName";
            public const string EndpointURL = "int-notification-centre-url";
            public const string NotificationsString = "notifications";
        }

        public static class FormattingConstants
        {
            public const string ConsentCreated = nameof(ConsentCreated);
            public const string ConsentResulted = nameof(ConsentResulted);
        }

        public static class HttpClients
        {
            public const string CommunicationClient = nameof(CommunicationClient);
            public const string NotificationCentre = Configuration.NotificationCentre;
            public const string PaymentInitiation = Configuration.PaymentInitiation;
            public const string HomeLoanMgmtApi = Configuration.LoanManagementApi;
            public const string HomeLoanRepaymentsApi = Configuration.LoanRepaymentsApi;
            public const string DirectDebitApi = Configuration.DirectDebitApi;
            public const string ScheduledPaymentsApi = Configuration.ScheduledPaymentsApi;
            public const string Bpay = Configuration.Bpay;
            
            public static class MetaData
            {
                public const string Accept = "application/json";
                public const string InitiatingSystemId = "ConsentWorkflowManagement";
                public const string InitiatingSystemVersion = "V1.0";
                public const string SendingSystemId = "NotificationCentre";
                public const string SendingSystemVersion = "V1.0";
                public const string DateTimeFormat = "yyyy-MM-ddTHH:mm:ss.fffZ";
            }
        }

        /// <summary>Constants used with service bus</summary>
        public static class ServiceBus
        {
            /// <summary>Service Bus Configuration keys</summary>
            public static class Config
            {
                /// <summary>Configuration Key for service bus connection string</summary>
                public const string ConnectionString = "ServiceBus:ConnectionString01";
            }

            /// <summary>Service Bus Topics</summary>
            public static class Topics
            {
                /// <summary>Consent Topic (T51)</summary>
                public const string Consent = "t51.consent.topic";
            }

            /// <summary>Service Bus Subscriptions</summary>
            public static class Subscriptions
            {
                /// <summary>Consent Created Subscription (T51.1)</summary>
                public const string ConsentCreated = "t51.1.consent.created.subscription";
                /// <summary>Consent Updated Subscription (T51.2)</summary>
                public const string ConsentUpdated = "t51.2.consent.updated.subscription";
                /// <summary>Consent Resulted Subscription (T51.3)</summary>
                public const string ConsentResulted = "t51.3.consent.resulted.subscription";
            }

            public const string EV52CancelDirectDebitEventName = "EV52CancelDirectDebit";
            public const string EV52CancelDirectDebitTopic = "t37directdebit";
            public const string SendingSystemId = "DirectDebit";
            public const string SendingSystemVersion = "v1";
        }

        public static class ConsentDateTimeFormats
        {
            public const string Format = "yyyy-MM-ddTHH:mm:ssZ";
        }

        public static class CustomHeaders
        {
            public const string Authorization = nameof(Authorization);
            public const string TemenosCif = "temenos-cif";
            public const string AuthLevel = "azure-ad-auth-level";
            public const string InteractionId = "Interaction-Id";
            public const string SessionId = "Trusteer-Session-Id";
        }
        
        public static class QueryParameters
        {
            public const string StandingOrderId = "standingOrderId";
        }

        public static class PaymentOrderProducts
        {
            public const string VMAINTSTO = "VMAINTSTO";
            public const string VMAPARWITI = "VMAPARWITI";
            public const string VMABECSSTO = "VMABECSSTO";
            public const string VMAPARWITO = "VMAPARWITO";
            public const string VMABPAYSTO = "VMABPAYSTO";
        }

        public static class RegexPatterns
        {
            public const string PaymentScheduleLater = "e1D";
            public const string PaymentScheduleRecurring = "(e[12]W|e[13]M)";

            public static readonly TimeSpan Timeout = TimeSpan.FromMilliseconds(100);
        }
        
        public static class FrequencyCodes
        {
            public const string Daily = "e1D";
            public const string Weekly = "e1W";
            public const string Fortnightly = "e2W";
            public const string Monthly = "e1M";
            public const string Quarterly = "e3M";
        }

        public static class AzureAdAuthLevel
        {
            public const string L2 = "L2";
            public const string L3 = "L3";
        }
    }
}