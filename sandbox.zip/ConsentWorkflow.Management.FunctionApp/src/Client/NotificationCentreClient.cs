﻿using Microsoft.Extensions.Options;
using Platform.Library.Common.ErrorHandling;
using Platform.Library.Http.Abstractions;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Notification centre client.
    /// </summary>
    public class NotificationCentreClient : INotificationCentreClient
    {
        private readonly IHttpClientHelper _httpClientHelper;
        private readonly ISettings _settings;
        private readonly NotificationCentreSettings _notificationCentreSettings;
        private readonly ILogger<NotificationCentreClient> _logger;
        private readonly IAzureServiceTokenProviderClient _azureServiceProviderClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="NotificationCentreClient"/> class.
        /// </summary>
        /// <param name="httpClientHelper">Http client helper.</param>
        /// <param name="azureServiceProviderClient">Azure service provider client.</param>
        /// <param name="settings">Settings.</param>
        /// <param name="notificationCentreSettings">Notification Centre Client Settings</param>
        /// <param name="logger">Logger.</param>
        public NotificationCentreClient(
            IHttpClientHelper httpClientHelper,
            IAzureServiceTokenProviderClient azureServiceProviderClient,
            ISettings settings,
            IOptions<NotificationCentreSettings> notificationCentreSettings,
            ILogger<NotificationCentreClient> logger)
        {
            _httpClientHelper = httpClientHelper.GuardNull(nameof(httpClientHelper));
            _azureServiceProviderClient = azureServiceProviderClient.GuardNull(nameof(azureServiceProviderClient));
            _settings = settings.GuardNull(nameof(settings));
            _notificationCentreSettings = notificationCentreSettings.GuardNull(nameof(notificationCentreSettings));
            _logger = logger.GuardNull(nameof(logger));
        }

        /// <summary>
        /// Create notification.
        /// </summary>
        /// <param name="request">Request.</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <returns>true when notification is created successfully otherwise false.</returns>
        public async Task<bool> CreateNotification(
            CreateNotificationRequest request,
            CancellationToken cancellationToken)
        {
            _logger.LogDebug($"Started execution for {nameof(CreateNotification)}");

            var headers = StandardHeaderExtensions
                .GetStandardHeaders()
                .AsCustomHeaders()
                .AcceptsJson()
                .WithAzureAdTokenHeader(_azureServiceProviderClient);

            var httpResponse = await _httpClientHelper.PostAsync(
                Constants.HttpClients.NotificationCentre,
                _notificationCentreSettings.CreateNotificationPath,
                request,
                headers,
                null,
                cancellationToken);

            if (!httpResponse.IsSuccessStatusCode)
            {
                // Log response and convert to standard communication error
                _logger.LogError(ErrorMessageModelFactory.CreateErrorMessageModel(
                    httpResponse.StatusCode.ToString(),
                    httpResponse.ReasonPhrase));
                throw StandardApiExceptionFactory.CreateInternalServerErrorStandardApiException();
            }

            _logger.LogDebug($"Completed execution for {nameof(CreateNotification)}");
            return true;
        }
    }
}
