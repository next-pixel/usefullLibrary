﻿using Platform.Library.Common;
using Platform.Library.Communication.Extensions;
using static Platform.Library.Communication.Extensions.Constants;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Communication client.
    /// </summary>
    public class CommunicationClient : ICommunicationClient
    {
        private readonly IBrandResolver _brandResolver;
        private readonly IServiceBusEventPublisher _serviceBusEventPublisher;
        private readonly ISettings _settings;
        private readonly ICommunicationMapper _communicationMapper;
        private readonly ILogger<CommunicationClient> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="CommunicationClient"/> class.
        /// </summary>
        /// <param name="pushNotificationSuccessContent">Push notification success content.</param>
        /// <param name="serviceBusEventPublisher">Service bus event publisher.</param>
        /// <param name="settings">Settings.</param>
        /// <param name="communicationMapper">Communication mapper.</param>
        /// <exception cref="ArgumentNullException">Throws <see cref="ArgumentNullException"/> when any args is null.</exception>
        public CommunicationClient(
            IBrandResolver brandResolver,
            IServiceBusEventPublisher serviceBusEventPublisher,
            ISettings settings,
            ICommunicationMapper communicationMapper,
            ILogger<CommunicationClient> logger)
        {
            _brandResolver = brandResolver.GuardNull(nameof(brandResolver));
            _serviceBusEventPublisher = serviceBusEventPublisher.GuardNull(nameof(serviceBusEventPublisher));
            _settings = settings.GuardNull(nameof(settings));
            _communicationMapper = communicationMapper.GuardNull(nameof(communicationMapper));
            _logger = logger.GuardNull(nameof(logger));
        }

        /// <summary>
        /// Send push or sms notifications.
        /// </summary>
        /// <param name="isRequestSuccess">Is request a success or not.</param>
        /// <param name="customerId">Customer id.</param>
        /// <param name="customerName">Customer name.</param>
        /// <param name="consentStatus">Consent status.</param>
        /// <returns>Represent async operation.</returns>
        public async Task SendPushOrSmsNotifications(bool isRequestSuccess, string customerId, string customerName, string consentStatus)
        {
            var formatting = _brandResolver.Definition().ExtractFormatting<ConsentResultedFormatting>();

            _logger.LogDebug($"Started execution for {nameof(SendPushOrSmsNotifications)}");

            var pushNotificationEvent = GetEv32CommunicationPreparedEvent(
                channelType: CommunicationChannel.Push,
                customerId: customerId,
                customerName: customerName,
                bodyText: isRequestSuccess ? formatting.SuccessPushBody(consentStatus) : formatting.ErrorPushBody,
                title: isRequestSuccess ? formatting.SuccessPushTitle(consentStatus) : formatting.ErrorPushTitle,
                link: formatting.PushLinkUriResulted
            );

            await _serviceBusEventPublisher.CreateAndPublishEvent(_settings.ServiceBus.CommunicationEV32PreparedTopic, pushNotificationEvent);
            _logger.LogInformation($"{nameof(EventModels.EV32CommunicationPreparedEvent)} for push notification published successfully.");

            if (isRequestSuccess)
            {
                var smsNotificationEvent = GetEv32CommunicationPreparedEvent(
                    channelType: CommunicationChannel.Sms,
                    customerId: customerId,
                    customerName: customerName,
                    bodyText: formatting.SMSBody(customerName, consentStatus)
                );

                await _serviceBusEventPublisher.CreateAndPublishEvent(_settings.ServiceBus.CommunicationEV32PreparedTopic, smsNotificationEvent);
                _logger.LogInformation($"{nameof(EventModels.EV32CommunicationPreparedEvent)} for sms notification published successfully.");
            }
        }

        private EventModels.EV32CommunicationPreparedEvent GetEv32CommunicationPreparedEvent(string channelType, string customerId, string customerName, string bodyText, string title = null, string link = null)
        {
           return _communicationMapper.CreateConsentWorkflowManagementEv32CommunicationEvent(
                    systemId: nameof(ConsentResultedFunction),
                    recipientId: customerId,
                    customerId: customerId,
                    customerFirstName: customerName,
                    channelType: channelType,
                    bodyText: bodyText,
                    title: title,
                    link: link);
        }
    }
}
