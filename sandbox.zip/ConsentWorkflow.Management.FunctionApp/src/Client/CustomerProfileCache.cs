﻿using ConsentWorkflowManagementFunctionApp.Client.Abstractions;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.Modules.Customer.ResponseDtos;
using System.Collections.Concurrent;

namespace ConsentWorkflowManagementFunctionApp
{
    public class CustomerProfileCache : ICustomerProfileCache
    {
        private readonly ConcurrentDictionary<string, Lazy<Task<GetContactDetailsResponse>>> _cache = new();

        private readonly ILogger<CustomerProfileCache> _logger;
        private readonly IT24CustomerClient _t24CustomerClient;

        public CustomerProfileCache(IT24CustomerClient customerClient, ILogger<CustomerProfileCache> logger)
        {
            _t24CustomerClient = customerClient.GuardNull(nameof(customerClient));
            _logger = logger.GuardNull(nameof(logger));
        }

        public async Task<GetContactDetailsResponse> GetCustomerContactDetailsAsync(string customerId, CancellationToken cancellationToken = default)
        {
            return await GetCustomerContactDetailsAsync(customerId, null, null, cancellationToken);
        }

        public Task<GetContactDetailsResponse> GetCustomerContactDetailsAsync(string customerId, IStandardHeaderModel standardHeaders, IDictionary<string, string> customHeaders, CancellationToken cancellationToken = default)
        {
            // check if the customer cache is enabled, then call T24 to get the customer details
            // otherwise, try to get it from local customer cache
            var customerContactDetail = _t24CustomerClient.IsCustomerCached
                ? GetDataForCustomerProfile(customerId, standardHeaders, customHeaders, cancellationToken)
                : _cache.GetOrAdd(customerId, new Lazy<Task<GetContactDetailsResponse>>(GetDataForCustomerProfile(customerId, standardHeaders, customHeaders, cancellationToken)))?.Value;

            return customerContactDetail;
        }

        private async Task<GetContactDetailsResponse> GetDataForCustomerProfile(string customerId, IStandardHeaderModel standardHeaders, IDictionary<string, string> customHeaders, CancellationToken cancellationToken = default)
        {
            var headers = standardHeaders
                .AsCustomHeaders()
                .With(customHeaders);

            try
            {
                var customerContactDetail = await _t24CustomerClient.GetContactDetailsAsync(customerId, headers, cancellationToken);
                return customerContactDetail;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Unable to retrieve customer {{CIF}} from T24 for {nameof(CustomerProfileCache)}: {{ErrorMessage}}", customerId, ex.Message);
                throw;
            }
        }
    }
}
