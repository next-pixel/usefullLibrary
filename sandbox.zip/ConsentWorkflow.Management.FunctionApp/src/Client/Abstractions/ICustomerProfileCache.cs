﻿using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.Modules.Customer.ResponseDtos;

namespace ConsentWorkflowManagementFunctionApp.Client.Abstractions
{
    /// <summary>
    /// Interface for the <see cref="CustomerProfileCache"/>
    /// </summary>
    public interface ICustomerProfileCache
    {
        /// <summary>
        /// Retrieve the <see cref="GetContactDetailsResponse"/> from T24 or the cached value
        /// </summary>
        /// <param name="customerId">CIF of the customer to retrieve</param>
        /// <param name="cancellationToken"><see cref="CancellationToken"/> for this asynchronous process</param>
        /// <returns>A cached instance of <see cref="GetContactDetailsResponse"/></returns>
        Task<GetContactDetailsResponse> GetCustomerContactDetailsAsync(string customerId, CancellationToken cancellationToken = default);

        /// <summary>
        /// Retrieve the <see cref="GetContactDetailsResponse"/> from T24 or the cached value
        /// </summary>
        /// <param name="customerId">CIF of the customer to retrieve</param>
        /// <param name="standardHeaders">Standard Headers to use for call to customer profile</param>
        /// <param name="customHedaers">Additional headers required for the call</param>
        /// <param name="cancellationToken"><see cref="CancellationToken"/> for this asynchronous process</param>
        /// <returns>A cached instance of <see cref="GetContactDetailsResponse"/></returns>
        Task<GetContactDetailsResponse> GetCustomerContactDetailsAsync(string customerId, IStandardHeaderModel standardHeaders, IDictionary<string, string> customHeaders, CancellationToken cancellationToken = default);
    }
}
