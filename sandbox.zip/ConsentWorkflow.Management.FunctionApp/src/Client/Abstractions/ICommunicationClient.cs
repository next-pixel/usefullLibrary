﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Interface for communication client.
    /// </summary>
    public interface ICommunicationClient
    {
        /// <summary>
        /// Send push or sms notifications.
        /// </summary>
        /// <param name="isRequestSuccess">Is request a success or not.</param>
        /// <param name="customerId">Customer id.</param>
        /// <param name="customerName">Customer name.</param>
        /// <param name="consentStatus">Consent status.</param>
        /// <returns>Represent async operation.</returns>
        Task SendPushOrSmsNotifications(bool isRequestSuccess, string customerId, string customerName, string consentStatus);
    }
}
