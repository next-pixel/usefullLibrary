﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Interface for notification centre client.
    /// </summary>
    public interface INotificationCentreClient
    {
        /// <summary>
        /// Create notification.
        /// </summary>
        /// <param name="request">Request.</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <returns>true when notification is created successfully otherwise false.</returns>
        Task<bool> CreateNotification(CreateNotificationRequest request, CancellationToken cancellationToken);
    }
}
