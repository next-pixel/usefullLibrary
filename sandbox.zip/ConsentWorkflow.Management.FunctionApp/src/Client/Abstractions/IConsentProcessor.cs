﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Interface for consent procesor.
    /// </summary>
    /// <remarks>IMPORTANT: Any implementation of <see cref="IConsentProcessor"/> should support <see cref="ILogger{ConsentProcessor}">logging</see></remarks>
    public interface IConsentProcessor
    {
        /// <summary>
        /// To process consents which are APPROVED.
        /// </summary>
        /// <param name="consent">Consent.</param>
        /// <param name="standardHeaders">Standard headers to use for downstream clients</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <returns>Represent async operation.</returns>
        /// <exception cref="UnrecoverableMessageException">Throw <see cref="UnrecoverableMessageException"/> when request type is invalid.</exception>
        public Task ProcessApprovedConsents(OdsModels.Consent consent, IStandardHeaderModel standardHeaders, CancellationToken cancellationToken);

        /// <summary>
        /// To process consent which are CANCELLED, DECLINED or EXPIRED.
        /// </summary>
        /// <param name="consent">Consent.</param>
        /// <param name="standardHeaders">Standard headers to use for downstream clients</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <returns>Represents async operation.</returns>
        public Task ProcessUnapprovedConsents(OdsModels.Consent consent, IStandardHeaderModel standardHeaders, CancellationToken cancellationToken);

        /// <summary>
        /// To process scheduled payment consent for extra info.
        /// </summary>
        /// <param name="consent">Consent.</param>
        /// <param name="standardHeaders">Standard Headers to use for downstream clients</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <returns>Represents async operation.</returns>
        public Task ProcessScheduledPaymentConsent(ConsentCreatedComposite consent, IStandardHeaderModel standardHeaders, CancellationToken cancellationToken);
    }
}
