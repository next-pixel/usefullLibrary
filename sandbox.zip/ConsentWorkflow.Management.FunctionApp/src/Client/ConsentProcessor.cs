using AutoMapper;
using ConsentWorkflowManagementFunctionApp.Client.Abstractions;
using ConsentWorkflowManagementFunctionApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Platform.Library.Common;
using Platform.Library.Common.Standard.ErrorHandling;
using Platform.Library.Communication.Extensions;
using Platform.Library.Events.Models;
using Platform.Library.Events.Models.Enum;
using Platform.Library.Http.Abstractions;
using Platform.Library.Ods.Core.OdsDB.DataModel;
using Platform.Library.Ods.Core.OdsDB.DataModel.SubModels.Consent;
using Platform.Library.Ods.Core.OdsDB.DataModel.SubModels.Consent.Enumerations;
using Platform.Library.T24.SDK;
using StandingOrderAction = Platform.Library.Ods.Core.OdsDB.DataModel.SubModels.Consent.Enumerations.StandingOrderAction;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Consent procesor class
    /// </summary>
    /// <remarks>IMPORTANT: <see cref="ConsentProcessor"/> already supports <see cref="ILogger{ConsentProcessor}">logging</see></remarks>
    public class ConsentProcessor : IConsentProcessor
    {
        private readonly ICustomerProfileCache _customerProfileCache;
        private readonly IT24AccountClient _t24AccountClient;
        private readonly IT24PaymentClient _t24PaymentClient;
        private readonly ISettings _settings;
        private readonly HomeLoansMgmtSettings _homeLoanMgmtSettings;
        private readonly HomeLoansRepaymentsSettings _homeLoanRepaymentSettings;
        private readonly ScheduledPaymentsSettings _scheduledPaymentsSettings;
        private readonly PaymentInitiationSettings _paymentInitiationSettings;
        private readonly DirectDebitSettings _directDebitSettings;
        private readonly BpaySettings _bpaySettings;
        private readonly IMapper _mapper;
        private readonly IHttpClientHelper _httpClientHelper;
        private readonly ICommunicationClient _communicationClient;
        private readonly IAzureServiceTokenProviderClient _azureServiceProviderClient;
        private readonly INotificationCentreClient _notificationCentreClient;
        private readonly IBrandResolver _brandResolver;
        private readonly ILogger<ConsentProcessor> _logger;
        private readonly IServiceBusEventPublisher _serviceBusEventPublisher;

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsentProcessor"/> class.
        /// </summary>
        /// <param name="accountClient">T24 client</param>
        /// <param name="paymentClient">T24 client</param>
        /// <param name="settings">Settings.</param>
        /// <param name="homeLoanMgmtSettings">Home Loan Management Client Settings</param>
        /// <param name="homeLoanRepaymentsSettings">Home Loan Repayments Client Settings</param>
        /// <param name="scheduledPaymentsSettings">Scheduled Payments Client Settings</param>
        /// <param name="paymentInitiationSettings">Payment Initiation Client Settings</param>
        /// <param name="directDebitsSettings">Direct Debit Client SEttings</param>
        /// <param name="mapper">Mapper.</param>
        /// <param name="httpClientHelper">Helper for Http calls</param>
        /// <param name="communicationClient">Communication client.</param>
        /// <param name="brandResolver">Brand resolver.</param>
        /// <param name="accountClient">T24 account client</param>
        /// <param name="azureServiceProviderClient">Service provider client</param>
        /// <param name="notificationCentreClient">Notificaiton centre client</param>
        /// <param name="customerProfileCache">Customer Profile Cache</param>
        /// <param name="logger">Logger.</param>
        /// <exception cref="ArgumentNullException">Throws <see cref="ArgumentNullException"/> when any parameter is null.</exception>
        public ConsentProcessor(
            IOptions<HomeLoansMgmtSettings> homeLoanMgmtSettings,
            IOptions<HomeLoansRepaymentsSettings> homeLoanRepaymentsSettings,
            IOptions<ScheduledPaymentsSettings> scheduledPaymentsSettings,
            IOptions<PaymentInitiationSettings> paymentInitiationSettings,
            IOptions<DirectDebitSettings> directDebitsSettings,
            IOptions<BpaySettings> bpaySettings,
            ISettings settings,
            IMapper mapper,
            IHttpClientHelper httpClientHelper,
            ICommunicationClient communicationClient,
            IBrandResolver brandResolver,
            IT24AccountClient accountClient,
            IT24PaymentClient paymentClient,
            IAzureServiceTokenProviderClient azureServiceProviderClient,
            ICustomerProfileCache customerProfileCache,
            INotificationCentreClient notificationCentreClient,
            IServiceBusEventPublisher serviceBusEventPublisher,
            ILogger<ConsentProcessor> logger)
        {
            _settings = settings.GuardNull(nameof(settings));
            _serviceBusEventPublisher = serviceBusEventPublisher.GuardNull(nameof(serviceBusEventPublisher));
            _homeLoanMgmtSettings = homeLoanMgmtSettings.GuardNull(nameof(homeLoanMgmtSettings));
            _homeLoanRepaymentSettings = homeLoanRepaymentsSettings.GuardNull(nameof(homeLoanRepaymentsSettings));
            _scheduledPaymentsSettings = scheduledPaymentsSettings.GuardNull(nameof(scheduledPaymentsSettings));
            _paymentInitiationSettings = paymentInitiationSettings.GuardNull(nameof(paymentInitiationSettings));
            _directDebitSettings = directDebitsSettings.GuardNull(nameof(directDebitsSettings));
            _bpaySettings = bpaySettings.GuardNull(nameof(bpaySettings));
            _mapper = mapper.GuardNull(nameof(mapper));
            _httpClientHelper = httpClientHelper.GuardNull(nameof(httpClientHelper));
            _communicationClient = communicationClient.GuardNull(nameof(communicationClient));
            _brandResolver = brandResolver.GuardNull(nameof(brandResolver));
            _t24AccountClient = accountClient.GuardNull(nameof(accountClient));
            _t24PaymentClient = paymentClient.GuardNull(nameof(paymentClient));
            _azureServiceProviderClient = azureServiceProviderClient.GuardNull(nameof(azureServiceProviderClient));
            _notificationCentreClient = notificationCentreClient.GuardNull(nameof(notificationCentreClient));
            _customerProfileCache = customerProfileCache.GuardNull(nameof(customerProfileCache));
            _logger = logger.GuardNull(nameof(logger));
        }

        /// <summary>
        /// To process consents which are APPROVED.
        /// </summary>
        /// <param name="consent">Consent.</param>
        /// <param name="standardHeaders">Standard Headers to use for downstream clients</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <returns>Represent async operation.</returns>
        /// <exception cref="UnrecoverableMessageException">Throw <see cref="UnrecoverableMessageException"/> when request type is invalid.</exception>
        public async Task ProcessApprovedConsents(OdsModels.Consent consent, IStandardHeaderModel standardHeaders, CancellationToken cancellationToken)
        {
            if (!Enum.TryParse<ConsentRequestTypeEnum>(consent.RequestType, out var requestType))
            {
                throw _logger.LogAndRaiseUnrecoverableException("Unable to process consent {ConsentId} with invalid request type {RequestType}", consent.ConsentId, consent.RequestType);
            }

            var requestorCustomerId = consent?.Parties?.FirstOrDefault(x => x.Role == ConsentCustomerRole.REQUESTOR)?.CustomerId;

            var customHeaders = CustomHeadersBuilder
                .With(Constants.CustomHeaders.TemenosCif, requestorCustomerId)
                .With(Constants.CustomHeaders.AuthLevel, AzureAdAuthLevel.L2)
                .With(Constants.CustomHeaders.InteractionId, Guid.NewGuid().ToString())
                .With(Constants.CustomHeaders.SessionId, Guid.NewGuid().ToString())
                .AcceptsJson()
                .WithAzureAdTokenHeader(_azureServiceProviderClient, _settings.AzureAd.ResourceId);

            switch (requestType)
            {
                case ConsentRequestTypeEnum.PAYMENT:

                    var initiatePaymentRequest = await GetInitiatePaymentRequest(consent, standardHeaders, cancellationToken);

                    customHeaders.With(Constants.CustomHeaders.AuthLevel, AzureAdAuthLevel.L3);

                    await InitiateRequestAsync(
                        HttpClients.PaymentInitiation,
                        standardHeaders,
                        customHeaders,
                        consent,
                        initiatePaymentRequest,
                        _paymentInitiationSettings.InitiatePaymentPath,
                        HttpMethod.Post,
                        cancellationToken);

                    _logger.LogInformation("Initiate payment is complete for consent {ConsentId}", consent.ConsentId);
                    break;

                case ConsentRequestTypeEnum.OFFSET:

                    var offsetLinkOrDelinkRequest = await GetLinkOrDelinkRequest(consent, standardHeaders, cancellationToken);

                    await InitiateRequestAsync(
                        HttpClients.HomeLoanMgmtApi,
                        standardHeaders,
                        customHeaders,
                        consent,
                        offsetLinkOrDelinkRequest,
                        _homeLoanMgmtSettings.ManageOffsetPath.FormatNullSafe(consent.AccountDetails.BundleArrangementId),
                        HttpMethod.Patch,
                        cancellationToken);

                    _logger.LogInformation($"Offset Linked or Delinked in {HttpClients.HomeLoanMgmtApi} for consent {{ConsentId}}", consent.ConsentId);
                    break;

                case ConsentRequestTypeEnum.REPAYINT:
                case ConsentRequestTypeEnum.REPAYMNT:

                    var executeSettlementInstructionsRequest = _mapper.Map<ExecuteSettlementInstructionsRequest>(consent);

                    await InitiateRequestAsync(
                        HttpClients.HomeLoanRepaymentsApi,
                        standardHeaders,
                        customHeaders,
                        consent,
                        executeSettlementInstructionsRequest,
                        _homeLoanRepaymentSettings.ExecuteSettlementInstructionsPath.FormatNullSafe(consent.AccountDetails.ArrangementId),
                        HttpMethod.Post,
                        cancellationToken);
                    _logger.LogInformation($"Executing settlement instructions in {HttpClients.HomeLoanRepaymentsApi} for consent {{ConsentId}}", consent.ConsentId);
                    break;

                case ConsentRequestTypeEnum.REPAYEXT:

                    var directDebitCreateRequest = _mapper.Map<ActiveDirectDebitCreateRequest>(consent);

                    await InitiateRequestAsync(
                        HttpClients.DirectDebitApi,
                        standardHeaders,
                        customHeaders,
                        consent,
                        directDebitCreateRequest,
                        _directDebitSettings.CreateActiveDirectDebitPath.FormatNullSafe(consent.AccountDetails.ArrangementId),
                        HttpMethod.Post,
                        cancellationToken);

                    if (!string.IsNullOrWhiteSpace(directDebitCreateRequest.DirectDebitId))
                    {
                        var compositeEvent = new EV52CancelDirectDebitCompositeEvent
                        {
                            DirectDebitId = directDebitCreateRequest.DirectDebitId,
                            StandardHeaderModel = standardHeaders
                        };

                        var ev52MappedEvent = _mapper.Map<EV52CancelDirectDebitEvent>(compositeEvent);
                        await _serviceBusEventPublisher.CreateAndPublishEvent(ServiceBus.EV52CancelDirectDebitTopic, ev52MappedEvent);

                        _logger.LogInformation($"Cancel direct debit event published for {{ConsentId}}", consent.ConsentId);
                    }

                    _logger.LogInformation($"Active direct debit created in {HttpClients.DirectDebitApi} for consent {{ConsentId}}", consent.ConsentId);
                    break;

                case ConsentRequestTypeEnum.SCHEDPAY:
                    await SchedulePayments(consent, cancellationToken, standardHeaders, customHeaders);

                    break;

                default:

                    throw _logger.LogAndRaiseUnrecoverableException("Unable to process consent {ConsentId} with unsupported request type {RequestType}", consent.ConsentId, requestType);
            }
        }

        private async Task SchedulePayments(OdsModels.Consent consent, CancellationToken cancellationToken, IStandardHeaderModel standardHeaders, IDictionary<string, string> customHeaders)
        {
            var standingOrderAction = consent.RequestDetails.Payments.StandingOrderAction;
            var hasMandatoryFields = (!string.IsNullOrEmpty(consent.AccountDetails.AccountNumber) && !string.IsNullOrEmpty(consent.AccountDetails.BsbNumber));

            try
            {
                if (standingOrderAction == StandingOrderAction.CREATE)
                {
                    if (!hasMandatoryFields)
                    {
                        throw _logger.LogAndRaiseUnrecoverableException("Mandatory fields missing for creating scheduled payments for {ConsentId}", consent.ConsentId);
                    }

                    var createScheduledPaymentRequest = await GetCreateScheduledPaymentRequest(consent, standardHeaders, cancellationToken);

                    if (createScheduledPaymentRequest != null)
                    {
                        await InitiateRequestAsync(
                            HttpClients.ScheduledPaymentsApi,
                            standardHeaders,
                            customHeaders,
                            consent,
                            createScheduledPaymentRequest,
                            _scheduledPaymentsSettings.CreateScheduledPaymentPath.FormatNullSafe(consent.AccountDetails.ArrangementId),
                            HttpMethod.Post,
                            cancellationToken);

                        _logger.LogInformation($"Scheduled payments created in {HttpClients.ScheduledPaymentsApi} for consent {{ConsentId}}", consent.ConsentId);
                    }
                }
                else if (standingOrderAction == StandingOrderAction.UPDATE)
                {
                    var updateScheduledPaymentRequest = _mapper.Map<UpdateScheduledPaymentsRequest>(consent);

                    await InitiateRequestAsync(
                        HttpClients.ScheduledPaymentsApi,
                        standardHeaders,
                        customHeaders,
                        consent,
                        updateScheduledPaymentRequest,
                        _scheduledPaymentsSettings.UpdateScheduledPaymentPath.ReplaceStandingOrderId(consent),
                        HttpMethod.Put,
                        cancellationToken);

                    _logger.LogInformation($"Scheduled payments updated for {HttpClients.ScheduledPaymentsApi} for consent {{ConsentId}}", consent.ConsentId);
                }
                else if (standingOrderAction == StandingOrderAction.DELETE)
                {
                    await InitiateRequestAsync(
                        HttpClients.ScheduledPaymentsApi,
                        standardHeaders,
                        customHeaders,
                        consent,
                        string.Empty,
                        _scheduledPaymentsSettings.DeleteScheduledPaymentPath.ReplaceStandingOrderId(consent),
                        HttpMethod.Delete,
                        cancellationToken);

                    _logger.LogInformation($"Scheduled payments deleted for {HttpClients.ScheduledPaymentsApi} for consent {{ConsentId}}", consent.ConsentId);
                }
            }
            catch (Exception ex)
            {
                throw _logger.LogAndRaiseUnrecoverableException("Mandatory fields missing or validation failure {ConsentId}", consent.ConsentId, ex.Message);
            }
        }

        private CreateScheduledPaymentDetails GetConsentDetails(OdsModels.Consent consent, string availableBalance)
        {
            return new CreateScheduledPaymentDetails
            {
                SourceCustomerName = string.Concat(consent.Requestor.FirstName, " ", consent.Requestor.LastName),
                SourceAccountNumber = consent.AccountDetails.AccountNumber,
                SourceBsbNumber = consent.AccountDetails.BsbNumber,
                DestinationType = (PaymentType)consent.RequestDetails.Payments.Destination.Type,
                DestinationBeneficiaryId = consent.RequestDetails.Payments.Destination.BeneficiaryId,
                DestinationBeneficiaryName = consent.RequestDetails.Payments.Destination.BeneficiaryName,
                DestinationArrangementId = consent.RequestDetails.Payments.Destination.ArrangementId,
                DestinationAccountNumber = consent.RequestDetails.Payments.Destination.AccountNumber,
                DestinationBsbNumber = consent.RequestDetails.Payments.Destination.BsbNumber,
                DestinationBPayBillerCode = consent.RequestDetails.Payments.Destination.BPayBillerCode,
                DestinationBPayCrn = consent.RequestDetails.Payments.Destination.BPayCrn,
                Amount = consent.RequestDetails.Payments.Amount,
                Frequency = (PaymentFrequency)consent.RequestDetails.Payments.Frequency,
                StartDate = consent.RequestDetails.Payments.StartDate.Value,
                EndDate = consent.RequestDetails.Payments.EndDate,
                NoOfTransfers = consent.RequestDetails.Payments.NoOfTransfers,
                AccountBalance = availableBalance,
                Description = consent.RequestDetails.Payments.Description
            };
        }

        private async Task<InitiatePaymentRequest> GetInitiatePaymentRequest(OdsModels.Consent consent, IStandardHeaderModel standardHeaders, CancellationToken cancellationToken)
        {
            try
            {
                var accountDetailsResponse = await _t24AccountClient.GetAccountDetailsAsync(
                    consent.AccountDetails.ArrangementId,
                    standardHeaders
                        .AsCustomHeaders()
                        .AcceptsJson(),
                    cancellationToken
                );

                var availableBalance = accountDetailsResponse.Body.FirstOrDefault()?.AvailableBalance;
                var initiatePaymentRequest = _mapper.Map<InitiatePaymentRequest>(consent);
                initiatePaymentRequest.AccountBalance = Convert.ToDecimal(availableBalance);

                return initiatePaymentRequest;
            }
            catch (Exception ex)
            {
                throw _logger.LogAndRaiseUnrecoverableException(ex, "Error occured while building Initial Payments request for {ConsentId} and ArrangementId {ArrangementId}", consent.ConsentId, consent.AccountDetails.ArrangementId);
            }
        }

        private async Task<CreateScheduledPaymentsRequest> GetCreateScheduledPaymentRequest(OdsModels.Consent consent, IStandardHeaderModel standardHeaders, CancellationToken cancellationToken)
        {
            try
            {
                var accountDetailsResponse = await _t24AccountClient.GetAccountDetailsAsync(
                    consent.AccountDetails.ArrangementId,
                    standardHeaders
                        .AsCustomHeaders()
                        .AcceptsJson(),
                    cancellationToken
                );

                var accountDetails = accountDetailsResponse
                    .Body?
                    .FirstOrDefault();

                var createScheduledPaymentDetails = GetConsentDetails(consent, string.IsNullOrWhiteSpace(accountDetails.AvailableBalance) ? accountDetails.AvailableBalance : "0");

                return _mapper.Map<CreateScheduledPaymentsRequest>(createScheduledPaymentDetails);
            }
            catch (Exception ex)
            {
                throw _logger.LogAndRaiseUnrecoverableException(ex, "Error occured while building Scheduled Payments request for {ConsentId} and ArrangementId {ArrangementId}", consent.ConsentId, consent.AccountDetails.ArrangementId);
            }
        }

        private async Task<OffsetLinkOrDelinkRequest> GetLinkOrDelinkRequest(OdsModels.Consent consent, IStandardHeaderModel standardHeaders, CancellationToken cancellationToken)
        {
            try
            {
                var accountDetailsResponse = await _t24AccountClient.GetAccountDetailsAsync(
                    consent.AccountDetails.ArrangementId,
                    standardHeaders
                        .AsCustomHeaders()
                        .AcceptsJson(),
                    cancellationToken
                );

                var accountDetails = accountDetailsResponse
                    .Body?
                    .FirstOrDefault();

                var offsetLinkOrDelinkCompositeRequest = OffsetLinkOrDelinkCompositeRequest.Define(consent, accountDetails);

                return _mapper.Map<OffsetLinkOrDelinkRequest>(offsetLinkOrDelinkCompositeRequest);
            }
            catch (StandardApiException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw _logger.LogAndRaiseUnrecoverableException(ex, "Error occured while building {0} offset account request for {ConsentId} and ArrangementId {ArrangementId}", consent.RequestDetails.Offsets.OffsetAction.ToString(), consent.ConsentId, consent.AccountDetails.ArrangementId);
            }
        }

        /// <summary>
        /// To process consent which are CANCELLED, DECLINED or EXPIRED.
        /// </summary>
        /// <param name="consent">Consent.</param>
        /// <param name="standardHeaders">Standard Headers to use for downstream clients</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <returns>Represents async operation.</returns>
        public async Task ProcessUnapprovedConsents(OdsModels.Consent consent, IStandardHeaderModel standardHeaders, CancellationToken cancellationToken)
        {
            _logger.LogDebug($"Processing unapproved consent {{ConsentId}} for {consent.DescribeConsentParties()}", consent.ConsentId);

            var customerParties = consent.Parties;
            foreach (var party in customerParties)
            {
                var customer = await _customerProfileCache.GetCustomerContactDetailsAsync(party.CustomerId, cancellationToken);
                var customerName = customer?.GivenName;

                _logger.LogInformation($"Creating notification");
                var createNotificationRequest = _brandResolver.GetNotificationCreateRequest(
                    consent.Status,
                    party.CustomerId,
                    customerName,
                    CommTypes.ConsentResutedCategory
                );

                await _notificationCentreClient.CreateNotification(createNotificationRequest, cancellationToken);

                await _communicationClient.SendPushOrSmsNotifications(true, party.CustomerId, customerName, consent.Status);
            }
        }

        /// <summary>
        /// Takes a newly created scheduled payment consent and enriches based on payment order product type
        /// </summary>
        /// 
        /// <param name="consent">Consent.</param>
        /// <param name="standardHeaders">Standard Headers to use for downstream clients</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <returns>Represents async operation.</returns>
        public async Task ProcessScheduledPaymentConsent(ConsentCreatedComposite consent, IStandardHeaderModel standardHeaders, CancellationToken cancellationToken)
        {
            _logger.LogDebug("Processing scheduled payment consent {ConsentId}", consent.Payload.ConsentId);

            var customHeaders = standardHeaders
                .AsCustomHeaders()
                .AcceptsJson();

            var queryParams = new Dictionary<string, string>
            {
                { T24SdkConstants.QueryParameter.ArrangementId, consent.Payload.AccountDetails.ArrangementId },
                { QueryParameters.StandingOrderId, consent.Payload.RequestDetails.Payment.StandingOrderId }
            };

            consent.StandingOrderResponse = await _t24PaymentClient.GetStandingOrdersAsync(customHeaders, queryParams, cancellationToken);

            var pendingTransaction = consent.StandingOrderResponse.Body.FirstOrDefault()?.PendingTransactions.FirstOrDefault();

            var paymentOrderProduct = pendingTransaction?.PaymentOrderProduct?.ToUpper();

            switch (paymentOrderProduct)
            {
                case PaymentOrderProducts.VMAINTSTO:
                case PaymentOrderProducts.VMAPARWITI:
                    consent.AccountDetailsResponse = await _t24AccountClient.GetAccountDetailsAsync(pendingTransaction.CounterPartyAccountId, customHeaders, cancellationToken);
                    break;

                case PaymentOrderProducts.VMABECSSTO:
                case PaymentOrderProducts.VMAPARWITO:
                    consent.GetInstitutionResponse = await _t24PaymentClient.GetInstitutionNameAsync(pendingTransaction.AccountWithBankClearingCode, customHeaders, cancellationToken);
                    break;

                case PaymentOrderProducts.VMABPAYSTO:
                    if (pendingTransaction.BeneficiaryAccountId != null)
                    {
                        var httpResponse = await SendGetRequestToHttpClient(_bpaySettings.ClientName, _bpaySettings.GetBpayBillerDetailsPath.Replace("{0}", pendingTransaction.BeneficiaryAccountId), standardHeaders, customHeaders, cancellationToken);
                        var content = await httpResponse.Content.ReadAsStringAsync();
                        consent.BpayBillerCodeResponse = JsonConvert.DeserializeObject<BpayBillerCodeResponse>(content);
                    }
                    break;
                default:
                    _logger.LogAndRaiseUnrecoverableException($"PaymentOrderProduct.{pendingTransaction?.PaymentOrderProduct ?? "NULL"} is not supported by {nameof(ProcessScheduledPaymentConsent)}");
                    break;
            }
        }

        /// <summary>
        /// Send Get request to http client.
        /// </summary>
        /// <param name="clientName">Client name.</param>
        /// <param name="uri">Client uri.</param>
        /// <param name="headers">Custom headers.</param>
        /// <param name="customHeaders"> </param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <param name="standardHeaders"> </param>
        /// <returns>HttpResponseMessage</returns>
        private async Task<HttpResponseMessage> SendGetRequestToHttpClient(string clientName, string uri, IStandardHeaderModel standardHeaders, IDictionary<string, string> customHeaders, CancellationToken cancellationToken)
        {
            HttpResponseMessage httpResponse = null;

            try
            {
                httpResponse = await _httpClientHelper.GetAsync(
                    httpClientName: clientName,
                    uri: uri,
                    customHeaders: customHeaders,
                    standardHeaderModel: standardHeaders,
                    cancellationToken: cancellationToken);

                if (!_logger.TryParseHttpResponse(httpResponse, clientName, HttpMethod.Get, uri))
                    return httpResponse;
            }
            catch (Exception ex)
            {
                _logger.LogStandardException(clientName, HttpMethod.Get, uri, ex);
            }

            _logger.LogDebug($"Completed execution for {nameof(SendGetRequestToHttpClient)}");
            return httpResponse;
        }

        /// <summary>
        /// Initiate a request.
        /// </summary>
        /// <typeparam name="T">Generic type.</typeparam>
        /// <param name="clientName">Client name.</param>
        /// <param name="standardHeaders">Standard Headers to use for downstream clients</param>
        /// <param name="consent">Consent status.</param>
        /// <param name="request">Request.</param>
        /// <param name="uri">Client uri.</param>
        /// <param name="httpVerb">Http verb for client.</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <returns>Represents async task.</returns>
        public async Task InitiateRequestAsync<T>(string clientName, IStandardHeaderModel standardHeaders, IDictionary<string, string> customHeaders, Consent consent, T request, string uri, HttpMethod httpVerb, CancellationToken cancellationToken = default)
        {
            _logger.LogDebug($"Started execution for {nameof(InitiateRequestAsync)}");

            var consentStatus = consent.Status;

            var isRequestProcessed = await SendRequestToHttpClient(clientName, httpVerb, request, uri, standardHeaders, customHeaders, cancellationToken);

            foreach (var customerId in consent.Parties.Select(party => party.CustomerId))
            {
                var customerContactDetail = await _customerProfileCache.GetCustomerContactDetailsAsync(customerId, standardHeaders, customHeaders, cancellationToken);

                _logger.LogInformation($"Creating notification");
                var createNotificationRequest = _brandResolver.GetNotificationCreateRequest(
                    consentStatus,
                    customerId,
                    customerContactDetail?.GivenName,
                    CommTypes.ConsentResutedCategory,
                    isRequestProcessed
                );

                await _notificationCentreClient.CreateNotification(
                    createNotificationRequest,
                    cancellationToken);

                await _communicationClient.SendPushOrSmsNotifications(isRequestProcessed, customerId, customerContactDetail?.GivenName, consentStatus);
            }

            _logger.LogDebug($"Completed execution for {nameof(InitiateRequestAsync)}");
        }

        /// <summary>
        /// Send request to http client.
        /// </summary>
        /// <typeparam name="T">Generic type.</typeparam>
        /// <param name="clientName">Client name.</param>
        /// <param name="httpVerb">Http verb.</param>
        /// <param name="request">Request body.</param>
        /// <param name="uri">Client uri.</param>
        /// <param name="headers">Custom headers.</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <returns>Represent true when request is successful otherwise false.</returns>
        private async Task<bool> SendRequestToHttpClient<T>(string clientName, HttpMethod httpVerb, T request, string uri, IStandardHeaderModel standardHeaders, IDictionary<string, string> customHeaders, CancellationToken cancellationToken)
        {
            try
            {
                var httpResponse = await CallRespectiveHttpClient(clientName, httpVerb, request, uri, standardHeaders, customHeaders, cancellationToken);

                if (!_logger.TryParseHttpResponse(httpResponse, clientName, httpVerb, uri))
                    return false;
            }
            // Excluded from Sonar Coverage as cost to cover is too high
            catch (Exception ex)
            {
                return _logger.LogStandardException(clientName, httpVerb, uri, ex);
            }

            _logger.LogDebug($"Completed execution for {nameof(SendRequestToHttpClient)}");
            return true;
        }

        /// <summary>
        /// Call respective http client.
        /// </summary>
        /// <typeparam name="T">Generic type.</typeparam>
        /// <param name="clientName">Client name.</param>
        /// <param name="httpVerb">Http verb.</param>
        /// <param name="request">Request body.</param>
        /// <param name="uri">Client uri.</param>
        /// <param name="headers">Customer headers.</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <returns>Represent async operation.</returns>
        private async Task<HttpResponseMessage> CallRespectiveHttpClient<T>(string clientName, HttpMethod httpVerb, T request, string uri, IStandardHeaderModel standardHeaders, IDictionary<string, string> customHeaders, CancellationToken cancellationToken)
        {
            _logger.LogDebug($"{nameof(CallRespectiveHttpClient)} - {clientName} : {httpVerb} {uri}");
            try
            {
                if (HttpMethods.IsPost(httpVerb.Method))
                    return await _httpClientHelper.PostAsync(
                        httpClientName: clientName,
                        uri: uri,
                        request: request,
                        customHeaders: customHeaders,
                        standardHeaderModel: standardHeaders,
                        cancellationToken: cancellationToken);

                if (HttpMethods.IsPatch(httpVerb.Method))
                    return await _httpClientHelper.PatchAsync(
                        httpClientName: clientName,
                        uri: uri,
                        request: request,
                        customHeaders: customHeaders,
                        standardHeaderModel: standardHeaders,
                        cancellationToken: cancellationToken);

                if (HttpMethods.IsPut(httpVerb.Method))
                    return await _httpClientHelper.PutAsync(
                        httpClientName: clientName,
                        uri: uri,
                        request: request,
                        customHeaders: customHeaders,
                        standardHeaderModel: standardHeaders,
                        cancellationToken: cancellationToken);

                if (HttpMethods.IsDelete(httpVerb.Method))
                    return await _httpClientHelper.DeleteAsync(
                        httpClientName: clientName,
                        uri: uri,
                        customHeaders: customHeaders,
                        standardHeaderModel: standardHeaders,
                        cancellationToken: cancellationToken);
            }
            finally
            {
                _logger.LogDebug($"Completed execution for {nameof(CallRespectiveHttpClient)}");
            }

            return null;
        }
    }
}
