namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// <see cref="ClientSettings"/> for API-to-API communications with the Home Loan Management Api
    /// </summary>
    public class HomeLoansMgmtSettings : ClientSettings
    {
        /// <inheritdoc cref="ClientSettings.ConfigName"/>
        public override string ConfigName => Configuration.LoanManagementApi;

        /// <summary>
        /// Path to manage offsets
        /// </summary>
        public string ManageOffsetPath { get; set; }
    }
}
