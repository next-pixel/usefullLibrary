﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// <see cref="ClientSettings"/> for API-to-API communication with the Notification Centre API
    /// </summary>
    public class NotificationCentreSettings : ClientSettings
    {
        /// <inheritdoc cref="ClientSettings.ConfigName"/>
        public override string ConfigName => Configuration.NotificationCentre;

        /// <summary>
        /// Path to creating a notification
        /// </summary>
        public string CreateNotificationPath { get; set; }
    }
}
