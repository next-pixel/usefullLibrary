﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Servicebus options.
    /// </summary>
    public class ServiceBusConfigurationOptions : IServiceBusConfigurationOptions
    {
        /// <summary>
        /// Gets or sets connection string for 1st region.
        /// </summary>
        public string ConnectionString01 { get; set; }

        /// <summary>
        /// Gets or sets Connection string for 2nd region.
        /// </summary>
        public string ConnectionString02 { get; set; }

        /// <summary>
        /// Gets or sets T51 consent topic name.
        /// </summary>
        public string T51ConsentTopicName { get; set; }

        /// <summary>
        /// Gets or sets EV32 comms prepared event topic name.
        /// </summary>
        public string CommunicationEV32PreparedTopic { get; set; }
    }
}
