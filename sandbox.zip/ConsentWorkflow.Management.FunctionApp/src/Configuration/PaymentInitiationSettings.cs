﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// <see cref="ClientSettings"/> for API-to-API communication with the Payment Initiation API
    /// </summary>
    public class PaymentInitiationSettings : ClientSettings
    {
        /// <inheritdoc cref="ClientSettings.ConfigName"/>
        public override string ConfigName => Configuration.PaymentInitiation;

        /// <summary>
        /// Path to initiate a payment
        /// </summary>
        public string InitiatePaymentPath { get; set; }
    }
}
