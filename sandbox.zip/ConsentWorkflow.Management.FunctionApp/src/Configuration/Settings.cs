﻿using Library.Azure.Functions.Extensions.Configuration;
using Microsoft.Extensions.Configuration;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Settings class.
    /// </summary>
    public class Settings : StandardFunctionSettings, ISettings
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Settings"/> class.
        /// </summary>
        /// <param name="configuration">Configuration.</param>
        public Settings(IConfiguration configuration) : base(configuration)
        {
            configuration.AssertArgumentIsNotNull("ConfigurationRoot");
            configuration.Bind(this);
        }

        /// <summary>
        /// Gets or sets APIM subscription key.
        /// </summary>
        public string ApimSubscriptionKey { get; set; }

        /// <summary>
        /// Gets or sets service bus options.
        /// </summary>
        public IServiceBusConfigurationOptions ServiceBus { get; set; } = new ServiceBusConfigurationOptions();

        /// <summary>
        /// Gets or sets ODS options.
        /// </summary>
        public IOdsOptions Ods { get; set; } = new OdsOptions();

        /// <summary>
        /// Gets or sets cron duration for triggering consent expiration function.
        /// </summary>
        public string ConsentExpirationCronDuration { get; set; }

        public AzureAd AzureAd { get; } = new();
    }
}
