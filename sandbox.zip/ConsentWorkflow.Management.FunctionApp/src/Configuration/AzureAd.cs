﻿namespace ConsentWorkflowManagementFunctionApp
{
    public class AzureAd
    {
        public string ResourceId { get; set; }
    }
}
