﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// <see cref="ClientSettings"/> for API-to-API connectivity with the Direct Debits API
    /// </summary>
    public class ScheduledPaymentsSettings : ClientSettings
    {
        /// <inheritdoc cref="ClientSettings.ConfigName"/>
        public override string ConfigName => Constants.Configuration.ScheduledPaymentsApi;

        /// <summary>
        /// Path to creating a scheduled payment
        /// </summary>
        public string CreateScheduledPaymentPath { get; set; }

        /// <summary>
        /// Path to updating a scheduled payment
        /// </summary>
        public string UpdateScheduledPaymentPath { get; set; }

        /// <summary>
        /// Path to deleting a scheduled payment
        /// </summary>
        public string DeleteScheduledPaymentPath { get; set; }
    }
}
