﻿namespace ConsentWorkflowManagementFunctionApp
{ 
    /// <summary>
    /// Interface for settings.
    /// </summary>
    public interface ISettings
    {
        /// <summary>
        /// Gets APIM subscription key.
        /// </summary>
        string ApimSubscriptionKey { get; }

        /// <summary>
        /// Gets service bus options.
        /// </summary>
        IServiceBusConfigurationOptions ServiceBus { get; }

        /// <summary>
        /// Gets ODS options.
        /// </summary>
        IOdsOptions Ods { get; }

        /// <summary>
        /// Gets cron duration for triggering consent expiration function.
        /// </summary>
        string ConsentExpirationCronDuration { get; }

        /// <summary>
        /// Gets AzureAd
        /// </summary>
        AzureAd AzureAd { get; }
    }
}
