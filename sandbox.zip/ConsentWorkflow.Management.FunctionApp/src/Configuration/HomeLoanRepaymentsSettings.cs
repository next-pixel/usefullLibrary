namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// <see cref="ClientSettings"/> for API-to-API communication with the Home Loan Repayments API
    /// </summary>
    public class HomeLoansRepaymentsSettings : ClientSettings
    {
        /// <inheritdoc cref="ClientSettings.ConfigName"/>
        public override string ConfigName => Configuration.LoanRepaymentsApi;

        /// <summary>
        /// Path to executing settlement instructions
        /// </summary>
        public string ExecuteSettlementInstructionsPath { get; set; }
    }
}
