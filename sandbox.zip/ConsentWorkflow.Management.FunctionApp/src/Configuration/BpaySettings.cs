namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// <see cref="ClientSettings"/> for API-to-API communication with the BPay API
    /// </summary>
    public class BpaySettings : ClientSettings
    {
        /// <inheritdoc cref="ClientSettings.ConfigName"/>
        public override string ConfigName => Configuration.Bpay;

        /// <summary>
        /// Path to get biller details
        /// </summary>
        public string GetBpayBillerDetailsPath { get; set; }
    }
}

