namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// <see cref="ClientSettings"/> for API-to-API connectivity with the Direct Debits API
    /// </summary>
    public class DirectDebitSettings : ClientSettings
    {
        /// <inheritdoc cref="ClientSettings.ConfigName"/>
        public override string ConfigName => Configuration.DirectDebitApi;

        /// <summary>
        /// Path to creating an active direct debit
        /// </summary>
        public string CreateActiveDirectDebitPath { get; set; }
    }
}
