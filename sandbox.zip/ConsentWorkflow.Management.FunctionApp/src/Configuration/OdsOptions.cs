﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Ods options.
    /// </summary>
    public class OdsOptions : IOdsOptions
    {
        /// <summary>
        /// Gets or sets ODS consents database name.
        /// </summary>
        public string OdsConsentDatabaseName { get; set; }

        /// <summary>
        /// Gets or sets ODS consents collection name.
        /// </summary>
        public string OdsConsentCollectionName { get; set; }

        /// <summary>
        /// Gets or sets ODS Tenant id.
        /// </summary>
        public string TenantId { get; set; }

        /// <summary>
        /// Gets or sets ODS service end point.
        /// </summary>
        public string ServiceEndPoint { get; set; }

        /// <summary>
        /// Gets or sets ODS auth key.
        /// </summary>
        public string AuthKey { get; set; }
    }
}
