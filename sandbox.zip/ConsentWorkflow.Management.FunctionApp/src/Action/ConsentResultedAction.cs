﻿using Platform.Library.BaseEvent;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Action handler for processing consent resulted events.
    /// </summary>
    /// <typeparam name="T">Generic type for <see cref="EV70ConsentResulted"/>.</typeparam>
    public class ConsentResultedAction<T> : MessageHandler<T>
        where T : EventModels.EV70ConsentResulted
    {
        private readonly IOdsConsentsRepository _odsConsentsRepository;
        private readonly IConsentProcessor _consentProcessor;
        private readonly ILogger<ConsentResultedAction<T>> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsentResultedAction{T}"/> class.
        /// </summary>
        /// <param name="odsConsentsRepository">Ods consents repository.</param>
        /// <param name="consentProcessor">Consent processor.</param>
        /// <param name="logger">Logger.</param>
        /// <exception cref="ArgumentNullException">Throws <see cref="ArgumentNullException"/> when any parameter is null.</exception>
        public ConsentResultedAction(
            IOdsConsentsRepository odsConsentsRepository,
            IConsentProcessor consentProcessor,
            ILogger<ConsentResultedAction<T>> logger)
        {
            _odsConsentsRepository = odsConsentsRepository ?? throw new ArgumentNullException(nameof(odsConsentsRepository));
            _consentProcessor = consentProcessor ?? throw new ArgumentNullException(nameof(consentProcessor));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <summary>
        /// Adds extra logic to payload from event.
        /// </summary>
        /// <param name="payload">Payload.</param>
        /// <param name="context">Message context.</param>
        /// <param name="logger">Logger.</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <returns>Task operation.</returns>
        protected override async Task ActionPayload(T payload, ProcessMessageContext context, ILogger logger, CancellationToken cancellationToken)
        {
            // Construct standard headers from metadata
            var standardHeaders = payload
                .Metadata
                .MapMetadataTo<StandardHeaderModel>()
                .Update(HttpClients.MetaData.SendingSystemId, HttpClients.MetaData.SendingSystemVersion);

            _logger.LogDebug($"{this.ReadableTypeName()} processing event {payload.Metadata.EventName} with message id {payload.Metadata.MessageId}");

            List<OdsModels.Consent> consents = null;
            try
            {
                consents = await _odsConsentsRepository.SearchOdsForEntitiesAsync(c => c.ConsentId == payload.Payload.ConsentId, null)
                    ?? new();
            }
            catch ( Exception ex )
            {
                throw _logger.LogAndRaiseUnrecoverableException(ex, "Unable to retrieve consent with id {ConsentId} from ODS: {ErrorMessage}", payload.Payload.ConsentId, ex.Message);
            }

            // If we have more than one consent something went wrong?
            if ( consents.Count != 1 )
                throw _logger.LogAndRaiseUnrecoverableException("Unable to process - Unexpected number of consents returned ({ConsentCount})", consents.Count);

            var consent = consents.First();

            if (Enum.TryParse<ConsentStatus>(consent.Status, out var consentStatus))
            {
                if (consentStatus.In(ConsentStatus.CANCELLED,ConsentStatus.DECLINED,ConsentStatus.EXPIRED) )
                    await _consentProcessor.ProcessUnapprovedConsents(consent, standardHeaders, cancellationToken);
                else if (consentStatus == ConsentStatus.APPROVED)
                    await _consentProcessor.ProcessApprovedConsents(consent, standardHeaders, cancellationToken);
                else
                    throw _logger.LogAndRaiseUnrecoverableException(
                        new NotSupportedException($"{nameof(ConsentStatus)}.{consentStatus} is not currently supported by {this.ReadableTypeName()}.{nameof(ActionPayload)}"),
                        "Unable to process - consent status {ConsentStatus} not supported",
                        consentStatus
                    );
            }
            else
                throw _logger.LogAndRaiseUnrecoverableException("Unable to process - consent status {ConsentStatus} is invalid.", consentStatus);
        }
    }
}
