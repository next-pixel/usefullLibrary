﻿using Platform.Library.Communication.Extensions;
using Platform.Library.Ods.Core.OdsDB.DataModel.SubModels.Consent.Enumerations;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Action handler for <see cref="ConsentExpirationAction"/>.
    /// </summary>
    public class ConsentExpirationAction : IConsentExpirationAction
    {
        private readonly IOdsConsentsRepository _odsConsentRepository;
        private readonly IServiceBusEventPublisher _serviceBusEventPublisher;
        private readonly ISettings _settings;
        private readonly ILogger<ConsentExpirationAction> _logger;
        private readonly ICommunicationMapper _communicationMapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsentExpirationAction"/> class.
        /// Constructor for <see cref="ConsentExpirationAction"/>.
        /// </summary>
        /// <param name="odsConsentRepository">Ods consent client.</param>
        /// <param name="serviceBusEventPublisher">Servicebus event publisher.</param>
        /// <param name="settings">Settings.</param>
        /// <param name="logger">Logger.</param>
        /// <exception cref="ArgumentNullException">Throws ArgumentNullException when either of the argument is null.</exception>
        public ConsentExpirationAction(
            IOdsConsentsRepository odsConsentRepository,
            IServiceBusEventPublisher serviceBusEventPublisher,
            ISettings settings,
            ILogger<ConsentExpirationAction> logger,
            ICommunicationMapper communicationMapper)
        {
            _odsConsentRepository = odsConsentRepository.GuardNull(nameof(odsConsentRepository));
            _serviceBusEventPublisher = serviceBusEventPublisher.GuardNull(nameof(serviceBusEventPublisher));
            _settings = settings.GuardNull(nameof(settings));
            _logger = logger.GuardNull(nameof(logger));
            _communicationMapper = communicationMapper.GuardNull(nameof(communicationMapper));
        }

        /// <summary>
        /// Process event.
        /// </summary>
        /// <returns>Task.</returns>
        public async Task ProcessAsync()
        {
            // Take a snapshot of the current time
            var currentUtcDateTime = DateTime.UtcNow;
            _logger.LogDebug($"Started executing {nameof(ConsentExpirationAction)}.{nameof(ProcessAsync)} at {currentUtcDateTime.ToString(ConsentDateTimeFormats.Format)} with cron duration '{_settings.ConsentExpirationCronDuration}'");

            var consents = new List<OdsModels.Consent>();
            try
            {
                // Retrieve list of expired consents. Consent should satisfy either of the 2 conditions
                consents = (await _odsConsentRepository.SearchOdsForEntitiesAsync(
                    c =>
                    // Condition 1: Status is PENDING and
                    (c.Status.Equals(ConsentStatus.PENDING.ToString()) &&

                    // Condition 2a: ExpiryDateTime is LESS THAN OR EQUALS Current Date
                    (c.ExpiryDateTime <= currentUtcDateTime  
                    
                    // OR Condition 2b: StandingOrderAction is CREATE or UPDATE and StartDate is LESS THAN OR EQUALS Current Date
                    || ((c.RequestDetails.Payments.StandingOrderAction == StandingOrderAction.CREATE || c.RequestDetails.Payments.StandingOrderAction == StandingOrderAction.UPDATE)
                        && c.RequestDetails.Payments.StartDate <= currentUtcDateTime)))
                    , null))
                    ?? new();
            }
            catch ( Exception ex )
            {
                _logger.LogError(ex, $"{nameof(ConsentExpirationAction)}.{nameof(ProcessAsync)} was unable to retrieve consents from ODS: {ex.Message}");
                return;
            }

            var totalConsents = consents.Count;
            var failedUpdates = new List<(OdsModels.Consent Consent, string Action, Exception Exception)>();
            foreach (var consent in consents)
            {
                var action = "updating consent model";
                try
                {
                    // Updating consent model
                    consent.UpdateExpiredConsent(currentUtcDateTime);

                    // Updating Ods
                    action = "updating ODS";
                    await _odsConsentRepository.UpdateAsync(consent);

                    // publish EV70 consent resulted on T51 consent topic
                    action = "mapping to EV70ConsentResultedEvent";
                    var ev70ConsentResultedEvent = _communicationMapper.MapEv70ConsentResultedEvent(consent);

                    action = "publishing EV70ConsentResultedEvent";
                    await _serviceBusEventPublisher.CreateAndPublishEvent(_settings.ServiceBus.T51ConsentTopicName, ev70ConsentResultedEvent);
                }
                catch (Exception ex)
                {
                    // Collect any failed updates for reporting afterwards
                    failedUpdates.Add((consent, action, ex));
                }
            }

            // Handle results (Unsuccessful updates will simply be processed when the timer triggers next)
            if (failedUpdates.Any())
            {
                var aggregateException = new AggregateException(failedUpdates.FormatFailureMessage(), failedUpdates.Select(f => f.Exception));
                _logger.LogError(aggregateException, aggregateException.Message);
            }
            else if (totalConsents > 0)
                _logger.LogInformation($"Completed execution of {nameof(ConsentExpirationAction)}.{nameof(ProcessAsync)}: {totalConsents} consent(s) processed");
            else
                _logger.LogDebug($"Completed execution of {nameof(ConsentExpirationAction)}.{nameof(ProcessAsync)}: No consents processed");
        }
    }
}