﻿using AutoMapper;
using ConsentWorkflowManagementFunctionApp.Client.Abstractions;
using Microsoft.AspNetCore.Http;
using Platform.Library.BaseEvent;
using Platform.Library.Common;
using Platform.Library.Communication.Extensions;
using Platform.Library.Ods.Core.OdsDB.DataModel;
using Platform.Library.T24.SDK;
using Platform.Library.T24.SDK.Modules.Customer.ResponseDtos;
using ComConstants = Platform.Library.Communication.Extensions.Constants;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Consent Created Action Handler Implementation.
    /// </summary>
    /// <typeparam name="T">Type is Ev68ConsentCreatedEvent.</typeparam>
    public class ConsentCreatedAction<T> : MessageHandler<T>
        where T : EventModels.EV68ConsentCreatedEvent
    {
        private readonly ISettings _settings;
        private readonly IServiceBusEventPublisher _serviceBusEventPublisher;
        private readonly INotificationCentreClient _notificationCentreClient;
        private readonly ICommunicationMapper _communicationMapper;
        private readonly IOdsConsentsRepository _odsConsentRepository;
        private readonly ICustomerProfileCache _customerProfileCache;
        private readonly IConsentProcessor _consentProcessor;
        private readonly ILogger<ConsentCreatedAction<T>> _logger;
        private readonly IMapper _mapper;
        private readonly IBrandResolver _brandResolver;

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsentCreatedAction{T}"/> class.
        /// </summary>
        /// <param name="settings">Instance of ISettings.</param>
        /// <param name="sbEventPublisher">Instance of IServiceBusEventPublisher.</param>
        /// <param name="notificationCentreClient">Instance of INotificationCentreClient.</param>
        /// <param name="communicationMapper">Instance of ICommunicationMapper.</param>
        /// <param name="odsConsentRepository">Instance of IOdsConsentRepository.</param>
        /// <param name="customerProfileCache">Singleton cache for customer profiles</param>
        /// <param name="logger">Instance of ILogger<ConsentCreatedAction<T>>.</param>
        /// <param name="mapper">Instance of IMapper.</param>
        /// <param name="brandResolver">Instance of IBrandResolver.</param>
        /// <param name="t24GetAccountDetailHandler">T24 get account detail handler.</param>
        /// <param name="t24GetStandingOrdersHandler">T24 get standing orders handler </param>
        /// <param name="t24InstitutionNamesHandler">T24 get institution name handler </param>
        public ConsentCreatedAction(
            ISettings settings,
            IServiceBusEventPublisher sbEventPublisherInstance,
            INotificationCentreClient notificationCentreClient,
            ICommunicationMapper communicationMapper,
            IOdsConsentsRepository odsConsentRepository,
            ICustomerProfileCache customerProfileCache,
            IConsentProcessor consentProcessor,
            ILogger<ConsentCreatedAction<T>> logger,
            IMapper mapper,
            IBrandResolver brandResolver)
        {
            _settings = settings.GuardNull(nameof(settings));
            _serviceBusEventPublisher = sbEventPublisherInstance.GuardNull(nameof(sbEventPublisherInstance));
            _notificationCentreClient = notificationCentreClient.GuardNull(nameof(notificationCentreClient));
            _communicationMapper = communicationMapper.GuardNull(nameof(communicationMapper));
            _odsConsentRepository = odsConsentRepository.GuardNull(nameof(odsConsentRepository));
            _customerProfileCache = customerProfileCache.GuardNull(nameof(customerProfileCache));
            _consentProcessor = consentProcessor.GuardNull(nameof(consentProcessor));
            _logger = logger.GuardNull(nameof(_logger));
            _mapper = mapper.GuardNull(nameof(_mapper));
            _brandResolver = brandResolver.GuardNull(nameof(brandResolver));
        }

        /// <summary>
        /// Event payload action handler.
        /// </summary>
        /// <param name="payload">Message Payload.</param>
        /// <param name="context">Message Context.</param>
        /// <param name="logger">Injected Logger.</param>
        /// <param name="cancellationToken">Request Cancellation Token.</param>
        /// <returns>Task Operation.</returns>
        protected override async Task ActionPayload(T payload, ProcessMessageContext context, ILogger logger, CancellationToken cancellationToken)
        {
            _logger.LogDebug($"{this.ReadableTypeName()} processing event {payload.Metadata.EventName} with message id {payload.Metadata.MessageId}");

            // Construct standard headers
            var standardHeaders = payload
                .Metadata
                .MapMetadataTo<StandardHeaderModel>()
                .Update(HttpClients.MetaData.SendingSystemId, HttpClients.MetaData.SendingSystemVersion);

            var consentComposite = new ConsentCreatedComposite() 
            {
                Payload = payload.Payload
            };
            Consent incomingConsent = null;
            
            if (payload.Payload.CheckIfScheduledPaymentUpdate())
            {
                await _consentProcessor.ProcessScheduledPaymentConsent(consentComposite, standardHeaders, cancellationToken);
            }

            try
            {
                incomingConsent = _mapper.Map<Consent>(consentComposite);
            }
            catch (Exception ex)
            {
                throw logger.LogAndRaiseUnrecoverableException(ex, "Unable to map created consent with id {ConsentId}", incomingConsent?.ConsentId, nameof(Consent));
            }
            
            if (incomingConsent == null)
                throw logger.LogAndRaiseUnrecoverableException("The received message {MessageId} is not convertible to {RequiredObjectType}", payload.Metadata.MessageId, nameof(Consent));

            Consent createdConsent = null;
            try
            {
                createdConsent = await _odsConsentRepository.AddAsync(incomingConsent, incomingConsent.ConsentId);
            }
            catch (Exception ex)
            {
                throw logger.LogAndRaiseUnrecoverableException(ex, "Unable to add consent with id {ConsentId} to ODS: {ErrorMessage}", incomingConsent.ConsentId, ex.Message);
            }

            // Only send comms when consent was created
            var failures = new List<(ConsentSubModels.ConsentParty Party, Exception Exception)>();
            foreach (var entry in payload.Payload.Parties)
            {
                if (entry.Role == EventEnums.ConsentCustomerRoleEnum.APPROVER)
                {
                    string action = "retrieving customer profile";
                    try
                    {
                        // TODO: Can we use party.FirstName?
                        var customerContactDetail = await _customerProfileCache.GetCustomerContactDetailsAsync(entry.CustomerId, standardHeaders, null, cancellationToken);

                        action = "creating notification centre message";
                        await CreateNotificationCentreMessage(entry, createdConsent != null, logger, cancellationToken);

                        action = "creating push notification";
                        await CreatePushNotification(entry, customerContactDetail, createdConsent != null, payload.Metadata.MessageId, incomingConsent.ConsentId, logger);

                        if (createdConsent != null)
                        {
                            action = "creating sms";
                            await CreateSms(entry, customerContactDetail, payload.Metadata.MessageId, incomingConsent.ConsentId, logger);
                        }
                    }
                    catch (Exception ex)
                    {
                        failures.Add((entry, new InvalidOperationException($"Failed to send notifications/comms for {entry.CustomerId} when {action}", ex)));
                    }
                }
            }

            if (failures.Any())
            {
                var total = payload.Payload.Parties.Count;

                // At least *some* notifications were sent
                if (failures.Count < total)
                {
                    // When only some fail then dead letter it instead
                    var ex = new AggregateException($"{failures.Count()} of the {total} parties identified failed to send notifications or comms", failures.Select(f => f.Exception));
                    logger.LogError(ex, $"{this.ReadableTypeName()}.{nameof(ActionPayload)} failed to create or send notifications or comms for some parties: {ex.Message}");
                    context.Result = ProcessMessageResult.PoisonMessageIdentified;
                    context.ErrorMessage = "Error creating and / or sending some notification and comms";
                    context.ErrorReason = ex.Message;

                }
                // All notifications failed
                else
                {
                    // When all fail you can potentially try again
                    var ex = new AggregateException($"{(total == 1 ? "The party" : $"All {total} parties")} identified failed to send notifications or comms", failures.Select(f => f.Exception));
                    logger.LogError(ex, $"{this.ReadableTypeName()}.{nameof(ActionPayload)} failed to create or send any notifications or comms: {ex.Message}");
                    context.Result = ProcessMessageResult.RequiresRetry;
                    context.ErrorMessage = "Error creating and / or sending ALL notification and comms";
                    context.ErrorReason = ex.Message;
                }
            }
        }

        private async Task CreateNotificationCentreMessage(ConsentSubModels.ConsentParty party, bool odsSuccess, ILogger logger, CancellationToken cancellationToken)
        {
            var formatting = _brandResolver.Definition().ExtractFormatting<ConsentCreatedFormatting>();

            var notificationCentreRequest = new CreateNotificationRequest()
            {
                ActionableContext = NotificationCentre.NotificationActionContext,
                Actionable = NotificationCentre.NotificationActionable,
                Category = CommTypes.ConsentCreated,
                CustomerId = party.CustomerId,
                Linktext = formatting.NotificationLinkText,
                Linkuri = formatting.NotificationLinkUriCreated,
            };

            if (odsSuccess)
            {
                notificationCentreRequest.Title = formatting.SuccessNotificationTitle;
                notificationCentreRequest.Body = formatting.SuccessNotificationBody;
            }
            else
            {
                notificationCentreRequest.Title = formatting.ErrorNotificationTitle;
                notificationCentreRequest.Body = formatting.ErrorNotificationBody;
            }

            // create notification in Notification Centre
            await _notificationCentreClient.CreateNotification(notificationCentreRequest, cancellationToken);
            logger.LogInformation("Completed creating notification.");
        }

        private async Task CreatePushNotification(ConsentSubModels.ConsentParty party, GetContactDetailsResponse customerContactDetail, bool odsSuccess, string messageId, string consentId, ILogger logger)
        {
            // publish EV32 Push
            var formatting = _brandResolver.Definition().ExtractFormatting<ConsentCreatedFormatting>();

            var communicationEvent = _communicationMapper.CreateConsentWorkflowManagementEv32CommunicationEvent(
                nameof(ConsentCreatedFunction),
                party.CustomerId,
                party.CustomerId,
                customerContactDetail.GivenName,
                ComConstants.CommunicationChannel.Push,
                odsSuccess ? formatting.SuccessPushBody : formatting.ErrorPushBody,
                odsSuccess ? formatting.SuccessPushTitle : formatting.ErrorPushTitle,
                formatting.PushLinkUriCreated
            );

            logger.LogInformation("EV32CommunicationEvent prepared for message {MessageId}, Consent = {ConsentId}, Customer = {CustomerId} ({Email})", messageId, consentId, party.CustomerId, party.CustomerId);
            await _serviceBusEventPublisher.CreateAndPublishEvent(_settings.ServiceBus.CommunicationEV32PreparedTopic, communicationEvent);
        }

        private async Task CreateSms(ConsentSubModels.ConsentParty party, GetContactDetailsResponse customerContactDetail, string messageId, string consentId, ILogger logger)
        {
            var formatting = _brandResolver.Definition().ExtractFormatting<ConsentCreatedFormatting>();

            // publish EV32 SMS
            var communicationEvent = _communicationMapper.CreateConsentWorkflowManagementEv32CommunicationEvent(
                nameof(ConsentCreatedFunction),
                party.CustomerId,
                party.CustomerId,
                customerContactDetail.GivenName,
                ComConstants.CommunicationChannel.Sms,
                formatting.SMSBody(customerContactDetail.GivenName),
                null,
                null);

            logger.LogInformation("EV32CommunicationEvent prepared for message {MessageId}, Consent = {ConsentId}, Customer = {CustomerId} ({Email})", messageId, consentId, party.CustomerId, party.CustomerId);
            await _serviceBusEventPublisher.CreateAndPublishEvent(_settings.ServiceBus.CommunicationEV32PreparedTopic, communicationEvent);
        }
    }
}
