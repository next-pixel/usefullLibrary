﻿using Platform.Library.BaseEvent;
using Platform.Library.Communication.Extensions;
using Platform.Library.Events.Models.Enum;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Action handler for <see cref="ConsentUpdatedAction"/>.
    /// </summary>
    /// <typeparam name="T">Generic type for <see cref="EV69ConsentUpdatedEvent"/>.</typeparam>
    public class ConsentUpdatedAction<T> : MessageHandler<T>
        where T : EventModels.EV69ConsentUpdatedEvent
    {
        private readonly IOdsConsentsRepository _odsConsentRepository;
        private readonly IServiceBusEventPublisher _serviceBusEventPublisher;
        private readonly ISettings _settings;
        private readonly ILogger<ConsentUpdatedAction<T>> _logger;
        private readonly ICommunicationMapper _communicationMapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsentUpdatedAction{T}"/> class.
        /// Constructor for <see cref="ConsentUpdatedAction{T}"/>.
        /// </summary>
        /// <param name="odsConsentRepository">Ods consent client.</param>
        /// <param name="serviceBusEventPublisher">Servicebus event publisher.</param>
        /// <param name="settings">Settings.</param>
        /// <param name="logger">Logger.</param>
        /// <exception cref="ArgumentNullException">Throws ArgumentNullException when either of the argument is null.</exception>
        public ConsentUpdatedAction(
            IOdsConsentsRepository odsConsentRepository,
            IServiceBusEventPublisher serviceBusEventPublisher,
            ISettings settings,
            ILogger<ConsentUpdatedAction<T>> logger,
            ICommunicationMapper communicationMapper)
        {
            _odsConsentRepository = odsConsentRepository ?? throw new ArgumentNullException(nameof(odsConsentRepository));
            _serviceBusEventPublisher = serviceBusEventPublisher ?? throw new ArgumentNullException(nameof(serviceBusEventPublisher));
            _settings = settings ?? throw new ArgumentNullException(nameof(settings));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _communicationMapper = communicationMapper ?? throw new ArgumentNullException(nameof(communicationMapper));
        }

        /// <summary>
        /// Process event.
        /// </summary>
        /// <returns>Task.</returns>
        protected override async Task ActionPayload(T payload, ProcessMessageContext context, ILogger logger, CancellationToken cancellationToken)
        {
            // Construct standard headers from metadata
            var standardHeaders = payload
                .Metadata
                .MapMetadataTo<StandardHeaderModel>()
                .Update(HttpClients.MetaData.SendingSystemId, HttpClients.MetaData.InitiatingSystemVersion);

            _logger.LogDebug($"{this.ReadableTypeName()} processing event {payload.Metadata.EventName} with message id {payload.Metadata.MessageId}");

            var ev69Payload = payload.Payload;
            var currentUtcDateTime = DateTime.UtcNow;

            List<OdsModels.Consent> consents = null;
            try
            {
                consents = await _odsConsentRepository.SearchOdsForEntitiesAsync(c => c.ConsentId == ev69Payload.ConsentId, null)
                    ?? new();
            }
            catch ( Exception ex )
            {
                throw _logger.LogAndRaiseUnrecoverableException(ex, "Unable to retrieve consent with id {ConsentId} from ODS: {ErrorMessage}", ev69Payload.ConsentId, ex.Message);
            }

            // If we have more than one consent something went wrong?
            if (consents.Count != 1)
                throw _logger.LogAndRaiseUnrecoverableException("Unable to process - Unexpected number of consents returned ({ConsentCount})", consents.Count);

            // Update the Consent
            var result = await UpdateConsentStatusAndCheckIfEventNeedsToPublishAsync(consents.First(), ev69Payload, currentUtcDateTime);
            if (result.ToPublish)
            {
                // publish EV70 consent resulted on T51 consent topic
                var ev70ConsentResultedEvent = _communicationMapper.MapEv70ConsentResultedEvent(result.Consent);

                await _serviceBusEventPublisher.CreateAndPublishEvent(_settings.ServiceBus.T51ConsentTopicName, ev70ConsentResultedEvent);
                _logger.LogInformation($"{nameof(EventModels.EV70ConsentResulted)} published successfully for consent {{ConsentId}} and customer {{CustomerId}}", ev69Payload.ConsentId, ev69Payload.CustomerId);
            }
            else if (result.Exception != null)
                throw _logger.LogAndRaiseUnrecoverableException(result.Exception, $"{this.ReadableTypeName()} failed to update consent with id {{ConsentId}} for customer {{CustomerId}}: {{ErrorMessage}}", ev69Payload.ConsentId, ev69Payload.CustomerId, result.Exception.Message);
        }

        /// <summary>
        /// Set consent status and check if event needs to be published.
        /// </summary>
        /// <param name="payloadStatus">Status from payload.</param>
        /// <param name="customerId">Customer id.</param>
        /// <param name="currentUtcDateTime">Current utc date time.</param>
        /// <param name="consent">Consent data.</param>
        /// <returns>True if ev70 event needs to be published otherwise false.</returns>
        private async Task<ConsentResult> UpdateConsentStatusAndCheckIfEventNeedsToPublishAsync(OdsModels.Consent consent, EventModels.EV69ConsentUpdatedPayload payload, DateTime timestamp)
        {
            var customerDetail = consent.Parties.FirstOrDefault(p => p.CustomerId == payload.CustomerId);
            if (customerDetail != null)
            {
                var needsPublishing = false;
                customerDetail.Response = payload.Status.ConvertEnum<ConsentResponseStatusEnum, OdsConsentEnums.ConsentResponseStatus>();
                customerDetail.ResponseDateTime = timestamp;

                if (customerDetail.Role == OdsConsentEnums.ConsentCustomerRole.REQUESTOR && customerDetail.Response == OdsConsentEnums.ConsentResponseStatus.CANCELLED)
                {
                    SetConsentUpdateProperties(consent, timestamp, ConsentStatus.CANCELLED);
                    needsPublishing = true;
                }
                else if (customerDetail.Role == OdsConsentEnums.ConsentCustomerRole.APPROVER)
                {
                    if (customerDetail.Response == OdsConsentEnums.ConsentResponseStatus.DECLINED)
                    {
                        SetConsentUpdateProperties(consent, timestamp, ConsentStatus.DECLINED);
                        needsPublishing = true;
                    }
                    else if (customerDetail.Response == OdsConsentEnums.ConsentResponseStatus.APPROVED
                                && consent.Parties
                                    .Where(p => p.Role == OdsConsentEnums.ConsentCustomerRole.APPROVER)
                                    .All(p => p.Response == OdsConsentEnums.ConsentResponseStatus.APPROVED))
                    {
                        SetConsentUpdateProperties(consent, timestamp, ConsentStatus.APPROVED);
                        needsPublishing = true;
                    }
                }

                consent.LastActionedDateTime = timestamp;

                try
                {
                    await _odsConsentRepository.UpdateAsync(consent);
                    _logger.LogInformation("Consent updated in ODS for {ConsentId}", consent.ConsentId);
                }
                catch ( Exception ex )
                {
                    return ConsentResult.Failure(consent, ex);
                }

                return needsPublishing
                    ? ConsentResult.RequiresPublishing(consent)
                    : ConsentResult.NoUpdate(consent);
            }

            return ConsentResult.Failure(
                consent,
                new ArgumentNullException(nameof(consent), $"Unable to update consent - cannot find customer {payload.CustomerId} in the parties")
            );
        }

        /// <summary>
        /// Set consetn
        /// </summary>
        /// <param name="consent">Consent data.</param>
        /// <param name="currentUtcDateTime">Current utc date time.</param>
        /// <param name="status">Status.</param>
        private static void SetConsentUpdateProperties(OdsModels.Consent consent, DateTime currentUtcDateTime, ConsentStatus status)
        {
            consent.Status = status.ToString();
            consent.ResultedDateTime = currentUtcDateTime;
        }
    }
}