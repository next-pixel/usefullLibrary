﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Interface for consent expiration action handler.
    /// </summary>
    public interface IConsentExpirationAction
    {
        /// <summary>
        /// To process expired consents.
        /// </summary>
        Task ProcessAsync();
    }
}
