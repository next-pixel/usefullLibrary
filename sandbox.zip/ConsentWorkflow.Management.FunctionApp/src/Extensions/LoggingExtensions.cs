﻿using Platform.Library.Common.Standard.ErrorHandling;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace ConsentWorkflowManagementFunctionApp
{
    internal static class LoggingExtensions
    {
        internal static bool TryParseHttpResponse(this ILogger logger, HttpResponseMessage httpResponse, string clientName, HttpMethod httpVerb, string uri, [CallerMemberName] string methodName = null)
        {
            if (httpResponse == null)
            {
                logger.LogError("[{MethodName}] {SystemId} responded with NULL to {Method}:{Path}",
                    methodName,
                    clientName,
                    httpVerb,
                    uri
                );

                return false;
            }
            else if (!httpResponse.IsSuccessStatusCode)
            {
                // Log response and convert to standard communication error
                logger.LogError("[{MethodName}] {SyswtemId} responded with {StatusCode} ({Reason}) to {Method}:{Path}",
                    methodName,
                    clientName,
                    httpResponse.StatusCode,
                    httpResponse.ReasonPhrase,
                    httpVerb,
                    uri
                );

                return false;
            }

            return true;
        }

        internal static bool LogStandardException(this ILogger logger, string clientName, HttpMethod httpVerb, string uri, Exception ex, [CallerMemberName] string methodName = null)
        {
            logger.LogError(ex, "[{MethodName}] {SywstemId} responded with an exception to {Method:{Path}\n{ErrorMessage}",
                methodName,
                clientName, 
                httpVerb, 
                uri, 
                ex.Message
            );

            return false;
        }
    }
}
