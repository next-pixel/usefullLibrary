﻿using Platform.Library.Common;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Extension methods for creating <see cref="CreateNotificationRequest"/>
    /// </summary>
    public static class CreateNotificationRequestExtensions
    {
        /// <summary>
        /// Get a <see cref="CreateNotificationRequest"/> from the provided details
        /// </summary>
        /// <param name="brandResolver"></param>
        /// <param name="consentStatus"></param>
        /// <param name="customerId"></param>
        /// <param name="customerGivenName"></param>
        /// <param name="category"></param>
        /// <param name="isRequestProcessed"></param>
        /// <returns></returns>
        public static CreateNotificationRequest GetNotificationCreateRequest(
            this IBrandResolver brandResolver,
            string consentStatus,
            string customerId,
            string customerGivenName,
            string category,
            bool isRequestProcessed = true)
        {
            var formatting = brandResolver.Definition().ExtractFormatting<ConsentResultedFormatting>();

            var createNotificationRequest = new CreateNotificationRequest()
            {
                ActionableContext = NotificationCentre.NotificationActionContext,
                Actionable = NotificationCentre.NotificationActionable,
                Category = category,
                CustomerId = customerId,
                Linktext = formatting.NotificationLinkText,
                Linkuri = formatting.NotificationLinkUriResulted,
            };

            if (isRequestProcessed)
            {
                createNotificationRequest.Title = formatting.SuccessNotificationTitle(consentStatus);
                createNotificationRequest.Body = formatting.SuccessNotificationBody(consentStatus);
            }
            else
            {
                createNotificationRequest.Title = formatting.ErrorNotificationTitle;
                createNotificationRequest.Body = formatting.ErrorNotificationBody;
            }

            return createNotificationRequest;
        }
    }
}
