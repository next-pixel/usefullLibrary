﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Map between different enum types
    /// </summary>
    public static class PaymentFrequencyExtensions
    {
        /// <summary>
        /// Map Payment frequency enum from Event model to ODS Consent model
        /// </summary>
        /// <param name="frequency"></param>
        /// <returns></returns>
        public static OdsConsentEnums.PaymentFrequency ConvertToPaymentFrequency(this EventEnums.PaymentFrequencyEnum frequency)
        {
            return frequency switch
            {
                EventEnums.PaymentFrequencyEnum.ONCE => OdsConsentEnums.PaymentFrequency.ONCE,
                EventEnums.PaymentFrequencyEnum.WEEKLY => OdsConsentEnums.PaymentFrequency.WEEKLY,
                EventEnums.PaymentFrequencyEnum.FORTNIGHTLY => OdsConsentEnums.PaymentFrequency.FORTNIGHTLY,
                EventEnums.PaymentFrequencyEnum.MONTHLY => OdsConsentEnums.PaymentFrequency.MONTHLY,
                EventEnums.PaymentFrequencyEnum.QUARTERLY => OdsConsentEnums.PaymentFrequency.QUARTERLY,
                EventEnums.PaymentFrequencyEnum.None => OdsConsentEnums.PaymentFrequency.None,
                _ => throw new NotSupportedException($"{nameof(EventEnums.PaymentFrequencyEnum)}.{frequency} is not supported by {nameof(ConvertToPaymentFrequency)}")
            };
        }

        /// <summary>
        /// Map T24 payment frequency to ODS Consent payment frequency
        /// </summary>
        /// <param name="frequency"></param>
        /// <returns></returns>
        public static OdsConsentEnums.PaymentFrequency MapPaymentFrequencyFromStandingOrderFrequency(string frequency) 
        {
            if (frequency.Contains(FrequencyCodes.Daily))
                return OdsConsentEnums.PaymentFrequency.ONCE;
            if (frequency.Contains(FrequencyCodes.Weekly))
                return OdsConsentEnums.PaymentFrequency.WEEKLY;
            if (frequency.Contains(FrequencyCodes.Fortnightly))
                return OdsConsentEnums.PaymentFrequency.FORTNIGHTLY;
            if (frequency.Contains(FrequencyCodes.Monthly))
                return OdsConsentEnums.PaymentFrequency.MONTHLY;
            if (frequency.Contains(FrequencyCodes.Quarterly))
                return OdsConsentEnums.PaymentFrequency.QUARTERLY;

            throw new NotSupportedException($"Provided Frequency is not supported by {nameof(MapPaymentFrequencyFromStandingOrderFrequency)}");
        }
    }
}
