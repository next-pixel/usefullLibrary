﻿namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Extension methods for supporting <see cref="IStandardHeaderModel"/> with this component
    /// </summary>
    internal static class StandardHeaderExtensions
    {
        /// <summary>
        /// Get customer headers.
        /// </summary>
        /// <param name="sendingSystemId">Sending system id.</param>
        /// <param name="apimSubscriptionKey">APIM Subscription Key.</param>
        /// <returns>Dictionary with custom headers.</returns>
        internal static IStandardHeaderModel GetStandardHeaders(string requestId = null)
        {
            return new StandardHeaderModel
            {
                RequestId = requestId ?? Guid.NewGuid().ToString(),
                SendingSystemId = nameof(ConsentWorkflowManagementFunctionApp),
                SendingSystemVersion = HttpClients.MetaData.SendingSystemVersion,
                InitiatingSystemId = HttpClients.MetaData.InitiatingSystemId,
                InitiatingSystemVersion = HttpClients.MetaData.InitiatingSystemVersion,
                Timestamp = DateTimeOffset.UtcNow
            };
        }
    }
}
