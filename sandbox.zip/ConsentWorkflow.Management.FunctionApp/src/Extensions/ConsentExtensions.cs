﻿using Platform.Library.Events.Models;
using System.Text.RegularExpressions;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Extension methods to support handling <see cref="OdsModels.Consent"/> models
    /// </summary>
    internal static class ConsentExtensions
    {
        private static readonly Regex _regexTokens = new Regex($"{{[A-Za-z][A-Za-z0-9_]*}}", RegexOptions.Compiled, Constants.RegexPatterns.Timeout);

        /// <summary>
        /// Formatting the error reporting for the <see cref="ConsentExpirationAction"/>
        /// </summary>
        /// <param name="failures"></param>
        /// <returns></returns>
        internal static string FormatFailureMessage(this List<(OdsModels.Consent Consent, string Action, Exception Exception)> failures)
        {
            var groups = failures.GroupBy(f => f.Action);

            // When all failures are the same
            if (groups.Count() == 1)
                return string.Concat(
                    $"{failures.Count} consent(s) failed to update when {groups.First().Key}: ",
                    string.Join(
                        ", ",
                        failures.Select(f => f.Consent.ConsentId)
                    )
                );
            // When there are multiple different failures
            else
                return string.Concat(
                    $"{failures.Count} consent(s) failed to update: ",
                    string.Join(
                        ", ",
                        failures.Select(f => $"{f.Consent.ConsentId} when {f.Action}")
                    )
                );
        }

        /// <summary>
        /// Update a <see cref="OdsModels.Consent"/> to indicate it has expired
        /// </summary>
        /// <param name="consent"></param>
        /// <param name="timestamp"></param>
        internal static void UpdateExpiredConsent(this OdsModels.Consent consent, DateTime timestamp)
        {
            consent.Status = ConsentStatus.EXPIRED.ToString();
            consent.Parties.ForEachNullSafe(consent =>
            {
                if (consent.Response == OdsConsentEnums.ConsentResponseStatus.PENDING)
                {
                    consent.Response = OdsConsentEnums.ConsentResponseStatus.EXPIRED;
                    consent.ResponseDateTime = timestamp;
                }
            });
            consent.LastActionedDateTime = timestamp;
            consent.ResultedDateTime = timestamp;
        }

        /// <summary>
        /// Log and raise an <see cref="UnrecoverableMessageException"/> with an inner exception in a consistent manner
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="innerException"></param>
        /// <param name="message"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        internal static UnrecoverableMessageException LogAndRaiseUnrecoverableException(this ILogger logger, Exception innerException, string message, params object[] args)
        {
            logger.LogError(message, args);
            return new UnrecoverableMessageException(message.FormatErrorMessage(args), innerException);
        }

        /// <summary>
        /// Log and raise an <see cref="UnrecoverableMessageException"/> in a consistent manner
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="message"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        internal static UnrecoverableMessageException LogAndRaiseUnrecoverableException(this ILogger logger, string message, params object[] args)
        {
            return logger.LogAndRaiseUnrecoverableException(null, message, args);
        }

        /// <summary>
        /// Formatted string describing the parties of the provided <see cref="OdsModels.Consent">consent</see>
        /// </summary>
        /// <param name="consent"></param>
        /// <returns></returns>
        internal static string DescribeConsentParties(this OdsModels.Consent consent) 
        {
            return consent.Parties.Count == 1
                ? $"one customer ({consent.Parties.First().CustomerId})"
                : $"multiple customers ({string.Join(",", consent.Parties.Select(p => p.CustomerId))})";
        }

        /// <summary>
        /// Format an error message containing string tokens for logging so it can be used in an <see cref="Exception"/>
        /// </summary>
        /// <param name="message"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentOutOfRangeException"></exception>
        private static string FormatErrorMessage(this string message, params object[] args) 
        {
            var matches = _regexTokens.Matches(message);
            if (matches.Any())
            {
                if (args?.Any() ?? false)
                {
                    var result = message;
                    var argQueue = new Queue<string>(args.Select(a => a == null ? "NULL" : a.ToString()));
                    foreach (var match in matches.Cast<Match>())
                        result = result.Replace(match.Value, argQueue.Dequeue());

                    return result;
                }
                else
                    throw new ArgumentOutOfRangeException(nameof(args), $"Mismatch parameters for {nameof(FormatErrorMessage)} Message({matches.Count}) <> Params({args?.Count() ?? 0})");
            }
            else if ( args?.Any() ?? false)
                throw new ArgumentOutOfRangeException(nameof(args), $"Mismatch parameters for {nameof(FormatErrorMessage)} Message({matches.Count}) <> Params({args?.Count() ?? 0})");
            else
                return message;
        }

        /// <summary>
        /// Does a string value when converted to <typeparamref name="T">a specific enumeration</typeparamref> match the <paramref name="enumValue"/>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="value"></param>
        /// <param name="enumValue"></param>
        /// <returns></returns>
        internal static bool MatchesEnumValue<T>(this string value, T enumValue)
            where T : struct, Enum
        {
            return Enum.TryParse<T>(value, out var valueAsEnum)
                ? enumValue.Equals(valueAsEnum)
                : false;
        }

        /// <summary>
        /// Display the name of the class in a readable format
        /// </summary>
        /// <remarks>TODO: Need to make this public in common</remarks>
        /// <typeparam name="T"></typeparam>
        /// <param name="instance"></param>
        /// <returns></returns>
        internal static string ReadableTypeName<T>(this T instance)
        {
            return typeof(T).IsGenericType
                ? $"{typeof(T).Name.Split("`").First()}<{string.Join(",", typeof(T).GetGenericArguments().Select(t => t.Name))}>"
                : typeof(T).Name;
        }
        
        /// <summary>
        /// Check if a <see cref="EV68ConsentCreatedPayload"/> event payload is for a deleted or updated scheduled payment 
        /// </summary>
        /// <param name="payload"></param>
        /// <returns></returns>
        internal static bool CheckIfScheduledPaymentUpdate(this EV68ConsentCreatedPayload payload)
        {
            return payload.RequestType == EventEnums.ConsentRequestTypeEnum.SCHEDPAY 
                && (payload.RequestDetails.Payment.StandingOrderAction == EventEnums.StandingOrderAction.DELETE 
                || payload.RequestDetails.Payment.StandingOrderAction == EventEnums.StandingOrderAction.UPDATE);
        }

        /// <summary>
        /// Convert one enum type to another
        /// </summary>
        /// <typeparam name="TEnum1"></typeparam>
        /// <typeparam name="TEnum2"></typeparam>
        /// <param name="inputEnum"></param>
        /// <returns></returns>
        public static TEnum2 ConvertEnum<TEnum1, TEnum2>(this TEnum1 inputEnum)
            where TEnum1 : struct, Enum
            where TEnum2 : struct, Enum
        {
            return Enum.TryParse(inputEnum.ToString(), out TEnum2 outputEnum)
                ? outputEnum
                : throw new InvalidCastException($"Cannot convert \"{inputEnum}\" to '{typeof(TEnum2).FullName}'");
        }
    }
}