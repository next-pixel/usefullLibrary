﻿using StandingOrderAction = Platform.Library.Ods.Core.OdsDB.DataModel.SubModels.Consent.Enumerations.StandingOrderAction;
using StandingOrderActionEvent = Platform.Library.Events.Models.Enum.StandingOrderAction;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Mapper to map between different enum types
    /// </summary>
    public static class StandingOrderEnumExtensions
    {
        /// <summary>
        /// Map standing order action from event to ODS Consent model
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static StandingOrderAction AsOdsStandingOrderAction(this StandingOrderActionEvent value)
        {
            return value switch
            {
                StandingOrderActionEvent.CREATE => StandingOrderAction.CREATE,
                StandingOrderActionEvent.UPDATE => StandingOrderAction.UPDATE,
                StandingOrderActionEvent.DELETE => StandingOrderAction.DELETE,
                StandingOrderActionEvent.None => StandingOrderAction.None,
                _ => throw new NotSupportedException($"{nameof(EventEnums.StandingOrderAction)}.{value} is not supported by {nameof(AsOdsStandingOrderAction)}")
            };
        }
    }
}
