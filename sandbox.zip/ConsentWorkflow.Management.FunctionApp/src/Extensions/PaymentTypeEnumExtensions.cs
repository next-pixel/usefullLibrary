﻿using PaymentTypeODS = Platform.Library.Ods.Core.OdsDB.DataModel.SubModels.Consent.PaymentType;
using PaymentTypeConsent = Platform.Library.Events.Models.Enum.ConsentPaymentTypeEnum;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Mapper to map between different enum types
    /// </summary>
    public static class PaymentTypeEnumExtensions
    {
        /// <summary>
        /// Map Payment frequency enum from Event model to ODS Consent model
        /// </summary>
        /// <param name="paymentType"></param>
        /// <returns></returns>
        public static PaymentTypeODS Convert(this PaymentTypeConsent paymentType)
        {
            return paymentType switch
            {
                PaymentTypeConsent.INTERNAL => PaymentTypeODS.INTERNAL,
                PaymentTypeConsent.DIRECT_ENTRY => PaymentTypeODS.DIRECT_ENTRY,
                PaymentTypeConsent.BPAY => PaymentTypeODS.BPAY,
                PaymentTypeConsent.NPP => PaymentTypeODS.NPP,
                _ => throw new NotSupportedException($"{nameof(PaymentTypeODS)}.{paymentType} is not supported by {nameof(Convert)}")
            };
        }

        /// <summary>
        /// Map Payment Order Product to ODS Consent Payment Type enum
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public static PaymentTypeODS ConvertToOdsPaymentType(this string product)
        {
            return product switch
            {
                PaymentOrderProducts.VMAINTSTO => PaymentTypeODS.INTERNAL,
                PaymentOrderProducts.VMAPARWITI => PaymentTypeODS.INTERNAL,
                PaymentOrderProducts.VMABECSSTO => PaymentTypeODS.DIRECT_ENTRY,
                PaymentOrderProducts.VMAPARWITO => PaymentTypeODS.DIRECT_ENTRY,
                PaymentOrderProducts.VMABPAYSTO => PaymentTypeODS.BPAY,
                _ => throw new NotSupportedException($"{nameof(PaymentOrderProducts)}.{(product.IsNotNullOrWhiteSpace() ? product : "NULL")} is not supported by {nameof(ConvertToOdsPaymentType)}")
            };
        }
    }
}
