﻿using Platform.Library.Ods.Core.OdsDB.DataModel;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Mapper to map between different enum types
    /// </summary>
    public static class ReplaceStandingOrderExtensions
    {
        public static string ReplaceStandingOrderId(this string s, Consent consent)
        {
            object value = s.IsNullOrWhiteSpace() ? s : string.Format(s, consent.RequestDetails.Payments.StandingOrderId);
            return ((string)value);
        }
    }
}
