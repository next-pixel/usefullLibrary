﻿using AutoMapper;
using ConsentWorkflowManagementFunctionApp.Client.Abstractions;
using Denovo.Library.Account.Extensions;
using FluentValidation;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Documents.Client;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.FeatureManagement;
using Platform.Library.Common;
using Platform.Library.Common.Extensions;
using Platform.Library.Communication.Extensions;
using Platform.Library.HealthChecks;
using Platform.Library.Ods.Infrastructure.Data.DocumentDB.Client;
using Platform.Library.Ods.Infrastructure.Data.DocumentDB.Client.Abstraction;
using Platform.Library.T24.SDK.DependencyInjection;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Extension methods to support the container registration on <see cref="Startup"/>
    /// </summary>
    internal static class RegistrationExtensions
    {
        /// <summary>
        /// Register all services required by the component
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        /// <returns></returns>
        internal static IServiceCollection RegisterServices(this IServiceCollection services) 
        {
            // Register settings
            services.AddSingleton<ISettings, Settings>();

            // Register T24 SDK
            T24SdkContainer.RegisterT24Sdk(
                services,
#if DEBUG
                true,
#else
                false,
#endif
                null,
                Constants.Configuration.FunctionApp
                );

            // Register Feature Management
            services.AddFeatureManagement();

            // Register Action Handlers
            services
                .AddDenovoAccountTypes()
                .RegisterLogging()
                .RegisterAllValidators()
                .RegisterActionHandlers()
                .RegisterOdsDependencies()
                .RegisterAutoMapperProfiles()
                .RegisterServiceEventPublisher()
                .RegisterHttpClients()
                .RegisterApplicationDependencies()
                .RegisterAzureServiceTokenProviderClient()                
                .RegisterBrandResolver();                

            return services;
        }

        /// <summary>
        /// Register logging
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        internal static IServiceCollection RegisterLogging(this IServiceCollection services) 
        {
            services.AddSingleton<ILoggerFactory, LoggerFactory>();
            services.AddTransient<ILogger>(sp => sp.GetRequiredService<ILoggerFactory>().CreateLogger("default"));
            services.AddSingleton(typeof(ILogger<>), typeof(Logger<>));
            services.AddLogging(builder => builder
                .AddConsole()
                .AddDebug()
                .SetMinimumLevel(LogLevel.Debug));

            return services;
        }

        /// <summary>
        /// Register validators
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        internal static IServiceCollection RegisterValidators(this IServiceCollection services)
        {
            // Adding as a singleton as function app needs to be restarted to get new settings
            services.AddSingleton<IValidator<ISettings>, SettingsValidator>();

            return services;
        }

        /// <summary>
        /// Register action handlers
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        internal static IServiceCollection RegisterActionHandlers(this IServiceCollection services)
        {
            services
                .AddTransient<IConsentExpirationAction, ConsentExpirationAction>()
                .AddTransient<IMessageHandler<EventModels.EV68ConsentCreatedEvent>, ConsentCreatedAction<EventModels.EV68ConsentCreatedEvent>>()
                .AddTransient<IMessageHandler<EventModels.EV69ConsentUpdatedEvent>, ConsentUpdatedAction<EventModels.EV69ConsentUpdatedEvent>>()
                .AddTransient<IMessageHandler<EventModels.EV70ConsentResulted>, ConsentResultedAction<EventModels.EV70ConsentResulted>>();

            return services;
        }

        /// <summary>
        /// Register ODS dependencies
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        internal static IServiceCollection RegisterOdsDependencies(this IServiceCollection services) 
        {
            // WANT TO USE THIS
            //services.RegisterOds();

            // FROM Autofac

            // Ods Repositories
            services
                .AddSingleton<IOdsConsentsRepository,OdsConsentsRepository>()
                .AddSingleton<CosmosClient>(provider =>
                {
                    var odsSettings = provider.GetRequiredService<IOdsOptions>();
                    return new CosmosClient(
                        odsSettings.ServiceEndPoint,
                        odsSettings.AuthKey
                    );
                });

            // ODS db client factory
            services.AddSingleton<IOdsDbClientFactory, OdsDbClientFactory>(provider =>
            {
                var odsSettings = provider.GetRequiredService<ISettings>().Ods;

                var odsDbClientFactory = new OdsDbClientFactory(
                    odsSettings.OdsConsentDatabaseName,
                    new List<string> { odsSettings.OdsConsentCollectionName },
                    new DocumentClient(
                        new Uri(odsSettings.ServiceEndPoint),
                        odsSettings.AuthKey,
                        new JsonSerializerSettings
                        {
                            NullValueHandling = NullValueHandling.Ignore,
                            DefaultValueHandling = DefaultValueHandling.Ignore,
                            ContractResolver = new CamelCasePropertyNamesContractResolver(),
                            DateTimeZoneHandling = DateTimeZoneHandling.Utc,
                            DateFormatString = ConsentDateTimeFormats.Format
                        }));
                return odsDbClientFactory;
            });

            return services;
        }

        /// <summary>
        /// Register any additional application dependencies
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        internal static IServiceCollection RegisterApplicationDependencies(this IServiceCollection services)
        {
            services.AddTransient<ICommunicationMapper, CommunicationMapper>();
            services.AddTransient<IConsentProcessor, ConsentProcessor>();
            services.AddTransient<ICommunicationClient, CommunicationClient>();
            services.AddTransient<INotificationCentreClient, NotificationCentreClient>();
            services.AddSingleton<ICustomerProfileCache, CustomerProfileCache>();

            return services;
        }

        /// <summary>
        /// Register service bus event publishing
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        internal static IServiceCollection RegisterServiceEventPublisher(this IServiceCollection services)
        {
            services.AddSingleton<IServiceBusEventPublisher, ServiceBusEventPublisher>(provider =>
            {
                var settings = provider.GetRequiredService<ISettings>();

                return new ServiceBusEventPublisher(
                    provider.GetRequiredService<ILogger<ServiceBusEventPublisher>>(),
                    settings.ServiceBus.ConnectionString01, 
                    settings.ServiceBus.ConnectionString02,
                    provider.GetRequiredService<IValidationResolver>()
                );
            });

            return services;
        }


        /// <summary>
        /// Register all Http Clients automatically as they all support Client Settings
        /// </summary>
        /// <param name="services"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        public static IServiceCollection RegisterHttpClients(this IServiceCollection services)
        {
            services.RegisterAllHttpClients(
                Constants.Configuration.FunctionApp,
                defaultHeaders: null,
#if DEBUG
                inDebug: true
#else
                inDebug:false
#endif
                );

            return services;
        }

        /// <summary>
        /// Extension method to add health checks.
        /// </summary>
        /// <param name="services">Services.</param>
        public static IServiceCollection AddHealthChecks(this IServiceCollection services)
        {
            services.AddFunctionAppHealthChecks()
                .AddFunctionAppServiceBusTriggerHealthCheck()
                .AddSettingsHealthCheck<ISettings>()
                .AddClientSettings();

            return services;
        }
    }
}
