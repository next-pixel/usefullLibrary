﻿using System.Text.RegularExpressions;

namespace ConsentWorkflowManagementFunctionApp
{
    /// <summary>
    /// Map between different enum types
    /// </summary>
    public static class PaymentScheduleExtensions
    {
        /// <summary>
        /// Map Event payment timing to ODS Consent payment schedule
        /// </summary>
        /// <param name="paymentTiming"></param>
        /// <returns></returns>
        public static OdsConsentEnums.PaymentSchedule ConvertToPaymentSchedule(this EventEnums.PaymentTimingEnum paymentTiming)
        {
            return paymentTiming switch
            {
                EventEnums.PaymentTimingEnum.NOW => OdsConsentEnums.PaymentSchedule.NOW,
                EventEnums.PaymentTimingEnum.LATER => OdsConsentEnums.PaymentSchedule.LATER,
                EventEnums.PaymentTimingEnum.RECURRING => OdsConsentEnums.PaymentSchedule.RECURRING,
                EventEnums.PaymentTimingEnum.None => OdsConsentEnums.PaymentSchedule.None,
                _ => throw new NotSupportedException($"Provided Payment Timing is not supported by {nameof(ConvertToPaymentSchedule)}")
            };
        }
        
        /// <summary>
        /// Map T24 payment frequency to ODS Consent payment schedule enum
        /// </summary>
        /// <param name="frequency"></param>
        /// <returns></returns>
        public static OdsConsentEnums.PaymentSchedule MapPaymentScheduleFromStandingOrderFrequency(string frequency)
        {
            if(Regex.IsMatch(frequency, RegexPatterns.PaymentScheduleLater, RegexOptions.Compiled, RegexPatterns.Timeout))
                return OdsConsentEnums.PaymentSchedule.LATER;
            if(Regex.IsMatch(frequency, RegexPatterns.PaymentScheduleRecurring, RegexOptions.Compiled, RegexPatterns.Timeout))
                return OdsConsentEnums.PaymentSchedule.RECURRING;

            throw new NotSupportedException($"Provided Frequency is not supported by {nameof(MapPaymentScheduleFromStandingOrderFrequency)}");
        }
    }
}
