﻿// Global Usings
global using System.Text.Json;
global using System.Text.Json.Serialization;
global using Microsoft.Extensions.Logging;
global using Platform.Library.Http;
global using Platform.Library.Common.Standard.Models;
global using Platform.Library.Common.Standard.Models.Abstractions;
global using Platform.Library.Azure.ServiceBus.Extensions.Models;
global using Library.Azure.ServiceBus;
global using MsJson = System.Text.Json.Serialization;

// TODO: Remove these once we stop supporting newtonsoft
global using Newtonsoft.Json;
global using Newtonsoft.Json.Serialization;

// Common Aliases
global using EventModels = Platform.Library.Events.Models;
global using ConsentSubModels = Platform.Library.Events.Models.SubModels.Consent;
global using EventEnums = Platform.Library.Events.Models.Enum;
global using OdsModels = Platform.Library.Ods.Core.OdsDB.DataModel;
global using OdsSubModels = Platform.Library.Ods.Core.OdsDB.DataModel.SubModels;
global using OdsConsent = Platform.Library.Ods.Core.OdsDB.DataModel.SubModels.Consent;
global using OdsConsentEnums = Platform.Library.Ods.Core.OdsDB.DataModel.SubModels.Consent.Enumerations;

// Common shortcuts
global using static ConsentWorkflowManagementFunctionApp.Constants;
