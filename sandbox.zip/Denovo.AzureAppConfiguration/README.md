# Introduction
This README contains a brief overview of Azure App Configuration deployment. For full documentation, see [this confluence page](https://hub.deloittedigital.com.au/wiki/display/ARC/Azure+App+Configuration)

This Repository contains feature flags and all the configuration required for Runtime Components that cannot be determined by the release process due to either the component not knowing config for a downstream system 
or is unable to determine the configuration value to due access limitations (e.g. Client Ids from Azure AD)

This repository does not contain configuration relevant to the deployment of infrastructure\platform components (think Application Gateways, APIM Instances etc). 

This pipeline is made up of three parts 

- Git Repo 
- Deploy Pipeline Task
- Verify Pipeline Task 

# Purpose
Provide a consolidated view of configuration that is source controlled and deployable across all environments. but also flexible enough to be updated
in an environment if\when configuration values change 


# Development Cycle
Any new feature flag or configuration for a component should be added to this git Repo during development. 

Configuration:

- Add the Value to configMaster.json file with a value of "VALUENOTSET" - this tells the release process to upload an entry to the app config service with that value will be overwritten in the next step of the release
- Add the value(s) or key vault secret name(s) to each of the environment files, including label(s) if desired.
- PR - the PR build will compare the configMaster.json with all the environment files to make sure each configuration entry is set per environment
- Complete PR

Feature Flags:

- Add the Value to configMaster.json file with a value of ""
- Add the label(s) to each of the environment files.
- PR - the PR build will compare the configMaster.json with all the environment files to make sure each configuration entry is set per environment
- Complete PR

# Deploy and Verify
The Release Process does the following steps per environment:
1. Creates the App Configuration service if it doesn't exist
2. For configuration, deploys the Master Config file (the configMaser.json file) which will set up the configuration with the values VALUENOTSET.
3. For configuration, deploys the file for the environment which will update the configuration values to the values in the corresponding environment file 
3. For feature flags, deploys the file for the environment which will update the flag labels to the labels in the corresponding environment file 
4. Assign the required role to the Service Principal to allow it to read the configuration values

The Release Process has a second 'Verify' step which is run per environment and does the following steps:
1. Verifies if any of the values are still set to "VALUENOTSET"
2. Verifies if any of the values linked to keyvault do not have corresponding secrets of the correct name in keyvault

If any of the verification steps fail then the errors will be output in the logs:

`Key Vault value for URI https://mykv.vault.azure.net/secrets/MySecret not set in Key Vault - Key MySetting `


# Manual Updates

Manual updates to the config files can be made by creating a new branch and submitting a PR for the changes.

Changes can also be made directly to the values in the App Configuration service in the Azure Portal but they will need to be reflected back into the config files or they will be overwritten when the release process is run. 