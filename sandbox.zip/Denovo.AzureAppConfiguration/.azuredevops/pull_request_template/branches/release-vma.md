|**Change Type:**|[`Release`] or [`Cherry-Pick`]|
|-:|:-|
|**Target Brand:**|`VMA`|
|**Deployment Ticket:**|[{Jira Card Title}](https://qdigital.atlassian.net/browse/Jira_Number})|
|**Repository:**|[Denovo.AzureAppConfiguration](https://dev.azure.com/qdigitalcode/DenovoBank/_git/Denovo.AzureAppConfiguration)|
  
## {Jira_Number} Overview
{Summarize contents of the release}
  
## Additional Information
- {Provide additional information relevant to people reviewing the code}

## Reviewer Notes
- {Add notes for reviewers to pay attention to}

# CHECKLIST
Please check the following when reviewing this PR:
- [ ] **Did the developer update their local repository?**
   * Executing a `git pull origin master` on the local branch before raising the PR ensures that you have the latest changes and are less likely to conflict with other changes done at the same time

- [ ] **Are there any references to Mocks in PRE/PRD?**
  * The word "Mock" should not appear in the `PRE.json` or `PRD.json` configuration files

- [ ] **Is the use of HttpClient pathing consistent?**
  * [Consistent Rules for setting BaseAddress / RequestUri](https://stackoverflow.com/a/23438417)

- [ ] **Have Key Vault references been implemented correctly?**
  * Secrets cannot exist in `configMaster.json` and must be defined in each environment
  * Secrets must exist in Key Vault prior to this PR being raised
  * If you do not know the secret then please set the value to `secret`
  
  ## Commit Messages
  