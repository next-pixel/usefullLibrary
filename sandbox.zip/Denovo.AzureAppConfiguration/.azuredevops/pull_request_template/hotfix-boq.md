|**Change Type:**|[`Hotfix`]|
|-:|:-|
|**Target Brand:**|`BOQ`|
|**Jira Ticket:**|[{Jira Card Title}](https://qdigital.atlassian.net/browse/{Jira_Number})|
|**Repository:**|[Denovo.AzureAppConfiguration](https://dev.azure.com/qdigitalcode/DenovoBank/_git/Denovo.AzureAppConfiguration)|
  
## {Jira_Number} Resolution
{Summarize how you resolved the defect}
  
## Additional Information
- {Provide additional information relevant to people reviewing the code}

## Reviewer Notes
- {Add notes for reviewers to pay attention to}

## Commit Messages