# Script takes a json file for azure app config and extracts variables that have the VALUENOTSET 
# value assigned. These variables are then deleted from the file in place.  The script then goes 
# through the config files for the different environments to validate if aforementioned variables
# exist within these files. If they don't these variables would be appended to a list which is 
# returned by the script. If they do, the script returns None.

import json
import re
import sys

def get_unset_values(json_data):
    """
    Function to iterate through configMaster.json and extract all the variables
    that have the VALUENOTSET value assigned. 
    Stores these variables in a list which is returned by the function.
    """

    unset_variables = []

    for key in json_data:
        
        if "VMA" in json_data[key]:
            if isinstance(json_data[key]["VMA"], str):
                if "VALUENOTSET" in json_data[key]["VMA"]:
                    unset_variables.append(key)
               
        if "BOQ" in json_data[key]:
            if isinstance(json_data[key]["BOQ"], str):
                if "VALUENOTSET" in json_data[key]["BOQ"]:
                    if key not in unset_variables:
                        unset_variables.append(key)

        if "MEB" in json_data[key]:
            if isinstance(json_data[key]["MEB"], str):
                if "VALUENOTSET" in json_data[key]["MEB"]:
                    if key not in unset_variables:
                        unset_variables.append(key)
    
    return unset_variables


def validate_files(keys):
    """
    Goes through the different environment files from DEV to PRD and checks if the keys 
    which had the Value set to VALUENOTSET exist within these files.
    If they don't, they are appended to a list which is then returned
    """

    envs = ["DEV", "TST", "HLT", "SIT", "SIT02", "UAT", "PFT", "HFX", "PRD"]
    missing_variables = []

    for env in envs:
        with open(env+".json") as f:
            env_data = json.load(f)

        for key in keys:
            if key not in env_data:
                missing_variables.append(key)
                
    return missing_variables


def delete_unset_values(path_to_file, keys):
    """
    Function to iterate through the configMaster.json file and delete variables that have the 
    VALUENOTSET value assigned to them. 
    Overwrites to the same file.
    """


    with open(path_to_file, 'r') as config_file:
        data = json.load(config_file)
    
    # Keys contains the variables that have the VALUENOTSET value assigned to them
    for element in list(data):
        if element in keys:
            del data[element]

    # Overwrites to the same file
    with open(path_to_file, 'w') as config_file:
        
        data = json.dump(data, config_file)

    return


def main():

    # sys.argv = ["configMaster.json"]
    path_to_file = sys.argv[1]
    with open(path_to_file) as f:
        data = json.load(f)

    # get keys from configMaster.json that have VALUENOTSET assigned
    keys = get_unset_values(data)

    # Overwrite the file in place to delete the keys that have VALUENOTSET assigned
    delete_unset_values(path_to_file, keys)
    
    # for unset keys, check the different env files if they contain the key at all
    # If they don't, append them to a list which is then returned for error handling
    missing_keys = validate_files(keys)

    # If there are keys that are not set in the different environment files, raise an exception
    # returning those keys
    if missing_keys:
        return missing_keys
        
    return 


if __name__ == "__main__":
    # execute only if run as a script
    print(main())