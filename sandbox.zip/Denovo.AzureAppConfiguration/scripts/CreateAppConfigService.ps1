
param (
    [string] $location,
    [string] $appConfigurationName,
    [string] $resourceGroup
)

az appconfig create --location $location --name $appConfigurationName --resource-group $resourceGroup --sku standard