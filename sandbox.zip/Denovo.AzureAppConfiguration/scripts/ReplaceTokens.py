# Python 3.9.2

# Script takes a json file for azure app config and replaces key tokens with corresponding values
# inside the json file. The script uses recursion to replace tokens to avoid tokens being
# left in file. It also allows labels to be used as well by attempting to add key with same
# label. If key doesn't exist in the label it uses a key with no label. 

# PARAMS
# 1: The file having tokens replaced.
# 2: OPTIONAL, a file that has common tokens

import json
import re
import sys

no_label = "DEFAULT"

# restructures original json for better querying
# json
# --> label [default = "DEFAULT"]
# ---> ---> key
# ---> ---> ---> value 
def get_kvs_from_labels(json_data):
    labels = {no_label: {}}
    for (k,v) in json_data.items():
        if(type(v) is dict):
            for (label, l_value) in v.items():
                if label not in labels:
                    labels[label] = {}
                labels[label][k] = l_value
        else:
            labels[no_label][k] = v
    return labels

# goes through each of the key value pairs and replaces tokens
# if value has labels, it iterates through those lables and replaces tokens
# returns new dictionary (json) object with values replaced
def replace_tokens(json_data, labels):
    new_dict = {}
    for (k,v) in json_data.items():
        if isinstance(v, str):
            v = recursive_replace_token(v, no_label, labels)
            new_dict[k] = v
        elif isinstance(v, dict):
            label_dict = {}
            for (label, l_value) in v.items():
                if isinstance(l_value, str):
                    l_value = recursive_replace_token(l_value, label, labels)
                    label_dict[label] = l_value
            new_dict[k] = label_dict
    return new_dict

# recursively replaces each token in a string
# finds first substring match which starts with "$(" and ends with ")"
# if value has label and cannot find token in same label it searches for same token with no label
# replaces substring token with value and repeats with recursion
# returns string once there are no tokens left in string
def recursive_replace_token(value, label, labels):
    token = re.search("\$\((?!\$\().*?\)", value)
    if token is None:
        return value
    else:
        token_string = token.group()
        key = token_string[2:-1]
        new_string = labels.get(label).get(key) or labels.get(no_label).get(key)
        if new_string == None:
            print("variable not found: '{}'".format(key))
            sys.stderr.write("error in string: '{}'\n".format(value))
            quit()
        value = value.replace(token_string, new_string) 
        return recursive_replace_token(value, label, labels)

def merge(dict1, dict2):
    result = dict1 | dict2 # use merge operator (|)  
    for x in dict1:
        if x in dict2:
            result[x] = dict1[x] | dict2[x]
    #Replace VALUENOTSET
    for x in result:
        for label in result[x]:
            if result[x][label] == "VALUENOTSET":
                if (x in dict1 and label in dict1[x]) and (x in dict2 and label in dict2[x]):
                    replace = "VALUENOTSET"
                    replace = dict1[x][label] if dict2[x][label] == "VALUENOTSET" else replace
                    replace = dict2[x][label] if dict1[x][label] == "VALUENOTSET" else replace
                    result[x][label] = replace
    return result
             
def main():
    # sys.argv = ["scripts/ReplaceTokens.py", "configMaster.json", "DEV.json"]
    path_to_file = sys.argv[1]
    with open(path_to_file) as f:
        data = json.load(f)

    # get keys for each label for easier querying
    labels = get_kvs_from_labels(data)

    # get helper vars
    if len(sys.argv) == 3:
        with open(sys.argv[2]) as f:
            helper_data = json.load(f)
        helper_vars = get_kvs_from_labels(helper_data)
        labels = merge(labels, helper_vars)
    
    # replaces tokens
    new_json = replace_tokens(data, labels)
    # writes to file
    with open((path_to_file), 'w') as fp:
        json.dump(new_json, fp, indent=4)
    

if __name__ == "__main__":
    # execute only if run as a script
    main()