import json
import sys
from datetime import datetime

def main():
    path_to_file = sys.argv[1]

    with open(path_to_file) as f:
        data = json.load(f)

    now = datetime.now()
    dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
    data["sentinel"] = dt_string
    
    # writes to file
    with open((path_to_file), 'w') as fp:
        json.dump(data, fp, indent=4)

if __name__ == "__main__":
    # execute only if run as a script
    main()