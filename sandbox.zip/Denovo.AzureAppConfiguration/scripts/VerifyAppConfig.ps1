###############
# Validate App Config service and key vault values
###############
param (
    [string] $appConfigurationName,
    [string] $keyVault
)

Write-Host $appConfigurationName
Write-Host $keyVault

$currentConfig = az appconfig kv list -n $appConfigurationName | ConvertFrom-Json
$errorList = $null

Write-Host "Current App Configuration Keys"
Write-Host "----------"

$currentConfig | ForEach-Object {
    Write-Host $_.key

    if($_.Value -match 'uri(.*)/secrets/')
    {
        Write-Host "    KeyVault Url:" + $_.Value
    }

    $keyName = $_.key
    $keyValue = $_.Value

    if($keyValue -contains "VALUENOTSET")
    {
        $errorList = $errorList + "`n Key value for $keyName not set in app config service - value is $keyValue  "        
    }

    if($keyValue -match 'uri(.*)/secrets/')
    {
        $keyVaultJson = $keyValue | ConvertFrom-Json
        $keyVault = ([System.Uri]$keyVaultJson.Uri).Host -replace ".vault.azure.net"
        $KVContent = az keyvault secret list --vault-name $keyVault  | ConvertFrom-Json
        $KVCertContent = az keyvault certificate list --vault-name $keyVault  | ConvertFrom-Json

        if($KVContent.id -notcontains $keyVaultJson.Uri -And 
        $KVCertContent.id.Replace("/certificates/", "/secrets/") -notcontains $keyVaultJson.Uri )
        {
            $errorList = $errorList + "`n Key Vault value for URI " +  $keyVaultJson.Uri + " not set in Key Vault - Key $keyName " 
        }
    }
}

 if($null -ne $errorList){
    Write-Error $errorList
}

 