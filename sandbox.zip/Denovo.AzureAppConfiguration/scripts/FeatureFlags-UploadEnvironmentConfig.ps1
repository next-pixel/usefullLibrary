###############
#  Imports an environment file into memory and uploads each value into the app config service feature manager
###############

param (
    [string] $appConfigurationName,
    [string] $appConfigurationEnvironmentFilePath
)

Write-Host "Getting Environment File $appConfigurationEnvironmentFilePath"

$appConfigFile = Get-Content -path $appConfigurationEnvironmentFilePath | ConvertFrom-Json
$currentConfig = az appconfig feature list -n $appConfigurationName --all | ConvertFrom-Json
$errorList = $null

($appConfigFile.PSobject.Properties) | ForEach-Object {
    $flagName = $_.Name
    $flagLabels = $_.Value

    $currentValue = $currentConfig | Where-Object key -Match $flagName
    
    foreach ($label in $flagLabels) {
        try
        {
            # if the feature flag already exists with the same label then don't add it again
            if(($currentValue.Label -contains $label) -or ([string]::IsNullOrEmpty($label) -and ![string]::IsNullOrEmpty($currentValue.Key) -and $currentValue.Label -contains $null))
            {
                Write-Host "Feature Flag: '$flagName' with label: '$label' has not changed from previous release, skipping"
                continue
            }

            Write-Host "Adding Feature Flag: '$flagName', Label: '$label'"

            if (!([string]::IsNullOrEmpty($label)))
            {
                az appconfig feature set -n $appConfigurationName --feature $flagName --label $label --yes
            }
            else
            {
                az appconfig feature set -n $appConfigurationName --feature $flagName --yes
            }
        }
        catch 
        {
            Write-Error "******* Upload Enviroment Config Failed on Entry: '$flagName', Label: '$label'. Retry Deployment Step *******" 
        }
    } 
 }

 if($null -ne $errorList){
    Write-Error $errorList
 }
 else {
    Write-Host "Update Complete"
 }
 
