###############
#  Imports the app config json file into memory and compares if each value in the 
#  file exists in the app config service if it does not it uploads the value
###############
param (
    [string] $appConfigurationName,
    [string] $appConfigFile,
    [boolean] $dryRun = $false,
    [boolean] $outputResults = $true
)

[System.Collections.ArrayList]$updateList = @()
$updatedCount = 0

Set-Variable -Name DefaultLabel -Value "Default" -Option Constant

# ----------
# Logging Functions
# ----------

if (Test-Path 'env:SYSTEM_DEBUG')
{
    if($env:SYSTEM_DEBUG -eq $true)
    {
        $loggingLevel = "Debug"
    }

}
else {
    $loggingLevel = "Information"
}

if ($dryRun)
{
    $loggingLevel = "Warning"
}

function LogLevel
{
    switch ($loggingLevel) {
        "All" { return 8 }
        "Trace" { return 7 }
        "Debug" { return 6 }
        "Information" { return 5 }
        "Warning" { return 4 }
        "Error" { return 3 }
        "Fatal" { return 2 }
        "Off" { return 1 }
        Default { return 0 }
    }
}

function LogInformation($message)
{
    if(LogLevel -ge 5)
    {
        Write-Host "[INFO]  " $message
    }
}

function LogWarning ($message) {

    if(LogLevel -ge 4)
    {
        Write-Host "[WARN]  " $message
    }
    
}

function LogError($message) 
{
    if(LogLevel -ge 3)
    {
        Write-Error "[ERROR] $message"
    }
}

function LogDebug($message) 
{
    if(LogLevel -ge 6)
    {
        Write-Host "[DEBUG] " $message
    }
}

function AddValueToList($keyName, $label, $type, $currentVal, $newVal)
{
    $item = [PSCustomObject]@{
        Key = $keyName
        Label = $label
        Type = $type
        CurrentValue = $currentVal
        NewValue = $newVal
    }
    $updateList.Add($item) | Out-Null
    $updatedCount++
}

LogInformation "Logging level is set to $loggingLevel"

LogInformation "Loading Master Config File [$appConfigFile]"
$configFile = Get-Content -path $appConfigFile | ConvertFrom-Json


LogInformation "Getting Existing config from AAC [$appConfigurationName]"
$currentConfig = az appconfig kv list -n $appConfigurationName --all | ConvertFrom-Json
$errorList = $null

if($currentConfig -eq $null)
{
    LogError "Error: Unable to get current configuration from Azure App Configuration [$appConfigurationName]"
    exit 1
}

$missingExistingKeys = 0
$totalKeys = 0

($configFile.PSobject.Properties) | ForEach-Object {

    $keyName = $_.Name

    $keyValue = if($_.Value.GetType().Name -eq "String") { "{""$DefaultLabel"": ""$($_.Value)""}" | ConvertFrom-Json } else { $_.Value }

    LogDebug "ConfigFileObject | KeyName: [$keyName] - KeyValue [$keyValue]"

    $totalKeys++

    # if the key already exists with the same value then don't add it again
    # check if value is a json object (for adding labels)
    if($keyValue.GetType().Name -contains "PSCustomObject")
    {

        # Cycle through each of the values of the file
        foreach($kvPair in $keyValue.PSObject.Properties)
        {
            $label = $kvPair.Name
            $value = $kvPair.Value
            
            if($label -eq $DefaultLabel -or $label -eq $null)
            {
                # Get the exact value for the current key with default/empty label
                $currentConfigForLabel = $currentConfig | where { ($_.key -ceq $keyName) -and ($_.label -eq $null) }
            }
            else
            {
                # Get the exact value for the current label and key
                $currentConfigForLabel = $currentConfig | where { ($_.key -ceq $keyName) -and ($_.label -ceq $label) }
            }

            $currentConfigForLabelValue = $currentConfigForLabel.value 
            LogDebug "Current config from AAC for Label [$label]: $currentConfigForLabelValue"

            try {
                if ($value -ceq $currentConfigForLabel.Value -and $currentConfigForLabel -ne $null) {
                    # Configuration is the same, continue
                    LogInformation "Config for [$keyName/$label] has not changed. Value: [$value]"
                    continue
                }

                LogInformation "Value for [$keyName/$label] is out of sync"
                LogDebug "Expected Value: $value"
                LogDebug "Actual (AAC) Value: $currentConfigForLabelValue"

                if($value -match 'uri(.*)/secrets/')
                {
                    $keyVaultJson = $value | ConvertFrom-Json
                    $keyVault = ([System.Uri]$keyVaultJson.Uri).Host -replace ".vault.azure.net"
                    $KVContent = az keyvault secret list --vault-name $keyVault  | ConvertFrom-Json
                    $KVCertContent = az keyvault certificate list --vault-name $keyVault  | ConvertFrom-Json
                    $PlainTextUriValue = $keyVaultJson.uri

                    # IF the Key Vault value doesn't already exist then fail out. otherwise it breaks everything that uses the app config service 
                    if($KVContent.id -notcontains $keyVaultJson.Uri -And 
                    ($KVCertContent.id -And $KVCertContent.id.Replace("/certificates/", "/secrets/") -notcontains $keyVaultJson.Uri))
                    {
                        LogDebug "Error: Key Vault value for URI  [$keyVaultJson.Uri] not set in Key Vault - Key [$keyName]"
                        $errorList = $errorList + "`n Key Vault value for URI [" +  $keyVaultJson.Uri + "] not set in Key Vault - Key [$keyName]" 
                    }
                    else
                    {
                        if ($label -eq $DefaultLabel)
                        {
                            LogInformation "Adding KV Entry Key: [$keyName], Value: [$PlainTextUriValue]"
                            if(!$dryRun)
                            {
                                az appconfig kv set-keyvault -n $appConfigurationName --key $keyName --secret-identifier $keyVaultJson.Uri --yes 
                            }
                            AddValueToList "$keyName" "$label" "AKV" "$currentConfigForLabelValue" "$value"
                        }
                        else
                        {
                            LogInformation "Adding KV Entry Key: [$keyName], Value: [$keyVaultJson.Uri] and Label: [$label]"
                            if(!$dryRun)
                            {
                                az appconfig kv set-keyvault -n $appConfigurationName --key $keyName --secret-identifier $keyVaultJson.Uri --label $label --yes 
                            }
                            AddValueToList "$keyName" "$label" "AKV" "$currentConfigForLabelValue" "$value"
                        }
                    }            
                }
                else 
                {
                    if ($label -eq $DefaultLabel)
                    {
                        LogInformation "Adding Standard Entry [$keyName], Value: [$value]"
                        if(!$dryRun)
                        {
                            az appconfig kv set -n $appConfigurationName --key $keyName --value="""$value""" --yes --content-type """"
                        }
                        AddValueToList "$keyName" "$label" "AAC" "$currentConfigForLabelValue" "$value"
                        
                    }
                    else
                    {

                        LogInformation "Adding Standard Entry for [$keyName]: Value: [$value], Label: [$label]"
                        if(!$dryRun)
                        {
                           az appconfig kv set -n $appConfigurationName --key $keyName --value="""$value""" --label $label --yes --content-type """"
                        }
                        AddValueToList $keyName $label "AAC" $currentConfigForLabelValue $value
                        
                    }    
                }
            }
            catch 
            {
                LogError "******* Upload Config Failed on Entry [$keyName], Value: [$value] and Label: [$label] Retry Deployment Step *******" 
            }
        }
    }
    else # leaved the below statement for now. But likely to be removed in future
    {
        try
        {
            $currentValueLabel = $currentValue.Label
            $currentValueValue = $currentValue.Value
            $currentValueLastModified = $currentValue.LastModified

            LogDebug "CurrentValue | Label: [$currentValueLabel], Value: [$currentValueValue], LastModified: [$currentValueLastModified]"

            if(($currentValue.Value -ceq $keyValue) -and $currentValue.Name -eq $keyName)
            {
                LogInformation "Key: [$keyName] has not changed from previous release, skipping"
                continue
            }
            
            if($keyValue -match 'uri(.*)/secrets/')
            {
                $keyVaultJson = $keyValue | ConvertFrom-Json
                $keyVault = ([System.Uri]$keyVaultJson.Uri).Host -replace ".vault.azure.net"
                $KVContent = az keyvault secret list --vault-name $keyVault  | ConvertFrom-Json
                $KVCertContent = az keyvault certificate list --vault-name $keyVault  | ConvertFrom-Json
                $PlainTextUriValue = $keyVaultJson.Uri

                # IF the Key Vault value doesn't already exist then fail out. otherwise it breaks everything that uses the app config service 
                if($KVContent.id -notcontains $keyVaultJson.Uri -And 
                ($KVCertContent.id -And $KVCertContent.id.Replace("/certificates/", "/secrets/") -notcontains $keyVaultJson.Uri))
                {
                    LogDebug "Error: Key Vault value for URI [$PlainTextUriValue] not set in Key Vault - Key [$keyName]" 
                    $errorList = $errorList + "`n Key Vault value for URI $PlainTextUriValue not set in Key Vault - Key $keyName" 
                }
                else
                {
                    LogInformation "Adding KV Entry Key: [$keyName], Value: [$PlainTextUriValue]"
                    if(!$dryRun)
                    {
                       az appconfig kv set-keyvault -n $appConfigurationName --key $keyName --secret-identifier $keyVaultJson.Uri --yes   
                    }
                    AddValueToList "$keyName" "$currentValueLabel" "AKV" "$currentValueValue" "$keyValue"
                    
                }            
            }
            else {
                LogInformation "Adding Standard Entry [$keyName], Value: [$keyValue]"
                if(!$dryRun)
                {
                   az appconfig kv set -n $appConfigurationName --key $keyName --value """$keyValue""" --yes --content-type """"      
                }
                AddValueToList "$keyName" "$currentValueLabel" "AAC" "$currentValueValue" "$keyValue"
                  
            }
        }
        catch 
        {
            LogError "******* Upload Config Failed on Entry [$keyName], Value: [$keyValue]. Retry Deployment Step *******"
        }
    }
 }

 LogInformation "Config Update Complete"
 LogInformation "Total Keys $totalKeys"
 LogInformation "Missing Keys Created $missingExistingKeys"
 LogInformation "Keys Udpated $updatedCount"

if($null -ne $errorList){
LogError $errorList
}

if($outputResults)
{
    Write-Host ""
    Write-Host "============================="
    Write-Host "| App Configuration Changes |"
    Write-Host "============================="
    Write-Host ""
    $updateList | Format-Table -AutoSize -Wrap | Out-String -Width 4096
}
