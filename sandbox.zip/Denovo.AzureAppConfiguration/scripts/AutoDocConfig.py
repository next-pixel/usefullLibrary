# Need to add file called AutoDocConfig.docx

import json
import pandas as pd
import docx

def main():
    columns = {
        "Common": "./configMaster.json",
        "DEV": "./DEV.json",
        "TST": "./TST.json",
        "SIT": "./SIT.json",
        "UAT": "./UAT.json"
    }

    table = []

    for (environment, path_to_file) in columns.items():

        with open(path_to_file) as f:
            data = json.load(f)
        
        for (key, obj) in data.items():
            if isinstance(obj, str):
                table.append([key, obj, "No Label", environment])
            else:
                for (label, value) in obj.items():
                    table.append([key, value, label, environment])
                
    df = pd.DataFrame(table, columns= ["Key", "Value", "Label", "Environment"])

    doc = docx.Document("AutoDocConfig.docx")
    t = doc.add_table(df.shape[0]+1, df.shape[1])
    # add the header rows.
    for j in range(df.shape[-1]):
        t.cell(0,j).text = df.columns[j]

    # add the rest of the data frame
    for i in range(df.shape[0]):
        for j in range(df.shape[-1]):
            t.cell(i+1,j).text = str(df.values[i,j])
    
    doc.save('AutoDocConfig.docx')


if __name__ == "__main__":
    # execute only if run as a script
    main()