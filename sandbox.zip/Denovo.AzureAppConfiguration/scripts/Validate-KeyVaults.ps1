
param (
    [Parameter(Mandatory)]
    [string] $AppConfigRootFolder,

    [Parameter(Mandatory)]
    [string] $EnvironmentFilter,

    [Parameter(Mandatory)]
    [ValidateSet('Error','Warn', 'Info')]
    [string] $ScriptErrorAction = "Error",

    [string[]] $PlaceHolders = ('secret')
)

# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Check-ConfigurationUri
{
    param (
        [string] $keyName,
        [string] $brand,
        [string] $uri
    )
    Write-Host "Checking $uri"

    $keyVault = ([System.Uri]$uri).Host -replace ".vault.azure.net"

    if ($script:keyVaultCache.Name -notContains $keyVault)
    {
        Write-Host "Caching the '$keyVault' Key Vault's secrets..."
        $cacheItem = [PSCustomObject]@{
            Name = $keyVault
            Secrets = az keyvault secret list --vault-name $keyVault  | ConvertFrom-Json
        }
        $script:keyVaultCache.add($cacheItem) | Out-Null
    }
    else 
    {
       $cacheItem = $script:keyVaultCache | Where-Object Name -eq $keyvault 
    }
   
    # If the Key Vault value doesn't already exist then fail out. otherwise it breaks everything that uses the app config service 
    if ($cacheItem.Secrets -eq $null)
    {
        $script:errorList.Add("Invalid permissions for $keyVault. Unable to check for AAC Key $keyName->$brand") | Out-Null
    }
    elseif ($cacheItem.Secrets.id -notcontains $uri) 
    {
        $script:errorList.Add("Key Vault value for URI $uri not set. (AAC Key = $keyName->$brand)") | Out-Null
    }
}
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Check-ConfigurationValue
{
    param (
        [string] $keyname, 
        [string] $brand,
        [string] $value,
        [string[]] $placeholders
    )
    
    if ($value -ne $null)
    {
        # if value is like : "{\"uri\":\"https://uat-edc-denovo-kv01.vault.azure.net/secrets/nppLatencyStorageConnectionString\"}"
        if ($value -match 'uri(.*)/secrets/')
        {
            $uri = $value | ConvertFrom-Json | Select-Object -ExpandProperty uri
            Check-ConfigurationUri -keyName $keyName -brand $brand -uri $uri
        }
        # if value is like: "https://uat-edc-denovo-kv01.vault.azure.net/secrets/nppLatencyStorageConnectionString"
        elseif ($value -like "*vault.azure.net/secrets/*")
        {
            Check-ConfigurationUri -keyName $keyName -brand $brand -uri $value
        }
        # if the value is a placeholder value that should have a Key Vault value then log the error
        elseif ($value -in $placeholders)
        {
            $script:warningList.Add("Key Vault value expected. Current value is '$value'. (AAC Key = $keyName->$brand)") | Out-Null
        }
    }
}

# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# START
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

$script:errorList = [System.Collections.ArrayList]@()
$script:warningList = [System.Collections.ArrayList]@()
$script:keyVaultCache = [System.Collections.ArrayList]@()
$ErrorActionPreference = 'Stop'

$file = Get-ChildItem -Path $AppConfigRootFolder -Filter "$EnvironmentFilter.json"

Write-Host "Loading AAC file: $($file.name) for the $EnvironmentFilter environment."
$data = Get-Content -Path $file | ConvertFrom-Json

$fields = $data | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name

Write-Host "Checking $($fields.count) fields..."
foreach ($field in $fields)
{
    $boqValue = $data.$field.BOQ
    $vmaValue = $data.$field.VMA

    Check-ConfigurationValue -keyname $field -brand 'BOQ' -value $boqValue -placeholders $PlaceHolders
    Check-ConfigurationValue -keyname $field -brand 'VMA' -value $vmaValue -placeholders $PlaceHolders
}
Write-Host

if ($errorList.Count -gt 0)
{
    switch ($ScriptErrorAction)
    {
        # use the log formatting that Azure Devops Pipelines use
        "Error" 
        {
            $errorList | ForEach-Object { Write-Host "##vso[task.LogIssue type=error;]$_" }
            exit 1
        }
        "Warn" 
        {   
            $errorList | ForEach-Object { Write-Host "##vso[task.LogIssue type=warning;]$_" }
        }
        "Info" 
        {
            $errorList | ForEach-Object { Write-Host "$_" }
        }
    }
}
else 
{
    Write-Host "All key vault references in $($file.name) exist in $EnvironmentFilter Key Vaults."
}
# if there are any warnings, output them here
if ($warningList.Count -gt 0)
{
    Write-Host
    Write-Host "Found keys with placeholder values ($($PlaceHolders -join ', ')) in $($file.name)"
    $warningList | ForEach-Object { Write-Host "##vso[task.LogIssue type=warning;]$_" }
}

Write-Host "All done."