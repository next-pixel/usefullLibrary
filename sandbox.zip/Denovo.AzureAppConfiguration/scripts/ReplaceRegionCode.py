import json
import sys

def main():
    path_to_file = sys.argv[1]
    regionCode = sys.argv[2]

    with open(path_to_file) as f:
        data = json.load(f)

    data["regionOne.code"]["VMA"] = regionCode
    data["regionOne.code"]["BOQ"] = regionCode
    data["regionOne.code"]["MEB"] = regionCode
    
    # writes to file
    with open((path_to_file), 'w') as fp:
        json.dump(data, fp, indent=4)

if __name__ == "__main__":
    # execute only if run as a script
    main()