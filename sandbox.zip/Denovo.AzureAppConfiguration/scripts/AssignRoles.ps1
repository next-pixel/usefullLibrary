###############
# Assign proper role to environment service principal
###############
param (
    [string] $appConfigurationName,
    [string] $environmentServicePrincipalId
)

# Retrieve app registration client id
$appRegistrationJsonText = az ad sp show --id $environmentServicePrincipalId
$appRegistrationJson = $appRegistrationJsonText | ConvertFrom-Json
$appRegistrationId = $appRegistrationJson.objectId
Write-Host $appRegistrationId

# Get the app config service id
$appConfigJsonText = az resource list --name $appConfigurationName --resource-type Microsoft.AppConfiguration/configurationStores
$appConfigJson = $appConfigJsonText | ConvertFrom-Json
$appConfigId = $appConfigJson.id
Write-Host $appConfigId

## Assign role
az role assignment create --assignee-object-id $appRegistrationId --scope $appConfigId --role "App Configuration Data Reader"