﻿param (
    [string] $Folder = "..",
    [string] $masterFilename = "configMaster.json"
    )

$emptyData = "DATA-NOT-SET"

Write-Host "Processing $masterFilename"
$masterFile = Join-Path -Path $Folder -ChildPath $masterFilename
$master = Get-Content $masterFile -Raw | ConvertFrom-Json

# get the list of env JSON files
$envFiles = Get-ChildItem -Path $Folder -Exclude $masterFilename | Where-Object Extension -eq ".json"

# build the initial list from the configMaster
$variables = New-Object System.Collections.ArrayList
foreach ($property in $master.PsObject.Properties)
{
    $row = [PsCustomObject] @{
        Key = $property.name
    }
    # Add DATA-NOT-SET values for each ENV
    $envFiles | ForEach-Object {  $row | Add-Member -MemberType NoteProperty -Name $_.BaseName -Value $emptyData | Out-Null }
    $variables.Add($row) | Out-Null
}
$noConfigMasterDefinedList = New-Object System.Collections.ArrayList
# go through each ENV file and update the $variables to replace the DATA-NOT-SET with the actual value
foreach ($environment in $envFiles)
{
    Write-Host "Processing $($environment.Name)" 
    $envData = Get-Content -Path $environment.FullName -Raw | ConvertFrom-Json
    foreach ($property in $envData.PsObject.Properties)
    {
        $variable = $variables | Where-Object Key -eq $property.name
        if ($variable -eq $null)
        {
            $row = [PSCustomObject] @{
                Environment = $environment.baseName
                Key = $property.name
            }
            $noConfigMasterDefinedList.Add($row) | out-Null
        }
        else
        {
            $variable.$($environment.baseName) = $property.Value    
        }
    }
}
Write-Host
Write-Host "--- REPORT ---"
if ($noConfigMasterDefinedList.count -gt 0)
{
    #pivot data based on key name to make a more readable report
    $keyGroup = $noConfigMasterDefinedList | Group-Object -Property Key
    $errorMsg = "Found $($keyGroup.length) keys defined in environment files that are not defined in $masterFilename `r`n"
    $keyGroup | ForEach-Object { $errorMsg += "Key: $($_.Name), Environments: $($_.Group.Environment -join ', ')`r`n" }
    Write-Host "##vso[task.logissue type=error;]$errorMsg"
}
Write-Host
$missingVars = $variables | Where-Object { $_.psobject.properties.value -eq $emptyData}
if ($missingVars.count -gt 0)
{
    $errorMsg =  "Found $($missingVars.count) keys defined in $masterFilename that are missing environment values `r`n" 
    $missingVars | ForEach-Object { $errorMsg += "Key: $($_.Key), Environments: $(($_.psobject.properties | Where-Object {$_.Value -eq $emptyData} | Select-Object -ExpandProperty Name) -join ', ' )`r`n" }
    Write-Host "##vso[task.logissue type=error;]$errorMsg"
}
# if no issues found, its happy days
if ($noConfigMasterDefinedList.count -eq 0 -and $missingVars.count -eq 0)
{
    Write-Host "All checks passed."
}
else 
{
    Write-Host "##vso[task.complete result=Failed;]Check log for details on what needs to be corrected"
}
