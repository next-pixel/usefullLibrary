param (
    [string] $appConfigurationName
)

Write-Host "Adding Sentinel"
az appconfig kv set -n $appConfigurationName --key "sentinel" --value (Get-Date -UFormat "%d/%m/%Y %H:%M:%S") --yes