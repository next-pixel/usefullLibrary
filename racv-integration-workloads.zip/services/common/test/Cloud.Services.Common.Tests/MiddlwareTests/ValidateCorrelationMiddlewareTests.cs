﻿using Cloud.Services.Common.Middleware;
using Microsoft.AspNetCore.Http;

namespace Cloud.Integration.Common.Tests.Unit.Middleware
{
    public class ValidateCorrelationMiddlewareTests
    {
        [Fact]
        public async Task InvokeAsync_ValidCorrelationId_ShouldCallNextMiddleware()
        {
            // Arrange
            var middleware = new ValidateCorrelationMiddleware(next: (innerHttpContext) =>
            {
                innerHttpContext.Response.StatusCode = StatusCodes.Status200OK;
                return Task.CompletedTask;
            });

            var context = new DefaultHttpContext();
            context.Request.Headers.Append("x-correlation-id", Guid.NewGuid().ToString());

            // Act
            await middleware.InvokeAsync(context);

            // Assert
            Assert.Equal(StatusCodes.Status200OK, context.Response.StatusCode);
        }
    }
}