﻿namespace Cloud.Services.Common.Constants;

/// <summary>
///     Constants to be used across all workloads' services.
/// </summary>
public static class ServicesConstants
{
    /// <summary>
    ///     Used to access the workload name in the configuration.
    /// </summary>
    public const string WorkloadKey = "Workload";

    public const string MessageTrackerContainerKey = "MessageTrackerContainer";
    public const string LogRequestResponseToggleKey = "LogRequestResponseToggle";

    /// <summary>
    ///     Correlation id property name. Used to access the correlation id in requests and telemetry logs.
    /// </summary>
    public const string CorrelationIdLogPropertyName = "x-correlation-id";
    public const string AlertWaring = "AlertWarning";
    public const string Authorization = "Authorization";
    public const string OpenIdConfigurationUrl = "OpenIdConfigurationUrl";
    public const string BlobServiceUriKey = "MessageTrackerBlobServiceUri";
    public const string ApplicationInsightConnectionStringKey = "APPLICATIONINSIGHTS_CONNECTION_STRING";
    public const string AppConfigurationEndPointKey = "AppConfigurationEndPoint";
    public const string KeyVaultEndPointKey = "KeyVaultEndPoint";
    public const string EnvironmentKey = "Environment";
    public const string ConfigurationRefreshKey = "sentinel";
    public const string TennantIdKey = "AzureAD:TenantId";
    public const string AzureClientId = "AZURE_CLIENT_ID";
    public const string ServiceBusNamespace = "ServiceBusConnection:fullyQualifiedNamespace";
    public const string StorageAccountTableUriKey = "StorageAccountTableUri";
    public const string CosmosDbEndpointKey = "CosmosDbEndpoint";
}
