﻿using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Extensions;
using Cloud.Services.Common.Middleware;
using Cloud.Services.Common.Settings;
using Cloud.Services.Common.Tracking.Implementations;
using Cloud.Services.Common.Tracking.Interfaces;
using Cloud.Services.Common.Utility.Handlers.Implementation;
using Cloud.Services.Common.Utility.Handlers.Interfaces;
using GraphQL;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using System.IO.Compression;

namespace Cloud.Services.Common.Startup;

/// <summary>
///     Abstracts common steps when starting up an Services api.
/// </summary>
public static class ApiBaseStartup
{
    /// <summary>
    ///     Configure services via dependency injection.
    /// </summary>
    /// <param name="builder">Web application builder.</param>
    /// <exception cref="ArgumentNullException"></exception>
    public static void ConfigureServices<TCaller>(WebApplicationBuilder builder)
    {
        ArgumentNullException.ThrowIfNull(builder);

        // Define keys used to access values in the configuration manager.
        var _systemName = "ServicesApi";
        var _excludeHeaders = new[] { ServicesConstants.Authorization, "subscription-key", "x-api-key" };

        // Use response compression
        builder.Services.AddResponseCompression(options =>
        {
            options.EnableForHttps = true;
            options.Providers.Add<GzipCompressionProvider>();
            options.Providers.Add<BrotliCompressionProvider>();
        });

        builder.Services.Configure<BrotliCompressionProviderOptions>(options =>
        {
            options.Level = CompressionLevel.Fastest;
        });

        builder.Services.Configure<GzipCompressionProviderOptions>(options =>
        {
            options.Level = CompressionLevel.Fastest;
        });

        // Add configuration
        builder.Services.Configure<IConfiguration>(builder.Configuration);

        // Retrieve the app settings from the application configuration.
        var appSettings = new AppSettings();
        builder.Configuration.Bind(appSettings);

        // Enable application insights.
        builder.Services.AddApplicationInsights(
            appSettings.ApplicationInsightConnectionString);

        // Configure app configuration service in the web host.
        builder.ConfigureAppConfiguration<TCaller>(
            new Uri(appSettings.AppConfigurationEndPoint),
            appSettings.AzureClientId,
            appSettings.Environment,
            appSettings.Workload,
            ServicesConstants.ConfigurationRefreshKey);

        builder.AddCustomModelValidationError();

        //Add OpenId authentication
        builder.Services
            .AddAuthentication(opts =>
            {
                opts.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                opts.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(
                opts =>
                {
                    var configManager = new ConfigurationManager<OpenIdConnectConfiguration>(
                        builder.Configuration[ServicesConstants.OpenIdConfigurationUrl],
                        new OpenIdConnectConfigurationRetriever(),
                        new HttpDocumentRetriever())
                    { AutomaticRefreshInterval = new TimeSpan(1, 0, 0) };

                    var discoveryDocument = configManager.GetConfigurationAsync().GetAwaiter().GetResult();
                    var signingKeys = discoveryDocument.SigningKeys;
                    var issuer = discoveryDocument.Issuer;

                    opts.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidAudience = issuer,
                        ValidIssuer = issuer,
                        ValidateIssuer = true,
                        IssuerSigningKeys = signingKeys,
                        ValidateAudience = true,
                        RequireExpirationTime = true,
                        ValidateLifetime = true,
                        ClockSkew = TimeSpan.Zero
                    };
                });
#if RELEASE
            // Add message tracker system.
            builder.Services.AddTransient<IMessageTrackerMiddlewareConfiguration, MessageTrackerMiddlewareConfiguration>();
            builder.Services.AddMessageTracker(new Uri(appSettings.BlobServiceUri));
#endif

        // Add message tracker system.
        builder.Services.AddTransient<IMessageTrackerMiddlewareConfiguration, MessageTrackerMiddlewareConfiguration>();
        builder.Services.AddMessageTracker(new Uri(appSettings.BlobServiceUri));

        // Add Message Tracker Handler.
        builder.Services.AddTransient<IMessageTrackerHandlerConfiguration, MessageTrackerHandlerConfiguration>();

        builder.Services.AddSingleton<IMessageTrackerHandler<HttpRequestMessage, HttpResponseMessage>>(provider =>
            CreateMessageTrackerHandler(provider, _systemName, _excludeHeaders));
        builder.Services.AddSingleton<IMessageTrackerHandler<GraphQLRequest, GraphQLResponse<JObject>>>(provider =>
            CreateMessageTrackerHandler(provider, _systemName, _excludeHeaders));

        // Default Services
        builder.Services.AddControllers();
        builder.Services.AddEndpointsApiExplorer();
    }

    /// <summary>
    ///     This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
    /// </summary>
    /// <param name="app">Application builder.</param>
    /// <param name="env">Environment.</param>
    /// <param name="logging">Logging builder.</param>
    /// <exception cref="ArgumentNullException"></exception>
    public static void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggingBuilder logging)
    {
        ArgumentNullException.ThrowIfNull(app);
        ArgumentNullException.ThrowIfNull(env);
        ArgumentNullException.ThrowIfNull(logging);

        // Configure the HTTP request pipeline.
        if (env.IsDevelopment())
        {
            logging.AddDebug();
        }

        app.UseAzureAppConfiguration();
        app.UseMiddleware<ValidateCorrelationMiddleware>();
        app.UseMiddleware<RequestEnrichmentMiddleware>();
#if RELEASE
            app.UseMiddleware<MessageTrackerMiddleware>();
#endif
        app.UseAuthentication();
        app.UseAuthorization();
        app.UseHttpsRedirection();
        app.UseResponseCompression();
    }

    private static MessageTrackerHandler CreateMessageTrackerHandler(IServiceProvider provider, string systemName,
        string[] excludeHeaders)
    {
        var logger = provider.GetRequiredService<ILogger<MessageTrackerHandler>>();
        var messageTracker = provider.GetRequiredService<IMessageTracker>();
        var messageTrackerHandlerConfiguration = provider.GetRequiredService<IMessageTrackerHandlerConfiguration>();
        return new MessageTrackerHandler(logger, messageTracker, messageTrackerHandlerConfiguration, systemName,
            excludeHeaders);
    }
}
