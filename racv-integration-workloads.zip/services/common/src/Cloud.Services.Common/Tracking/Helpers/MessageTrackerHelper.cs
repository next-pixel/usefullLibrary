﻿using Cloud.Services.Common.Tracking.Enumerations;

namespace Cloud.Services.Common.Tracking.Helpers
{
    /// <summary>
    /// Helper methods for the message tracker system.
    /// </summary>
    public static class MessageTrackerHelper
    {
        /// <summary>
        /// Formats the file path for message tracking.
        /// </summary>
        /// <remarks>
        /// Payload will be uploaded to the following container/folder destination:
        /// 
        /// Container: tracking
        ///    Folder: [WorkloadName]/[Message timestamp (in UTC)|yyyyMMdd]/[CorrelationId]/[SystemName]
        ///      Blob: [InteractionId]-[OperationName]-[Protocol]-[OperationType].json
        /// </remarks>
        /// <param name="workloadName"></param>
        /// <param name="timestamp"></param>
        /// <param name="correlationIdentifier"></param>
        /// <param name="systemName"></param>
        /// <param name="interactionIdentifier"></param>
        /// <param name="operationName"></param>
        /// <param name="operationProtocol"></param>
        /// <param name="operationType"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        public static string FormatFilePath(string workloadName, DateTime timestamp, string correlationIdentifier, string systemName, string interactionIdentifier, string operationName, OperationProtocols operationProtocol, OperationTypes operationType)
        {
            if (string.IsNullOrWhiteSpace(workloadName)) throw new ArgumentNullException(nameof(workloadName));
            if (string.IsNullOrWhiteSpace(correlationIdentifier)) throw new ArgumentNullException(nameof(correlationIdentifier));
            if (string.IsNullOrWhiteSpace(interactionIdentifier)) throw new ArgumentNullException(nameof(interactionIdentifier));
            if (string.IsNullOrWhiteSpace(operationName)) throw new ArgumentNullException(nameof(operationName));

            string folder = $"{workloadName}/{timestamp.ToString("yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture)}/{correlationIdentifier}/{systemName}";
            string blobName = $"{interactionIdentifier}-{operationName}-{operationProtocol}-{operationType}.json";
            return $"{folder}/{blobName}";
        }
    }
}
