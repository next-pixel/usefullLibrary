﻿using System.ComponentModel;

namespace Cloud.Services.Common.Tracking.Enumerations
{
    /// <summary>
    /// Enumerates the possible message directions.
    /// </summary>
    public enum MessageDirections
    {
        [Description("Unknown")]
        Unknown,
        [Description("Inbound")]
        Inbound,
        [Description("Outbound")]
        Outbound
    }
}
