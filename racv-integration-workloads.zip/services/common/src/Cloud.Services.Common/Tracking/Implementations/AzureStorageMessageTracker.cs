﻿using Cloud.Services.Common.Azure.Blob.Interfaces;
using Cloud.Services.Common.Azure.Blob.Models;
using Cloud.Services.Common.Tracking.Interfaces;
using Cloud.Services.Common.Tracking.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Text;

namespace Cloud.Services.Common.Tracking.Implementation
{
    /// <summary>
    /// Implementation of <see cref="IMessageTracker"/> via direct upload of payload to Azure Blob storage.
    /// </summary>
    public class AzureStorageMessageTracker : IMessageTracker
    {
        /// <summary>
        /// Logger.
        /// </summary>
        private readonly ILogger<AzureStorageMessageTracker> _logger;
        
        /// <summary>
        /// Uploads messages through the blob storage client.
        /// </summary>
        private readonly IBlobStore _blobStore;

        /// <summary>
        /// Constructor for the <see cref="AzureStorageMessageTracker"/> class.
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="blobStore"></param>
        /// <exception cref="ArgumentNullException"></exception>
        public AzureStorageMessageTracker(ILogger<AzureStorageMessageTracker> logger, IBlobStore blobStore)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _blobStore = blobStore ?? throw new ArgumentNullException(nameof(blobStore));
        }

        /// <summary>
        /// Uploads a message to the Blob Store.
        /// </summary>
        /// <typeparam name="TMessage">Message type inheriting from <see cref="BaseMessage"/></typeparam>
        /// <param name="message">Message to be uploaded.</param>
        /// <returns>Task to upload the messages.</returns>
        public async Task TrackMessageAsync<TMessage>(TMessage message, string filePath, string containerName)
            where TMessage : BaseMessage
        {
            ArgumentNullException.ThrowIfNull(message);

            _logger.LogInformation("Uploading a message to the Blob Store.");
            string content = JsonConvert.SerializeObject(message, Formatting.Indented);
            using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(content)))
            {
                await _blobStore.Upload(new BlobModel(filePath, containerName, stream));
            }
        }
    }
}
