﻿namespace Cloud.Services.Common.Tracking.Models
{
    /// <summary>
    /// A message dedicated to capturing RESTful API requests.
    /// </summary>
    public class TrackerRestRequestMessage : BaseMessage
    {
        /// <summary>
        /// The base url of the request controller action.
        /// </summary>
        public string? BaseUrl { get; set; }

        /// <summary>
        /// The path of the request controller action.
        /// </summary>
        public string? Path { get; set; }

        /// <summary>
        /// The verb of the request controller action. This could be GET, POST, PUT etc.
        /// </summary>
        public string? Verb { get; set; }

        /// <summary>
        /// The complete query string of the requested resource.
        /// </summary>
        public string? QueryString { get; set; }

        /// <summary>
        /// A collection of the HTTP request headers.
        /// </summary>
        public Dictionary<string, string>? Headers { get; set; }
    }
}
