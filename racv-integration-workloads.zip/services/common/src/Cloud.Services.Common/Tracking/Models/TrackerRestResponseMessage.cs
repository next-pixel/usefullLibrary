﻿namespace Cloud.Services.Common.Tracking.Models
{
    /// <summary>
    /// A message dedicated to capturing RESTful API responses.
    /// </summary>
    public class TrackerRestResponseMessage : BaseMessage
    {
        /// <summary>
        /// The HTTP staus code of the response.
        /// </summary>
        public int? StatusCode { get; set; }

        /// <summary>
        /// A collection of the HTTP response headers.
        /// </summary>
        public Dictionary<string, string>? Headers { get; set; }
    }
}
