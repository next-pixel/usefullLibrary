namespace Cloud.Services.Common.Tracking.Models
{
    /// <summary>
    /// A class to capture the raw payload for an individual message.
    /// </summary>
    public class Payload
    {
        /// <summary>
        /// This is the MIME type of the payload body.
        /// </summary>
        public string? ContentType { get; set; }

        /// <summary>
        /// The raw payload of the message. This could be JSON, XML etc.
        /// </summary>
        public string? Body { get; set; }
    }
}
