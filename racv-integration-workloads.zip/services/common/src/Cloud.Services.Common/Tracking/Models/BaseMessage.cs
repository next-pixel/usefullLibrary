﻿using Cloud.Services.Common.Tracking.Enumerations;
using Newtonsoft.Json.Converters;
using System.Text.Json.Serialization;

namespace Cloud.Services.Common.Tracking.Models
{
    /// <summary>
    /// The base message used for unified message tracking.
    /// </summary>
    public abstract class BaseMessage
    {
        /// <summary>
        /// A unique identifier for a group of related interactions across disparate systems.
        /// </summary>
        public string? CorrelationId { get; set; }

        /// <summary>
        /// A unique identifier for a set (or pair) of messages that relate to a single system or service.
        /// </summary>
        public Guid InteractionId { get; set; }

        /// <summary>
        /// A unique identifier for an individual message.
        /// </summary>
        public Guid ActivityId { get; set; }

        /// <summary>
        /// The primary identifier for this tracked message. This could be "BondIdentifier", "BondIdentifier" etc.
        /// </summary>
        public string? PrimaryIdentifier { get; set; }

        /// <summary>
        /// The secondary identifier for this tracked message. This could capture specific metadata about an operation.
        /// </summary>
        public string? SecondaryIdentifier { get; set; }

        /// <summary>
        /// The source or target system for this particular tracked message. In an inbound context, this will be an identifier captured from the supplied authentication token.
        /// For example, for an application authenticated with Azure AD, the value captured here could be the "appid" claim.
        /// </summary>
        public string? SystemId { get; set; }

        /// <summary>
        /// The name of the particular operation you are performing. In an HTTP API context, this could be the controller action name. In a gRPC context, this could be the remote procedure call name. In a provider interaction context, this could be a stored procedure name etc.
        /// </summary>
        public string? OperationName { get; set; }

        /// <summary>
        /// The name of the workload that handled the message. In a .NET Core context, this could be the current assembly name (USM.Cloud.Account.API etc). For other workloads this could be the Logic App name etc.
        /// </summary>
        public string? WorkloadName { get; set; }

        /// <summary>
        /// The date and time index at which the message instance was created (at runtime).
        /// </summary>
        public DateTime MessageTimestamp { get; set; }

        /// <summary>
        /// The nature of the tracked message, indicating whether it was a request or response interaction.
        /// </summary>
        [JsonConverter(typeof(StringEnumConverter))]
        public OperationTypes OperationType { get; set; }

        /// <summary>
        /// The nature of the interaction, indicating whether the interaction was inbound to the integration layer (such as an API or gRPC request) or if the interaction was outbound from the integration layer (such as calling a database or a web service).
        /// </summary>
        [JsonConverter(typeof(StringEnumConverter))]
        public MessageDirections Direction { get; set; }

        /// <summary>
        /// The protocol over which this message was tracked. Examples include HTTPS, gRPC, SQL etc.
        /// </summary>
        [JsonConverter(typeof(StringEnumConverter))]
        public OperationProtocols Protocol { get; set; }

        /// <summary>
        /// The payload object contains the raw request or response data for an interaction. In a HTTP context, this will be the Body. In a gRPC context, this will be the message content. In a provider interaction, this will (initially) the internal model content.
        /// </summary>
        public Payload? Payload { get; set; }

        /// <summary>
        /// The type of <see cref="BaseMessage"/> that was used to record the content.
        /// </summary>
        public string MessageType => GetType().Name;
    }
}
