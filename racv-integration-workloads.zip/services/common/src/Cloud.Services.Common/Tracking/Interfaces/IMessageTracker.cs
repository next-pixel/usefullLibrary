﻿using Cloud.Services.Common.Tracking.Models;

namespace Cloud.Services.Common.Tracking.Interfaces
{
    /// <summary>
    /// Message tracker interface.
    /// </summary>
    public interface IMessageTracker
    {
        /// <summary>
        /// Tracks a message.
        /// </summary>
        /// <typeparam name="TMessage">Message type inheriting from the <see cref="BaseMessage"/> class.</typeparam>
        /// <param name="message">The message to track.</param>
        /// <returns></returns>
        Task TrackMessageAsync<TMessage>(TMessage message, string filePath, string containerName) where TMessage : BaseMessage;
    }
}
