﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace Cloud.Services.Common.Models
{
    public class OperationSuccessResponse
    {
        /// <summary>
        /// Successful operation message
        /// </summary>
        [DataMember(Name = "message")]
        [Required]
        public string Message { get; } = "Operation Successful.";

        /// <summary>
        /// Response data
        /// </summary>
        [DataMember(Name = "data")]
        [Required]
        public object? Data { get; set; }
    }
}
