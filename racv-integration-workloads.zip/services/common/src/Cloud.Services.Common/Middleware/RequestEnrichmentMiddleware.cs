﻿using Cloud.Services.Common.Constants;
using Microsoft.ApplicationInsights.DataContracts;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace Cloud.Services.Common.Middleware
{
    /// <summary>
    /// Configures the request telemetry, for example adding custom properties.
    /// </summary>
    public class RequestEnrichmentMiddleware
    {
        /// <summary>
        /// Processes HTTP requests.
        /// </summary>
        private readonly RequestDelegate _next;
        /// <summary>
        /// Logger.
        /// </summary>
        private readonly ILogger<RequestEnrichmentMiddleware> _logger;

        /// <summary>
        /// Constructor for the <see cref="RequestEnrichmentMiddleware"/> class.
        /// </summary>
        /// <param name="next"></param>
        /// <param name="loggerFactory"></param>
        /// <exception cref="ArgumentNullException"></exception>
        public RequestEnrichmentMiddleware(RequestDelegate next, ILoggerFactory loggerFactory)
        {
            _next = next ?? throw new ArgumentNullException(nameof(next));
            _logger = loggerFactory.CreateLogger<RequestEnrichmentMiddleware>();
        }

        /// <summary>
        /// Invoke the middleware.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InvokeAsync(HttpContext context)
        {
            var requestTelemetry = context.Features.Get<RequestTelemetry>();
            if (requestTelemetry == null) { return; }
            _logger.LogDebug($"Adding custom property to request telemetry '{ServicesConstants.CorrelationIdLogPropertyName}'.");
            string correlationIdentifier = context.Request.Headers[ServicesConstants.CorrelationIdLogPropertyName][0]!.ToString();
            requestTelemetry.Properties[ServicesConstants.CorrelationIdLogPropertyName] = correlationIdentifier;
            await _next(context);
        }
    }
}
