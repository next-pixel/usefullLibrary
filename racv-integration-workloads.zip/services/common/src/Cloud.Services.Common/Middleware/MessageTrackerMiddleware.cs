﻿using System.Globalization;
using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Extensions;
using Cloud.Services.Common.Tracking.Enumerations;
using Cloud.Services.Common.Tracking.Helpers;
using Cloud.Services.Common.Tracking.Interfaces;
using Cloud.Services.Common.Tracking.Models;
using Microsoft.ApplicationInsights.AspNetCore.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace Cloud.Services.Common.Middleware;

/// <summary>
///     This middleware component will serve all workloads that have been built as ASP.NET Core APIs. It is inserted into
///     the HTTP request/response pipeline to automatically capture the request and response payloads for all API
///     interactions within a workload.
/// </summary>
public class MessageTrackerMiddleware
{
    /// <summary>
    ///     The system name.
    /// </summary>
    private const string _systemName = "ServicesApi";

    /// <summary>
    ///     Application configuration values. Some of these values are logged with the request / response.
    /// </summary>
    private readonly IMessageTrackerMiddlewareConfiguration _configuration;

    /// <summary>
    ///     Header keys to filter out of the request / response logs.
    /// </summary>
    private readonly string[] _excludeHeaderKeys = [ServicesConstants.Authorization, "subscription-key", "x-api-key"];

    /// <summary>
    ///     Logger.
    /// </summary>
    private readonly ILogger<MessageTrackerMiddleware> _logger;

    /// <summary>
    ///     Message tracker client.
    /// </summary>
    private readonly IMessageTracker _messageTracker;

    /// <summary>
    ///     Processes HTTP requests.
    /// </summary>
    private readonly RequestDelegate _next;

    /// <summary>
    ///     Constructor for the <see cref="MessageTrackerMiddleware" /> class.
    /// </summary>
    /// <param name="next"></param>
    /// <param name="messageTracker"></param>
    /// <param name="configuration"></param>
    /// <exception cref="ArgumentNullException"></exception>
    public MessageTrackerMiddleware(RequestDelegate next, IMessageTracker messageTracker,
        IMessageTrackerMiddlewareConfiguration configuration, ILoggerFactory loggerFactory)
    {
        _next = next ?? throw new ArgumentNullException(nameof(next));
        _messageTracker = messageTracker ?? throw new ArgumentNullException(nameof(messageTracker));
        _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        _logger = loggerFactory.CreateLogger<MessageTrackerMiddleware>();
    }

    /// <summary>
    ///     Invoke the middleware.
    /// </summary>
    /// <param name="context"></param>
    /// <returns></returns>
    public async Task Invoke(HttpContext context)
    {
        if (_configuration.LogRequestResponseToggle)
        {
            // generate the interaction identifier for the pair (request, response)
            var interactionId = Guid.NewGuid();
            // log the request
            await LogRequest(context, interactionId);
            // swap out the stream on the response body so that we can read it
            var originalBodyStream = context.Response.Body;
            using var responseBody = new MemoryStream();
            context.Response.Body = responseBody;
            // write the contents of the response body into our swapped stream
            await _next(context);
            // log the response
            await LogResponse(context, interactionId);
            // put the original stream back
            await responseBody.CopyToAsync(originalBodyStream);
            context.Response.Body = originalBodyStream;
        }
        else
        {
            await _next(context);
        }
    }

    /// <summary>
    ///     Logs the HTTP response to the message tracker system.
    /// </summary>
    /// <param name="context"></param>
    /// <param name="interactionId"></param>
    /// <returns></returns>
    private async Task LogResponse(HttpContext context, Guid interactionId)
    {
        var payload = new Payload
        {
            ContentType = context.Response.ContentType, Body = await context.Response.GetResponseBodyAsStringAsync()
        };

        var xCorrelationIdentifier =
            context.Request.Headers[ServicesConstants.CorrelationIdLogPropertyName][0]!.ToLower(CultureInfo
                .InvariantCulture);
        var timestamp = DateTime.UtcNow;
        var operationName = context.Request.Method;
        var protocol = context.Request.IsHttps ? OperationProtocols.HTTPS : OperationProtocols.HTTP;
        var operationType = OperationTypes.Response;

        var logEntry = new TrackerRestResponseMessage
        {
            CorrelationId = xCorrelationIdentifier,
            InteractionId = interactionId,
            ActivityId = Guid.NewGuid(),
            OperationName = operationName,
            WorkloadName = _configuration.WorkloadName,
            MessageTimestamp = timestamp,
            OperationType = operationType,
            Protocol = protocol,
            Payload = payload,
            StatusCode = context.Response.StatusCode,
            Headers = context.Request.Headers.Where(a => !_excludeHeaderKeys.Contains(a.Key))
                .ToDictionary(a => a.Key, a => a.Value.ToString()),
            SystemId = _systemName
        };

        var filePath = MessageTrackerHelper.FormatFilePath(_configuration.WorkloadName, timestamp,
            xCorrelationIdentifier, _systemName, interactionId.ToString(), operationName, protocol, operationType);

        try
        {
            await _messageTracker.TrackMessageAsync(logEntry, filePath, _configuration.ContainerName);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName +
                "} failed to log response with error: {message}", xCorrelationIdentifier, ex.Message);
            throw;
        }
    }

    /// <summary>
    ///     Logs the HTTP request to the message tracker system.
    /// </summary>
    /// <param name="context"></param>
    /// <param name="interactionId"></param>
    /// <returns></returns>
    private async Task LogRequest(HttpContext context, Guid interactionId)
    {
        var payload = new Payload
        {
            ContentType = context.Request.ContentType, Body = await context.Request.GetRequestBodyAsStringAsync()
        };

        var xCorrelationIdentifier =
            context.Request.Headers[ServicesConstants.CorrelationIdLogPropertyName][0]!.ToLower(CultureInfo
                .InvariantCulture);
        var timestamp = DateTime.UtcNow;
        var operationName = context.Request.Method;
        var protocol = context.Request.IsHttps ? OperationProtocols.HTTPS : OperationProtocols.HTTP;
        var operationType = OperationTypes.Request;

        var logEntry = new TrackerRestRequestMessage
        {
            CorrelationId = xCorrelationIdentifier,
            InteractionId = interactionId,
            ActivityId = Guid.NewGuid(),
            OperationName = operationName,
            WorkloadName = _configuration.WorkloadName,
            MessageTimestamp = timestamp,
            OperationType = operationType,
            Protocol = protocol,
            Payload = payload,
            Path = "",
            Verb = context.Request.Method,
            QueryString = context.Request.QueryString.ToString(),
            Headers = context.Request.Headers.Where(a => !_excludeHeaderKeys.Contains(a.Key))
                .ToDictionary(a => a.Key, a => a.Value.ToString()),
            SystemId = _systemName,
            BaseUrl = context.Request.GetUri().AbsoluteUri
        };

        var filePath = MessageTrackerHelper.FormatFilePath(_configuration.WorkloadName, timestamp,
            xCorrelationIdentifier, _systemName, interactionId.ToString(), operationName, protocol, operationType);

        try
        {
            await _messageTracker.TrackMessageAsync(logEntry, filePath, _configuration.ContainerName);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName +
                "} failed to log response with error: {message}", xCorrelationIdentifier, ex.Message);
            throw;
        }
    }
}
