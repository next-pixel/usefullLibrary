﻿using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Exceptions;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace Cloud.Services.Common.Middleware
{
    /// <summary>
    /// Validates Correlation Id in REST API services. 
    /// </summary>
    public class ValidateCorrelationMiddleware
    {
        /// <summary>
        /// Processes HTTP requests.
        /// </summary>
        private readonly RequestDelegate _next;

        /// <summary>
        /// Message to show on detecting an invalid or missing correlation identifier.
        /// </summary>
        private const string InvalidCorrIdMessage = "Invalid Correlation Identifier";

        /// <summary>
        /// Constructor for the <see cref="ValidateCorrelationMiddleware"/> class.
        /// </summary>
        /// <param name="next"></param>
        /// <param name="loggerFactory"></param>
        /// <exception cref="ArgumentNullException"></exception>
        public ValidateCorrelationMiddleware(RequestDelegate next)
        {
            _next = next ?? throw new ArgumentNullException(nameof(next));
        }

        /// <summary>
        /// Invoke the middleware.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InvokeAsync(HttpContext context)
        {
            if (context.Request.Headers.ContainsKey(ServicesConstants.CorrelationIdLogPropertyName))
            {
                Guid correlationId;
                if (Guid.TryParse(context.Request.Headers[ServicesConstants.CorrelationIdLogPropertyName][0], out correlationId) && correlationId != Guid.Empty)
                {
                    await _next(context);
                    return;
                }
            }
            context.Response.StatusCode = StatusCodes.Status400BadRequest;
            context.Response.ContentType = "application/json";
            var errorDetails = new OperationFailureResponseDetail[]
            {
                new OperationFailureResponseDetail()
                {
                    Message = InvalidCorrIdMessage
                }
            };
            var errorBody = new OperationFailureResponse(InvalidCorrIdMessage, errorDetails);
            await context.Response.WriteAsync(JsonConvert.SerializeObject(errorBody));
        }
    }
}
