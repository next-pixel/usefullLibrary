﻿namespace Cloud.Services.Common.Settings
{
    public class ChargeFoxSettings
    {
        public const string ConfigurationSectionName = "ChargeFoxSettings";
        public string BaseUrl { get; set; } = string.Empty;
        public string LatestMutualVersion { get; set; } = string.Empty;
        public string OCPIHandshakeCredentialsToken { get; set; } = string.Empty;
        public string OCPISenderCredentialsToken { get; set; } = string.Empty;
        public string OCPIReceiverCredentialsToken { get; set; } = string.Empty;
        public int ChargerLocationsLimit { get; set; } = 400;
        public int ChargerTariffsLimit { get; set; } = 400;
        public int ChargerLocationsRequestDelayInMs { get; set; } = 0;
        public int ChargerTariffsRequestDelayInMs { get; set; } = 0;
    }
}
