﻿namespace Cloud.Services.Common.Settings
{
    public class OCPISettings
    {
        public const string ConfigurationSectionName = "OCPISettings";
        public string VersionsEndpoint { get; set; } = string.Empty;
        public OCPIVersion VersionDetails { get; set; } = new();
    }

    public class OCPIVersion
    {
        public Version Version { get; set; } = new Version();
        public string Url { get; set; } = string.Empty;
        public List<Endpoint> Endpoints { get; set; } = new List<Endpoint>();
    }

    public class Endpoint
    {
        public string Identifier { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
        public string Url { get; set; } = string.Empty;
    }
}
