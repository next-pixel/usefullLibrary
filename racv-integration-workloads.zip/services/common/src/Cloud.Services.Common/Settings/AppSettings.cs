﻿using Cloud.Services.Common.Constants;
using Microsoft.Extensions.Configuration;

namespace Cloud.Services.Common.Settings
{
    public class AppSettings
    {
        [ConfigurationKeyName(ServicesConstants.ApplicationInsightConnectionStringKey)]
        public string ApplicationInsightConnectionString { get; set; } = string.Empty;

        [ConfigurationKeyName(ServicesConstants.AppConfigurationEndPointKey)]
        public string AppConfigurationEndPoint { get; set; } = string.Empty;

        [ConfigurationKeyName(ServicesConstants.AzureClientId)]
        public string AzureClientId { get; set; } = string.Empty;

        [ConfigurationKeyName(ServicesConstants.EnvironmentKey)]
        public string Environment { get; set; } = string.Empty;

        [ConfigurationKeyName(ServicesConstants.WorkloadKey)]
        public string Workload { get; set; } = string.Empty;

        [ConfigurationKeyName(ServicesConstants.BlobServiceUriKey)]
        public string BlobServiceUri { get; set; } = string.Empty;
    }
}