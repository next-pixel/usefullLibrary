﻿using Azure.Security.KeyVault.Certificates;
using Cloud.Services.Common.Azure.Keyvault.Interfaces;
using Cloud.Services.Common.Connector.Models.Exceptions;
using Cloud.Services.Common.Constants;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Security.Cryptography.X509Certificates;

namespace Cloud.Services.Common.Azure.Keyvault.Implementations
{
    public class KeyvaultCertificateService : IKeyvaultCertificateService
    {
        private readonly ILogger<KeyvaultCertificateService> _logger;

        /// <summary>
        /// Keyvault certificate client.
        /// </summary>
        private readonly CertificateClient _certificateClient;

        public KeyvaultCertificateService(
            ILogger<KeyvaultCertificateService> logger,
            CertificateClient certificateClient)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _certificateClient = certificateClient ?? throw new ArgumentNullException(nameof(certificateClient));
        }

        public async Task<X509Certificate2> DownloadCertificateAsync(
            string certificateName,
            Guid xCorrelationIdentifier)
        {
            var certificate = await _certificateClient.DownloadCertificateAsync(certificateName);

            if (certificate == null)
            {
                string exceptionMessage = $"Failed to retrieve the client certificate for generating salesforce token.";
                var customException = new ExternalApiDependencyException(exceptionMessage);
                _logger.LogError(
                    customException,
                    "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName + "} " +
                    "Authentication failed due to external API dependency. message: {Message} " +
                    "ERROR DETAILS: {ErrorDetails}",
                    xCorrelationIdentifier,
                    customException.Message,
                    JsonConvert.SerializeObject(customException.ErrorDetails));
                throw customException;
            }
            return certificate.Value;
        }
    }
}