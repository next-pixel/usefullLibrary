﻿using System.Security.Cryptography.X509Certificates;

namespace Cloud.Services.Common.Azure.Keyvault.Interfaces
{
    public interface IKeyvaultCertificateService
    {
        Task<X509Certificate2> DownloadCertificateAsync(string certificateName, Guid xCorrelationIdentifier);
    }
}
