﻿using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Cloud.Services.Common.Azure.Blob.Interfaces;
using Cloud.Services.Common.Azure.Blob.Models;
using Microsoft.Extensions.Logging;

namespace Cloud.Services.Common.Azure.Blob.Implementation
{
    /// <summary>
    /// Concrete implementation of interface <see cref="IBlobStore"/> which allows the caller to perform various operations on an Azure Blob Service client.
    /// </summary>
    public class AzureBlobStore : IBlobStore
    {
        /// <summary>
        /// Azure Blob Service client.
        /// </summary>
        private readonly BlobServiceClient _blobClient;
        /// <summary>
        /// Logger.
        /// </summary>
        private readonly ILogger<AzureBlobStore> _logger;

        /// <summary>
        /// Constructor for <see cref="AzureBlobStore"/>.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="storageAccount">Azure Blob Service client to be used.</param>
        /// <exception cref="ArgumentNullException"></exception>
        public AzureBlobStore(ILogger<AzureBlobStore> logger, BlobServiceClient storageAccount)
        {
            _blobClient = storageAccount ?? throw new ArgumentNullException(nameof(storageAccount));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <summary>
        /// Downloads a blob from an Azure Blob Store container.
        /// </summary>
        /// <param name="filePath">Path to the blob in the container.</param>
        /// <param name="containerName">Container name.</param>
        /// <returns>The status of the download request.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        public async Task<BlobOperationResponse> Download(string filePath, string containerName)
        {
            if (string.IsNullOrWhiteSpace(filePath)) throw new ArgumentNullException(nameof(filePath));
            if (string.IsNullOrWhiteSpace(containerName)) throw new ArgumentNullException(nameof(containerName));
            var blobContainerClient = _blobClient.GetBlobContainerClient(containerName);
            var blobClient = blobContainerClient.GetBlobClient(filePath);
            Response? response = null;
            var ms = new MemoryStream();
            try
            {
                response = await blobClient.DownloadToAsync(ms);
                ms.Position = 0;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
            var blob = new BlobModel(filePath, containerName, ms);
            return new BlobOperationResponse(response.Status, blob);
        }

        /// <summary>
        /// Uploads a blob to an Azure Blob Service container.
        /// </summary>
        /// <param name="blob">Blob details.</param>
        /// <param name="metadata">Optional metadata relating to the blob.</param>
        /// <returns>The blob store operation response.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        public async Task<BlobOperationResponse> Upload(BlobModel blob, Dictionary<string, string>? metadata = null)
        {
            ArgumentNullException.ThrowIfNull(blob);
            var blobContainerClient = _blobClient.GetBlobContainerClient(blob.ContainerName);

            var blobClient = blobContainerClient.GetBlobClient(blob.FilePath);
            Response<BlobContentInfo>? response = null; 
            try
            {
                _logger.LogDebug($"Uploading blob to '{blob.ContainerName}/{blob.FilePath}'");
                blob.Content.Seek(0, SeekOrigin.Begin);
                response = await blobClient.UploadAsync(blob.Content, null, metadata);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
            return new BlobOperationResponse(response.GetRawResponse().Status, blob);
        }

        /// <summary>
        /// Deletes a blob from an Azure Blob Store container.
        /// </summary>
        /// <param name="filePath">Path to the blob in the container.</param>
        /// <param name="containerName">Container name.</param>
        /// <returns>The status of the delete request.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        public async Task<BlobOperationResponse> Delete(string filePath, string containerName)
        {
            if (string.IsNullOrWhiteSpace(filePath)) throw new ArgumentNullException(nameof(filePath));
            if (string.IsNullOrWhiteSpace(containerName)) throw new ArgumentNullException(nameof(containerName));
            var blobContainerClient = _blobClient.GetBlobContainerClient(containerName);
            var blobClient = blobContainerClient.GetBlobClient(filePath);
            Response? response = null;
            try
            {
                response = await blobClient.DeleteAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
            return new BlobOperationResponse(response.Status);
        }

        /// <summary>
        /// Checks whether a blob exists.
        /// </summary>
        /// <param name="blob">Blob details.</param>
        /// <returns>True with the blob exists within the client and false otherwise.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        public async Task<bool> Exists(BlobModel blob)
        {
            ArgumentNullException.ThrowIfNull(blob);

            var blobContainerClient = _blobClient.GetBlobContainerClient(blob.ContainerName);

            // can't exist if the container doesn't.
            if (!await blobContainerClient.ExistsAsync()) return false;

            var blobClient = blobContainerClient.GetBlobClient(blob.FilePath);

            return await blobClient.ExistsAsync();
        }

        /// <summary>
        /// Loads metadata for a blob.
        /// </summary>
        /// <param name="blob">Blob details.</param>
        /// <returns>Blob metadata.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        public async Task<Dictionary<string, string>> LoadMetadata(Uri blob)
        {
            ArgumentNullException.ThrowIfNull(blob);

            var uriBuilder = new BlobUriBuilder(blob);

            var blobContainerClient = _blobClient.GetBlobContainerClient(uriBuilder.BlobContainerName);
            var blobClient = blobContainerClient.GetBlobClient(uriBuilder.BlobName);

            var props = await blobClient.GetPropertiesAsync();

            return new Dictionary<string, string>(props.Value.Metadata);
        }

        /// <summary>
        /// Gets the number of blobs in a container.
        /// </summary>
        /// <param name="containerName">Name of the container.</param>
        /// <returns>The number of blobs in the given container.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        public Task<int> GetBlobCount(string containerName)
        {
            if (string.IsNullOrWhiteSpace(containerName)) throw new ArgumentNullException(nameof(containerName));

            var blobContainerClient = _blobClient.GetBlobContainerClient(containerName);

            if (!blobContainerClient.Exists())
            {
                return Task.FromResult(0);
            }

            return Task.FromResult(blobContainerClient.GetBlobs().Count());
        }
    }
}
