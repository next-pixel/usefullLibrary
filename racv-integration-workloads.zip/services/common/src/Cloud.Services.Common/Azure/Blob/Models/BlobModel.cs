﻿namespace Cloud.Services.Common.Azure.Blob.Models
{
    /// <summary>
    /// Blob details.
    /// </summary>
    public class BlobModel : IDisposable
    {
        /// <summary>
        /// Constructor for <see cref="BlobModel"/>.
        /// </summary>
        /// <param name="filePath">Path to the blob within the container.</param>
        /// <param name="containerName">Container name.</param>
        /// <param name="content">Contents of the blob.</param>
        public BlobModel(string filePath, string containerName, MemoryStream content)
        {
            FilePath = filePath;
            ContainerName = containerName;
            Content = content;
        }
        /// <summary>
        /// Path to the blob within the container.
        /// </summary>
        public string FilePath { get; set; }
        /// <summary>
        /// Container name.
        /// </summary>
        public string ContainerName { get; set; }
        /// <summary>
        /// Contents of the blob.
        /// </summary>
        public Stream Content { get; set; }

        void IDisposable.Dispose()
        {
            if (Content != null)
            {
                Content.Dispose();
            }
            GC.SuppressFinalize(this);
        }
    }
}
