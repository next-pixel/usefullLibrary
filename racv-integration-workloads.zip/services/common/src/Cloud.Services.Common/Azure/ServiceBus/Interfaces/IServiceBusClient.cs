﻿using Azure.Messaging.ServiceBus;

namespace Cloud.Services.Common.Azure.ServiceBus.Interfaces
{
    /// <summary>
    /// Interface for Service Bus clients.
    /// </summary>
    public interface IServiceBusClient
    {
        /// <summary>
        /// Sends a list of messages to the Service Bus client.
        /// </summary>
        /// <param name="queueOrTopicName">The name of the queue or topic.</param>
        /// <param name="messages">Messages to send.</param>
        /// <returns></returns>
        Task SendMessagesAsync(string queueOrTopicName, IEnumerable<ServiceBusMessage> messages);

        /// <summary>
        /// Sends a message to the Service Bus client.
        /// </summary>
        /// <param name="queueOrTopicName">The name of the queue or topic.</param>
        /// <param name="message">Message to send.</param>
        /// <returns></returns>
        Task SendMessageAsync(string queueOrTopicName, ServiceBusMessage message);

        /// <summary>
        /// Receives messages from the Service Bus client.
        /// </summary>
        /// <param name="queueName">The name of the queue.</param>
        /// <param name="maxMessages">The maximum number of messages to receive.</param>
        /// <returns>The received messages.</returns>
        Task<IEnumerable<ServiceBusReceivedMessage>> ReceiveQueueMessagesAsync(string queueName, int maxMessages);

        /// <summary>
        /// Schedules a message to be sent to the Service Bus client.
        /// </summary>
        /// <param name="queueOrTopicName">The name of the queue or topic.</param>
        /// <param name="message">Message to send.</param>
        /// <param name="dateTimeOffset">The UTC time at which to send the message.</param>
        /// <returns></returns>
        Task ScheduleMessageAsync(string queueOrTopicName, ServiceBusMessage message, DateTimeOffset dateTimeOffset);

        /// <summary>
        /// Completes a batch of service bus messages.
        /// </summary>
        /// <param name="queueName">The name of the queue to which the messages belong.</param>
        /// <param name="receivedMessages">The messages to complete.</param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        Task CompleteQueueMessagesAsync(string queueName, IEnumerable<ServiceBusReceivedMessage> receivedMessages);

        /// <summary>
        /// Complete all the messages received from the queue.
        /// </summary>
        /// <param name="queueName">The queue name.</param>
        Task CompleteQueueMessagesAsync(string queueName);

        /// <summary>
        /// Abandons service bus messages.
        /// </summary>
        /// <param name="queueName">The name of the queue to which the messages belong.</param>
        /// <param name="receivedMessages">The messages to complete.</param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        Task AbandonQueueMessagesAsync(string queueName, IEnumerable<ServiceBusReceivedMessage> receivedMessages);

        /// <summary>
        /// Abandon all the messages received from the queue.
        /// </summary>
        /// <param name="queueName">The queue name.</param>
        Task AbandonQueueMessagesAsync(string queueName);

        /// <summary>
        /// Dead letters service bus messages.
        /// </summary>
        /// <param name="queueName">The name of the queue to which the messages belong.</param>
        /// <param name="receivedMessages">The messages to dead letter.</param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        Task DeadLetterQueueMessagesAsync(string queueName, IEnumerable<ServiceBusReceivedMessage> receivedMessages);

        /// <summary>
        /// Dead letters all the messages received from the queue.
        /// </summary>
        /// <param name="queueName">The queue name.</param>
        Task DeadLetterQueueMessagesAsync(string queueName);
    }
}
