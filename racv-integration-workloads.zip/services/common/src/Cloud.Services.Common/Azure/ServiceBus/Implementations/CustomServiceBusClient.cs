﻿using Azure.Messaging.ServiceBus;
using Cloud.Services.Common.Azure.ServiceBus.Interfaces;
using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;

namespace Cloud.Services.Common.Azure.ServiceBus.Implementations
{
    public class CustomServiceBusClient : IServiceBusClient
    {
        /// <summary>
        /// Azure Service Bus client.
        /// </summary>
        private readonly ServiceBusClient _serviceBusClient;
        /// <summary>
        /// Logger.
        /// </summary>
        private readonly ILogger<CustomServiceBusClient> _logger;
        /// <summary>
        /// List of receivers indexed by queue or topic name.
        /// </summary>
        private readonly ConcurrentDictionary<string, ServiceBusReceiver> _receiverList;
        /// <summary>
        /// List of senders indexed by queue or topic name.
        /// </summary>
        private readonly ConcurrentDictionary<string, ServiceBusSender> _senderList;
        /// <summary>
        /// List of service bus received messages for each queue or topic name.
        /// </summary>
        private readonly ConcurrentDictionary<string, List<ServiceBusReceivedMessage>> _serviceBusReceivedMessages;

        /// <summary>
        /// Class constructor.
        /// </summary>
        /// <param name="logger">Logger.</param>
        /// <param name="serviceBusClient">Azure Service Bus client.</param>
        /// <exception cref="ArgumentNullException"></exception>
        public CustomServiceBusClient(ILogger<CustomServiceBusClient> logger, ServiceBusClient serviceBusClient)
        {
            _serviceBusClient = serviceBusClient ?? throw new ArgumentNullException(nameof(serviceBusClient));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _receiverList = new ConcurrentDictionary<string, ServiceBusReceiver>();
            _senderList = new ConcurrentDictionary<string, ServiceBusSender>();
            _serviceBusReceivedMessages = new ConcurrentDictionary<string, List<ServiceBusReceivedMessage>>();
        }

        /// <summary>
        /// Sends a list of messages to the Service Bus client.
        /// </summary>
        /// <param name="queueOrTopicName">The name of the queue or topic.</param>
        /// <param name="messages">Messages to send.</param>
        /// <returns></returns>
        public async Task SendMessagesAsync(string queueOrTopicName, IEnumerable<ServiceBusMessage> messages)
        {
            ArgumentNullException.ThrowIfNull(messages);
            ArgumentNullException.ThrowIfNull(queueOrTopicName);
            try
            {
                _logger.LogDebug("Uploading messages to Service Bus");
                ServiceBusSender? sender;
                if (!_senderList.TryGetValue(queueOrTopicName, out sender))
                {
                    sender = _serviceBusClient.CreateSender(queueOrTopicName);
                    _senderList[queueOrTopicName] = sender;
                }

                ServiceBusMessageBatch batch = await sender.CreateMessageBatchAsync();
                for (int i = 0; i < messages.Count(); i++)
                {
                    if (!batch.TryAddMessage(messages.ElementAt(i)))
                    {
                        await sender.SendMessagesAsync(batch);
                        batch = await sender.CreateMessageBatchAsync();
                        i--;
                    }
                }

                await sender.SendMessagesAsync(batch);
            }
            catch (TimeoutException ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
            catch (ServiceBusException ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Sends a message to the Service Bus client.
        /// </summary>
        /// <param name="queueOrTopicName">The name of the queue or topic.</param>
        /// <param name="message">Message to send.</param>
        /// <returns></returns>
        public async Task SendMessageAsync(string queueOrTopicName, ServiceBusMessage message)
        {
            ArgumentNullException.ThrowIfNull(message);
            ArgumentNullException.ThrowIfNull(queueOrTopicName);
            try
            {
                _logger.LogDebug("Uploading message to Service Bus");
                ServiceBusSender? sender;
                if (!_senderList.TryGetValue(queueOrTopicName, out sender))
                {
                    sender = _serviceBusClient.CreateSender(queueOrTopicName);
                    _senderList[queueOrTopicName] = sender;
                }
                await sender.SendMessageAsync(message);
            }
            catch (TimeoutException ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
            catch (ServiceBusException ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Schedules a message to be sent to the Service Bus client.
        /// </summary>
        /// <param name="queueOrTopicName">The name of the queue or topic.</param>
        /// <param name="message">Message to send.</param>
        /// <param name="dateTimeOffset">The UTC time at which to send the message.</param>
        /// <returns></returns>
        public async Task ScheduleMessageAsync(string queueOrTopicName, ServiceBusMessage message, DateTimeOffset dateTimeOffset)
        {
            ArgumentNullException.ThrowIfNull(message);
            ArgumentNullException.ThrowIfNull(queueOrTopicName);
            try
            {
                _logger.LogDebug("Scheduling message to be sent to Service Bus at {ScheduleMessageTime}", dateTimeOffset);
                ServiceBusSender? sender;
                if (!_senderList.TryGetValue(queueOrTopicName, out sender))
                {
                    sender = _serviceBusClient.CreateSender(queueOrTopicName);
                    _senderList[queueOrTopicName] = sender;
                }
                await sender.ScheduleMessageAsync(message, dateTimeOffset);
            }
            catch (TimeoutException ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
            catch (ServiceBusException ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Receives messages from the Service Bus client.
        /// </summary>
        /// <param name="queueName">The name of the queue.</param>
        /// <param name="maxMessages">The maximum number of messages to receive.</param>
        /// <returns>The received messages.</returns>
        public async Task<IEnumerable<ServiceBusReceivedMessage>> ReceiveQueueMessagesAsync(string queueName, int maxMessages)
        {
            ArgumentNullException.ThrowIfNull(queueName);
            try
            {
                _logger.LogDebug("Receiving messages from Service Bus");
                ServiceBusReceiver? receiver;
                if (!_receiverList.TryGetValue(queueName, out receiver))
                {
                    receiver = _serviceBusClient.CreateReceiver(queueName);
                    _receiverList[queueName] = receiver;
                }
                var messages = await receiver.ReceiveMessagesAsync(maxMessages);
                List<ServiceBusReceivedMessage>? existingMessagges;
                if (!_serviceBusReceivedMessages.TryGetValue(queueName, out existingMessagges))
                {
                    existingMessagges = new List<ServiceBusReceivedMessage>();
                }
                foreach (var message in messages)
                {
                    existingMessagges.Add(message);
                }
                _serviceBusReceivedMessages[queueName] = existingMessagges;
                return messages.Select(m => m);
            }
            catch (TimeoutException ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
            catch (ServiceBusException ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Completes a batch of service bus messages.
        /// </summary>
        /// <param name="queueName">The name of the queue to which the messages belong.</param>
        /// <param name="receivedMessages">The messages to complete.</param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        public async Task CompleteQueueMessagesAsync(string queueName, IEnumerable<ServiceBusReceivedMessage> receivedMessages)
        {
            ArgumentNullException.ThrowIfNull(receivedMessages);
            ArgumentNullException.ThrowIfNull(queueName);
            try
            {
                _logger.LogDebug("Completing messages from Service Bus");
                ServiceBusReceiver? receiver;
                if (!_receiverList.TryGetValue(queueName, out receiver))
                {
                    receiver = _serviceBusClient.CreateReceiver(queueName);
                    _receiverList[queueName] = receiver;
                }
                var messageTasks = receivedMessages.Select(m => receiver.CompleteMessageAsync(m));
                await Task.WhenAll(messageTasks);
            }
            catch (TimeoutException ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
            catch (ServiceBusException ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Complete all the messages received from the queue.
        /// </summary>
        /// <param name="queueName">The queue name.</param>
        public async Task CompleteQueueMessagesAsync(string queueName)
        {
            if (_receiverList.TryGetValue(queueName, out var receiver) && _serviceBusReceivedMessages.TryGetValue(queueName, out var messages))
            {
                var tasks = messages.Select(m => receiver.CompleteMessageAsync(m));
                await Task.WhenAll(tasks);
                _serviceBusReceivedMessages.Remove(queueName, out var _value);
            }
        }

        /// <summary>
        /// Abandons service bus messages.
        /// </summary>
        /// <param name="queueName">The name of the queue to which the messages belong.</param>
        /// <param name="receivedMessages">The messages to abandon.</param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        public async Task AbandonQueueMessagesAsync(string queueName, IEnumerable<ServiceBusReceivedMessage> receivedMessages)
        {
            ArgumentNullException.ThrowIfNull(receivedMessages);
            ArgumentNullException.ThrowIfNull(queueName);
            try
            {
                _logger.LogDebug("Abandoning messages from Service Bus");
                ServiceBusReceiver? receiver;
                if (!_receiverList.TryGetValue(queueName, out receiver))
                {
                    receiver = _serviceBusClient.CreateReceiver(queueName);
                    _receiverList[queueName] = receiver;
                }
                var messageTasks = receivedMessages.Select(m => receiver.AbandonMessageAsync(m));
                await Task.WhenAll(messageTasks);
            }
            catch (TimeoutException ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
            catch (ServiceBusException ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Abandon all the messages received from the queue.
        /// </summary>
        /// <param name="queueName">The queue name.</param>
        public async Task AbandonQueueMessagesAsync(string queueName)
        {
            if (_receiverList.TryGetValue(queueName, out var receiver) && _serviceBusReceivedMessages.TryGetValue(queueName, out var messages))
            {
                var tasks = messages.Select(m => receiver.AbandonMessageAsync(m));
                await Task.WhenAll(tasks);
                _serviceBusReceivedMessages.Remove(queueName, out var _value);
            }
        }

        /// <summary>
        /// Dead letters service bus messages.
        /// </summary>
        /// <param name="queueName">The name of the queue to which the messages belong.</param>
        /// <param name="receivedMessages">The messages to dead letter.</param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        public async Task DeadLetterQueueMessagesAsync(string queueName, IEnumerable<ServiceBusReceivedMessage> receivedMessages)
        {
            ArgumentNullException.ThrowIfNull(receivedMessages);
            ArgumentNullException.ThrowIfNull(queueName);
            try
            {
                _logger.LogDebug("Abandoning messages from Service Bus");
                ServiceBusReceiver? receiver;
                if (!_receiverList.TryGetValue(queueName, out receiver))
                {
                    receiver = _serviceBusClient.CreateReceiver(queueName);
                    _receiverList[queueName] = receiver;
                }
                var messageTasks = receivedMessages.Select(m => receiver.DeadLetterMessageAsync(m));
                await Task.WhenAll(messageTasks);
            }
            catch (TimeoutException ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
            catch (ServiceBusException ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Dead letters all the messages received from the queue.
        /// </summary>
        /// <param name="queueName">The queue name.</param>
        public async Task DeadLetterQueueMessagesAsync(string queueName)
        {
            if (_receiverList.TryGetValue(queueName, out var receiver) && _serviceBusReceivedMessages.TryGetValue(queueName, out var messages))
            {
                var tasks = messages.Select(m => receiver.DeadLetterMessageAsync(m));
                await Task.WhenAll(tasks);
                _serviceBusReceivedMessages.Remove(queueName, out var _value);
            }
        }
    }
}