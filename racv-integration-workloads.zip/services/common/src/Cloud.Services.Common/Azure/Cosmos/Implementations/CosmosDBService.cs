﻿using Cloud.Services.Common.Azure.Cosmos.Interfaces;
using Microsoft.Azure.Cosmos;
using System.Net;

namespace Cloud.Services.Common.Azure.Cosmos.Implementations
{

    /// <summary>
    /// Service used to access CosmosDb to add, replace or update data for Job Status
    /// </summary>
    public class CosmosDBService : ICosmosDBService
    {
        private readonly Container _container;

        public CosmosDBService(Container container)
        {
            _container = container;
        }

        public async Task<T> GetItemAsync<T>(string id)
        {
            try
            {
                var response = await _container.ReadItemAsync<T>(id, new PartitionKey(id));
                return response.Resource;
            }
            catch (CosmosException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
            {
                return default;
            }
        }

        public async Task<List<T>> GetItemsQueryable<T>(QueryDefinition parameterizedQuery)
        {
            try
            {
                List<T> values = new List<T>();
                
                // Query multiple items from container
                using FeedIterator<T> filteredFeed = _container.GetItemQueryIterator<T>(
                    queryDefinition: parameterizedQuery
                );

                // Iterate query result pages
                while (filteredFeed.HasMoreResults)
                {
                    FeedResponse<T> response = await filteredFeed.ReadNextAsync();

                    // Iterate query results
                    foreach (T item in response)
                    {
                        values.Add(item);
                    }
                }
                return values;
            }
            catch (CosmosException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
            {
                return default;
            }
        }

        public async Task<bool> UpsertItemAsync<T>(string id, T newItem)
        {
            await _container.UpsertItemAsync(newItem, new PartitionKey(id));

            return true;
        }
    }
}