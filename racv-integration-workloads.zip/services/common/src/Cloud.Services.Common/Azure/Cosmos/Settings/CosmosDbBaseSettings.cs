﻿using Microsoft.Azure.Cosmos;

namespace Cloud.Services.Common.Azure.Cosmos.Settings
{
    public class CosmosDbBaseSettings
    {
        public const string ConfigurationSectionName = "CosmosDbBaseSettings";
        public string Endpoint { get; set; } = string.Empty;
        public string DatabaseId { get; set; } = string.Empty;

        public ConnectionMode ConnectionMode { get; set; } = ConnectionMode.Gateway;
    }
}
