﻿using Microsoft.Azure.Cosmos;

namespace Cloud.Services.Common.Azure.Cosmos.Interfaces
{
    public interface ICosmosDBService
    {
        Task<T> GetItemAsync<T>(string id);
        Task<List<T>> GetItemsQueryable<T>(QueryDefinition parameterizedQuery);
        Task<bool> UpsertItemAsync<T>(string id, T newItem);
    }
}
