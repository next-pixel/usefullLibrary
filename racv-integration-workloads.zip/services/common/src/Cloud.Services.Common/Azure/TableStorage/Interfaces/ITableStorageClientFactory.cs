﻿namespace Cloud.Services.Common.Azure.TableStorage.Interfaces
{
    /// <summary>
    /// Table Storage Client Factory interface
    /// </summary>
    public interface ITableStorageClientFactory
    {
        /// <summary>
        /// Create/Retrieve a specific instance of a <see cref="TableClient"/>
        /// </summary>
        /// <param name="endpoint">Table storage endpoint.</param>
        /// <param name="tableName">Container name required by the client to instantiate</param>
        /// <returns>Instance of the <see cref="IBlobContainerClient"/> for the specific container provided</returns>
        IAzureTableStorageService CreateClient(string endpoint, string tableName);
    }
}

