﻿using Azure.Data.Tables;

namespace Cloud.Services.Common.Azure.TableStorage.Interfaces
{
    public interface IAzureTableStorageService
    {
        /// <summary>
        /// Updates or insert an Entity based on the partition key and row key
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="entity"></param>
        /// <returns></returns>
        Task<int> UpsertEntityAsync<T>(T entity) where T : ITableEntity;

        Task<int> BatchUpsert<T>(List<T> entryList) where T : ITableEntity;

        Task<TableEntity> GetTableEntry(string partitionKey, string rowKey);

        Task<T> GetTableEntry<T>(string partitionKey, string rowKey) where T : class, ITableEntity, new();

        Task<List<T>> QueryTable<T>(string filter, int maxPerPage) where T : class, ITableEntity, new();

        Task<int> DeleteEntry(string partitionKey, string rowKey);
    }
}
