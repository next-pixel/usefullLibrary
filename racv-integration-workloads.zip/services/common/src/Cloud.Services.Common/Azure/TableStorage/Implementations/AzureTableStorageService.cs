﻿using Azure.Data.Tables;
using Azure;
using Cloud.Services.Common.Azure.TableStorage.Interfaces;
using Cloud.Services.Common.Azure.TableStorage.Exceptions;

namespace Cloud.Services.Common.Azure.TableStorage.Implementations
{
    //Reliable component
    /// <summary>
    /// Implementation for the <see cref="IAzureTableStorageService"/> interface
    /// </summary>
    public class AzureTableStorageService : IAzureTableStorageService
    {
        private readonly TableClient _tableClient;

        public AzureTableStorageService(TableServiceClient serviceClient, string tableName)
        {
            ArgumentNullException.ThrowIfNull(serviceClient);
            ArgumentNullException.ThrowIfNull(tableName);

            _tableClient = serviceClient.GetTableClient(tableName);
            _tableClient.CreateIfNotExists();
        }

        public AzureTableStorageService(TableClient tableClient)
        {
            _tableClient = tableClient;
            _tableClient.CreateIfNotExists();
        }

        public async Task<int> UpsertEntityAsync<T>(T entity) where T : ITableEntity
        {
            var response = await _tableClient.UpsertEntityAsync(entity);
            return response.Status;
        }

        public async Task<int> BatchUpsert<T>(List<T> entryList) where T : ITableEntity
        {
            var actions = new List<TableTransactionAction>();
            actions.AddRange(entryList.Select(entry => new TableTransactionAction(TableTransactionActionType.UpsertReplace, entry)));
            await _tableClient.SubmitTransactionAsync(actions).ConfigureAwait(false);
            return 200;
        }

        public async Task<TableEntity> GetTableEntry(string partitionKey, string rowKey)
        {
            try
            {
                var response = await _tableClient.GetEntityAsync<TableEntity>(partitionKey, rowKey);
                return response;
            }
            catch (RequestFailedException ex) when (ex.Status == 404)
            {
                throw new EntryNotFoundException(_tableClient.AccountName, partitionKey, rowKey);
            }

        }

        public async Task<T> GetTableEntry<T>(string partitionKey, string rowKey) where T : class, ITableEntity, new()
        {
            try
            {
                var response = await _tableClient.GetEntityAsync<T>(partitionKey, rowKey);
                return response;
            }
            catch (RequestFailedException ex) when (ex.Status == 404)
            {
                throw new EntryNotFoundException(_tableClient.AccountName, partitionKey, rowKey);
            }
        }

        public async Task<List<T>> QueryTable<T>(string filter, int maxPerPage) where T : class, ITableEntity, new()
        {
            AsyncPageable<T> response = _tableClient.QueryAsync<T>(filter, maxPerPage);

            await using (IAsyncEnumerator<Page<T>> enumerator = response.AsPages().GetAsyncEnumerator())
            {
                List<T> result = new List<T>();

                while (await enumerator.MoveNextAsync())
                {
                    if (enumerator.Current.Values.Any())
                        result.AddRange(enumerator.Current.Values);
                }

                return result;
            }
        }

        public async Task<int> DeleteEntry(string partitionKey, string rowKey)
        {
            try
            {
                var response = await _tableClient.DeleteEntityAsync(partitionKey, rowKey);
                return response.Status;
            }
            catch (RequestFailedException ex) when (ex.Status == 404)
            {
                throw new EntryNotFoundException(_tableClient.AccountName, partitionKey, rowKey);
            }
        }
    }
}

