﻿using Azure.Data.Tables;
using Azure.Identity;
using Cloud.Services.Common.Azure.TableStorage.Interfaces;

namespace Cloud.Services.Common.Azure.TableStorage.Implementations
{
    /// <summary>
    /// Implementation for the <see cref="ITableStorageClientFactory"/> interface
    /// </summary>
    public class TableStorageClientFactory : ITableStorageClientFactory
    {
        private readonly Dictionary<string, IAzureTableStorageService> _clients = new Dictionary<string, IAzureTableStorageService>();

        /// <summary>
        /// Create/Retrieve a specific instance of a <see cref="IAzureTableStorageService"/>
        /// </summary>
        /// <param name="endpoint">Table storage endpoint</param>
        /// <param name="tableName">Container name required by the client to instantiate</param>
        /// <returns>Instance of the <see cref="IAzureTableStorageService"/> for the specific container provided</returns>
        public IAzureTableStorageService CreateClient(string endpoint, string tableName)
        {
            if (string.IsNullOrWhiteSpace(endpoint)) throw new ArgumentNullException(nameof(endpoint));
            if (string.IsNullOrWhiteSpace(tableName)) throw new ArgumentNullException(nameof(tableName));

            // Return an existing instance if this container has already been referenced previously
            if (_clients.TryGetValue($"{endpoint}|{tableName}", out var existingClient))
                return existingClient;

            string tableStorageUrl = $"https://{endpoint}/{tableName}";
            var serviceClient = new TableServiceClient(new Uri(tableStorageUrl),
               new DefaultAzureCredential(),
               new TableClientOptions());

            // Create a new client and cache it
            var tableClient = new AzureTableStorageService(serviceClient, tableName);

            _clients.Add($"{endpoint}|{tableName}", tableClient);
            return tableClient;
        }
    }
}
