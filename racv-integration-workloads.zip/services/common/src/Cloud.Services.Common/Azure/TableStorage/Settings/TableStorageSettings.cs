﻿namespace Cloud.Services.Common.Azure.TableStorage.Settings
{
    public class TableStorageSettings
    {
        public const string ConfigurationSectionName = "TableStorageSettings";
        public string Endpoint { get; set; } = string.Empty;
    }
}
