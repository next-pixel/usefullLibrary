﻿namespace Cloud.Services.Common.Azure.TableStorage.Exceptions
{
    public class EntryNotFoundException : Exception
    {
        public string? AccountName { get; set; }

        public EntryNotFoundException(string partitionKey, string rowKey) : base($"Entry {partitionKey}(partitionKey), {rowKey}(rowKey) not found.")
        {

        }

        public EntryNotFoundException(string accountName, string partitionKey, string rowKey) : base($"Entry {partitionKey}(partitionKey), {rowKey}(rowKey) not found.")
        {
            AccountName = accountName;
        }

        public EntryNotFoundException(string message, Exception innerException) : base(message, innerException)
        {

        }
        public EntryNotFoundException()
        {

        }
    }
}
