﻿using Cloud.Services.Common.Exceptions;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;

namespace Cloud.Services.Common.Extensions
{
    /// <summary>
    /// Extension methods to configure custom behaviour when model validation errors occur.
    /// </summary>
    public static class ModelValidationErrorExtensions
    {
        /// <summary>
        /// Defines custom message on model validation error.
        /// </summary>
        /// <param name="builder"></param>
        public static void AddCustomModelValidationError(this WebApplicationBuilder builder)
        {
            builder.Services
                .AddMvc()
                .ConfigureApiBehaviorOptions(options => {
                    options.InvalidModelStateResponseFactory = actionContext =>
                    {
                        var errorDetails = actionContext.ModelState.Values.SelectMany(m => m.Errors).Select(e => new OperationFailureResponseDetail() { Message = e.ErrorMessage });
                        return new BadRequestObjectResult(new OperationFailureResponse("One or more validation errors occurred.", errorDetails.ToArray()));
                    };
                });
        }
    }
}
