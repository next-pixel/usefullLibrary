﻿namespace Cloud.Services.Common.Exceptions
{
    public class OperationFailureException : Exception
    {
        /// <summary>
        /// Gets or sets the ErrorDetails.
        /// </summary>
        /// <value>The ErrorDetails.</value>
        public OperationFailureResponseDetail[]? ErrorDetails { get; set; }

        /// <summary>
        /// Constructor with error message as argument.
        /// </summary>
        /// <param name="message">Exception message.</param>
        public OperationFailureException(string message) : base(message) { }

        /// <summary>
        /// Constructor for creating the object.
        /// </summary>
        /// <param name="message">Exception message.</param>
        /// <param name="errorDetails">Details of the error.</param>
        public OperationFailureException(string message, OperationFailureResponseDetail[] errorDetails) : base(message)
        {
            ErrorDetails = errorDetails;
        }
    }
}
