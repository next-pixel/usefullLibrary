﻿namespace Cloud.Services.Common.Connector.Models.Exceptions
{
    /// <summary>
    /// Custom exception class inherited from the Exception. Used to hold the exception messages generated calling an external API.
    /// </summary>
    public class ConnectorOperationSystemException : Exception
    {
        /// <summary>
        /// Gets or sets the ErrorDetails.
        /// </summary>
        /// <value>The ErrorDetails.</value>
        public ConnectorOperationErrorDetail[]? ErrorDetails { get; set; }

        /// <summary>
        /// Constructor with error message as argument.
        /// </summary>
        /// <param name="message">Exception message.</param>
        public ConnectorOperationSystemException(string message) : base(message) { }

        /// <summary>
        /// Constructor for creating the object.
        /// </summary>
        /// <param name="message">Exception message.</param>
        /// <param name="errorDetails">Details of the error.</param>
        public ConnectorOperationSystemException(string message, ConnectorOperationErrorDetail[] errorDetails) : base(message)
        {
            ErrorDetails = errorDetails;
        }
    }
}
