﻿namespace Cloud.Services.Common.Connector.Models.Exceptions
{
    /// <summary>
    /// Represents an exception that is thrown when a connector operation is unauthorized.
    /// </summary>
    public class ConnectorOperationUnauthorizedException : Exception
    {
        /// <summary>
        /// Gets or sets the ErrorDetails.
        /// </summary>
        /// <value>The ErrorDetails.</value>
        public ConnectorOperationErrorDetail[]? ErrorDetails { get; set; }

        /// <summary>
        /// Constructor with error message as argument.
        /// </summary>
        /// <param name="message">Exception message.</param>
        public ConnectorOperationUnauthorizedException(string message) : base(message) { }

        /// <summary>
        /// Constructor for creating the object.
        /// </summary>
        /// <param name="message">Exception message.</param>
        /// <param name="errorDetails">Details of the error.</param>
        public ConnectorOperationUnauthorizedException(string message, ConnectorOperationErrorDetail[] errorDetails) : base(message)
        {
            ErrorDetails = errorDetails;
        }

    }
}
