﻿using System.Globalization;

namespace Cloud.Services.Common.Connector.Models.Exceptions
{
    /// <summary>
    /// Operation error details.
    /// </summary>
    public class ConnectorOperationErrorDetail
    {
        /// <summary>
        /// When the error occured.
        /// </summary>
        public string Timestamp { get; set; } = DateTime.UtcNow.ToString("yyyy-MM-dd-HH:mm:ss.fffzz", CultureInfo.InvariantCulture);

        /// <summary>
        /// Error code.
        /// </summary>
        public string Code { get; set; } = "";

        /// <summary>
        /// Message of the error.
        /// </summary>
        public string? Message { get; set; }

        /// <summary>
        /// The entity that the error pertains to.
        /// </summary>
        public string? Entity { get; set; }
    }
}
