﻿namespace Cloud.Services.Common.Connector.Models
{
    /// <summary>
    /// The class to return response data coming from the Transact connector.
    /// </summary>
    public class ConnectorSuccessResult
    {
        /// <summary>
        /// Identifier. The identifier for entity created or updated.
        /// </summary>
        public string? Identifier { get; set; }

        /// <summary>
        /// Status of the request.
        /// </summary>
        public string? Status { get; set; }

        /// <summary>
        /// TransactionStatus of the request.
        /// </summary>
        public string? TransactionStatus { get; set; }

        /// <summary>
        /// Unique Identifier for the request.
        /// </summary>
        public string? UniqueIdentifier { get; set; }
    }
}
