﻿using Newtonsoft.Json;

namespace Cloud.Services.Common.Connector.Models.OCPI
{
    public class VersionsResponse : OCPIResponse
    {
        [JsonProperty("data")]
        public List<OCPIVersion>? Versions { get; set; }
    }

    public class OCPIVersion
    {
        [JsonProperty("version")]
        public Version? Version { get; set; }

        [JsonProperty("url")]
        public string? URL { get; set; }
    }
}