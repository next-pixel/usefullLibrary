﻿using System.Text.Json.Serialization;

namespace Cloud.Services.Common.Connector.Models.OCPI
{
    public class VersionEndpointsResponse : OCPIResponse
    {
        [JsonPropertyName("data")]
        public VersionEndpoints? VersionEndpoints { get; set; }

    }

    public class VersionEndpoints
    {
        [JsonPropertyName("version")]
        public string? Version { get; set; }

        [JsonPropertyName("endpoints")]
        public List<Endpoint>? Endpoints { get; set; }
    }

    public class Endpoint
    {
        [JsonPropertyName("identifier")]
        public string? Identifier { get; set; }

        [JsonPropertyName("role")]
        public string? Role { get; set; }

        [JsonPropertyName("url")]
        public string? URL { get; set; }
    }
}
