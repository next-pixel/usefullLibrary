﻿using Newtonsoft.Json;

namespace Cloud.Services.Common.Connector.Models.OCPI
{
    public abstract class OCPIResponse
    {
        [JsonProperty("status_code")]
        public int? StatusCode { get; set; }

        [JsonProperty("status_message")]
        public string? StatusMessage { get; set; }

        [JsonProperty("timestamp")]
        public DateTime Timestamp { get; set; }
    }
}
