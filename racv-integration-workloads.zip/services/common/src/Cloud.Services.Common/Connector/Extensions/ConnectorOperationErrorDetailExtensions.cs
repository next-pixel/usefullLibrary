﻿using Cloud.Services.Common.Connector.Models.Exceptions;
using Cloud.Services.Common.Exceptions;

namespace Cloud.Services.Common.Connector.Extensions
{
    /// <summary>
    /// Extension methods for the <see cref="ConnectorOperationErrorDetail"/> class.
    /// </summary>
    public static class ConnectorOperationErrorDetailExtensions
    {
        /// <summary>
        /// Converts an array of <see cref="ConnectorOperationErrorDetail"/> objects to an array of <see cref="OperationFailureResponseDetail"/> objects.
        /// </summary>
        /// <param name="errorDetails">Array of <see cref="ConnectorOperationErrorDetail"/> objects to map.</param>
        /// <returns>An array of <see cref="OperationFailureResponseDetail"/> objects.</returns>
        public static OperationFailureResponseDetail[] Convert(this ConnectorOperationErrorDetail[] errorDetails)
        {
            return errorDetails.Select(errorDetail => new OperationFailureResponseDetail
            {
                Timestamp = errorDetail.Timestamp,
                Code = errorDetail.Code,
                Message = errorDetail.Message,
                Entity = errorDetail.Entity
            }).ToArray();
        }
    }
}
