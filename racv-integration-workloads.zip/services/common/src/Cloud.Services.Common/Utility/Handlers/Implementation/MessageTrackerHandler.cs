﻿using System.Globalization;
using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Tracking.Enumerations;
using Cloud.Services.Common.Tracking.Helpers;
using Cloud.Services.Common.Tracking.Interfaces;
using Cloud.Services.Common.Tracking.Models;
using Cloud.Services.Common.Utility.Extensions;
using Cloud.Services.Common.Utility.Handlers.Interfaces;
using GraphQL;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;

namespace Cloud.Services.Common.Utility.Handlers.Implementation;

/// <summary>
///     Provides a method to log Http requests and response pairs for a given system.
/// </summary>
public class MessageTrackerHandler : IMessageTrackerHandler<HttpRequestMessage, HttpResponseMessage>,
    IMessageTrackerHandler<GraphQLRequest, GraphQLResponse<JObject>>
{
    /// <summary>
    ///     Application configuration values.
    /// </summary>
    private readonly IMessageTrackerHandlerConfiguration _configuration;

    /// <summary>
    ///     Specifies header values which should not be logged.
    /// </summary>
    private readonly string[] _excludeHeaders;

    /// <summary>
    ///     Logger.
    /// </summary>
    private readonly ILogger _logger;

    /// <summary>
    ///     Message tracker interface.
    /// </summary>
    private readonly IMessageTracker _messageTracker;

    /// <summary>
    ///     The logged requests and responses will be made against this system.
    /// </summary>
    private readonly string _systemName;

    /// <summary>
    ///     Class constructor.
    /// </summary>
    /// <param name="logger">Logger.</param>
    /// <param name="messageTracker">Message tracker interface.</param>
    /// <param name="configuration">Application configuration values.</param>
    /// <param name="systemName">The logged requests and responses will be made against this system.</param>
    /// <param name="excludeHeaders">Specifies header values which should not be logged.</param>
    /// <exception cref="ArgumentNullException"></exception>
    public MessageTrackerHandler(ILogger<MessageTrackerHandler> logger, IMessageTracker messageTracker,
        IMessageTrackerHandlerConfiguration configuration, string systemName, string[] excludeHeaders)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _messageTracker = messageTracker ?? throw new ArgumentNullException(nameof(messageTracker));
        _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        _systemName = systemName ?? throw new ArgumentNullException(nameof(systemName));
        _excludeHeaders = excludeHeaders ?? throw new ArgumentNullException(nameof(excludeHeaders));
    }

    public async Task LogRequestResponse(HttpRequestMessage request, HttpResponseMessage response,
        Guid correlationIdentifier, OperationProtocols protocol)
    {
        await LogRequestResponse<HttpRequestMessage, HttpResponseMessage>(request, response, correlationIdentifier,
            protocol);
    }

    public async Task LogRequestResponse(GraphQLRequest request, GraphQLResponse<JObject> response,
        Guid correlationIdentifier, OperationProtocols protocol)
    {
        await LogRequestResponse<GraphQLRequest, GraphQLResponse<JObject>>(request, response, correlationIdentifier,
            protocol);
    }

    /// <summary>
    ///     Logs a request and response pair to the message tracker system.
    /// </summary>
    /// <param name="request">HttpRequestMessage request.</param>
    /// <param name="response">HttpResponseMessage response.</param>
    /// <param name="correlationIdentifier">Correlation identifier corresponding to the original api call.</param>
    /// <param name="protocol">The protocol used in making the request e.g. HTTP or HTTPS.</param>
    /// <returns></returns>
    /// <exception cref="ArgumentNullException"></exception>
    private async Task LogRequestResponse<TRequest, TResponse>(TRequest request, TResponse response,
        Guid correlationIdentifier, OperationProtocols protocol)
    {
        ArgumentNullException.ThrowIfNull(request);
        ArgumentNullException.ThrowIfNull(response);
        if (request.Equals(default(TRequest)))
        {
            throw new ArgumentNullException(nameof(request));
        }

        if (request.Equals(default(TResponse)))
        {
            throw new ArgumentNullException(nameof(response));
        }

        if (correlationIdentifier == Guid.Empty)
        {
            throw new ArgumentNullException(nameof(correlationIdentifier));
        }

        if (_configuration.LogRequestResponseToggle)
        {
            var interactionIdentifier = Guid.NewGuid();
            var workloadName = _configuration.WorkloadName;
            var timestamp = DateTime.Now;

            try
            {
                switch (request)
                {
                    case HttpRequestMessage httpRequest:
                        {
                            var operationName = httpRequest.Method.ToString();
                            await LogHttpRequest(httpRequest, correlationIdentifier, interactionIdentifier,
                                workloadName,
                                protocol,
                                operationName, timestamp).ConfigureAwait(false);
                            break;
                        }
                    case GraphQLRequest graphQLRequest:
                        {
                            var operationName = HttpMethod.Post.Method;
                            await LogGraphQLRequest(graphQLRequest, correlationIdentifier, interactionIdentifier,
                                workloadName,
                                protocol,
                                operationName, timestamp).ConfigureAwait(false);
                            break;
                        }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName +
                    "} failed to log {SystemName} request with error: {Message}", correlationIdentifier, _systemName,
                    ex.Message);
                throw;
            }

            try
            {
                if (request is HttpRequestMessage httpRequest && response is HttpResponseMessage httpResponse)
                {
                    var operationName = httpRequest.Method.ToString();
                    await LogHttpResponse(httpResponse, correlationIdentifier, interactionIdentifier, workloadName,
                        protocol,
                        operationName, timestamp).ConfigureAwait(false);
                }
                else if (response is GraphQLResponse<JObject> graphQLResponse)
                {
                    var operationName = HttpMethod.Post.Method;
                    await LogGraphQLResponse(graphQLResponse, correlationIdentifier, interactionIdentifier,
                        workloadName,
                        protocol,
                        operationName, timestamp).ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName +
                    "} failed to log {SystemName} response with error: {Message}", correlationIdentifier, _systemName,
                    ex.Message);
                throw;
            }
        }
    }

    /// <summary>
    ///     Logs the request to the message tracker system.
    /// </summary>
    /// <param name="request">The HTTP request message.</param>
    /// <param name="correlationIdentifier">The correlation identifier corresponding to the original API call.</param>
    /// <param name="interactionIdentifier">The unique identifier for the interaction.</param>
    /// <param name="workloadName">The name of the workload.</param>
    /// <param name="protocol">The protocol used in making the request.</param>
    /// <param name="operationName">The name of the operation.</param>
    /// <param name="timestamp">The timestamp when the request was made.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    private async Task LogHttpRequest(HttpRequestMessage request, Guid correlationIdentifier,
        Guid interactionIdentifier, string workloadName, OperationProtocols protocol, string operationName,
        DateTime timestamp)
    {
        var loggedRequest = await request.GetRestRequestMessageAsync(
            correlationIdentifier, interactionIdentifier, workloadName, protocol,
            request.RequestUri?.ToString(), _excludeHeaders, _systemName, operationName, timestamp);
        await TrackMessageAsync(loggedRequest, correlationIdentifier, interactionIdentifier, workloadName,
            operationName,
            protocol, OperationTypes.Response, timestamp);
    }

    /// <summary>
    ///     Logs the response to the message tracker system.
    /// </summary>
    /// <param name="response">The HTTP response message.</param>
    /// <param name="correlationIdentifier">The correlation identifier corresponding to the original API call.</param>
    /// <param name="interactionIdentifier">The unique identifier for the interaction.</param>
    /// <param name="workloadName">The name of the workload.</param>
    /// <param name="protocol">The protocol used in making the request.</param>
    /// <param name="operationName">The name of the operation.</param>
    /// <param name="timestamp">The timestamp when the response was received.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    private async Task LogHttpResponse(HttpResponseMessage response, Guid correlationIdentifier,
        Guid interactionIdentifier, string workloadName, OperationProtocols protocol, string operationName,
        DateTime timestamp)
    {
        var loggedResponse = await response.GetRestResponseMessageAsync(
            correlationIdentifier, interactionIdentifier, workloadName, protocol, _excludeHeaders,
            operationName, _systemName, timestamp);
        await TrackMessageAsync(loggedResponse, correlationIdentifier, interactionIdentifier, workloadName,
            operationName,
            protocol, OperationTypes.Response, timestamp);
    }

    private async Task LogGraphQLRequest(GraphQLRequest request, Guid correlationIdentifier,
        Guid interactionIdentifier, string workloadName, OperationProtocols protocol, string operationName,
        DateTime timestamp)
    {
        var loggedRequest = request.GetGraphQLRequestMessage(
            correlationIdentifier, interactionIdentifier, workloadName, protocol,
            "test", _excludeHeaders, _systemName, operationName, timestamp);
        await TrackMessageAsync(loggedRequest, correlationIdentifier, interactionIdentifier, workloadName,
            operationName,
            protocol, OperationTypes.Response, timestamp);
    }

    private async Task LogGraphQLResponse(GraphQLResponse<JObject> response, Guid correlationIdentifier,
        Guid interactionIdentifier, string workloadName, OperationProtocols protocol, string operationName,
        DateTime timestamp)
    {
        var loggedResponse = response.GetGraphQLResponseMessage(correlationIdentifier, interactionIdentifier,
            workloadName, protocol, _excludeHeaders,
            operationName, _systemName, timestamp);
        await TrackMessageAsync(loggedResponse, correlationIdentifier, interactionIdentifier, workloadName,
            operationName,
            protocol, OperationTypes.Response, timestamp);
    }

    private async Task TrackMessageAsync<TMessage>(TMessage loggedMessage, Guid correlationIdentifier,
        Guid interactionIdentifier, string workloadName, string operationName, OperationProtocols protocol,
        OperationTypes operationType, DateTime timestamp)
        where TMessage : BaseMessage
    {
        var filePath = MessageTrackerHelper.FormatFilePath(
            workloadName, timestamp,
            correlationIdentifier.ToString().ToLower(CultureInfo.InvariantCulture),
            _systemName, interactionIdentifier.ToString(), operationName, protocol,
            operationType);
        await _messageTracker.TrackMessageAsync(loggedMessage, filePath, _configuration.ContainerName);
    }
}
