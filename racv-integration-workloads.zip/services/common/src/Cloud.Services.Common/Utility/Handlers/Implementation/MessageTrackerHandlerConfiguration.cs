﻿using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Utility.Handlers.Interfaces;
using Microsoft.Extensions.Configuration;

namespace Cloud.Services.Common.Utility.Handlers.Implementation;

/// <summary>
///     Configuration values for <see cref="MessageTrackerHandler" />.
/// </summary>
public class MessageTrackerHandlerConfiguration : IMessageTrackerHandlerConfiguration
{
    /// <summary>
    ///     The default container name.
    /// </summary>
    private const string _defaultContainerName = "delete-after-365-days";

    /// <summary>
    ///     Container key name.
    /// </summary>
    private const string _containerKeyName = ServicesConstants.MessageTrackerContainerKey;

    /// <summary>
    ///     The key name for configuration that toggles if requests and responses should be logged.
    /// </summary>
    private const string _logRequestResponseToggleKeyName = ServicesConstants.LogRequestResponseToggleKey;

    /// <summary>
    ///     The configuration object.
    /// </summary>
    private readonly IConfiguration _configuration;

    /// <summary>
    ///     Class Constructor.
    /// </summary>
    public MessageTrackerHandlerConfiguration(IConfiguration configuration)
    {
        _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
    }

    /// <summary>
    ///     Gets the workload name.
    /// </summary>
    public string WorkloadName => _configuration[ServicesConstants.WorkloadKey] ?? throw new InvalidOperationException($"{ServicesConstants.WorkloadKey} cannot be null");

    /// <summary>
    ///     Container name.
    /// </summary>
    public string ContainerName => _configuration[_containerKeyName] ?? _defaultContainerName;

    /// <summary>
    ///     Toggles if requests and responses should be logged.
    /// </summary>
    public bool LogRequestResponseToggle
    {
        get
        {
            var configValue = _configuration[_logRequestResponseToggleKeyName];
            if (bool.TryParse(configValue, out var result))
            {
                return result;
            }

            return true; // Default to true if the configuration value is null or not a valid boolean
        }
    }
}
