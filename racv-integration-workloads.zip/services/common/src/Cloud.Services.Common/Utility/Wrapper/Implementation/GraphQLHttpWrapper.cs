﻿using GraphQL;
using GraphQL.Client.Http;
using GraphQL.Client.Serializer.Newtonsoft;
using System.Globalization;
using Cloud.Services.Common.Tracking.Enumerations;
using Cloud.Services.Common.Utility.Wrapper.Interfaces;
using Newtonsoft.Json.Linq;

namespace Cloud.Services.Common.Utility.Wrapper.Implementation;

public class GraphQLHttpWrapper : IGraphQLHttpWrapper<GraphQLRequest, GraphQLResponse<JObject>>
{
    public delegate Task RequestCompletedHandler(GraphQLRequest request, GraphQLResponse<JObject> response,
        Guid correlationIdentifier, OperationProtocols protocols);

    private readonly GraphQLHttpClient _client;
    private event RequestCompletedHandler _requestCompleted;

    public GraphQLHttpWrapper(string endpointUrl, RequestCompletedHandler requestCompleted)
    {
        if (string.IsNullOrWhiteSpace(endpointUrl))
        {
            throw new ArgumentNullException(nameof(endpointUrl));
        }

        _client = new GraphQLHttpClient(endpointUrl, new NewtonsoftJsonSerializer());
        _requestCompleted = requestCompleted ?? throw new ArgumentNullException(nameof(requestCompleted));
    }

    public async Task<GraphQLResponse<JObject>> SendAsync(GraphQLRequest restRequest, Guid correlationIdentifier, string apiKey = "")
    {
        if (correlationIdentifier == Guid.Empty)
        {
            throw new ArgumentException(null, nameof(correlationIdentifier));
        }
        
        if (!string.IsNullOrWhiteSpace(apiKey) && 
            !_client.HttpClient.DefaultRequestHeaders.TryGetValues("x-api-key", out _))
        {
            _client.HttpClient.DefaultRequestHeaders.Add("x-api-key", apiKey);
        }

        var response = await _client.SendQueryAsync<JObject>(restRequest);
        
        await _requestCompleted.Invoke(
            restRequest,
            response,
            correlationIdentifier,
            _client.HttpClient.BaseAddress?.Scheme.ToLower(CultureInfo.InvariantCulture) == "https"
                ? OperationProtocols.HTTPS
                : OperationProtocols.HTTP);
        
        return response;
    }
}