﻿using System.Globalization;
using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Tracking.Enumerations;
using Cloud.Services.Common.Utility.Wrapper.Interfaces;

namespace Cloud.Services.Common.Utility.Wrapper.Implementation;

/// <summary>
///     Concrete implementation of the IHttpWrapper interface that uses the HTTP client factory.
/// </summary>
public class HttpWrapper : IHttpWrapper<HttpRequestMessage, HttpResponseMessage>
{
    /// <summary>
    ///     Request completed handler delegate.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="response"></param>
    /// <param name="correlationIdentifier"></param>
    /// <param name="protocols"></param>
    /// <returns></returns>
    public delegate Task RequestCompletedHandler(HttpRequestMessage request, HttpResponseMessage response,
        Guid correlationIdentifier, OperationProtocols protocols);

    /// <summary>
    ///     The rest client to be used to send the http request.
    /// </summary>
    private readonly IHttpClientFactory _clientFactory;

    /// <summary>
    ///     Constructor to set the private variables.
    /// </summary>
    /// <param name="restClient">The rest client.</param>
    /// <param name="requestCompleted">Event handler that is called after the request is executed.</param>
    public HttpWrapper(IHttpClientFactory httpClientFactory, RequestCompletedHandler requestCompleted)
    {
        _clientFactory = httpClientFactory ?? throw new ArgumentNullException(nameof(httpClientFactory));
        _requestCompleted = requestCompleted ?? throw new ArgumentNullException(nameof(requestCompleted));
    }

    /// <summary>
    ///     Send the request.
    /// </summary>
    /// <param name="restRequest"></param>
    /// <param name="correlationIdentifier">Request correlation identifier.</param>
    /// <returns>Returns the response.</returns>
    public async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage restRequest,
        string client,
        Guid correlationIdentifier,
        string authorization = "")
    {
        if (correlationIdentifier == Guid.Empty)
        {
            throw new ArgumentException(null, nameof(correlationIdentifier));
        }

        using var httpClient = _clientFactory.CreateClient(client);

        if (!string.IsNullOrWhiteSpace(authorization))
        {
            httpClient.DefaultRequestHeaders.Add(ServicesConstants.Authorization, authorization);
        }

        // send the request
        var restResponse = await httpClient.SendAsync(restRequest);
        await _requestCompleted.Invoke(
            restRequest,
            restResponse,
            correlationIdentifier,
            httpClient.BaseAddress?.Scheme.ToLower(CultureInfo.InvariantCulture) == "https"
                ? OperationProtocols.HTTPS
                : OperationProtocols.HTTP);
        return restResponse;
    }

    /// <summary>
    ///     An event which defines the steps to perform once a request has been sent and the response received.
    /// </summary>
    private event RequestCompletedHandler _requestCompleted;
}
