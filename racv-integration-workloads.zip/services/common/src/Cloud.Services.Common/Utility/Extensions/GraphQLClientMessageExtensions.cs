﻿using Cloud.Services.Common.Tracking.Enumerations;
using Cloud.Services.Common.Tracking.Models;
using Newtonsoft.Json;
using GraphQL;
using Newtonsoft.Json.Linq;

namespace Cloud.Services.Common.Utility.Extensions
{
    public static class GraphQLClientMessageExtensions
    {
        public static TrackerRestRequestMessage GetGraphQLRequestMessage(
            this GraphQLRequest originalRequest,
            Guid correlationIdentifier,
            Guid interactionIdentifier,
            string workloadName,
            OperationProtocols protocol,
            string? path,
            string[] excludeHeaders,
            string systemIdentifier,
            string operationName,
            DateTime timestamp)
        {
            if (originalRequest is null) throw new ArgumentNullException(nameof(originalRequest));
            if (correlationIdentifier == Guid.Empty) throw new ArgumentNullException(nameof(correlationIdentifier));
            if (interactionIdentifier == Guid.Empty) throw new ArgumentNullException(nameof(interactionIdentifier));
            if (string.IsNullOrWhiteSpace(workloadName)) throw new ArgumentNullException(nameof(workloadName));
            if (string.IsNullOrWhiteSpace(path)) throw new ArgumentNullException(nameof(path));
            if (excludeHeaders is null) throw new ArgumentNullException(nameof(excludeHeaders));
            if (string.IsNullOrWhiteSpace(systemIdentifier)) throw new ArgumentNullException(nameof(systemIdentifier));
            if (string.IsNullOrWhiteSpace(operationName)) throw new ArgumentNullException(nameof(operationName));

            var payload = new Payload
            {
                Body = JsonConvert.SerializeObject(new
                {
                    query = originalRequest.Query,
                    variables = originalRequest.Variables,
                    operationName = originalRequest.OperationName
                })
            };

            var headers = new Dictionary<string, string>();

            var operationType = OperationTypes.Request;

            return new TrackerRestRequestMessage
            {
                CorrelationId = correlationIdentifier.ToString(),
                InteractionId = interactionIdentifier,
                ActivityId = Guid.NewGuid(),
                OperationName = operationName,
                WorkloadName = workloadName,
                MessageTimestamp = timestamp,
                OperationType = operationType,
                Protocol = protocol,
                Payload = payload,
                Path = path,
                Verb = operationName,
                QueryString = originalRequest.Query,
                Headers = headers,
                SystemId = systemIdentifier,
                BaseUrl = "" // TODO: Add base URL
            };
        }

        public static TrackerRestResponseMessage GetGraphQLResponseMessage(
            this GraphQLResponse<JObject> originalResponse,
            Guid correlationIdentifier,
            Guid interactionIdentifier,
            string workloadName,
            OperationProtocols protocol,
            string[] excludeHeaders,
            string method,
            string systemIdentifier,
            DateTime timestamp)
        {
            if (originalResponse is null) throw new ArgumentNullException(nameof(originalResponse));
            if (correlationIdentifier == Guid.Empty) throw new ArgumentNullException(nameof(correlationIdentifier));
            if (interactionIdentifier == Guid.Empty) throw new ArgumentNullException(nameof(interactionIdentifier));
            if (string.IsNullOrWhiteSpace(workloadName)) throw new ArgumentNullException(nameof(workloadName));
            if (string.IsNullOrWhiteSpace(method)) throw new ArgumentNullException(nameof(method));
            if (string.IsNullOrWhiteSpace(systemIdentifier)) throw new ArgumentNullException(nameof(systemIdentifier));

            var payload = new Payload
            {
                Body = JsonConvert.SerializeObject(new
                {
                    data = originalResponse.Data,
                    errors = originalResponse.Errors,
                    extensions = originalResponse.Extensions
                })
            };

            var headers = new Dictionary<string, string>();

            return new TrackerRestResponseMessage
            {
                CorrelationId = correlationIdentifier.ToString(),
                InteractionId = interactionIdentifier,
                ActivityId = Guid.NewGuid(),
                OperationName = method,
                WorkloadName = workloadName,
                MessageTimestamp = timestamp,
                OperationType = OperationTypes.Response,
                Protocol = protocol,
                Payload = payload,
                StatusCode = originalResponse.Errors != null && originalResponse.Errors.Any() ? 400 : 200,
                Headers = headers,
                SystemId = systemIdentifier
            };
        }
    }
}
