###############
#  Imports an environment file into memory and uploads each value into the app config service.
###############

param (
    [Parameter(Mandatory)]
    [string] $ConfigurationFile
)

# Import related helpers.
#Import-Module $PSScriptRoot\scripts\Imports.psm1 -Force

Write-Host "****************************************************"
Write-Host "         Deploying App Configuration Values         "
Write-Host "****************************************************"

Write-Host "Getting app configuration keys-value pairs from '$ConfigurationFile'."

if ($false -eq (Test-Path -Path $ConfigurationFile)) {
    Write-Error "Unable to load file from '$($ConfigurationFile)'"
    exit 1
}
$appConfigFile = Get-Content -Raw -path $ConfigurationFile | ConvertFrom-Json
$appConfigs = $appConfigFile.parameters.appconfigkeysToDeploy.value
$appConfigurationName = $appConfigFile.parameters.appconfigName.value
Write-Host "Getting app configuration resource name to be used in the deployment: '$appConfigurationName'."
foreach ($items in $appConfigs) {

    $configLabel = $items.label
    $configKey = $items.name
    $type = $items.type     
    if ($items.keytype -eq 'keyvault') {
        $secretName = $items.value
        $secretExists = az keyvault secret show --name $secretName --vault-name $items.keyvaultname.Split(".")[0] --query "value" -o tsv --only-show-errors
        if (!$secretExists) {
            $errorList = "Secret $secretName does not exist in keyvault $items.keyvaultname"
            break
        }
        $configValue = 'https://' + $items.keyvaultname + '/secrets/' + $items.value
        if ($configLabel -eq '' -or $null -eq $configLabel) {
            az appconfig kv set-keyvault --secret-identifier $configValue -n $appConfigurationName --key $configKey  --yes
        }
        else {
            az appconfig kv set-keyvault --secret-identifier $configValue -n $appConfigurationName --key $configKey --label $configLabel --yes
        }
    }
    else {
        
        if ($items.type -eq 'application/json') {
            $configValue = $items.value | ConvertTo-Json -Compress -Depth 100
        }
        else {
            $configValue = $items.value
        }

        if ($configLabel -eq '' -or $null -eq $configLabel) {
            az appconfig kv set -n $appConfigurationName --key $configKey --value $configValue --content-type $type  --yes    
        }   
        else {
            az appconfig kv set -n $appConfigurationName --key $configKey --label $configLabel --value $configValue --content-type $type --yes    
        }
    }   
}

if ($null -ne $errorList) {
    Write-Error $errorList
    exit 1
}

Write-Host "Update Complete"
