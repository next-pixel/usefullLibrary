﻿using Cloud.Services.Account.Common.Constants;
using Cloud.Services.Account.Common.Models.Salesforce.Auth;
using Cloud.Services.Account.Common.Settings;
using Cloud.Services.Account.Connector.Salesforce.Interfaces;
using Cloud.Services.Common.Azure.Keyvault.Interfaces;
using Cloud.Services.Common.Connector.Models.Exceptions;
using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Utility.Wrapper.Interfaces;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography.X509Certificates;

namespace Cloud.Services.Account.Connector.Salesforce.Implementations
{
    /// <summary>
    /// Salesforce authentication implementation.
    /// </summary>
    public class SalesforceAuth : ISalesforceAuth
    {
        private readonly ILogger<SalesforceAuth> _logger;
        private readonly IMemoryCache _memoryCache;
        private readonly IHttpWrapper<HttpRequestMessage, HttpResponseMessage> _httpWrapper;
        private readonly IKeyvaultCertificateService _keyvaultCertificateService;
        private readonly SalesforceAuthSettings _salesforceAuthSettings;

        public SalesforceAuth(
            IMemoryCache memoryCache,
            ILogger<SalesforceAuth> logger,
            IHttpWrapper<HttpRequestMessage, HttpResponseMessage> httpWrapper,
            IOptions<SalesforceAuthSettings> salesforceAuthSettings,
            IKeyvaultCertificateService keyvaultCertificateService)
        {
            _memoryCache = memoryCache ?? throw new ArgumentNullException(nameof(logger));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _httpWrapper = httpWrapper ?? throw new ArgumentNullException(nameof(httpWrapper));
            _salesforceAuthSettings = salesforceAuthSettings.Value ?? throw new ArgumentNullException(nameof(salesforceAuthSettings));
            _keyvaultCertificateService = keyvaultCertificateService ?? throw new ArgumentNullException(nameof(keyvaultCertificateService));
        }

        /// <summary>
        /// Retrieves the access token for Salesforce authentication.
        /// </summary>
        /// <param name="correlationIdentifier">The correlation identifier.</param>
        /// <returns>The access token as a string.</returns>
        public async Task<string> GetAccessToken(Guid correlationIdentifier)
        {
            var token = await _memoryCache.GetOrCreateAsync(
                InternalConstants.SalesforceAccessTokenCacheKey,
                async entry =>
                {
                    // This delegate is called if the value is not found in the cache
                    var jwtToken = await ConstructSalesforceSecurityToken(correlationIdentifier);
                    var accessToken = await GetAccessTokenAsync(correlationIdentifier, jwtToken);
                    return accessToken;
                });

            return token!.ToString();
        }

        /// <summary>
        /// Constructs a Salesforce security token using a client certificate and private key.
        /// </summary>
        /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
        /// <returns>The Salesforce security token.</returns>
        /// <exception cref="ExternalApiDependencyException">Thrown when there is a failure in retrieving the client certificate or private key.</exception>
        private async Task<string> ConstructSalesforceSecurityToken(Guid xCorrelationIdentifier)
        {
            var tokenHandler = new JwtSecurityTokenHandler();

            // Get the certificate from Key Vault Service
            var certificate = await _keyvaultCertificateService.DownloadCertificateAsync(
                _salesforceAuthSettings.CertificateName,
                xCorrelationIdentifier);

            // Get the private key from the certificate
            var privateKey = certificate.GetRSAPrivateKey();

            if (privateKey == null)
            {
                string exceptionMessage = $"Client certificate was found but failed to retrieve the key from the certificate.";
                var customException = new ExternalApiDependencyException(exceptionMessage);
                _logger.LogError(
                    customException,
                    "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName + "} " +
                    "Authentication failed due to external API dependency. message: {Message} " +
                    "ERROR DETAILS: {ErrorDetails}",
                    xCorrelationIdentifier,
                    customException.Message,
                    JsonConvert.SerializeObject(customException.ErrorDetails));
                throw customException;
            }

            // Setup JWT Descriptor
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Issuer = _salesforceAuthSettings.ClientId,
                Subject = new ClaimsIdentity(
                [
                    new Claim("sub", _salesforceAuthSettings.Username)
                ]),
                Audience = _salesforceAuthSettings.BaseUrl,
                Expires = DateTime.UtcNow.AddMinutes(15),
                SigningCredentials = new SigningCredentials(
                    new RsaSecurityKey(privateKey),
                    SecurityAlgorithms.RsaSha256)
            };

            // Construct JWT
            var token = tokenHandler.CreateToken(tokenDescriptor);
            var jwtToken = tokenHandler.WriteToken(token);

            return jwtToken;

        }

        /// <summary>
        /// Retrieve access token asynchronously.
        /// </summary>
        /// <param name="correlationIdentifier">Operation correlation identifier - used for logging.</param>
        /// <returns>Access token.</returns>
        public async Task<string> GetAccessTokenAsync(
            Guid xCorrelationIdentifier,
            string authorization)
        {
            if (xCorrelationIdentifier == Guid.Empty) throw new ArgumentNullException(nameof(xCorrelationIdentifier));
            _logger.LogInformation(
                "CorrelationId : { " + ServicesConstants.CorrelationIdLogPropertyName + "} " +
                "Started executing GetAccessTokenAsync.",
                xCorrelationIdentifier);

            // Prepare request
            var request = new HttpRequestMessage(HttpMethod.Post, $"services/oauth2/token");
            request.Content?.Headers.Add("Content-Type", "application/x-www-form-urlencoded");
            request.Content = new FormUrlEncodedContent(new Dictionary<string, string>()
            {
                {"grant_type", "urn:ietf:params:oauth:grant-type:jwt-bearer"},
                {"assertion", authorization }
            });

            // Send Request
            var response = await _httpWrapper.SendAsync(
                request,
                InternalConstants.SalesforceAuthHttpClient,
                xCorrelationIdentifier);
            var responseJson = await response.Content.ReadAsStringAsync();

            // Error handling
            if (response.IsSuccessStatusCode)
            {
                if (string.IsNullOrWhiteSpace(responseJson))
                {
                    string exceptionMessage = $"Authentication API responded with Status Code {response.StatusCode} but response content is empty.";
                    var customException = new ExternalApiDependencyException(exceptionMessage);
                    _logger.LogError(
                        customException,
                        "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName + "} " +
                        "Salesforce Authentication failed due to external API dependency. message: {Message} " +
                        "ERROR DETAILS: {ErrorDetails}",
                        xCorrelationIdentifier,
                        customException.Message,
                        JsonConvert.SerializeObject(customException.ErrorDetails));
                    throw customException;
                }
            }
            else
            {
                string exceptionMessage = $"Authentication API responded with Status Code {response.StatusCode}.";
                var customException = new ExternalApiDependencyException(exceptionMessage);

                _logger.LogError(
                    customException,
                    "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName + "} " +
                    "Salesforce Authentication failed due to external API dependency. message: {Message} " +
                    "ERROR DETAILS: {ErrorDetails}",
                    xCorrelationIdentifier,
                    customException.Message,
                    JsonConvert.SerializeObject(customException.ErrorDetails));

                throw customException;
            }

            // Deserialize response
            var result = JsonConvert.DeserializeObject<AccessTokenResponse>(responseJson);
            if (string.IsNullOrWhiteSpace(result?.AccessToken))
            {
                string exceptionMessage = $"Authentication API responded with Status Code {response.StatusCode} but access token is null.";
                var customException = new ExternalApiDependencyException(exceptionMessage);

                _logger.LogError(
                    customException,
                    "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName + "} " +
                    "Salesforce Authentication failed due to external API dependency. " +
                    "message: {Message} ERROR DETAILS: {ErrorDetails}",
                    xCorrelationIdentifier,
                    customException.Message,
                    JsonConvert.SerializeObject(customException.ErrorDetails));

                throw customException;
            }

            _logger.LogInformation(
                "CorrelationId : { " + ServicesConstants.CorrelationIdLogPropertyName + "} " +
                "Finished executing GetAccessTokenAsync.",
                xCorrelationIdentifier);

            return result.AccessToken.ToString();
        }
    }
}
