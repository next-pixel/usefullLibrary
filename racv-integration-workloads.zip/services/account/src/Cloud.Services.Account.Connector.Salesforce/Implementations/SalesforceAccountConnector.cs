using System.Net;
using System.Runtime.Serialization;
using System.Text;
using System.Text.Json;
using System.Web;
using Cloud.Services.Account.Common.Constants;
using Cloud.Services.Account.Common.Extensions;
using Cloud.Services.Account.Common.Models.Request;
using Cloud.Services.Account.Common.Models.Salesforce;
using Cloud.Services.Account.Common.Models.Salesforce.SObjects;
using Cloud.Services.Account.Common.Settings;
using Cloud.Services.Account.Connector.Salesforce.Interfaces;
using Cloud.Services.Common.Connector.Models.Exceptions;
using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Utility.Wrapper.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.Cosmos.Serialization.HybridRow;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using static Cloud.Services.Account.Common.Extensions.AuthorizationExtensions;

namespace Cloud.Services.Account.Connector.Salesforce.Implementations;

public class SalesforceAccountConnector : ISalesforceAccountConnector
{
    private readonly IHttpWrapper<HttpRequestMessage, HttpResponseMessage> _httpWrapper;
    private readonly ILogger<SalesforceAccountConnector> _logger;
    private readonly SalesforceSettings _salesforceSettings;

    /// <summary>
    ///     Initializes a new instance of the <see cref="SalesforceAccountConnector" /> class.
    /// </summary>
    /// <param name="logger">The logger.</param>
    /// <param name="httpWrapper">The HTTP wrapper</param>
    /// <param name="configuration">The App configuration</param>
    public SalesforceAccountConnector(
        ILogger<SalesforceAccountConnector> logger,
        IHttpWrapper<HttpRequestMessage, HttpResponseMessage> httpWrapper,
        IOptions<SalesforceSettings> salesforceSettings)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _httpWrapper = httpWrapper ?? throw new ArgumentNullException(nameof(httpWrapper));
        _salesforceSettings = salesforceSettings.Value ?? throw new ArgumentNullException(nameof(salesforceSettings));
    }

    /// <summary>
    ///     Retrieves account details from Salesforce.
    /// </summary>
    /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
    /// <param name="authorization">The authorization token.</param>
    /// <returns>
    ///     A <see cref="Task" /> representing the asynchronous operation, with a value of <see cref="AccountDetails" />
    ///     that contains the account details.
    /// </returns>
    /// <exception cref="HttpRequestException">Thrown when the request to Salesforce fails.</exception>
    /// <exception cref="SerializationException">Thrown when deserialization of the response from Salesforce fails.</exception>
    public async Task<AccountDetails?> GetAccountDetails(
        Guid xCorrelationIdentifier,
        string authorization)
    {
        HttpResponseMessage? response = null;

        var userId = authorization.GetUserId();

        if (userId is null)
        {
            _logger.LogError(
                "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                "} Salesforce JWT token does not contain a User Id", xCorrelationIdentifier);

            throw new InvalidOperationException("Salesforce JWT token does not contain a User Id");
        }

        try
        {
            // Build the URI with query parameters
            var query = @$"
            SELECT
                Account.PersonEmail,
                Account.FirstName,
                Account.LastName,
                Account.MembershipCardType__c,
                Account.MembershipStatus__c,
                Account.MemberNumber__c,
                Account.Name,
                Account.PersonBirthdate,
                Account.MemberStartDate__c,
                Account.Type,
                Account.CardNumber__c,
                Contact.Id,
                Contact.PreferredName__c
            FROM
                User
            WHERE
                Id='{userId}'".Replace(" ", "").Replace(Environment.NewLine, " ");

            var encodedQuery = HttpUtility.UrlEncode(query);

            var request = new HttpRequestMessage(HttpMethod.Get, $"services/data/v{_salesforceSettings.ApiVersion}/query?q={encodedQuery}");
            response = await _httpWrapper.SendAsync(
                request,
                InternalConstants.SalesforceHttpClient,
                xCorrelationIdentifier,
                authorization);

            response.EnsureSuccessStatusCode();

            var responseJson = await response.Content.ReadAsStringAsync();

            var result = System.Text.Json.JsonSerializer.Deserialize<QueryResponseModel<AccountDetails>>(responseJson);

            return result?.Records?[0];
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                "} Retrieving Account Details from Salesforce failed with Status Code: {statusCode}",
                xCorrelationIdentifier,
                response?.StatusCode);

            throw new HttpRequestException(
                $"Retrieving Account Details from Salesforce failed with Status Code: {response?.StatusCode}", ex, response?.StatusCode);
        }
        catch (SerializationException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                "} Deserialization of Account Details from Salesforce failed with error: {message}",
                xCorrelationIdentifier, ex.Message);

            throw new SerializationException(
                $"Deserialization of Account Details from Microservice failed with error: {ex.Message}", ex);
        }
    }

    public async Task SubmitAccountFeedback(
        FeedbackRequest? feedbackMessage,
        Guid xCorrelationIdentifier,
        string authorization)
    {
        ArgumentNullException.ThrowIfNull(feedbackMessage);
        ArgumentNullException.ThrowIfNull(xCorrelationIdentifier);
        ArgumentNullException.ThrowIfNull(authorization);

        _logger.LogInformation(
            "CorrelationId : { " + ServicesConstants.CorrelationIdLogPropertyName + "} Started Executing CreateBondAsync method.", xCorrelationIdentifier);

        // Prepare request
        var requestPayload = feedbackMessage.Convert();
        var request = new HttpRequestMessage(HttpMethod.Post,
            $"services/data/v{_salesforceSettings.ApiVersion}/sobjects/Mobile_App_Feedback__c");
        request.Content?.Headers.Add("Content-Type", "application/json");
        request.Content = new StringContent(
            JsonConvert.SerializeObject(requestPayload),
            Encoding.UTF8,
            "application/json");

        // Send Request
        var response = await _httpWrapper.SendAsync(
            request,
            InternalConstants.SalesforceIntegrationHttpClient,
            xCorrelationIdentifier,
            "Bearer " + authorization);
        var responseJson = await response.Content.ReadAsStringAsync();

        if (response.StatusCode == HttpStatusCode.BadRequest)
        {
            string exceptionMessage = $"Salesforce API responded with Status Code {response.StatusCode}.";
            var customException = new ConnectorOperationValidationException(exceptionMessage);

            // Deserialize response
            var result = JsonConvert.DeserializeObject<List<FailureResponseModel>>(responseJson);

            customException.ErrorDetails =
                result != null ? result.Select(error => new ConnectorOperationErrorDetail()
                {
                    Code = error.ErrorCode ?? string.Empty,
                    Message = error.Message
                }).ToArray() : null;

            _logger.LogError(
                customException,
                "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName + "} " +
                "Submit Feedback failed due to external API dependency. message: {Message} " +
                "ERROR DETAILS: {ErrorDetails}",
                xCorrelationIdentifier,
                customException.Message,
                JsonConvert.SerializeObject(customException.ErrorDetails));
            throw customException;
        }
        else if (response.StatusCode.Equals(HttpStatusCode.Unauthorized))
        {
            string exceptionMessage = $"Salesforce API responded with Status Code {response.StatusCode}.";
            var customException = new ConnectorOperationUnauthorizedException(exceptionMessage);

            _logger.LogError(
                customException,
                "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName + "} " +
                "Authentication failed due to external API dependency. message: {Message} " +
                "ERROR DETAILS: {ErrorDetails}",
                xCorrelationIdentifier,
                customException.Message,
                JsonConvert.SerializeObject(customException.ErrorDetails));

            throw customException;
        }
        else if (!response.IsSuccessStatusCode)
        {
            string exceptionMessage = $"Salesforce API responded with Status Code {response.StatusCode}.";
            var customException = new ExternalApiDependencyException(exceptionMessage);

            // Deserialize response
            var result = JsonConvert.DeserializeObject<List<FailureResponseModel>>(responseJson);
            customException.ErrorDetails =
                result != null ? result.Select(error => new ConnectorOperationErrorDetail()
                {
                    Code = error.ErrorCode ?? string.Empty,
                    Message = error.Message
                }).ToArray() : null;

            _logger.LogError(
                customException,
                "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName + "} " +
                "Submit Feedback failed due to external API dependency. message: {Message} " +
                "ERROR DETAILS: {ErrorDetails}", xCorrelationIdentifier,
                customException.InnerException?.Message,
                JsonConvert.SerializeObject(customException.ErrorDetails));

            throw customException;
        }
    }
}
