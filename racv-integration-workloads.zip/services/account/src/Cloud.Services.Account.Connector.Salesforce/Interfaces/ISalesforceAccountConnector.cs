using Cloud.Services.Account.Common.Models.Request;
using Cloud.Services.Account.Common.Models.Salesforce.SObjects;

namespace Cloud.Services.Account.Connector.Salesforce.Interfaces;

public interface ISalesforceAccountConnector
{
    Task<AccountDetails?> GetAccountDetails(Guid xCorrelationIdentifier, string authorization);
    Task SubmitAccountFeedback(FeedbackRequest? feedbackMessage, Guid xCorrelationIdentifier, string authorization);
}
