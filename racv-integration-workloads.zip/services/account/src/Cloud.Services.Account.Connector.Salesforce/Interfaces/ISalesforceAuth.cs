﻿namespace Cloud.Services.Account.Connector.Salesforce.Interfaces
{
    public interface ISalesforceAuth
    {
        public Task<string> GetAccessToken(Guid correlationIdentifier);
    }
}
