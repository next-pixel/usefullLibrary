using Azure.Messaging.ServiceBus;
using Cloud.Services.Account.Api.Extensions;
using Cloud.Services.Account.Api.Models.Request;
using Cloud.Services.Account.Api.Models.Response;
using Cloud.Services.Account.Common.Constants;
using Cloud.Services.Account.Common.Extensions;
using Cloud.Services.Account.Connector.Salesforce.Interfaces;
using Cloud.Services.Common.Azure.ServiceBus.Interfaces;
using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace Cloud.Services.Account.Api.Controllers
{
    /// <summary>
    /// Controller for handling requests related to account details.
    /// </summary>
    [ApiController]
    [Route("v1")]
    public class AccountController : ControllerBase
    {
        private readonly ILogger<AccountController> _logger;
        private readonly ISalesforceAccountConnector _salesforceAccountConnector;

        /// <summary>
        /// Interface to publish messages.
        /// </summary>
        private readonly IServiceBusClient _serviceBusClient;

        /// <summary>
        /// This variable is used to fetch configuration
        /// </summary>
        private readonly IConfiguration _configuration;

        /// <summary>
        /// Initializes a new instance of the <see cref="AccountController" /> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="salesforceAccountConnector">The Salesforce Account Details service.</param>
        /// <param name="serviceBusClient">Azure Service bus client</param>
        /// <exception cref="ArgumentNullException"></exception>
        public AccountController(ILogger<AccountController> logger,
            ISalesforceAccountConnector salesforceAccountConnector,
            IServiceBusClient serviceBusClient,
            IConfiguration configuration)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _salesforceAccountConnector = salesforceAccountConnector ?? throw new ArgumentNullException(nameof(salesforceAccountConnector));
            _serviceBusClient = serviceBusClient ?? throw new ArgumentNullException(nameof(serviceBusClient));
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        /// <summary>
        /// Gets the account details.
        /// </summary>
        /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
        /// <param name="authorization">JWT Bearer</param>
        /// <returns>The action result.</returns>
        [HttpGet("details")]
        [Authorize]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public async Task<ActionResult<DetailsResponse>> GetAccountDetailsAsync(
            [FromHeader(Name = ServicesConstants.CorrelationIdLogPropertyName)]
            Guid xCorrelationIdentifier,
            [FromHeader(Name = "Authorization")] string authorization)
        {
            _logger.LogInformation(
                "CorrelationId : { "
                + ServicesConstants.CorrelationIdLogPropertyName
                + "} Started executing Get Async Method.",
                xCorrelationIdentifier);

            try
            {
                var response =
                    await _salesforceAccountConnector.GetAccountDetails(xCorrelationIdentifier, authorization);

                var result = response.Convert();

                if (result.Data?.MembershipCardBarcode == null)
                {
                    _logger.LogWarning(
                        "AlertWarning : {" +
                        ServicesConstants.AlertWaring +
                        "} CorrelationId : {" +
                        ServicesConstants.CorrelationIdLogPropertyName +
                        "} Failed to generate a membership card barcode.", true, xCorrelationIdentifier);
                }


                if (result.Data?.FuelVoucherBarcode == null)
                {
                    _logger.LogWarning(
                        "AlertWarning : {" +
                        ServicesConstants.AlertWaring +
                        "} CorrelationId : {" +
                        ServicesConstants.CorrelationIdLogPropertyName +
                        "} Failed to generate a fuel voucher barcode.", true, xCorrelationIdentifier);
                }

                return Ok(result);
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex,
                    "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                    "} Retrieving Account Details failed with error: {message}", xCorrelationIdentifier, ex.Message);

                return StatusCode(ex.StatusCode != null ? (int)ex.StatusCode : StatusCodes.Status500InternalServerError,
                        new OperationFailureResponse("Http error occurred while retrieving Account Details.", null,
                        xCorrelationIdentifier.ToString()));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                    "} Retrieving Account Details failed with error: {message}", xCorrelationIdentifier, ex.Message);

                return StatusCode(StatusCodes.Status500InternalServerError,
                    new OperationFailureResponse("Error occurred while retrieving Account Details.", null,
                        xCorrelationIdentifier.ToString()));
            }
        }

        /// <summary>
        /// Posts the user feedback.
        /// </summary>
        /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
        /// <param name="authorization">JWT Bearer</param
        /// <param name="feedbackRequest">User feedback request body</param>
        /// <returns>The action result.</returns>
        [HttpPost("feedback")]
        [Authorize]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public async Task<ActionResult> SubmitAccountFeedbackAsync(
            [FromHeader(Name = ServicesConstants.CorrelationIdLogPropertyName)]
            Guid xCorrelationIdentifier,
            [FromHeader(Name = "Authorization")] string authorization,
            [FromBody] FeedbackRequest feedbackRequest)
        {
            _logger.LogInformation(
                "CorrelationId : { "
                + ServicesConstants.CorrelationIdLogPropertyName
                + "} Started executing Post Async Method.",
                xCorrelationIdentifier
            );

            try
            {
                // validate the request
                if (!feedbackRequest.IsRequestValid(out var operationFailureResponse))
                {
                    _logger.LogError(
                       "CorrelationId : {"
                       + ServicesConstants.CorrelationIdLogPropertyName
                       + "} Submit feedback request is invalid.",
                       xCorrelationIdentifier);

                    return new BadRequestObjectResult(
                        new OperationFailureResponse(
                            "One or more validation errors occurred.",
                            operationFailureResponse,
                            xCorrelationIdentifier.ToString()));
                }

                var userId = authorization.GetUserId();
                if (userId is null)
                {
                    _logger.LogError(
                        "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                        "} Salesforce JWT token does not contain a User Id", xCorrelationIdentifier);

                    throw new InvalidOperationException("Token does not contain a User Id");
                }

                var serviceBusMessage = new ServiceBusMessage(JsonSerializer.Serialize(feedbackRequest.Convert(userId)));
                await _serviceBusClient.SendMessageAsync(_configuration[InternalConstants.AccountFeedbackTopicNameKey], serviceBusMessage);

                return StatusCode(StatusCodes.Status201Created);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                    "} Retrieving Account Details failed with error: {message}", xCorrelationIdentifier, ex.Message);

                return StatusCode(StatusCodes.Status500InternalServerError,
                    new OperationFailureResponse("Error occured while retrieving Account Details.", null,
                        xCorrelationIdentifier.ToString()));
            }
        }
    }
}
