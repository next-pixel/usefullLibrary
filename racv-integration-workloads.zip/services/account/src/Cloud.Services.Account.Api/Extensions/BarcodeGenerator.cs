﻿using SkiaSharp;
using ZXing;
using ZXing.Common;
using ZXing.SkiaSharp;
using ZXing.SkiaSharp.Rendering;

namespace Cloud.Services.Account.Api.Extensions;

/// <summary>
///     A static utility class for generating barcodes.
/// </summary>
public static class BarcodeGenerator
{
    /// <summary>
    ///     Generates a PNG barcode as a base64 string.
    /// </summary>
    /// <param name="content">The content to encode in the barcode.</param>
    /// <param name="width">The width of the barcode. Default is 343.</param>
    /// <param name="height">The height of the barcode. Default is 72.</param>
    /// <param name="margin">The margin of the barcode. Default is 0.</param>
    /// <param name="format">The format of the barcode. Default is CODE_128.</param>
    /// <returns>A base64 string representing the PNG barcode.</returns>
    /// <exception cref="Exception">Thrown when an error occurs during barcode generation.</exception>
    public static string? GeneratePngBase64(string content, int width = 343, int height = 72, int margin = 0,
        BarcodeFormat format = BarcodeFormat.CODE_128)
    {
        try
        {
            if(content.Length != 16)
            {
                return null;
            }

            BarcodeWriter barcodeWriter = new()
            {
                Format = format,
                Options = new EncodingOptions
                {
                    Width = width, Height = height, Margin = margin, PureBarcode = true
                },
                Renderer = new SKBitmapRenderer
                {
                    Foreground = new SKColor(21, 21, 21), Background = SKColors.White
                }
            };

            using var barcode = barcodeWriter.Write(content);
            using var barcodePng = barcode.Encode(SKEncodedImageFormat.Png, 100);
            return Convert.ToBase64String(barcodePng.AsSpan());
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("An error occurred while generating the barcode.", ex);
        }
    }
}
