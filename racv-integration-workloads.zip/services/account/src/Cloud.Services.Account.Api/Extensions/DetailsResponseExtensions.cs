using static Cloud.Services.Account.Api.Extensions.BarcodeGenerator;
using ServiceResponse = Cloud.Services.Account.Api.Models.Response;
using SalesforceResponse = Cloud.Services.Account.Common.Models.Salesforce.SObjects;

namespace Cloud.Services.Account.Api.Extensions;

/// <summary>
///     Provides extension methods for Account Details responses.
/// </summary>
public static class DetailsResponseExtensions
{
    /// <summary>
    ///     Converts Salesforce Account Details to Microservice Account Details.
    /// </summary>
    /// <param name="sfDetailsResponse">The Salesforce Account Details.</param>
    /// <returns>The Microservice Account Details.</returns>
    /// <exception cref="ArgumentNullException">Thrown when sfDetailsResponse or sfDetailsResponse.Account is null.</exception>
    /// <exception cref="Exception">Thrown when an error occurs during conversion.</exception>
    public static ServiceResponse.DetailsResponse Convert(this SalesforceResponse.AccountDetails? sfDetailsResponse)
    {
        // Check if sfDetailsResponse is null
        if (sfDetailsResponse == null)
        {
            throw new ArgumentNullException(nameof(sfDetailsResponse),
                "Salesforce response is null.");
        }

        try
        {
            return new ServiceResponse.DetailsResponse
            {
                Message = "Operation successful.", Data = sfDetailsResponse.ConvertSFModel()
            };
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                "An error occurred while converting the Salesforce Account Details to Microservice Account Details.",
                ex);
        }
    }

    private static ServiceResponse.Details ConvertSFModel(this SalesforceResponse.AccountDetails sfAccountDetails)
    {
        ArgumentNullException.ThrowIfNull(sfAccountDetails);
        ArgumentNullException.ThrowIfNull(sfAccountDetails.Account);

        var sfAccount = sfAccountDetails.Account;
        var sfContact = sfAccountDetails.Contact;

        // Change the 7th digit of the card number to 0 to get the fuel voucher number
        var fuelVoucherNumber = (sfAccount.CardNumberC != null && sfAccount.CardNumberC.Length >= 7)
            ? sfAccount.CardNumberC.Remove(6, 1).Insert(6, "9")
            : null;

        return new ServiceResponse.Details
        {
            PersonEmail = sfAccount.PersonEmail,
            FirstName = sfAccount.FirstName,
            LastName = sfAccount.LastName,
            MembershipCardType = sfAccount.MembershipCardTypeC,
            MembershipStatus = sfAccount.MembershipStatusC,
            MemberNumber = sfAccount.MemberNumberC,
            Name = sfAccount.Name,
            ContactId = sfContact?.Id,
            PersonBirthdate = sfAccount.PersonBirthdate,
            MemberStartDate = sfAccount.MemberStartDateC,
            MembershipCardNumber = sfAccount.CardNumberC,
            MembershipCardBarcode = sfAccount.CardNumberC != null ? GeneratePngBase64(sfAccount.CardNumberC) : null,
            FuelVoucherNumber = fuelVoucherNumber,
            FuelVoucherBarcode = fuelVoucherNumber != null ? GeneratePngBase64(fuelVoucherNumber) : null
        };
    }
}
