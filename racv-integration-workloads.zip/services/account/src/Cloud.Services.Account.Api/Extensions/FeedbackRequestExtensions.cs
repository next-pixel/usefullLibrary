﻿using Cloud.Services.Account.Api.Validators;
using Cloud.Services.Account.Common.Models.Request;
using Cloud.Services.Common.Exceptions;
using System.Text;
using ApiRequest = Cloud.Services.Account.Api.Models.Request;

namespace Cloud.Services.Account.Api.Extensions
{
    public static class FeedbackRequestExtensions
    {
        public static bool IsRequestValid(
            this ApiRequest.FeedbackRequest feedbackRequest,
            out OperationFailureResponseDetail[]? failureResponseDetails)
        {
            failureResponseDetails = null;

            var result = new SubmitFeedbackValidator().Validate(feedbackRequest);

            if (!result.IsValid)
            {
                failureResponseDetails = result.Errors.Select(e =>
                {
                    return new OperationFailureResponseDetail
                    {
                        Message = e.ErrorMessage,
                        Entity = e.PropertyName
                    };
                }).ToArray();
            }
            return result.IsValid;
        }

        public static FeedbackRequest Convert(this ApiRequest.FeedbackRequest feedbackRequest, string userId)
        {
            return new FeedbackRequest
            {
                userId = userId,
                Description = feedbackRequest.Description?.RemoveSpecialCharacters(),
                Rating = feedbackRequest.Rating,
            };
        }
        public static string RemoveSpecialCharacters(this string str)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in str)
            {
                if ((c >= '0' && c <= '9') ||
                    (c >= 'A' && c <= 'Z') ||
                    (c >= 'a' && c <= 'z') ||
                    c == ' ' ||
                    c == ',' || c == '.' ||
                    c == '!' || c == '?')
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }
    }
}
