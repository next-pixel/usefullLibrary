﻿using Azure.Identity;
using Azure.Messaging.ServiceBus;
using Cloud.Services.Account.Common.Constants;
using Cloud.Services.Account.Common.Settings;
using Cloud.Services.Account.Connector.Salesforce.Implementations;
using Cloud.Services.Account.Connector.Salesforce.Interfaces;
using Cloud.Services.Common.Azure.ServiceBus.Implementations;
using Cloud.Services.Common.Azure.ServiceBus.Interfaces;
using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Startup;
using Cloud.Services.Common.Utility.Handlers.Interfaces;
using Cloud.Services.Common.Utility.Wrapper.Implementation;
using Cloud.Services.Common.Utility.Wrapper.Interfaces;

namespace Cloud.Services.Account.Api;

internal class Program
{
    private Program() { }

    private static void Main(string[] args)
    {
        // Create the web application builder.
        var builder = WebApplication.CreateBuilder(args);

        // Add common services
        ConfigureServices(builder);

        // Build the app
        var app = builder.Build();

        // Configure app
        ApiBaseStartup.Configure(app, app.Environment, builder.Logging);

        // Map controllers
        app.MapControllers();

        // Configure the HTTP request pipeline.
        app.Run();
    }

    private static void ConfigureServices(WebApplicationBuilder builder)
    {
        // Add common services
        ApiBaseStartup.ConfigureServices<Program>(builder);

        // Retrieve the SalesforceSettings from the application configuration.
        var salesforceSettings = new SalesforceSettings();
        builder.Configuration.Bind(SalesforceSettings.ConfigurationSectionName, salesforceSettings);

        // Register settings as IOptions.
        builder.Services.Configure<SalesforceSettings>(builder.Configuration!.GetSection(SalesforceSettings.ConfigurationSectionName));

        // Add Service Bus connector.
        var serviceBusClient = new ServiceBusClient(
            builder.Configuration["ServiceBusConnectionFullyQualifiedNamespace"],
#if DEBUG
            new AzureCliCredential(),
#else
            new ManagedIdentityCredential(builder.Configuration[ServicesConstants.AzureClientId]),
#endif
            new ServiceBusClientOptions
            {
                TransportType = ServiceBusTransportType.AmqpWebSockets,
            });
        builder.Services.AddSingleton(serviceBusClient);

        // Add HTTP Client
        builder.Services.AddHttpClient(InternalConstants.SalesforceHttpClient,
            client => { client.BaseAddress = new Uri(salesforceSettings.BaseUrl ?? string.Empty); });

        // Add HttpWrapper
        builder.Services.AddSingleton<IHttpWrapper<HttpRequestMessage, HttpResponseMessage>, HttpWrapper>(
            provider =>
            {
                var httpClientFactory = provider.GetRequiredService<IHttpClientFactory>();
                var messageTrackerHandler =
                    provider.GetRequiredService<IMessageTrackerHandler<HttpRequestMessage, HttpResponseMessage>>();
                var wrapper = new HttpWrapper(httpClientFactory, messageTrackerHandler.LogRequestResponse);
                return wrapper;
            });

        // Add Salesforce Connector
        builder.Services.AddTransient<ISalesforceAccountConnector, SalesforceAccountConnector>();
        builder.Services.AddTransient<IServiceBusClient, CustomServiceBusClient>();

    }
}
