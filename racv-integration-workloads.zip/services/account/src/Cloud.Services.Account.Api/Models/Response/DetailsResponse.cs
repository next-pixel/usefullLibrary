using System.Text.Json.Serialization;
using Cloud.Services.Account.Common.Utilities;

namespace Cloud.Services.Account.Api.Models.Response;

/// <summary>
///     Response payload from Microservice representing Account details
/// </summary>
public class DetailsResponse
{
    [JsonPropertyName("message")]
    public string? Message { get; set; }

    [JsonPropertyName("data")]
    public Details? Data { get; set; }
}

public class Details
{
    [JsonPropertyName("personEmail")]
    public string? PersonEmail { get; set; }

    [JsonPropertyName("firstName")]
    public string? FirstName { get; set; }

    [JsonPropertyName("lastName")]
    public string? LastName { get; set; }

    [JsonPropertyName("membershipCardType")]
    public string? MembershipCardType { get; set; }

    [JsonPropertyName("membershipStatus")]
    public string? MembershipStatus { get; set; }

    [JsonPropertyName("memberNumber")]
    public string? MemberNumber { get; set; }

    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("personBirthdate")]
    [JsonConverter(typeof(DateFormatConverter))]
    public DateTime? PersonBirthdate { get; set; }

    [JsonPropertyName("memberStartDate")]
    [JsonConverter(typeof(DateFormatConverter))]
    public DateTime? MemberStartDate { get; set; }

    [JsonPropertyName("membershipCardNumber")]
    public string? MembershipCardNumber { get; set; }

    [JsonPropertyName("membershipCardBarcode")]
    public string? MembershipCardBarcode { get; set; }

    [JsonPropertyName("fuelVoucherNumber")]
    public string? FuelVoucherNumber { get; set; }

    [JsonPropertyName("fuelVoucherBarcode")]
    public string? FuelVoucherBarcode { get; set; }

    [JsonPropertyName("contactId")]
    public string? ContactId { get; set; }
}
