﻿
namespace Cloud.Services.Account.Api.Models.Request
{
    public class FeedbackRequest
    {
        public string? Description { get; set; }
        public int? Rating { get; set; }
    }
}
