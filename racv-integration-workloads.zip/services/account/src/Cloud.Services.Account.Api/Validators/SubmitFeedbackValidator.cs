﻿using Cloud.Services.Account.Api.Models.Request;
using FluentValidation;
using Microsoft.IdentityModel.Tokens;

namespace Cloud.Services.Account.Api.Validators
{
    public class SubmitFeedbackValidator : AbstractValidator<FeedbackRequest>
    {
        public SubmitFeedbackValidator()
        {
            RuleFor(m => m.Description)
                .MaximumLength(1250)
                .WithMessage("'Description' length can't be more than 1250 characters.");

            RuleFor(request => request.Rating)
                .GreaterThan(0)
                .LessThanOrEqualTo(3)
                .WithMessage("'Rating' should be between 1 and 3.");
        }
    }
}
