﻿namespace Cloud.Services.Account.Common.Models.Request
{
    public class FeedbackRequest
    {
        public string? userId { get; set; }
        public string? Description { get; set; }
        public int? Rating { get; set; }
    }
}
