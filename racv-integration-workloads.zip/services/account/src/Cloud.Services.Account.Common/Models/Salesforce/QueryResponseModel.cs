﻿using System.Text.Json.Serialization;

namespace Cloud.Services.Account.Common.Models.Salesforce;

public class QueryResponseModel<T>
{
    [JsonPropertyName("totalSize")]
    public int TotalSize { get; set; }

    [JsonPropertyName("done")]
    public bool Done { get; set; }

    [JsonPropertyName("records")]
    public List<T>? Records { get; set; }
}
