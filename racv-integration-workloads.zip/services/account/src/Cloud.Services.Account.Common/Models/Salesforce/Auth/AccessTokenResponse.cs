﻿using Newtonsoft.Json;

namespace Cloud.Services.Account.Common.Models.Salesforce.Auth
{
    public class AccessTokenResponse
    {
        [JsonProperty(PropertyName = "access_token")]
        public string? AccessToken { get; set; }
    }
}
