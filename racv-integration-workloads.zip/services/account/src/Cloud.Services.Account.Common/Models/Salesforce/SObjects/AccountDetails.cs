using System.Text.Json.Serialization;
using Cloud.Services.Account.Common.Utilities;

namespace Cloud.Services.Account.Common.Models.Salesforce.SObjects;

/// <summary>
///     Represents a Record.
/// </summary>
public class AccountDetails
{
    [JsonPropertyName("attributes")]
    public Attributes? Attributes { get; set; }

    [JsonPropertyName("Account")]
    public Account? Account { get; set; }

    [JsonPropertyName("Contact")]
    public Contact? Contact { get; set; }
}

/// <summary>
///     Represents the Attributes of a record.
/// </summary>
public class Attributes
{
    [JsonPropertyName("type")]
    public string? Type { get; set; }

    [JsonPropertyName("url")]
    public string? Url { get; set; }
}

/// <summary>
///     Represents the Account of a record.
/// </summary>
public class Account
{
    [JsonPropertyName("attributes")]
    public Attributes? Attributes { get; set; }

    [JsonPropertyName("PersonEmail")]
    public string? PersonEmail { get; set; }

    [JsonPropertyName("FirstName")]
    public string? FirstName { get; set; }

    [JsonPropertyName("LastName")]
    public string? LastName { get; set; }

    [JsonPropertyName("CardNumber__c")]
    public string? CardNumberC { get; set; }

    [JsonPropertyName("MembershipCardType__c")]
    public string? MembershipCardTypeC { get; set; }

    [JsonPropertyName("MembershipStatus__c")]
    public string? MembershipStatusC { get; set; }

    [JsonPropertyName("MemberNumber__c")]
    public string? MemberNumberC { get; set; }

    [JsonPropertyName("Name")]
    public string? Name { get; set; }

    [JsonPropertyName("PersonBirthdate")]
    [JsonConverter(typeof(DateFormatConverter))]
    public DateTime? PersonBirthdate { get; set; }

    [JsonPropertyName("MemberStartDate__c")]
    [JsonConverter(typeof(DateFormatConverter))]
    public DateTime? MemberStartDateC { get; set; }

    [JsonPropertyName("Type")]
    public string? Type { get; set; }
}

/// <summary>
///     Represents the Contact of a record.
/// </summary>
public class Contact
{
    [JsonPropertyName("attributes")]
    public Attributes? Attributes { get; set; }

    [JsonPropertyName("Id")]
    public string? Id { get; set; }

    [JsonPropertyName("PreferredName__c")]
    public string? PreferredNameC { get; set; }
}
