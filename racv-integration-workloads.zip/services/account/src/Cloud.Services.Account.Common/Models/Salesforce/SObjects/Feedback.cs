﻿using Newtonsoft.Json;

namespace Cloud.Services.Account.Common.Models.Salesforce.SObjects
{
    public class Feedback
    {
        [JsonProperty("Comments__c")]
        public string? Comments { get; set; }

        [JsonProperty("User_Lookup__c")]
        public string? UserId { get; set; }

        [JsonProperty("Feedback_Rating__c")]
        public int? Rating { get; set; }
    }
}
