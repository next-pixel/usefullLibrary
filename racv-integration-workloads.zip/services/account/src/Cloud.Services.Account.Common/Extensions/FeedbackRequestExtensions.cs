﻿using Cloud.Services.Account.Common.Models.Request;
using Cloud.Services.Account.Common.Models.Salesforce.SObjects;

namespace Cloud.Services.Account.Common.Extensions
{
    public static class FeedbackRequestExtensions
    {
        public static Feedback Convert(this FeedbackRequest feedbackRequest)
        {
            return new Feedback
            {
                Comments = feedbackRequest.Description,
                Rating = feedbackRequest.Rating,
                UserId = feedbackRequest.userId,
            };
        }
    }
}
