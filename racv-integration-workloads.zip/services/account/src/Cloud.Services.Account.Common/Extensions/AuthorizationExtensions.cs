using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Newtonsoft.Json.Linq;
using System.IdentityModel.Tokens.Jwt;

namespace Cloud.Services.Account.Common.Extensions;

/// <summary>
///     Provides a method to extract the User Id from a Salesforce JWT token.
/// </summary>
public static class AuthorizationExtensions
{
    /// <summary>
    ///     Extracts the User Id from a Salesforce JWT token.
    /// </summary>
    /// <param name="authorization">The authorization string containing the JWT token.</param>
    /// <returns>The User Id if found; otherwise, null.</returns>
    public static string? GetUserId(this string authorization)
    {
        string? userId = null;

        var jwtHandler = new JwtSecurityTokenHandler();
        var jwtToken = jwtHandler.ReadJwtToken(authorization.Split(" ")[^1]);
        var subClaim = jwtToken.Claims.FirstOrDefault(claim => claim.Type == "sub");

        if (subClaim is not null)
        {
            userId = subClaim.Value.Split(":")[^1];
        }

        return userId;
    }
}
