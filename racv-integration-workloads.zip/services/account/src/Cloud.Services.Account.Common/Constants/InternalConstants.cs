namespace Cloud.Services.Account.Common.Constants;

/// <summary>
///     Constants to be used across all projects and workloads related to Account.
/// </summary>
public static class InternalConstants
{
    public const string SalesforceHttpClient = "SalesforceClient";
    public const string SalesforceAuthHttpClient = "SalesforceAuthClient";
    public const string SalesforceIntegrationHttpClient = "SalesforceIntegrationClient";
    public const string SalesforceApiDefaultVersion = "58.0";
    public const string AccountFeedbackTopicNameKey = "AccountFeedbackTopicName";
    public const string SalesforceAccessTokenCacheKey = "SalesforceAccessTokenCache";
}
