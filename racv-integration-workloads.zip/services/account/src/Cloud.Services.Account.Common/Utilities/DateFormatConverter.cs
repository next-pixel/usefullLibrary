using System.Globalization;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Cloud.Services.Account.Common.Utilities;

/// <summary>
///     Converts a DateTime to and from the "yyyy-MM-dd" format.
/// </summary>
public class DateFormatConverter : JsonConverter<DateTime?>
{
    private const string DateFormat = "yyyy-MM-dd";

    public override DateTime? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        var dateStr = reader.GetString();
        if (string.IsNullOrWhiteSpace(dateStr))
        {
            return null;
        }

        if (DateTime.TryParseExact(dateStr, DateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None,
                out var dateValue))
        {
            return dateValue;
        }

        throw new FormatException($"Received date with invalid format: {dateStr}. Expected format is {DateFormat}.");
    }

    public override void Write(Utf8JsonWriter writer, DateTime? value, JsonSerializerOptions options)
    {
        if (value.HasValue)
        {
            writer.WriteStringValue(value.Value.ToString(DateFormat, CultureInfo.InvariantCulture));
        }
        else
        {
            writer.WriteNullValue();
        }
    }
}
