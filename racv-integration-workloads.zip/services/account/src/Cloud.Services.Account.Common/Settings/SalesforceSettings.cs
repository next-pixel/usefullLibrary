namespace Cloud.Services.Account.Common.Settings;

public class SalesforceSettings
{
    public const string ConfigurationSectionName = "SalesforceSettings";
    public string? BaseUrl { get; set; } = null;
    public string? IntegrationBaseUrl { get; set; } = null;
    public string? ApiVersion { get; set; } = null;
}
