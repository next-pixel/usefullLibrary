﻿using Microsoft.Extensions.Options;

namespace Cloud.Services.Account.Common.Settings.Validators
{
    public class SalesforceAuthSettingsValidator : IValidateOptions<SalesforceAuthSettings>
    {
        public ValidateOptionsResult Validate(string? name, SalesforceAuthSettings options)
        {
            if (options is null)
                return ValidateOptionsResult.Fail(
                    "Configuration object is null.");

            if (string.IsNullOrWhiteSpace(options.BaseUrl))
                return ValidateOptionsResult.Fail(
                    $"Property '{nameof(SalesforceAuthSettings.BaseUrl)}' cannot be blank.");

            if (string.IsNullOrWhiteSpace(options.ClientId))
                return ValidateOptionsResult.Fail(
                    $"Property '{nameof(SalesforceAuthSettings.ClientId)}' cannot be blank.");

            if (string.IsNullOrWhiteSpace(options.Username))
                return ValidateOptionsResult.Fail(
                    $"Property '{nameof(SalesforceAuthSettings.Username)}' cannot be blank.");

            if (string.IsNullOrWhiteSpace(options.CertificateName))
                return ValidateOptionsResult.Fail(
                    $"Property '{nameof(SalesforceAuthSettings.CertificateName)}' cannot be blank.");

            if (string.IsNullOrWhiteSpace(options.CertificateKeyvaultBaseUrl))
                return ValidateOptionsResult.Fail(
                    $"Property '{nameof(SalesforceAuthSettings.CertificateKeyvaultBaseUrl)}' cannot be blank.");

            return ValidateOptionsResult.Success;
        }
    }
}
