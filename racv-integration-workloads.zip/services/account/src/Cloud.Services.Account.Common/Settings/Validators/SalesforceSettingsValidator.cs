﻿using Microsoft.Extensions.Options;

namespace Cloud.Services.Account.Common.Settings.Validators
{
    public class SalesforceSettingsValidator : IValidateOptions<SalesforceSettings>
    {
        public ValidateOptionsResult Validate(string? name, SalesforceSettings options)
        {
            if (options is null)
                return ValidateOptionsResult.Fail(
                    "Configuration object is null.");

            if (string.IsNullOrWhiteSpace(options.ApiVersion))
                return ValidateOptionsResult.Fail(
                    $"Property '{nameof(SalesforceSettings.ApiVersion)}' cannot be blank.");
           
            if (string.IsNullOrWhiteSpace(options.BaseUrl))
                return ValidateOptionsResult.Fail(
                    $"Property '{nameof(SalesforceSettings.BaseUrl)}' cannot be blank.");

            if (string.IsNullOrWhiteSpace(options.IntegrationBaseUrl))
                return ValidateOptionsResult.Fail(
                    $"Property '{nameof(SalesforceSettings.IntegrationBaseUrl)}' cannot be blank.");

            return ValidateOptionsResult.Success;
        }
    }
}
