﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cloud.Services.Account.Common.Settings
{
    public class SalesforceAuthSettings
    {
        public const string ConfigurationSectionName = "SalesforceAuthSettings";
        public string BaseUrl { get; set; } = string.Empty;
        public string ClientId { get; set; } = string.Empty;
        public string Username { get; set; } = string.Empty;
        public string CertificateName { get; set; } = string.Empty;
        public string CertificateKeyvaultBaseUrl { get; set; } = string.Empty;
    }
}