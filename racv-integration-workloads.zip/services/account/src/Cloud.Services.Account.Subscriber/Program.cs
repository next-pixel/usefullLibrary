using Azure.Identity;
using Azure.Security.KeyVault.Certificates;
using Cloud.Services.Account.Common.Constants;
using Cloud.Services.Account.Common.Settings;
using Cloud.Services.Account.Common.Settings.Validators;
using Cloud.Services.Account.Connector.Salesforce.Implementations;
using Cloud.Services.Account.Connector.Salesforce.Interfaces;
using Cloud.Services.Common.Azure.Keyvault.Implementations;
using Cloud.Services.Common.Azure.Keyvault.Interfaces;
using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Extensions;
using Cloud.Services.Common.Settings;
using Cloud.Services.Common.Tracking.Interfaces;
using Cloud.Services.Common.Utility.Handlers.Implementation;
using Cloud.Services.Common.Utility.Handlers.Interfaces;
using Cloud.Services.Common.Utility.Wrapper.Implementation;
using Cloud.Services.Common.Utility.Wrapper.Interfaces;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

IConfigurationRoot? configuration = null;
var functionAppSettings = new AppSettings();

var host = new HostBuilder()
    .ConfigureFunctionsWebApplication()
    .ConfigureAppConfiguration(configBuilder =>
    {
        // compile a temporary configuration instance
        configuration = configBuilder.Build();

        // Retrieve the function app settings from the application configuration.
        configuration.Bind(functionAppSettings);

        configBuilder.AddAzureAppConfigurationOptions(
            new Uri(functionAppSettings.AppConfigurationEndPoint),
            functionAppSettings.AzureClientId,
            functionAppSettings.Environment,
            functionAppSettings.Workload,
            ServicesConstants.ConfigurationRefreshKey);

        // compile a temporary configuration instance
        configuration = configBuilder.Build();
    })
    .ConfigureServices(services =>
    {
        // Define keys used to access values in the configuration manager.
        var _systemName = "MobileAppApi";
        var _excludeHeaders = new[] { ServicesConstants.Authorization, "subscription-key" };

        // Enable application insights.
        services.AddApplicationInsightsTelemetryWorkerService();
        services.ConfigureFunctionsApplicationInsights();
        services.Configure<LoggerFilterOptions>(options =>
        {
            // The Application Insights SDK adds a default logging filter that instructs ILogger to capture only Warning and more severe logs. Application Insights requires an explicit override.
            LoggerFilterRule toRemove = options.Rules.FirstOrDefault(rule => rule.ProviderName == "Microsoft.Extensions.Logging.ApplicationInsights.ApplicationInsightsLoggerProvider")!;
            if (toRemove is not null)
            {
                options.Rules.Remove(toRemove);
            }
        });

        // Retrieve the SalesforceSettings from the application configuration.
        var salesforceSettings = new SalesforceSettings();
        configuration!.Bind(SalesforceSettings.ConfigurationSectionName, salesforceSettings);

        // Retrieve the SalesforceAuthSettings from the application configuration.
        var salesforceAuthSettings = new SalesforceAuthSettings();
        configuration!.Bind(SalesforceAuthSettings.ConfigurationSectionName, salesforceAuthSettings);

        // Register settings as IOptions.
        services.Configure<SalesforceSettings>(configuration!.GetSection(SalesforceSettings.ConfigurationSectionName));
        services.Configure<SalesforceAuthSettings>(configuration!.GetSection(SalesforceAuthSettings.ConfigurationSectionName));

        //Add settings validators
        services.AddSingleton<IValidateOptions<SalesforceSettings>, SalesforceSettingsValidator>();
        services.AddSingleton<IValidateOptions<SalesforceAuthSettings>, SalesforceAuthSettingsValidator>();

        // Add message tracker system.
        services.AddMessageTracker(new Uri(functionAppSettings.BlobServiceUri));

        // Add Message Tracker Handler.
        services.AddTransient<IMessageTrackerHandlerConfiguration, MessageTrackerHandlerConfiguration>();
        services.AddSingleton<IMessageTrackerHandler<HttpRequestMessage, HttpResponseMessage>, MessageTrackerHandler>(
                provider =>
                {
                    var logger = provider.GetRequiredService<ILogger<MessageTrackerHandler>>();
                    var messageTracker = provider.GetRequiredService<IMessageTracker>();
                    var messageTrackerHandlerConfiguration =
                        provider.GetRequiredService<IMessageTrackerHandlerConfiguration>();
                    return new MessageTrackerHandler(logger, messageTracker, messageTrackerHandlerConfiguration,
                        _systemName, _excludeHeaders);
                });

        // Add HTTP Client
        services.AddHttpClient(InternalConstants.SalesforceAuthHttpClient,
            client => { client.BaseAddress = new Uri(salesforceAuthSettings.BaseUrl); });

        // Add Salesforce User HTTP Client
        services.AddHttpClient(InternalConstants.SalesforceHttpClient,
            client => { client.BaseAddress = new Uri(salesforceSettings.BaseUrl ?? string.Empty); });

        // Add Salesforce Integration HTTP Client
        services.AddHttpClient(InternalConstants.SalesforceIntegrationHttpClient,
            client => { client.BaseAddress = new Uri(salesforceSettings.IntegrationBaseUrl ?? string.Empty); });

        // Add HttpWrapper
        services.AddSingleton<IHttpWrapper<HttpRequestMessage, HttpResponseMessage>, HttpWrapper>(
            provider =>
            {
                var httpClientFactory = provider.GetRequiredService<IHttpClientFactory>();
                var messageTrackerHandler =
                    provider.GetRequiredService<IMessageTrackerHandler<HttpRequestMessage, HttpResponseMessage>>();
                var wrapper = new HttpWrapper(httpClientFactory, messageTrackerHandler.LogRequestResponse);
                return wrapper;
            });

        // Add additional service
        services.AddMemoryCache();
        services.AddSingleton<ISalesforceAuth, SalesforceAuth>();
        services.AddTransient<ISalesforceAccountConnector, SalesforceAccountConnector>();
        services.AddSingleton<IKeyvaultCertificateService, KeyvaultCertificateService>(
            provider =>
            {
#if DEBUG
                var credential = new AzureCliCredential();
#else
                var credential = new ManagedIdentityCredential(configuration[ServicesConstants.AzureClientId]);
#endif
                return new KeyvaultCertificateService(
                    provider.GetRequiredService<ILogger<KeyvaultCertificateService>>(),
                    new CertificateClient(
                        new Uri(salesforceAuthSettings.CertificateKeyvaultBaseUrl),
                        credential));
            });
    }).Build();

await host.RunAsync();