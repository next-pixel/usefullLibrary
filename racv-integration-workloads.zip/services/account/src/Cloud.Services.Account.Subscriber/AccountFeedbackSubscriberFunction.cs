using Azure.Messaging.ServiceBus;
using Cloud.Services.Account.Common.Models.Request;
using Cloud.Services.Account.Connector.Salesforce.Implementations;
using Cloud.Services.Account.Connector.Salesforce.Interfaces;
using Cloud.Services.Common.Connector.Models.Exceptions;
using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Connector.Extensions;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using Microsoft.Extensions.Caching.Memory;
using Cloud.Services.Account.Common.Constants;
using Microsoft.Azure.WebJobs;

namespace Cloud.Services.Account.Subscriber
{
    public class AccountFeedbackSubscriberFunction
    {
        private readonly ILogger<AccountFeedbackSubscriberFunction> _logger;
        private readonly ISalesforceAccountConnector _salesforceAccountConnector;
        private readonly ISalesforceAuth _salesforceAuth;
        private readonly IMemoryCache _memoryCache;

        public AccountFeedbackSubscriberFunction(
            ILogger<AccountFeedbackSubscriberFunction> logger,
            ISalesforceAccountConnector salesforceAccountConnector,
            ISalesforceAuth salesforceAuth,
            IMemoryCache memoryCache)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _salesforceAccountConnector = salesforceAccountConnector ?? throw new ArgumentNullException(nameof(salesforceAccountConnector));
            _salesforceAuth = salesforceAuth ?? throw new ArgumentNullException(nameof(salesforceAuth));
            _memoryCache = memoryCache ?? throw new ArgumentNullException(nameof(logger));

        }

        /// <summary>
        ///     Runs the AccountFeedbackSubscriber Function.
        /// </summary>
        /// <param name="sbMessage">The service bus message.</param>
        /// <param name="deliveryCount">The delivery count.</param>
        /// <param name="messageActions">The message actions.</param>
        /// <returns>
        ///     A <see cref="Task" /> representing the asynchronous operation.
        /// </returns>
        [Singleton]
        [Function(nameof(AccountFeedbackSubscriberFunction))]
        public async Task RunAsync(
           [ServiceBusTrigger(
            "%AccountFeedbackTopicName%",
            "%AccountFeedbackSubscriptionName%",
            Connection = "ServiceBusConnection")]
            ServiceBusReceivedMessage sbMessage,
           int deliveryCount,
           ServiceBusMessageActions messageActions)
        {
            var correlationIdentifier = Guid.NewGuid();
            if (Guid.TryParse(sbMessage.CorrelationId, out var identifier))
            {
                correlationIdentifier = identifier;
            }
            try
            {
                _logger.LogInformation("Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "} Starting {FunctionName} for message Id: {MessageId}",
                       correlationIdentifier,
                       nameof(AccountFeedbackSubscriberFunction),
                       sbMessage.MessageId);

                // Deserialize service bus message
                var feedbackMessage = JsonSerializer.Deserialize<FeedbackRequest>(sbMessage.Body.ToString());

                // Fetch salesforce access token
                var authorization = await _salesforceAuth.GetAccessToken(correlationIdentifier);

                // Submit account feedback
                await _salesforceAccountConnector.SubmitAccountFeedback(
                    feedbackMessage,
                    correlationIdentifier,
                    authorization);

                _logger.LogInformation("Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "} Function: {FunctionName} completed for message Id: {MessageId}",
                        correlationIdentifier,
                        nameof(AccountFeedbackSubscriberFunction),
                        sbMessage.MessageId);

            }
            catch (ConnectorOperationValidationException ex)
            {
                _logger.LogError(ex,
                    "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "} Function: {FunctionName} failed with validation error: {message}",
                    correlationIdentifier,
                    nameof(AccountFeedbackSubscriberFunction),
                    ex.ErrorDetails?.Convert());
                await messageActions.DeadLetterMessageAsync(sbMessage);
            }
            catch (ExternalApiDependencyException ex)
            {
                _logger.LogError(ex,
                    "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "} Function: {FunctionName} failed with transient API error: {message}",
                    correlationIdentifier,
                    nameof(AccountFeedbackSubscriberFunction),
                    ex.ErrorDetails?.Convert());
                await messageActions.AbandonMessageAsync(sbMessage);
            }
            catch (ConnectorOperationUnauthorizedException ex)
            {
                _logger.LogError(ex,
                    "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "} Function: {FunctionName} failed with unauthorized error: {message}",
                    correlationIdentifier,
                    nameof(AccountFeedbackSubscriberFunction),
                    ex.ErrorDetails?.Convert());
                _memoryCache.Remove(InternalConstants.SalesforceAccessTokenCacheKey);
                await messageActions.AbandonMessageAsync(sbMessage);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "} Function: {FunctionName} failed with unexpected error: {message}; RetryCount:{RetryCount}",
                    correlationIdentifier,
                    nameof(AccountFeedbackSubscriberFunction),
                    ex.Message,
                    deliveryCount);
                await messageActions.DeadLetterMessageAsync(sbMessage);
            }
        }
    }
}
