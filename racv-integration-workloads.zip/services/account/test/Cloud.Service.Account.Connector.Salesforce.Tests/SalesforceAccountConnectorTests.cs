﻿using Cloud.Services.Account.Common.Models.Request;
using Cloud.Services.Account.Common.Models.Salesforce;
using Cloud.Services.Account.Common.Models.Salesforce.SObjects;
using Cloud.Services.Account.Common.Settings;
using Cloud.Services.Account.Connector.Salesforce.Implementations;
using Cloud.Services.Common.Connector.Models.Exceptions;
using Cloud.Services.Common.Utility.Wrapper.Interfaces;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using System.Net;
using System.Runtime.Serialization;

namespace Cloud.Service.Account.Connector.Salesforce.Tests
{
    public class SalesforceAccountConnectorTest
    {
        private readonly Mock<IHttpWrapper<HttpRequestMessage, HttpResponseMessage>> _mockHttpWrapper;
        private readonly Mock<ILogger<SalesforceAccountConnector>> _mockLogger;
        private readonly IOptions<SalesforceSettings> _salesforceSettings;
        private readonly SalesforceAccountConnector _salesforceAccountConnector;

        public SalesforceAccountConnectorTest()
        {
            _mockHttpWrapper = new Mock<IHttpWrapper<HttpRequestMessage, HttpResponseMessage>>();
            _mockLogger = new Mock<ILogger<SalesforceAccountConnector>>();
            _salesforceSettings = Options.Create(new SalesforceSettings
            {
                BaseUrl = "baseUrl",
                ApiVersion = "apiVersion",
                IntegrationBaseUrl = "integrationBaseUrl",
            });

            _salesforceAccountConnector = new SalesforceAccountConnector(
                _mockLogger.Object,
                _mockHttpWrapper.Object,
                _salesforceSettings);
        }

        [Fact]
        public async Task SubmitAccountFeedback_WithValidParameters_SendsRequestSuccessfully()
        {
            // Arrange
            FeedbackRequest feedbackMessage = new FeedbackRequest { /* Initialize with valid values */ };
            Guid xCorrelationIdentifier = Guid.NewGuid();
            string authorization = "valid_token";

            _mockHttpWrapper
                .Setup(wrapper => wrapper.SendAsync(
                    It.IsAny<HttpRequestMessage>(),
                    It.IsAny<string>(),
                    It.IsAny<Guid>(),
                    It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK
                });

            // Act
            await _salesforceAccountConnector.SubmitAccountFeedback(feedbackMessage, xCorrelationIdentifier, authorization);

            // Assert
            _mockHttpWrapper.Verify(wrapper => wrapper.SendAsync(
                It.IsAny<HttpRequestMessage>(),
                It.IsAny<string>(),
                It.IsAny<Guid>(),
                It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task SubmitAccountFeedback_WithBadRequestResponse_ThrowsConnectorOperationValidationException()
        {
            // Arrange
            FeedbackRequest feedbackMessage = new FeedbackRequest { /* Initialize with valid values */ };
            Guid xCorrelationIdentifier = Guid.NewGuid();
            string authorization = "valid_token";

            _mockHttpWrapper
                .Setup(wrapper => wrapper.SendAsync(
                    It.IsAny<HttpRequestMessage>(),
                    It.IsAny<string>(),
                    It.IsAny<Guid>(),
                    It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Content = new StringContent(
                        System.Text.Json.JsonSerializer.Serialize(
                            new List<FailureResponseModel>
                            {
                                new FailureResponseModel { ErrorCode = "error_code", Message = "error_message" }
                            }))
                });

            // Act & Assert
            var exception = await Assert.ThrowsAsync<ConnectorOperationValidationException>(() =>
                _salesforceAccountConnector.SubmitAccountFeedback(feedbackMessage, xCorrelationIdentifier, authorization));

            Assert.Equal("Salesforce API responded with Status Code BadRequest.", exception.Message);
            Assert.NotNull(exception.ErrorDetails);
            Assert.Single(exception.ErrorDetails);
            Assert.Equal("error_code", exception.ErrorDetails[0].Code);
            Assert.Equal("error_message", exception.ErrorDetails[0].Message);
        }

        [Fact]
        public async Task SubmitAccountFeedback_WithUnauthorizedResponse_ThrowsConnectorOperationUnauthorizedException()
        {
            // Arrange
            FeedbackRequest feedbackMessage = new FeedbackRequest { /* Initialize with valid values */ };
            Guid xCorrelationIdentifier = Guid.NewGuid();
            string authorization = "valid_token";

            _mockHttpWrapper
                .Setup(wrapper => wrapper.SendAsync(
                    It.IsAny<HttpRequestMessage>(),
                    It.IsAny<string>(),
                    It.IsAny<Guid>(),
                    It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.Unauthorized
                });

            // Act & Assert
            await Assert.ThrowsAsync<ConnectorOperationUnauthorizedException>(() =>
                _salesforceAccountConnector.SubmitAccountFeedback(feedbackMessage, xCorrelationIdentifier, authorization));
        }

        [Fact]
        public async Task SubmitAccountFeedback_WithFailedRequest_ThrowsExternalAPIDependencyException()
        {
            // Arrange
            FeedbackRequest feedbackMessage = new FeedbackRequest { /* Initialize with valid values */ };
            Guid xCorrelationIdentifier = Guid.NewGuid();
            string authorization = "valid_token";

            _mockHttpWrapper
                .Setup(wrapper => wrapper.SendAsync(
                    It.IsAny<HttpRequestMessage>(),
                    It.IsAny<string>(),
                    It.IsAny<Guid>(),
                    It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.InternalServerError,
                    Content = new StringContent(
                        System.Text.Json.JsonSerializer.Serialize(
                            new List<FailureResponseModel>
                            {
                                new FailureResponseModel { ErrorCode = "error_code", Message = "error_message" }
                            }))
                });

            // Act & Assert
            var exception = await Assert.ThrowsAsync<ExternalApiDependencyException>(() =>
                _salesforceAccountConnector.SubmitAccountFeedback(feedbackMessage, xCorrelationIdentifier, authorization));

            Assert.Equal("Salesforce API responded with Status Code InternalServerError.", exception.Message);
            Assert.NotNull(exception.ErrorDetails);
            Assert.Single(exception.ErrorDetails);
            Assert.Equal("error_code", exception.ErrorDetails[0].Code);
            Assert.Equal("error_message", exception.ErrorDetails[0].Message);
        }
    }
}