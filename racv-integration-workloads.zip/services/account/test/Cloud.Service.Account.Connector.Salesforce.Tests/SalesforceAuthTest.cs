﻿using Cloud.Services.Account.Connector.Salesforce.Implementations;
using Cloud.Services.Account.Common.Settings;
using Cloud.Services.Common.Azure.Keyvault.Interfaces;
using Cloud.Services.Common.Utility.Wrapper.Interfaces;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using Cloud.Services.Account.Common.Constants;
using System.Net;
using Cloud.Services.Common.Connector.Models.Exceptions;
using Cloud.Service.Account.Connector.Salesforce.Tests.Infrastructure;

namespace Cloud.Service.Account.Connector.Salesforce.Tests
{
    public class SalesforceAuthTests
    {
        private readonly SalesforceAuth _salesforceAuth;
        private readonly IMemoryCache _memoryCache;
        private readonly Mock<ILogger<SalesforceAuth>> _mockLogger;
        private readonly Mock<IHttpWrapper<HttpRequestMessage, HttpResponseMessage>> _mockHttpWrapper;
        private readonly Mock<IKeyvaultCertificateService> _mockKeyvaultCertificateService;
        private readonly SalesforceAuthSettings _salesforceAuthSettings;

        public SalesforceAuthTests()
        {
            _memoryCache = new MemoryCache(Options.Create(new MemoryCacheOptions()));
            _mockLogger = new Mock<ILogger<SalesforceAuth>>();
            _mockHttpWrapper = new Mock<IHttpWrapper<HttpRequestMessage, HttpResponseMessage>>();
            _mockKeyvaultCertificateService = new Mock<IKeyvaultCertificateService>();
            _salesforceAuthSettings = new SalesforceAuthSettings
            {
                CertificateName = "certificateName",
                ClientId = "clientId",
                Username = "username",
                BaseUrl = "baseUrl"
            };

            var options = Options.Create(_salesforceAuthSettings);

            _salesforceAuth = new SalesforceAuth(
                _memoryCache,
                _mockLogger.Object,
                _mockHttpWrapper.Object,
                options,
                _mockKeyvaultCertificateService.Object);
        }

        [Fact]
        public async Task GetAccessToken_ShouldReturnAccessToken()
        {
            // Arrange
            var correlationIdentifier = Guid.NewGuid();
            var expectedToken = "access_token";

            _memoryCache.Set(InternalConstants.SalesforceAccessTokenCacheKey, expectedToken);

            // Act
            var token = await _salesforceAuth.GetAccessToken(correlationIdentifier);

            // Assert
            Assert.Equal(expectedToken, token);
        }

        [Fact]
        public async Task GetAccessToken_ShouldReturnNewToken_WhenTokenDoesNotExistInMemoryCache()
        {
            // Arrange
            var correlationIdentifier = Guid.NewGuid();
            var expectedToken = "access_token";

            _memoryCache.Remove(InternalConstants.SalesforceAccessTokenCacheKey);

            _mockKeyvaultCertificateService.Setup(x => x.DownloadCertificateAsync(
                _salesforceAuthSettings.CertificateName,
                correlationIdentifier))
                .ReturnsAsync(SelfSignedCertificate.GenerateSelfSignedCertificate());

            _mockHttpWrapper.Setup(x => x.SendAsync(
                It.IsAny<HttpRequestMessage>(),
                It.IsAny<string>(),
                It.IsAny<Guid>(),
                It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent($"{{'access_token':'{expectedToken}'}}")
                });

            // Act
            var token = await _salesforceAuth.GetAccessToken(correlationIdentifier);

            // Assert
            Assert.Equal(expectedToken, token);
            _mockKeyvaultCertificateService.Verify(x => x.DownloadCertificateAsync(
                _salesforceAuthSettings.CertificateName,
                correlationIdentifier),
                Times.Once);
            _mockHttpWrapper.Verify(x => x.SendAsync(
                It.IsAny<HttpRequestMessage>(),
                It.IsAny<string>(),
                It.IsAny<Guid>(),
                It.IsAny<string>()),
                Times.Once);
        }

        [Fact]
        public async Task GetAccessToken_ShouldThrowException_WhenPrivateKeyIsNull()
        {
            // Arrange
            var correlationIdentifier = Guid.NewGuid();
            var certificate = SelfSignedCertificate.GenerateSelfSignedEcdCertificate();

            _memoryCache.Remove(InternalConstants.SalesforceAccessTokenCacheKey);

            _mockKeyvaultCertificateService.Setup(x => x.DownloadCertificateAsync(
                _salesforceAuthSettings.CertificateName,
                correlationIdentifier))
                .ReturnsAsync(certificate);

            // Act and Assert
            await Assert.ThrowsAsync<ExternalApiDependencyException>(async () =>
            {
                await _salesforceAuth.GetAccessToken(correlationIdentifier);
            });

            _mockKeyvaultCertificateService.Verify(x => x.DownloadCertificateAsync(
                _salesforceAuthSettings.CertificateName,
                correlationIdentifier),
                Times.Once);
        }

        [Theory]
        [InlineData(HttpStatusCode.OK, "{\"access_token\":\"\"}")]
        [InlineData(HttpStatusCode.OK, null)]
        [InlineData(HttpStatusCode.Unauthorized, null)]
        public async Task GetAccessToken_ShouldThrowException_WhenAuthenticationProducesInvalidResponse(
            HttpStatusCode httpStatusCode, string? response)
        {
            // Arrange
            var correlationIdentifier = Guid.NewGuid();
            var certificate = SelfSignedCertificate.GenerateSelfSignedCertificate();

            _memoryCache.Remove(InternalConstants.SalesforceAccessTokenCacheKey);

            _mockKeyvaultCertificateService.Setup(x => x.DownloadCertificateAsync(
                _salesforceAuthSettings.CertificateName,
                correlationIdentifier))
                .ReturnsAsync(certificate);

            _mockHttpWrapper.Setup(x => x.SendAsync(
                It.IsAny<HttpRequestMessage>(),
                It.IsAny<string>(),
                It.IsAny<Guid>(),
                It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = httpStatusCode,
                    Content = string.IsNullOrWhiteSpace(response) ? null : new StringContent(response)
                });

            // Act and Assert
            await Assert.ThrowsAsync<ExternalApiDependencyException>(async () =>
            {
                await _salesforceAuth.GetAccessToken(correlationIdentifier);
            });

            _mockKeyvaultCertificateService.Verify(x => x.DownloadCertificateAsync(
                _salesforceAuthSettings.CertificateName,
                correlationIdentifier),
                Times.Once);
        }
    }
}