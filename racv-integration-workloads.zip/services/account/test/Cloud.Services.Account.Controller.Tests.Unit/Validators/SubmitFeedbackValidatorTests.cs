﻿using Cloud.Services.Account.Api.Models.Request;
using Cloud.Services.Account.Api.Validators;
using FluentValidation.TestHelper;

namespace Cloud.Services.Account.Controller.Tests.Unit.Validators
{
    public class SubmitFeedbackValidatorTests
    {
        private readonly SubmitFeedbackValidator _validator;

        public SubmitFeedbackValidatorTests()
        {
            _validator = new SubmitFeedbackValidator();
        }

        [Fact]
        public void ShouldHaveErrorWhenDescriptionExceedsMaximumLength()
        {
            // Arrange
            var request = new FeedbackRequest { Description = new string('A', 1251) };

            // Act
            var result = _validator.TestValidate(request);

            // Assert
            result.ShouldHaveValidationErrorFor(x => x.Description)
                .WithErrorMessage("'Description' length can't be more than 1250 characters.");
        }

        [Fact]
        public void ShouldHaveErrorWhenRatingIsLessThanOne()
        {
            // Arrange
            var request = new FeedbackRequest { Rating = 0 };

            // Act
            var result = _validator.TestValidate(request);

            // Assert
            result.ShouldHaveValidationErrorFor(x => x.Rating)
                .WithErrorMessage("'Rating' must be greater than '0'.");
        }

        [Fact]
        public void ShouldHaveErrorWhenRatingIsGreaterThanThree()
        {
            // Arrange
            var request = new FeedbackRequest { Rating = 4 };

            // Act
            var result = _validator.TestValidate(request);

            // Assert
            result.ShouldHaveValidationErrorFor(x => x.Rating)
                .WithErrorMessage("'Rating' should be between 1 and 3.");
        }

        [Fact]
        public void ShouldNotHaveErrorsWhenValidationPasses()
        {
            // Arrange
            var request = new FeedbackRequest { Description = "Valid description .,?!&$'", Rating = 2 };

            // Act
            var result = _validator.TestValidate(request);

            // Assert
            result.ShouldNotHaveAnyValidationErrors();
        }
    }
}