﻿using Cloud.Services.Account.Api.Extensions;
using SalesforceResponse = Cloud.Services.Account.Common.Models.Salesforce.SObjects;

namespace Cloud.Services.Account.Controller.Tests.Unit.ExtensionsTests
{
    public class SalesforceResponseConverterTests
    {
        [Fact]
        public void Convert_NullSfDetailsResponse_ThrowsArgumentNullException()
        {
            // Arrange
            SalesforceResponse.AccountDetails? nullResponse = null;

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => nullResponse.Convert());
        }

        [Fact]
        public void Convert_ValidSfDetailsResponse_ReturnsCorrectServiceResponse()
        {
            // Arrange
            var mockSfResponse = new SalesforceResponse.AccountDetails
            {
                Account = new SalesforceResponse.Account
                {
                    PersonEmail = "test@example.com",
                    FirstName = "John",
                    LastName = "Doe",
                    MembershipCardTypeC = "Gold",
                    MembershipStatusC = "Active",
                    MemberNumberC = "123456",
                    Name = "John Doe",
                    PersonBirthdate = new DateTime(1990, 1, 1, 10, 10, 10, DateTimeKind.Unspecified),
                    MemberStartDateC = new DateTime(2020, 1, 1, 10, 10, 10, DateTimeKind.Unspecified),
                    CardNumberC = "1234567890123456"
                },
                Contact = new SalesforceResponse.Contact
                {
                    Id = "ContactId123"
                }
            };

            // Act
            var result = mockSfResponse.Convert();

            // Assert
            Assert.NotNull(result);
            Assert.Equal("Operation successful.", result.Message);
            Assert.NotNull(result.Data);
            Assert.Equal("test@example.com", result.Data.PersonEmail);
            Assert.Equal("John", result.Data.FirstName);
            Assert.Equal("Doe", result.Data.LastName);
            Assert.Equal("Gold", result.Data.MembershipCardType);
            Assert.Equal("Active", result.Data.MembershipStatus);
            Assert.Equal("123456", result.Data.MemberNumber);
            Assert.Equal("John Doe", result.Data.Name);
            Assert.Equal("ContactId123", result.Data.ContactId);
            Assert.Equal(new DateTime(1990, 1, 1, 10, 10, 10, DateTimeKind.Unspecified), result.Data.PersonBirthdate);
            Assert.Equal(new DateTime(2020, 1, 1, 10, 10, 10, DateTimeKind.Unspecified), result.Data.MemberStartDate);
            Assert.Equal("1234567890123456", result.Data.MembershipCardNumber);
            Assert.NotNull(result.Data.MembershipCardBarcode);
            Assert.Equal("1234569890123456", result.Data.FuelVoucherNumber);
            Assert.NotNull(result.Data.FuelVoucherBarcode);
        }

        [Fact]
        public void Convert_ExceptionDuringConversion_ThrowsInvalidOperationException()
        {
            // Arrange
            var mockSfResponse = new SalesforceResponse.AccountDetails
            {
                Account = null // This will cause an exception in ConvertSFModel
            };

            // Act & Assert
            var exception = Assert.Throws<InvalidOperationException>(() => mockSfResponse.Convert());
            Assert.Equal("An error occurred while converting the Salesforce Account Details to Microservice Account Details.", exception.Message);
        }

        [Fact]
        public void ConvertSFModel_NullSfAccountDetails_ThrowsArgumentNullException()
        {
            // Arrange
            SalesforceResponse.AccountDetails? nullAccountDetails = null;

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => nullAccountDetails.Convert());
        }

        [Fact]
        public void Convert_NullAccount_ThrowsInvalidOperationException()
        {
            // Arrange
            var sfAccountDetails = new SalesforceResponse.AccountDetails
            {
                Account = null,
                Contact = new SalesforceResponse.Contact()
            };

            // Act & Assert
            Assert.Throws<InvalidOperationException>(() => sfAccountDetails.Convert());
        }

        [Fact]
        public void ConvertSFModel_ValidInput_ReturnsCorrectDetails()
        {
            // Arrange
            var sfAccountDetails = new SalesforceResponse.AccountDetails
            {
                Account = new SalesforceResponse.Account
                {
                    PersonEmail = "test@example.com",
                    FirstName = "John",
                    LastName = "Doe",
                    MembershipCardTypeC = "Gold",
                    MembershipStatusC = "Active",
                    MemberNumberC = "123456",
                    Name = "John Doe",
                    PersonBirthdate = new DateTime(1990, 1, 1, 10, 10, 10, DateTimeKind.Unspecified),
                    MemberStartDateC = new DateTime(2020, 1, 1, 10, 10, 10, DateTimeKind.Unspecified),
                    CardNumberC = "1234567890123456"
                },
                Contact = new SalesforceResponse.Contact
                {
                    Id = "ContactId123"
                }
            };

            // Act
            var result = sfAccountDetails.Convert();

            // Assert
            Assert.NotNull(result);
            Assert.Equal("test@example.com", result.Data!.PersonEmail);
            Assert.Equal("John", result.Data!.FirstName);
            Assert.Equal("Doe", result.Data!.LastName);
            Assert.Equal("Gold", result.Data!.MembershipCardType);
            Assert.Equal("Active", result.Data!.MembershipStatus);
            Assert.Equal("123456", result.Data!.MemberNumber);
            Assert.Equal("John Doe", result.Data!.Name);
            Assert.Equal("ContactId123", result.Data!.ContactId);
            Assert.Equal(new DateTime(1990, 1, 1, 10, 10, 10, DateTimeKind.Unspecified), result.Data!.PersonBirthdate);
            Assert.Equal(new DateTime(2020, 1, 1, 10, 10, 10, DateTimeKind.Unspecified), result.Data!.MemberStartDate);
            Assert.Equal("1234567890123456", result.Data!.MembershipCardNumber);
            Assert.NotNull(result.Data!.MembershipCardBarcode);
            Assert.Equal("1234569890123456", result.Data!.FuelVoucherNumber);
            Assert.NotNull(result.Data!.FuelVoucherBarcode);
        }

        [Fact]
        public void ConvertSFModel_NullCardNumber_HandlesFuelVoucherCorrectly()
        {
            // Arrange
            var sfAccountDetails = new SalesforceResponse.AccountDetails
            {
                Account = new SalesforceResponse.Account
                {
                    CardNumberC = null
                },
                Contact = new SalesforceResponse.Contact()
            };

            // Act
            var result = sfAccountDetails.Convert();

            // Assert
            Assert.Null(result.Data!.MembershipCardNumber);
            Assert.Null(result.Data!.MembershipCardBarcode);
            Assert.Null(result.Data!.FuelVoucherNumber);
            Assert.Null(result.Data!.FuelVoucherBarcode);
        }

        [Fact]
        public void ConvertSFModel_ShortCardNumber_HandlesFuelVoucherCorrectly()
        {
            // Arrange
            var sfAccountDetails = new SalesforceResponse.AccountDetails
            {
                Account = new SalesforceResponse.Account
                {
                    CardNumberC = "123456"
                },
                Contact = new SalesforceResponse.Contact()
            };

            // Act
            var result = sfAccountDetails.Convert();

            // Assert
            Assert.Equal("123456", result.Data!.MembershipCardNumber);
            Assert.Null(result.Data!.MembershipCardBarcode);
            Assert.Null(result.Data!.FuelVoucherNumber);
            Assert.Null(result.Data!.FuelVoucherBarcode);
        }
    }
}