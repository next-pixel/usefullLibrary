﻿using Cloud.Services.Account.Api.Models.Request;
using Cloud.Services.Account.Api.Extensions;
using System.Text;
using FluentAssertions;

namespace Cloud.Services.Account.Controller.Tests.Unit.ExtensionsTests
{
    public class FeedbackRequestExtensionsTests
    {
        [Fact]
        public void IsRequestValid_WithValidRequest_ShouldReturnTrue()
        {
            // Arrange
            var feedbackRequest = new FeedbackRequest
            {
                Description = "Test feedback",
                Rating = 3
            };

            // Act
            var isValid = feedbackRequest.IsRequestValid(out var failureResponseDetails);

            // Assert
            isValid.Should().BeTrue();
            failureResponseDetails.Should().BeNull();
        }

        [Fact]
        public void IsRequestValid_WithInvalidRequest_ShouldReturnFalseAndFailureResponseDetails()
        {
            // Arrange
            var feedbackRequest = new FeedbackRequest
            {
                Description = null,
                Rating = 0
            };

            // Act
            var isValid = feedbackRequest.IsRequestValid(out var failureResponseDetails);

            // Assert
            isValid.Should().BeFalse();
            failureResponseDetails.Should().NotBeNull();
            failureResponseDetails.Should().HaveCount(1);
            failureResponseDetails?[0].Message.Should().Be("'Rating' must be greater than '0'.");
            failureResponseDetails?[0].Entity.Should().Be("Rating");
        }

        [Fact]
        public void Convert_ShouldReturnFeedbackRequestWithCorrectValues()
        {
            // Arrange
            var feedbackRequest = new FeedbackRequest
            {
                Description = "Test feedback",
                Rating = 3
            };
            var userId = "test_user";

            // Act
            var result = feedbackRequest.Convert(userId);

            // Assert
            result.Should().NotBeNull();
            result.userId.Should().Be(userId);
            result.Description.Should().Be(feedbackRequest.Description);
            result.Rating.Should().Be(feedbackRequest.Rating);
        }
    }
}
