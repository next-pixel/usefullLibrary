using System.Globalization;
using ServiceResponse = Cloud.Services.Account.Api.Models.Response;
using SalesforceResponse = Cloud.Services.Account.Common.Models.Salesforce.SObjects;

namespace Cloud.Services.Account.Controller.Tests.Unit.Infrastructure;

public static class TestDataHelper
{
    /// <summary>
    ///     Generates a mock Salesforce response for testing.
    /// </summary>
    /// <returns>A mock Salesforce response.</returns>
    public static SalesforceResponse.AccountDetails GetExpectedSalesforceResponse()
    {
        return new SalesforceResponse.AccountDetails
        {
            Attributes =
                new SalesforceResponse.Attributes
                {
                    Type = "User", Url = "/services/data/v58.0/sobjects/User/005Bn000006OSUOIA4"
                },
            Account = new SalesforceResponse.Account
            {
                Attributes =
                    new SalesforceResponse.Attributes
                    {
                        Type = "Account", Url = "/services/data/v58.0/sobjects/Account/001Bn00000FB7AeIAL"
                    },
                PersonEmail = "johndoe@example.com",
                FirstName = "John",
                LastName = "Doe",
                MembershipCardTypeC = null,
                MembershipStatusC = null,
                MemberNumberC = null,
                Name = "John Doe",
                PersonBirthdate = DateTime.Parse("1987-01-01", CultureInfo.InvariantCulture),
                MemberStartDateC = null,
                CardNumberC = "1234567890123459",
                Type = "Known contact"
            },
            Contact = new SalesforceResponse.Contact
            {
                Attributes = new SalesforceResponse.Attributes
                {
                    Type = "Contact", Url = "/services/data/v58.0/sobjects/Contact/003Bn00000HSpSKIA1"
                },
                Id = "003Bn00000HSpSKIA1",
                PreferredNameC = null
            }
        };
    }

    /// <summary>
    ///     Generates a mock service response for testing.
    /// </summary>
    /// <returns>A mock service response.</returns>
    public static ServiceResponse.DetailsResponse GetExpectedServiceResponse()
    {
        return new ServiceResponse.DetailsResponse
        {
            Message = "Operation successful.",
            Data = new ServiceResponse.Details
            {
                PersonEmail = "johndoe@example.com",
                FirstName = "John",
                LastName = "Doe",
                MembershipCardType = null,
                MembershipStatus = null,
                MemberNumber = null,
                Name = "John Doe",
                ContactId = "003Bn00000HSpSKIA1",
                PersonBirthdate = DateTime.Parse("1987-01-01", CultureInfo.InvariantCulture),
                MemberStartDate = null,
                MembershipCardNumber = "1234567890123459",
                MembershipCardBarcode =
                    "iVBORw0KGgoAAAANSUhEUgAAAVcAAABICAYAAABCxrbiAAAABHNCSVQICAgIfAhkiAAAAVtJREFUeJzt1EEKgzAUQMG2h/D+5/MSdtWFAbEWH0WZ2SkxP6i857Isy+PCpmlaXc/zvLr/ud5aPz43rhv321t/dN/R0blH5x+d8+38vX333tfWvNG35737dxvX7b33s85z9j6//mdX8Pr3AQDuSFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgCBNzewaoylKOvhAAAAAElFTkSuQmCC",
                FuelVoucherNumber = "1234569890123459",
                FuelVoucherBarcode =
                    "iVBORw0KGgoAAAANSUhEUgAAAVcAAABICAYAAABCxrbiAAAABHNCSVQICAgIfAhkiAAAAVhJREFUeJzt1EEKgzAUQMG2h/D+5/MSdtWFAZFIX0vLzE75JlHh3bdt224/bFmW3fW6rrv7r+uj+fG5cW5c72x+dt3R7L6z+8/uc7Tu0dyn9zs7x7/+t3Hu6nvPfo93vdfV7/VLHt8+AMA/EleAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0DgCdvBaozhKFdzAAAAAElFTkSuQmCC"
            }
        };
    }
}
