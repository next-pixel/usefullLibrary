﻿using Azure.Messaging.ServiceBus;
using Cloud.Services.Account.Api.Controllers;
using Cloud.Services.Account.Api.Models.Request;
using Cloud.Services.Account.Common.Constants;
using Cloud.Services.Account.Connector.Salesforce.Interfaces;
using Cloud.Services.Account.Controller.Tests.Unit.Infrastructure;
using Cloud.Services.Common.Azure.ServiceBus.Interfaces;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestPlatform.ObjectModel.Client;
using Moq;
using ServiceResponse = Cloud.Services.Account.Api.Models.Response;

namespace Cloud.Services.Account.Controller.Tests.Unit.UnitTests;

/// <summary>
/// This class contains unit tests for the <see cref="AccountController" />.
/// </summary>
public class AccountControllerTest
{
    private const string Authorization = "Bearer valid_token";
    private readonly AccountController _accountController;
    private readonly Mock<ILogger<AccountController>> _mockLogger;
    private readonly Mock<ISalesforceAccountConnector> _mockSalesforceAccountConnector;
    private readonly Mock<IServiceBusClient> _serviceBusClientMock = new Mock<IServiceBusClient>();
    private readonly Mock<IConfiguration> _configurationMock = new Mock<IConfiguration>();
    private readonly Guid _xCorrelationIdentifier;

    /// <summary>
    ///     Initializes a new instance of the AccountControllerTest class.
    /// </summary>
    public AccountControllerTest()
    {
        _mockLogger = LoggerHelper.GetLogger<AccountController>();
        _mockSalesforceAccountConnector = new Mock<ISalesforceAccountConnector>();
        _accountController = new AccountController(
            _mockLogger.Object,
            _mockSalesforceAccountConnector.Object,
            _serviceBusClientMock.Object,
            _configurationMock.Object);
        _xCorrelationIdentifier = Guid.NewGuid();

        _mockSalesforceAccountConnector
            .Setup(service => service.GetAccountDetails(_xCorrelationIdentifier, Authorization))
            .ReturnsAsync(TestDataHelper.GetExpectedSalesforceResponse());
    }

    /// <summary>
    /// Test case for GetAsync method in AccountController.
    /// This test verifies that the GetAsync method returns the expected result when called with valid parameters.
    /// </summary>
    [Fact]
    public async Task AccountController_GetAccountDetails_ShouldPass()
    {
        // Arrange

        // Act
        var result = await _accountController.GetAccountDetailsAsync(_xCorrelationIdentifier, Authorization);

        // Assert
        result.Should().NotBeNull();

        var okResult = result.Result as OkObjectResult;
        okResult.Should().NotBeNull();
        okResult.Should().BeOfType<OkObjectResult>();
        okResult?.StatusCode.Should().Be(StatusCodes.Status200OK);

        var returnValue = okResult?.Value as ServiceResponse.DetailsResponse;
        returnValue.Should().NotBeNull();
        returnValue.Should().BeOfType<ServiceResponse.DetailsResponse>();
        returnValue.Should().BeEquivalentTo(TestDataHelper.GetExpectedServiceResponse());

        _mockSalesforceAccountConnector.Verify(
            service => service.GetAccountDetails(_xCorrelationIdentifier, Authorization),
            Times.Once);
    }

    /// <summary>
    /// Test case for SubmitAccountFeedbackAsync method in AccountController.
    /// This test verifies that the SubmitAccountFeedbackAsync method returns 400 Bad request when invalid request is sent
    /// </summary>
    [Theory]
    [InlineData(null, 0)]
    [InlineData(null, 100)]
    public async Task AccountController_SubmitAccountFeedback_ShouldReturnBadRequest(string? description, int rating)
    {
        // Arrange
        var xCorrelationIdentifier = Guid.NewGuid();
        var authorization = "Bearer valid_token";
        var feedbackRequest = new FeedbackRequest
        {
            Description = description,
            Rating = rating
        };

        // Act
        var result = await _accountController.SubmitAccountFeedbackAsync(xCorrelationIdentifier, authorization, feedbackRequest);

        // Assert
        result.Should().NotBeNull();
        result.Should().BeOfType<BadRequestObjectResult>();

        _serviceBusClientMock.Verify(
            x => x.SendMessageAsync(
                It.Is<string>(topicName => topicName == _configurationMock.Object[InternalConstants.AccountFeedbackTopicNameKey]),
                It.IsAny<ServiceBusMessage>()),
            Times.Never);
    }

    /// <summary>
    /// Test case for SubmitAccountFeedbackAsync method in AccountController.
    /// This test verifies that the SubmitAccountFeedbackAsync method returns 500 internal server error
    /// </summary>
    [Fact]
    public async Task AccountController_SubmitAccountFeedback_ShouldReturnInternalServerError()
    {
        // Arrange
        var xCorrelationIdentifier = Guid.NewGuid();
        var authorization = "Bearer valid_token";
        var feedbackRequest = new FeedbackRequest()
        {
            Description = "Love this app",
            Rating = 3
        };

        // Act
        var result = await _accountController.SubmitAccountFeedbackAsync(xCorrelationIdentifier, authorization, feedbackRequest);

        // Assert
        result.Should().NotBeNull();
        result.Should().BeOfType<ObjectResult>();

        var returnValue = result as ObjectResult;
        returnValue?.StatusCode.Should().Be(StatusCodes.Status500InternalServerError);

        _serviceBusClientMock.Verify(
            x => x.SendMessageAsync(
                It.Is<string>(topicName => topicName == _configurationMock.Object[InternalConstants.AccountFeedbackTopicNameKey]),
                It.IsAny<ServiceBusMessage>()),
            Times.Never);
    }

    /// <summary>
    /// Test case for SubmitAccountFeedbackAsync method in AccountController.
    /// This test verifies that the SubmitAccountFeedbackAsync method returns 201 created
    /// </summary>
    [Fact]
    public async Task AccountController_SubmitAccountFeedback_ShouldPass()
    {
        // Arrange
        var xCorrelationIdentifier = Guid.NewGuid();
        var authorization = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJiMmM6MDA1OXAwMDAwMDhLVTI5QUFHIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.xzwWsbspvfunWGwudy1b-Y1JCoMv9HuramKyX9BHfg8";
        var feedbackRequest = new FeedbackRequest()
        {
            Description = "Love this app",
            Rating = 3
        };

        // Act
        var result = await _accountController.SubmitAccountFeedbackAsync(xCorrelationIdentifier, authorization, feedbackRequest);

        // Assert
        result.Should().NotBeNull();
        result.Should().BeOfType<StatusCodeResult>();

        var returnValue = result as StatusCodeResult;
        returnValue?.StatusCode.Should().Be(StatusCodes.Status201Created);

        _serviceBusClientMock.Verify(
            x => x.SendMessageAsync(
                It.Is<string>(topicName => topicName == _configurationMock.Object[InternalConstants.AccountFeedbackTopicNameKey]),
                It.IsAny<ServiceBusMessage>()),
            Times.Once);
    }
}