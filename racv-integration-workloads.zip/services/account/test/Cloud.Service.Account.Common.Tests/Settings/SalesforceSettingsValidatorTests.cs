﻿using Cloud.Services.Account.Common.Settings;
using Cloud.Services.Account.Common.Settings.Validators;

namespace Cloud.Service.Account.Common.Tests.Settings
{
    public class SalesforceSettingsValidatorTests
    {
        private readonly SalesforceSettingsValidator _validator;

        public SalesforceSettingsValidatorTests()
        {
            _validator = new SalesforceSettingsValidator();
        }

        [Fact]
        public void Validate_ShouldFail_WhenOptionsIsNull()
        {
            // Arrange
            string name = "SalesforceSettings";
            SalesforceSettings? options = null;

            // Act
            var result = _validator.Validate(name, options!);

            // Assert
            Assert.False(result.Succeeded);
            Assert.Equal("Configuration object is null.", result.FailureMessage);
        }

        [Fact]
        public void Validate_ShouldFail_WhenApiVersionIsBlank()
        {
            // Arrange
            string name = "SalesforceSettings";
            SalesforceSettings options = new SalesforceSettings
            {
                ApiVersion = "",
                BaseUrl = "https://example.com",
                IntegrationBaseUrl = "https://integration.example.com"
            };

            // Act
            var result = _validator.Validate(name, options);

            // Assert
            Assert.False(result.Succeeded);
            Assert.Equal("Property 'ApiVersion' cannot be blank.", result.FailureMessage);
        }

        [Fact]
        public void Validate_ShouldFail_WhenBaseUrlIsBlank()
        {
            // Arrange
            string name = "SalesforceSettings";
            SalesforceSettings options = new SalesforceSettings
            {
                ApiVersion = "v1",
                BaseUrl = "",
                IntegrationBaseUrl = "https://integration.example.com"
            };

            // Act
            var result = _validator.Validate(name, options);

            // Assert
            Assert.False(result.Succeeded);
            Assert.Equal("Property 'BaseUrl' cannot be blank.", result.FailureMessage);
        }

        [Fact]
        public void Validate_ShouldFail_WhenIntegrationBaseUrlIsBlank()
        {
            // Arrange
            string name = "SalesforceSettings";
            SalesforceSettings options = new SalesforceSettings
            {
                ApiVersion = "v1",
                BaseUrl = "https://example.com",
                IntegrationBaseUrl = ""
            };

            // Act
            var result = _validator.Validate(name, options);

            // Assert
            Assert.False(result.Succeeded);
            Assert.Equal("Property 'IntegrationBaseUrl' cannot be blank.", result.FailureMessage);
        }

        [Fact]
        public void Validate_ShouldSucceed_WhenOptionsAreValid()
        {
            // Arrange
            string name = "SalesforceSettings";
            SalesforceSettings options = new SalesforceSettings
            {
                ApiVersion = "v1",
                BaseUrl = "https://example.com",
                IntegrationBaseUrl = "https://integration.example.com"
            };

            // Act
            var result = _validator.Validate(name, options);

            // Assert
            Assert.True(result.Succeeded);
        }
    }
}
