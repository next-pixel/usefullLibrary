﻿using Cloud.Services.Account.Common.Settings.Validators;
using Cloud.Services.Account.Common.Settings;

namespace Cloud.Service.Account.Common.Tests.Settings
{
    public class SalesforceAuthSettingsValidatorTests
    {
        private readonly SalesforceAuthSettingsValidator _validator;

        public SalesforceAuthSettingsValidatorTests()
        {
            _validator = new SalesforceAuthSettingsValidator();
        }

        [Fact]
        public void Validate_ShouldFail_WhenOptionsIsNull()
        {
            // Arrange
            string name = "test";
            SalesforceAuthSettings? options = null;

            // Act
            var result = _validator.Validate(name, options!);

            // Assert
            Assert.False(result.Succeeded);
            Assert.Equal("Configuration object is null.", result.FailureMessage);
        }

        [Theory]
        [InlineData(null)]
        [InlineData("")]
        [InlineData(" ")]
        public void Validate_ShouldFail_WhenBaseUrlIsNullOrWhitespace(string baseUrl)
        {
            // Arrange
            string name = "test";
            var options = new SalesforceAuthSettings
            {
                BaseUrl = baseUrl,
                ClientId = "clientId",
                Username = "username",
                CertificateName = "certificateName",
                CertificateKeyvaultBaseUrl = "certificateKeyvaultBaseUrl"
            };

            // Act
            var result = _validator.Validate(name, options);

            // Assert
            Assert.False(result.Succeeded);
            Assert.Equal("Property 'BaseUrl' cannot be blank.", result.FailureMessage);
        }

        [Theory]
        [InlineData(null)]
        [InlineData("")]
        [InlineData(" ")]
        public void Validate_ShouldFail_WhenClientIdIsNullOrWhitespace(string clientId)
        {
            // Arrange
            string name = "test";
            var options = new SalesforceAuthSettings
            {
                BaseUrl = "baseUrl",
                ClientId = clientId,
                Username = "username",
                CertificateName = "certificateName",
                CertificateKeyvaultBaseUrl = "certificateKeyvaultBaseUrl"
            };

            // Act
            var result = _validator.Validate(name, options);

            // Assert
            Assert.False(result.Succeeded);
            Assert.Equal("Property 'ClientId' cannot be blank.", result.FailureMessage);
        }

        [Theory]
        [InlineData(null)]
        [InlineData("")]
        [InlineData(" ")]
        public void Validate_ShouldFail_WhenUsernameIsNullOrWhitespace(string username)
        {
            // Arrange
            string name = "test";
            var options = new SalesforceAuthSettings
            {
                BaseUrl = "baseUrl",
                ClientId = "clientId",
                Username = username,
                CertificateName = "certificateName",
                CertificateKeyvaultBaseUrl = "certificateKeyvaultBaseUrl"

            };

            // Act
            var result = _validator.Validate(name, options);

            // Assert
            Assert.False(result.Succeeded);
            Assert.Equal("Property 'Username' cannot be blank.", result.FailureMessage);
        }

        [Theory]
        [InlineData(null)]
        [InlineData("")]
        [InlineData(" ")]
        public void Validate_ShouldFail_WhenCertificateNameIsNullOrWhitespace(string certificateName)
        {
            // Arrange
            string name = "test";
            var options = new SalesforceAuthSettings
            {
                BaseUrl = "baseUrl",
                ClientId = "clientId",
                Username = "username",
                CertificateName = certificateName,
                CertificateKeyvaultBaseUrl = "certificateKeyvaultBaseUrl"
            };

            // Act
            var result = _validator.Validate(name, options);

            // Assert
            Assert.False(result.Succeeded);
            Assert.Equal("Property 'CertificateName' cannot be blank.", result.FailureMessage);
        }

        [Theory]
        [InlineData(null)]
        [InlineData("")]
        [InlineData(" ")]
        public void Validate_ShouldFail_WhenCertificateKeyvaultBaseUrlIsNullOrWhitespace(string keyvaultBaseUrl)
        {
            // Arrange
            string name = "test";
            var options = new SalesforceAuthSettings
            {
                BaseUrl = "baseUrl",
                ClientId = "clientId",
                Username = "username",
                CertificateName = "CertificateName",
                CertificateKeyvaultBaseUrl = keyvaultBaseUrl
            };

            // Act
            var result = _validator.Validate(name, options);

            // Assert
            Assert.False(result.Succeeded);
            Assert.Equal("Property 'CertificateKeyvaultBaseUrl' cannot be blank.", result.FailureMessage);
        }

        [Fact]
        public void Validate_ShouldSucceed_WhenOptionsAreValid()
        {
            // Arrange
            string name = "test";
            var options = new SalesforceAuthSettings
            {
                BaseUrl = "baseUrl",
                ClientId = "clientId",
                Username = "username",
                CertificateName = "certificateName",
                CertificateKeyvaultBaseUrl = "certificateKeyvaultBaseUrl"
            };

            // Act
            var result = _validator.Validate(name, options);

            // Assert
            Assert.True(result.Succeeded);
        }
    }
}
