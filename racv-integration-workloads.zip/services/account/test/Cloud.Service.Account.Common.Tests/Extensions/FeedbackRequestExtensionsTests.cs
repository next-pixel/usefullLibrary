﻿using Cloud.Services.Account.Common.Extensions;
using Cloud.Services.Account.Common.Models.Request;
using Cloud.Services.Account.Common.Models.Salesforce.SObjects;
using FluentAssertions;
using System.Text;

namespace Cloud.Service.Account.Common.Tests.Extensions
{
    public class FeedbackRequestExtensionsTests
    {
        [Fact]
        public void Convert_ShouldReturnFeedbackWithCorrectProperties()
        {
            // Arrange
            var feedbackRequest = new FeedbackRequest
            {
                Description = "Test feedback",
                Rating = 5,
                userId = "testUser"
            };

            // Act
            var result = feedbackRequest.Convert();

            // Assert
            result.Should().NotBeNull();
            result.Should().BeOfType<Feedback>();
            result.Comments.Should().Be(feedbackRequest.Description);
            result.Rating.Should().Be(feedbackRequest.Rating);
            result.UserId.Should().Be(feedbackRequest.userId);
        }
    }
}
