﻿using Cloud.Services.Common.Azure.Cosmos.Interfaces;
using Cloud.Services.Common.Exceptions;
using Cloud.Services.Common.Models;
using Cloud.Services.EV.Api.Controllers;
using Cloud.Services.EV.Api.Tests.Infrastructure.TestDataHelper;
using Cloud.Services.EV.Common.Settings;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using CosmosDb = Cloud.Services.EV.Common.Models.Connectors.CosmosDb;
using Response = Cloud.Services.EV.Api.Models.Response;

namespace Cloud.Services.EV.Api.Tests
{
    public class ControllerTests
    {
        private readonly ChargerLocationsController _controller;
        private readonly Mock<ILogger<ChargerLocationsController>> _loggerMock;
        private readonly Mock<ICosmosDBService> _locationsCosmosDbServiceMock;
        private readonly Mock<ICosmosDBService> _tariffsCosmosDbServiceMock;
        private readonly Mock<IOptions<EVSettings>> _evSettingsMock;
    

        public ControllerTests()
        {
            var evSettings = new EVSettings()
            {
                LocationsContainerId = "TestLocationsContainer",
                TariffsContainerId = "TestTariffsContainer",
                MemberDiscounts = new Dictionary<string, MemberDiscounts>
                {
                    { "TestDiscount", new MemberDiscounts { DiscountValue = 10, DiscountType = "Percent" } }
                }
            };

            _locationsCosmosDbServiceMock = new Mock<ICosmosDBService>();
            _evSettingsMock = new Mock<IOptions<EVSettings>>();
            _tariffsCosmosDbServiceMock = new Mock<ICosmosDBService>();
            _loggerMock = new Mock<ILogger<ChargerLocationsController>>();

            _evSettingsMock.Setup(s => s.Value).Returns(evSettings);

            _controller = new ChargerLocationsController(
                _loggerMock.Object,
                _evSettingsMock.Object,
                _locationsCosmosDbServiceMock.Object,
                _tariffsCosmosDbServiceMock.Object);
        }
    

        [Fact]
        public async Task GetChargerLocations_WithoutWatermark_ShouldReturnFullSyncResponse()
        {
            // Arrange
            var correlationId = Guid.NewGuid();
            var locations = ChargerLocationsHelper.GenerateChargerLocations();
            var tariffs = ChargerTariffsHelper.GenerateChargerTariffs();

            _locationsCosmosDbServiceMock.Setup(c => c.GetItemsQueryable<CosmosDb.ChargerLocation>(It.IsAny<QueryDefinition>()))
                .ReturnsAsync(locations);
            _tariffsCosmosDbServiceMock.Setup(c => c.GetItemsQueryable<CosmosDb.ChargerTariff>(It.IsAny<QueryDefinition>()))
                .ReturnsAsync(tariffs);

            var expectedResponseLocations = ChargerLocationsResponseHelper.GenerateChargerLocationsResponse();

            // Act
            var result = await _controller.GetChargerLocations(correlationId);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = (OkObjectResult)result;
            okResult.StatusCode.Should().Be(StatusCodes.Status200OK);
            okResult.Value.Should().BeOfType<OperationSuccessResponse>();

            var response = (OperationSuccessResponse?)okResult.Value;
            response?.Data.Should().NotBeNull();
            var actualResponseLocations = (List<Response.ChargerLocation>?)response?.Data;

            actualResponseLocations.Should().BeEquivalentTo(expectedResponseLocations);

        }

        [Fact]
        public async Task GetChargerLocations_WithWatermark_ShouldReturnResponse()
        {
            // Arrange
            var correlationId = Guid.NewGuid();
            var watermark = 123;
            var locations = ChargerLocationsHelper.GenerateChargerLocations();
            var tariffs = ChargerTariffsHelper.GenerateChargerTariffs();

            var expectedResponseLocations = ChargerLocationsResponseHelper.GenerateChargerLocationsResponse();

            _locationsCosmosDbServiceMock.Setup(c => c.GetItemsQueryable<CosmosDb.ChargerLocation>(It.IsAny<QueryDefinition>()))
                .ReturnsAsync(locations);
            _tariffsCosmosDbServiceMock.Setup(c => c.GetItemsQueryable<CosmosDb.ChargerTariff>(It.IsAny<QueryDefinition>()))
                .ReturnsAsync(tariffs);

            // Act
            var result = await _controller.GetChargerLocations(correlationId, watermark);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = (OkObjectResult)result;
            okResult.StatusCode.Should().Be(StatusCodes.Status200OK);
            okResult.Value.Should().BeOfType<OperationSuccessResponse>();

            var response = (OperationSuccessResponse?)okResult.Value;
            response?.Data.Should().NotBeNull();
            var actualResponseLocations = (List<Response.ChargerLocation>?)response?.Data;
            actualResponseLocations.Should().NotBeNull();
            actualResponseLocations.Should().BeEquivalentTo(expectedResponseLocations);
        }

        [Fact]
        public async Task GetChargerLocations_ExceptionThrown_ShouldReturnInternalServerError()
        {
            // Arrange
            var correlationId = Guid.NewGuid();
            var locations = ChargerLocationsHelper.GenerateChargerLocations();
            var exceptionMessage = "Error occurred while retrieving charger locations.";

            var expectedFailureResponse = new OperationFailureResponse(exceptionMessage, null, correlationId.ToString());

            _locationsCosmosDbServiceMock.Setup(c => c.GetItemsQueryable<CosmosDb.ChargerLocation>(It.IsAny<QueryDefinition>()))
                .ReturnsAsync(locations);
            _tariffsCosmosDbServiceMock.Setup(c => c.GetItemsQueryable<CosmosDb.ChargerTariff>(It.IsAny<QueryDefinition>()))
                .Throws(new Exception(exceptionMessage));

            // Act
            var result = await _controller.GetChargerLocations(correlationId);

            // Assert
            result.Should().BeOfType<ObjectResult>();
            var objectResult = (ObjectResult)result;
            objectResult.StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
            objectResult.Value.Should().BeOfType<OperationFailureResponse>();
            var actualFailureResponse = (OperationFailureResponse?)objectResult.Value;

            actualFailureResponse.Should().BeEquivalentTo(expectedFailureResponse,
                options => options.For(o => o.ErrorDetails).Exclude(o => o.Timestamp));
        }
    }
}
