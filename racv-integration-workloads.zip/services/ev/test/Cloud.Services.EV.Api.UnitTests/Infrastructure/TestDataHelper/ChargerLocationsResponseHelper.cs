﻿using Response = Cloud.Services.EV.Api.Models.Response;


namespace Cloud.Services.EV.Api.Tests.Infrastructure.TestDataHelper
{
    public static class ChargerLocationsResponseHelper
    {
        public static List<Response.ChargerLocation> GenerateChargerLocationsResponse()
        {
            return new List<Response.ChargerLocation>()
            {
                new Response.ChargerLocation
                {
                    Id = "123",
                    Name = "RACV sample charger location",
                    discountType = null,
                    discountValue = null,
                    Evses = new List<Response.EV>
                    {
                        new Response.EV
                        {
                            Connectors = new List<Response.Connector>
                            {
                                new Response.Connector
                                {
                                    PriceId = "tariffId",
                                    Price = new Response.Price
                                    {
                                        Elements = new List<Response.Element>
                                        {
                                            new Response.Element
                                            {
                                                PriceComponents = new List<Response.PriceComponent>
                                                {
                                                    new Response.PriceComponent
                                                    {
                                                        Type = "DummyType",
                                                        StepSize = 1
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    Location = new Response.Location
                    {
                        Latitude = 1,
                        Longitude = 1
                    }
                }
            };
        }

        public static List<Response.ChargerLocation> GenerateChargerLocationsMultipleTariffsResponse() =>
            new List<Response.ChargerLocation>()
            {
                    new Response.ChargerLocation
                    {
                        Id = "dbb20cdf-4104-4dc1-821a-c67a6b3eea15",
                        Name = "Charger 1",
                        Address = "123 Main St",
                        OpeningTimes = new Response.OpeningTimes { TwentyFourSeven = true },
                        City = "City 1",
                        Postcode = "12345",
                        State = "State 1",
                        Location = new Response.Location
                        {
                            Latitude = 40.7128f,
                            Longitude = -74.0060f
                        },
                        StationTimeZone = "UTC",
                        Directions = "Directions 1",
                        Operator = new Response.Operator { Name = "Operator 1", Url = "http://operator1.com" },
                        discountType = null,
                        discountValue = null,
                        Evses = new List<Response.EV>
                        {
                            new Response.EV
                            {
                                Connectors = new List<Response.Connector>
                                {
                                    new Response.Connector
                                    {
                                        Id = 1,
                                        Format = "CABLE",
                                        PriceId = "6ff196b6-c5c0-4910-9fce-36ff8538ee4f",
                                        Price = new Response.Price
                                        {
                                            Description = "Hello world",
                                            Elements = new List<Response.Element>
                                            {
                                                new Response.Element
                                                {
                                                    PriceComponents = new List<Response.PriceComponent>
                                                    {
                                                        new Response.PriceComponent
                                                        {
                                                            Price = 1234567f,
                                                            StepSize = 1,
                                                            Vat = 3
                                                        }
                                                    },
                                                    Restrictions = new Response.Restrictions
                                                    {
                                                        DayOfWeek = new List<string> { "MONDAY", "TUESDAY", "THURSDAY" }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            },
                            new Response.EV
                            {
                                Connectors = new List<Response.Connector>
                                {
                                    new Response.Connector
                                    {
                                        Id = 2,
                                        Format = "PLUG",
                                        PriceId = "e13e51f5-7d08-467a-b728-55a704f62629",
                                        Price = new Response.Price
                                        {
                                            Description = "Hello world",
                                            Elements = new List<Response.Element>
                                            {
                                                new Response.Element
                                                {
                                                    PriceComponents = new List<Response.PriceComponent>
                                                    {
                                                        new Response.PriceComponent
                                                        {
                                                            Price = 1234567f,
                                                            StepSize = 1,
                                                            Vat = 3
                                                        }
                                                    },
                                                    Restrictions = new Response.Restrictions
                                                    {
                                                        DayOfWeek = new List<string>{"WEDNESDAY"},

                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            },
                            new Response.EV
                            {
                                Connectors = new List<Response.Connector>
                                {
                                    new Response.Connector
                                    {
                                        Id = 3,
                                        Format = "PLUG",
                                        PriceId = "f9534ccc-ab8a-448e-b5f3-e4402c6dad6b",
                                        Price = new Response.Price
                                        {
                                            Description = "Hello world",
                                            Elements = new List<Response.Element>
                                            {
                                                new Response.Element
                                                {
                                                    PriceComponents = new List<Response.PriceComponent>
                                                    {
                                                        new Response.PriceComponent
                                                        {
                                                            Price = 1234567f,
                                                            StepSize = 1,
                                                            Vat = 3
                                                        }
                                                    },
                                                    Restrictions = new Response.Restrictions
                                                    {
                                                        DayOfWeek = new List<string>{"SATURDAY","SUNDAY"}
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
            };
    }
}
