﻿using System.Globalization;
using CosmosDb = Cloud.Services.EV.Common.Models.Connectors.CosmosDb;

namespace Cloud.Services.EV.Api.Tests.Infrastructure.TestDataHelper
{
    public static class ChargerTariffsHelper
    {
        public static List<CosmosDb.ChargerTariff> GenerateChargerTariffs() => new List<CosmosDb.ChargerTariff>()
        {
            new CosmosDb.ChargerTariff
            {
                Id = "tariffId",
                Elements= new List<CosmosDb.Element>
                {
                    new CosmosDb.Element
                    {
                        PriceComponents = new List<CosmosDb.PriceComponent>
                        {
                            new CosmosDb.PriceComponent
                            {
                                StepSize = 1,
                                Type = "DummyType"
                            }
                        }
                    }
                }
            }
        };

        internal static List<CosmosDb.ChargerTariff>? GenerateMultipleChargerTariffs() => new List<CosmosDb.ChargerTariff>
        {
            new CosmosDb.ChargerTariff
            {
                Id = "6ff196b6-c5c0-4910-9fce-36ff8538ee4f",
                CountryCode = "AU",
                PartyId = "CFX",
                Currency = "AUD",
                Type = "RandomType",
                StartDateTime = DateTime.Parse("2018-08-18T07:22:16.0000000Z", new CultureInfo("en-AU")),
                EndDateTime = DateTime.Parse("2018-08-18T07:22:16.0000000Z", new CultureInfo("en-AU")),
                EnergyMix = new CosmosDb.EnergyMix
                {
                    IsGreenEnergy = true
                },
                TariffAltText = new List<CosmosDb.TariffAltText>
                {
                    new CosmosDb.TariffAltText
                    {
                        Language = "en",
                        Text = "Hello world"
                    }
                },
                LastUpdated = DateTime.Parse("2018-08-18T07:22:16.0000000Z", new CultureInfo("en-AU")),
                Elements = new List<CosmosDb.Element>
                {
                    new CosmosDb.Element
                    {
                        PriceComponents = new List<CosmosDb.PriceComponent>
                        {
                            new CosmosDb.PriceComponent
                            {
                                Price = 1234567f,
                                StepSize = 1,
                                Vat = 3
                            }
                        },
                        Restrictions = new CosmosDb.Restrictions
                        {
                            DayOfWeek = new List<string> { "MONDAY", "TUESDAY", "THURSDAY" },
                        }
                    }
                }
            },
            new CosmosDb.ChargerTariff
            {
                Id = "e13e51f5-7d08-467a-b728-55a704f62629",
                CountryCode = "AU",
                PartyId = "CFX",
                Currency = "AUD",
                Type = "RandomType",
                StartDateTime = DateTime.Parse("2018-08-18T07:22:16.0000000Z", new CultureInfo("en-AU")),
                EndDateTime = DateTime.Parse("2018-08-18T07:22:16.0000000Z", new CultureInfo("en-AU")),
                EnergyMix = new CosmosDb.EnergyMix
                {
                    IsGreenEnergy = true
                },
                TariffAltText = new List<CosmosDb.TariffAltText>
                {
                    new CosmosDb.TariffAltText
                    {
                        Language = "en",
                        Text = "Hello world"
                    }
                },
                Elements = new List<CosmosDb.Element>
                {
                    new CosmosDb.Element
                    {
                        PriceComponents = new List<CosmosDb.PriceComponent>
                        {
                            new CosmosDb.PriceComponent
                            {
                                Price = 1234567f,
                                StepSize = 1,
                                Vat = 3
                            }
                        },
                        Restrictions = new CosmosDb.Restrictions
                        {
                            DayOfWeek = new List<string>{"WEDNESDAY"},

                        }
                    }
                }
            },
            new CosmosDb.ChargerTariff
            {
                Id = "f9534ccc-ab8a-448e-b5f3-e4402c6dad6b",
                CountryCode = "AU",
                PartyId = "CFX",
                Currency = "AUD",
                Type = "RandomType",
                StartDateTime = DateTime.Parse("2018-08-18T07:22:16.0000000Z", new CultureInfo("en-AU")),
                EndDateTime = DateTime.Parse("2018-08-18T07:22:16.0000000Z", new CultureInfo("en-AU")),
                EnergyMix = new CosmosDb.EnergyMix
                {
                    IsGreenEnergy = true
                },
                TariffAltText = new List<CosmosDb.TariffAltText>
                {
                    new CosmosDb.TariffAltText
                    {
                        Language = "en",
                        Text = "Hello world"
                    }
                },
                Elements = new List<CosmosDb.Element>
                {
                    new CosmosDb.Element
                    {
                        PriceComponents = new List<CosmosDb.PriceComponent>
                        {
                            new CosmosDb.PriceComponent
                            {
                                Price = 1234567f,
                                StepSize = 1,
                                Vat = 3
                            }
                        },
                        Restrictions = new CosmosDb.Restrictions
                        {
                            DayOfWeek = new List<string>{"SATURDAY","SUNDAY"},

                        }
                    }
                }
            }
        };
    }
}
