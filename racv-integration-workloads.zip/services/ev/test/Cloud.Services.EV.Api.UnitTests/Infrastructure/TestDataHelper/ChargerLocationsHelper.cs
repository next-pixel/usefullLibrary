﻿using CosmosDb = Cloud.Services.EV.Common.Models.Connectors.CosmosDb;


namespace Cloud.Services.EV.Api.Tests.Infrastructure.TestDataHelper
{
    public static class ChargerLocationsHelper
    {
        public static List<CosmosDb.ChargerLocation> GenerateChargerLocations() => new List<CosmosDb.ChargerLocation>()
            {
                new CosmosDb.ChargerLocation
                {
                    Id = "123",
                    Name = "RACV sample charger location",
                    EVses = new List<CosmosDb.EV>
                    {
                        new CosmosDb.EV
                        {
                            Connectors = new List<CosmosDb.Connector>
                            {
                                new CosmosDb.Connector
                                {
                                    TariffId = "tariffId"
                                }
                            }
                        }
                    },
                    Location = new CosmosDb.Location
                    {
                        Coordinates = [1,1]
                    }
                }
            };
        public static List<CosmosDb.ChargerLocation> GenerateUpdatedChargerLocations() => new List<CosmosDb.ChargerLocation>
            {
                new CosmosDb.ChargerLocation
                {
                    EVses = new List<CosmosDb.EV>
                    {
                        new CosmosDb.EV
                        {
                            Connectors = new List<CosmosDb.Connector>
                            {
                                new CosmosDb.Connector { TariffId = "tariff1" }
                            }
                        },
                        new CosmosDb.EV
                        {
                            Connectors = new List<CosmosDb.Connector>
                            {
                                new CosmosDb.Connector { TariffId = "tariff2" }
                            }
                        },
                        new CosmosDb.EV
                        {
                            Connectors = new List<CosmosDb.Connector>
                            {
                                new CosmosDb.Connector { TariffId = "tariff3" }
                            }
                        }
                    },
                }
            };
        public static List<CosmosDb.ChargerLocation> GenerateChargerLocationsMultipleTariffs() => new List<CosmosDb.ChargerLocation>
        {
            new CosmosDb.ChargerLocation
            {
                Id = "dbb20cdf-4104-4dc1-821a-c67a6b3eea15",
                Name = "Charger 1",
                Address = "123 Main St",
                OpeningTimes = new CosmosDb.OpeningTimes { TwentyFourSeven = true},
                City = "City 1",
                Postcode = "12345",
                State = "State 1",
                Location = new CosmosDb.Location
                {
                    Type = "Location Type",
                    Coordinates= new List<float>([40.7128f, -74.0060f])
                },
                StationTimeZone = "UTC",
                Directions = "Directions 1",
                Operator = new CosmosDb.Operator { Name = "Operator 1", Url = "http://operator1.com" },
                EVses = new List<CosmosDb.EV>
                {
                    new CosmosDb.EV
                    {
                        Connectors = new List<CosmosDb.Connector>
                        {
                            new CosmosDb.Connector
                            {
                                Id = 1,
                                Format = "CABLE",
                                TariffId = "6ff196b6-c5c0-4910-9fce-36ff8538ee4f"
                            }
                        }
                    },
                    new CosmosDb.EV
                    {
                        Connectors = new List<CosmosDb.Connector>
                        {
                            new CosmosDb.Connector
                            {
                                Id = 2,
                                Format = "PLUG",
                                TariffId = "e13e51f5-7d08-467a-b728-55a704f62629"
                            }
                        }
                    },
                    new CosmosDb.EV
                    {
                        Connectors = new List<CosmosDb.Connector>
                        {
                            new CosmosDb.Connector
                            {
                                Id = 3,
                                Format = "PLUG",
                                TariffId = "f9534ccc-ab8a-448e-b5f3-e4402c6dad6b"
                            }
                        }
                    }
                }
            }
        };
    }
}
