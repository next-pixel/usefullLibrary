﻿using Cloud.Services.EV.Api.Extensions;
using FluentAssertions;
using Microsoft.Azure.Cosmos;

namespace Cloud.Services.EV.Api.Tests.ExtensionsTests
{
    public class CosmosDbExtensionsTests
    {
        [Fact]
        public void ConstructFullSyncParameterizedQuery_ShouldReturnQueryDefinition()
        {
            // Act
            QueryDefinition query = CosmosDbExtensions.ConstructFullSyncParameterizedQuery();

            // Assert
            query.Should().NotBeNull();
            query.QueryText.Should().Be("SELECT * FROM c ORDER BY c._ts DESC");
        }

        [Theory]
        [InlineData(null)]
        [InlineData(123)]
        public void ConstructTariffsParameterizedQuery_ShouldReturnQueryDefinition(int? watermark)
        {
            // Act
            QueryDefinition query = watermark.ConstructTariffsParameterizedQuery();

            // Assert
            query.Should().NotBeNull();
            query.QueryText.Should().Be("SELECT * FROM c WHERE c._ts > @watermark ORDER BY c._ts DESC");
            query.GetQueryParameters().Should().HaveCount(1);
            query.GetQueryParameters().FirstOrDefault().Name.Should().BeEquivalentTo("@watermark");
            query.GetQueryParameters().FirstOrDefault().Value.Should().BeEquivalentTo(watermark);
        }

        [Theory]
        [InlineData(null, null)]
        [InlineData(123, new string[] { "tariffId1", "tariffId2" })]
        public void ConstructLocationParameterizedQuery_ShouldReturnQueryDefinition(int? watermark, string[] updatedTariffIds)
        {
            // Act
            QueryDefinition query = updatedTariffIds != null
                ? watermark.ConstructLocationParameterizedQuery(new List<string>(updatedTariffIds))
                : watermark.ConstructLocationParameterizedQuery(null);

            // Assert
            query.Should().NotBeNull();
            var actualParameters = query.GetQueryParameters();

            if (updatedTariffIds != null && updatedTariffIds.Length > 0)
            {
                query.QueryText.Should().Contain("SELECT DISTINCT VALUE c");
                query.QueryText.Should().Contain("JOIN e IN c.evses");
                query.QueryText.Should().Contain("ARRAY_CONTAINS(@updatedTariffIds, e.connectors[0].tariffId)");
                query.QueryText.Should().Contain("OR");
                query.QueryText.Should().Contain("c._ts > @watermark");

                actualParameters.Should().HaveCount(2);

                actualParameters[0].Name.Should().BeEquivalentTo("@updatedTariffIds");
                actualParameters[0].Value.Should().BeEquivalentTo(updatedTariffIds.ToArray());

                actualParameters[1].Name.Should().BeEquivalentTo("@watermark");
                actualParameters[1].Value.Should().BeEquivalentTo(watermark);
            }
            else
            {
                query.QueryText.Should().Be("SELECT * FROM c WHERE c._ts > @watermark ORDER BY c._ts DESC");
                actualParameters.Should().HaveCount(1);
                actualParameters[0].Name.Should().BeEquivalentTo("@watermark");
                actualParameters[0].Value.Should().BeEquivalentTo(watermark);
            }


        }

        [Fact]
        public void ConstructOldTariffsParametrizedQuery_ShouldReturnQueryDefinition()
        {
            // Arrange
            var oldTariffsIds = new HashSet<string> { "oldTariffId1", "oldTariffId2" };

            // Act
            QueryDefinition query = oldTariffsIds.ConstructOldTariffsParametrizedQuery();

            // Assert
            query.Should().NotBeNull();
            query.QueryText.Should().Be("SELECT * FROM c WHERE ARRAY_CONTAINS(@oldTariffsIds, c.id)");

            var actualParameters = query.GetQueryParameters();
            actualParameters.Should().HaveCount(1);
            actualParameters[0].Name.Should().BeEquivalentTo("@oldTariffsIds");
            actualParameters[0].Value.Should().BeEquivalentTo(oldTariffsIds.ToArray());
        }
    }
}
