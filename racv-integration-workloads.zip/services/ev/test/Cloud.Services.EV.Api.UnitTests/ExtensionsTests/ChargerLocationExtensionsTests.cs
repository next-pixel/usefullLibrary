﻿using Cloud.Services.EV.Api.Extensions;
using Cloud.Services.EV.Api.Tests.Infrastructure.TestDataHelper;
using FluentAssertions;
using CosmosDb = Cloud.Services.EV.Common.Models.Connectors.CosmosDb;
using Response = Cloud.Services.EV.Api.Models.Response;

namespace Cloud.Services.EV.Api.Tests.ExtensionsTests
{
    public class ChargerLocationExtensionsTests
    {
        [Fact]
        public void GetOldChargerTariffIds_ShouldReturnOldTariffIds()
        {
            // Arrange
            var cosmosDbChargerLocations = ChargerLocationsHelper.GenerateUpdatedChargerLocations();

            var updatedTariffIds = new List<string> { "tariff1", "tariff3" };

            // Act
            var result = cosmosDbChargerLocations.GetOldChargerTariffIds(updatedTariffIds);

            // Assert
            result.Should().HaveCount(1);
            result.Should().Contain("tariff2");
        }

        [Fact]
        public void ConstructChargerLocationsResponse_WithValidInput_ShouldReturnExpectedResult()
        {
            // Arrange
            var cosmosDbChargerLocations = ChargerLocationsHelper.GenerateChargerLocationsMultipleTariffs();
            var cosmosDbChargerTariffs = ChargerTariffsHelper.GenerateMultipleChargerTariffs();
            var actualChargerLocationsResponse = ChargerLocationsResponseHelper.GenerateChargerLocationsMultipleTariffsResponse();
            var evSettings = new Common.Settings.EVSettings
            {
                LocationsContainerId = "TestLocationsContainer",
                TariffsContainerId = "TestTariffsContainer",
                MemberDiscounts = new Dictionary<string, Common.Settings.MemberDiscounts>
                {
                    { "TestDiscount", new Common.Settings.MemberDiscounts { DiscountValue = 1, DiscountType = "Percent" } }
                }
            };
            
            
            // Act
            var result = cosmosDbChargerLocations.ConstructChargerLocationsResponse(
                cosmosDbChargerTariffs, evSettings);

            // Assert
            result.Should().NotBeNull();
            result.Should().HaveCount(1);
            result.Should().BeEquivalentTo(actualChargerLocationsResponse);
        }

        [Fact]

        public void ConstructChargerLocationsResponse_WithNullInput_ShouldReturnNull()
        {
            // Arrange
            List<CosmosDb.ChargerLocation>? cosmosDbChargerLocations = null;
            List<CosmosDb.ChargerTariff>? cosmosDbChargerTariffs = null;
            var evSettings = new Common.Settings.EVSettings
            {
                LocationsContainerId = "TestLocationsContainer",
                TariffsContainerId = "TestTariffsContainer",
                MemberDiscounts = new Dictionary<string, Common.Settings.MemberDiscounts>
                {
                    { "TestDiscount", new Common.Settings.MemberDiscounts { DiscountValue = 1, DiscountType = "Percent" } }
                }
            };
            // Act
            var result = cosmosDbChargerLocations!.ConstructChargerLocationsResponse(cosmosDbChargerTariffs,
                evSettings);

            // Assert
            result.Should().BeNull();
        }
    }
}
