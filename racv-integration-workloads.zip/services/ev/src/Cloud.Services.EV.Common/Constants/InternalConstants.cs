﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cloud.Services.EV.Common.Constants
{
    /// <summary>
    /// Contains constants used internally within the EV service.
    /// </summary>
    public static class InternalConstants
    {
        /// <summary>
        /// Represents the key to register and access Locations Cosmos DB service.
        /// </summary>
        public const string LocationsCosmosDbServiceKey = "LocationsCosmosDbService";

        /// <summary>
        /// Represents the key to register and access Tariffs Cosmos DB service.
        /// </summary>
        public const string TariffsCosmosDbServiceKey = "TariffsCosmosDbService";
    }
}
