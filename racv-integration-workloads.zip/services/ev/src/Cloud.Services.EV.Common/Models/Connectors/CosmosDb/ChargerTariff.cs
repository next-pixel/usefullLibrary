﻿using Newtonsoft.Json;

namespace Cloud.Services.EV.Common.Models.Connectors.CosmosDb
{
    public class ChargerTariff
    {
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }

        [JsonProperty(PropertyName = "countryCode")]
        public string? CountryCode { get; set; }

        [JsonProperty(PropertyName = "partyId")]
        public string? PartyId { get; set; }

        [JsonProperty(PropertyName = "currency")]
        public string? Currency { get; set; }

        [JsonProperty(PropertyName = "type")]
        public string? Type { get; set; }

        [JsonProperty(PropertyName = "tariffAltText")]
        public List<TariffAltText>? TariffAltText { get; set; }

        [JsonProperty(PropertyName = "elements")]
        public List<Element>? Elements { get; set; }

        [JsonProperty(PropertyName = "startDateTime")]
        public DateTime? StartDateTime { get; set; }

        [JsonProperty(PropertyName = "endDateTime")]
        public DateTime? EndDateTime { get; set; }

        [JsonProperty(PropertyName = "energyMix")]
        public EnergyMix? EnergyMix { get; set; }

        [JsonProperty(PropertyName = "lastUpdated")]
        public DateTime LastUpdated { get; set; }
    }

    public class EnergyMix
    {
        [JsonProperty(PropertyName = "isGreenEnergy")]
        public bool IsGreenEnergy { get; set; }
    }

    public class TariffAltText
    {
        [JsonProperty(PropertyName = "language")]
        public string? Language { get; set; }

        [JsonProperty(PropertyName = "text")]
        public string? Text { get; set; }
    }

    public class Element
    {
        [JsonProperty(PropertyName = "priceComponents")]
        public List<PriceComponent>? PriceComponents { get; set; }

        [JsonProperty(PropertyName = "restrictions")]
        public Restrictions? Restrictions { get; set; }
    }

    public class PriceComponent
    {
        [JsonProperty(PropertyName = "type")]
        public string? Type { get; set; }

        [JsonProperty(PropertyName = "price")]
        public float Price { get; set; }

        [JsonProperty(PropertyName = "pricePerStep")]
        public float PricePerStep { get; set; }

        [JsonProperty(PropertyName = "pricePerStepIncVat")]
        public float PricePerStepIncVat { get; set; }

        [JsonProperty(PropertyName = "stepSize")]
        public int StepSize { get; set; }

        [JsonProperty(PropertyName = "vat")]
        public float Vat { get; set; }
    }
    public class Restrictions
    {
        [JsonProperty(PropertyName = "maxDuration")]
        public int? MaxDuration { get; set; }

        [JsonProperty(PropertyName = "startTime")]
        public string? StartTime { get; set; }
        
        [JsonProperty(PropertyName = "endTime")]
        public string? EndTime { get; set; }
        
        [JsonProperty(PropertyName = "dayOfWeek")]
        public List<string>? DayOfWeek { get; set; }
    }
}
