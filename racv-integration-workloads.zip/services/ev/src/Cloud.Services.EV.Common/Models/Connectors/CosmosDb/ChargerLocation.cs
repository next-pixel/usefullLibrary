﻿using Newtonsoft.Json;

namespace Cloud.Services.EV.Common.Models.Connectors.CosmosDb
{
    public class ChargerLocation
    {
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }

        [JsonProperty(PropertyName = "name")]
        public string? Name { get; set; }

        [JsonProperty(PropertyName = "address")]
        public string? Address { get; set; }

        [JsonProperty(PropertyName = "openingTimes")]
        public OpeningTimes? OpeningTimes { get; set; }

        [JsonProperty(PropertyName = "city")]
        public string? City { get; set; }

        [JsonProperty(PropertyName = "postcode")]
        public string? Postcode { get; set; }

        [JsonProperty(PropertyName = "state")]
        public string? State { get; set; }

        [JsonProperty(PropertyName = "location")]
        public Location? Location { get; set; }

        [JsonProperty(PropertyName = "stationTimeZone")]
        public string? StationTimeZone { get; set; }

        [JsonProperty(PropertyName = "directions")]
        public string? Directions { get; set; }

        [JsonProperty(PropertyName = "operator")]
        public Operator? Operator { get; set; }

        [JsonProperty(PropertyName = "evses")]
        public List<EV>? EVses { get; set; }

        [JsonProperty(PropertyName = "lastUpdated")]
        public DateTime? LastUpdated { get; set; }
    }

    public class OpeningTimes
    {
        [JsonProperty(PropertyName = "twentyfourseven")]
        public bool TwentyFourSeven { get; set; }

        [JsonProperty(PropertyName = "regularHours")]
        public List<RegularHours>? RegularHours { get; set; }
    }

    public class RegularHours
    {
        [JsonProperty(PropertyName = "weekday")]
        public int Weekday { get; set; }

        [JsonProperty(PropertyName = "periodBegin")]
        public string? PeriodBegin { get; set; }

        [JsonProperty(PropertyName = "periodEnd")]
        public string? PeriodEnd { get; set; }
    }

    public class Location
    {
        [JsonProperty(PropertyName = "type")]
        public string? Type { get; set; }

        [JsonProperty(PropertyName = "coordinates")]
        public List<float>? Coordinates { get; set; }
    }

    public class Operator
    {
        [JsonProperty(PropertyName = "Name")]
        public string? Name { get; set; }

        [JsonProperty(PropertyName = "url")]
        public string? Url { get; set; }
    }

    public class EV
    {
        [JsonProperty(PropertyName = "id")]
        public string? Id { get; set; }

        [JsonProperty(PropertyName = "name")]
        public string? Name { get; set; }

        [JsonProperty(PropertyName = "status")]
        public string? Status { get; set; }

        [JsonProperty(PropertyName = "connectors")]
        public List<Connector>? Connectors { get; set; }
    }

    public class Connector
    {
        [JsonProperty(PropertyName = "id")]
        public int Id { get; set; }

        [JsonProperty(PropertyName = "standard")]
        public string? Standard { get; set; }

        [JsonProperty(PropertyName = "format")]
        public string? Format { get; set; }

        [JsonProperty(PropertyName = "maxElectricPower")]
        public int MaxElectricPower { get; set; }
        
        [JsonProperty(PropertyName = "tariffId")]
        public string? TariffId { get; set; }

    }
}