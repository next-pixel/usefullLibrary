﻿namespace Cloud.Services.EV.Common.Settings
{
    public class EVSettings
    {
        public const string ConfigurationSectionName = "EVSettings";
        public string LocationsContainerId { get; set; } = "EVChargersLocations";
        public string TariffsContainerId { get; set; } = "EVChargersTariffs";
        public Dictionary<string, MemberDiscounts> MemberDiscounts { get; set; }
    }

}