﻿namespace Cloud.Services.EV.Common.Settings
{
    public class MemberDiscounts
    {
        public const string ConfigurationSectionName = "MemberDiscounts";

        public int DiscountValue { get; set; }
        public string DiscountType { get; set; }
    }

}
