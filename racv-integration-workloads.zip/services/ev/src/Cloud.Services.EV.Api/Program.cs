using Azure.Identity;
using Cloud.Services.Common.Azure.Cosmos.Implementations;
using Cloud.Services.Common.Azure.Cosmos.Interfaces;
using Cloud.Services.Common.Azure.Cosmos.Settings;
using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Startup;
using Cloud.Services.EV.Common.Constants;
using Cloud.Services.EV.Common.Settings;
using Microsoft.Azure.Cosmos;

namespace Cloud.Services.EV;
internal class Program
{
    private Program() { }

    private static void Main(string[] args)
    {
        // Create the web application builder.
        var builder = WebApplication.CreateBuilder(args);

        // Add services.
        ConfigureServices(builder);

        // Build the app
        var app = builder.Build();

        // Configure app
        ApiBaseStartup.Configure(app, app.Environment, builder.Logging);

        // Map controllers
        app.MapControllers();

        // Configure the HTTP request pipeline.
        app.Run();
    }

    public static void ConfigureServices(WebApplicationBuilder builder)
    {
        // Add common services
        ApiBaseStartup.ConfigureServices<Program>(builder);

       // Bind EVSettings
            var evSettings = new EVSettings();
            builder.Configuration.Bind(EVSettings.ConfigurationSectionName, evSettings);

            // Add EVSettings to the service collection
            builder.Services.Configure<EVSettings>(
                builder.Configuration.GetSection(EVSettings.ConfigurationSectionName));

        // EV Settings
        builder.Configuration.Bind(
            EVSettings.ConfigurationSectionName,
            evSettings);

        // Cosmos settings
        var CosmosSettings = new CosmosDbBaseSettings();
        builder.Configuration.Bind(
            CosmosDbBaseSettings.ConfigurationSectionName,
            CosmosSettings);

        var cosmosClient = new CosmosClient(
            CosmosSettings.Endpoint,
#if DEBUG
            new AzureCliCredential(),
#else
            new ManagedIdentityCredential(builder.Configuration[ServicesConstants.AzureClientId]),
#endif
        new CosmosClientOptions()
        {
            ConnectionMode = ConnectionMode.Gateway,
            SerializerOptions = new CosmosSerializationOptions()
            {
                PropertyNamingPolicy = CosmosPropertyNamingPolicy.CamelCase,
            }
        });
        var locationsContainer = cosmosClient.GetContainer(CosmosSettings.DatabaseId, evSettings.LocationsContainerId);
        var tariffsContainer = cosmosClient.GetContainer(CosmosSettings.DatabaseId, evSettings.TariffsContainerId);

        // Locations cosmosDb Service
        builder.Services.AddKeyedSingleton<ICosmosDBService>(
            InternalConstants.LocationsCosmosDbServiceKey, new CosmosDBService(locationsContainer));

        // Tariffs cosmosDb Service
        builder.Services.AddKeyedSingleton<ICosmosDBService>(
            InternalConstants.TariffsCosmosDbServiceKey, new CosmosDBService(tariffsContainer));
    }
}
