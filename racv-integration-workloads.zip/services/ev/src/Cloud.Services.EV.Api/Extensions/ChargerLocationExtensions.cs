﻿using Cloud.Services.EV.Common.Settings;
using CosmosDb = Cloud.Services.EV.Common.Models.Connectors.CosmosDb;
using Response = Cloud.Services.EV.Api.Models.Response;

namespace Cloud.Services.EV.Api.Extensions
{
    public static class ChargerLocationExtensions
    {
        public static List<CosmosDb.ChargerTariff>? ChargerTariffs { get; private set; }

        public static HashSet<string> GetOldChargerTariffIds(
            this List<CosmosDb.ChargerLocation> cosmosDbChargerLocations,
            List<string>? updatedTariffIds)
        {
            var oldTariffsIds = new HashSet<string>();
            cosmosDbChargerLocations.ForEach(chargerLocation =>
            {
                chargerLocation.EVses?.ForEach(ev =>
                {
                    var tariffId = ev.Connectors?.FirstOrDefault()?.TariffId;
                    if (tariffId != null && updatedTariffIds != null && !updatedTariffIds.Contains(tariffId))
                    {
                        oldTariffsIds.Add(tariffId);
                    }
                });
            });
            return oldTariffsIds;
        }

        /// <summary>
        /// Extension to map <see cref="CosmosDb.ChargerLocation"/> to <see cref="Response.ChargerLocation"/> API response
        /// </summary>
        /// <param name="cosmosDbChargerLocations"></param>
        /// <returns></returns>
        public static List<Response.ChargerLocation>? ConstructChargerLocationsResponse(
            this List<CosmosDb.ChargerLocation> cosmosDbChargerLocations,
            List<CosmosDb.ChargerTariff>? cosmosDbChargerTariffs,
            EVSettings eVSettings)
        {
            if (cosmosDbChargerLocations != null)
            {
                ChargerTariffs = cosmosDbChargerTariffs;
                return cosmosDbChargerLocations.Select(chargerLocation =>
                {
                    var location = new Response.ChargerLocation
                    {
                        Id = chargerLocation.Id,
                        Name = chargerLocation.Name,
                        Address = chargerLocation.Address,
                        OpeningTimes = chargerLocation.OpeningTimes?.MapOpeningTimes(),
                        City = chargerLocation.City,
                        Postcode = chargerLocation.Postcode,
                        State = chargerLocation.State,
                        Location = new Response.Location
                        {
                            Latitude = chargerLocation.Location.Coordinates[0],
                            Longitude = chargerLocation.Location.Coordinates[1]
                        },
                        StationTimeZone = chargerLocation.StationTimeZone,
                        Directions = chargerLocation.Directions,
                        Operator = chargerLocation.Operator?.MapOperator(),
                        Evses = chargerLocation.EVses?.Select(ev => ev.MapEV()).ToList(),
                        LastUpdated = chargerLocation.LastUpdated,
                    };

                    if (location.Name != null && eVSettings.MemberDiscounts.ContainsKey(location.Name))
                    {
                        location.discountType = eVSettings.MemberDiscounts[location.Name].DiscountType;
                        location.discountValue  =eVSettings.MemberDiscounts[location.Name].DiscountValue;
                    }
                    return location;

                }).ToList();
            }
            return null;
        }

        /// <summary>
        /// Extension to map <see cref="CosmosDb.OpeningTimes"/> to <see cref="Response.OpeningTimes"/> API response
        /// </summary>
        /// <param name="openingTimes"></param>
        /// <returns></returns>
        private static Response.OpeningTimes MapOpeningTimes(this CosmosDb.OpeningTimes openingTimes)
        {
            return new()
            {
                TwentyFourSeven = openingTimes.TwentyFourSeven,
                RegularHours = openingTimes.RegularHours?.Select(regularHour => new Response.RegularHours()
                {
                    Weekday = regularHour.Weekday,
                    PeriodBegin = regularHour.PeriodBegin,
                    PeriodEnd = regularHour.PeriodEnd
                }).ToList()
            };
        }

        /// <summary>
        /// Extension to map <see cref="CosmosDb.Operator"/> to <see cref="Response.Operator"/> API response
        /// </summary>
        /// <param name="chargerOperator"></param>
        /// <returns></returns>
        private static Response.Operator MapOperator(this CosmosDb.Operator chargerOperator)
        {
            return new Response.Operator
            {
                Name = chargerOperator.Name,
                Url = chargerOperator.Url
            };
        }

        /// <summary>
        /// Extension to map <see cref="CosmosDb.EV"/> to <see cref="Response.EV"/> API response
        /// </summary>
        /// <param name="ev"></param>
        /// <returns></returns>
        private static Response.EV MapEV(this CosmosDb.EV ev) => new()
        {
            Id = ev.Id,
            Name = ev.Name,
            Status = ev.Status,
            Connectors = ev.Connectors?.Select(connector => connector.MapConnector()).ToList()
        };

        /// <summary>
        /// Extension to map <see cref="CosmosDb.Connector"/> to <see cref="Response.Connector"/> API response
        /// </summary>
        /// <param name="connector"></param>
        /// <returns></returns>
        private static Response.Connector MapConnector(this CosmosDb.Connector connector) => new()
        {
            Id = connector.Id,
            Standard = connector.Standard,
            Format = connector.Format,
            MaxElectricPower = connector.MaxElectricPower,
            PriceId = connector.TariffId,
            Price = connector.TariffId?.MapPrice(),

        };

        /// <summary>
        /// Extension to map <see cref="CosmosDb.Element"/> to <see cref="Response.Element"/> API response
        /// </summary>
        /// <param name="tariffId"></param>
        /// <returns></returns>
        private static Response.Price? MapPrice(this string tariffId)
        {
            var tariff = ChargerTariffs?.Find(tariff => tariff.Id == tariffId);
            if (tariff != null)
                return new Response.Price()
                {
                    Description = tariff.TariffAltText?.FirstOrDefault()?.Text,
                    Elements = tariff.Elements?.Select(element => element.MapElements()).ToList(),
                };
            return null;
        }

        /// <summary>
        /// Extension to map <see cref="CosmosDb.Element"/> to <see cref="Response.Element"/> API response
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        private static Response.Element MapElements(this CosmosDb.Element element) => new()
        {
            PriceComponents = element.PriceComponents?.Select(priceComponent => priceComponent.MapPriceComponent()).ToList(),
            Restrictions = (element.Restrictions != null) ? new Response.Restrictions()
            {
                MaxDuration = element.Restrictions.MaxDuration,
                DayOfWeek = element.Restrictions.DayOfWeek,
                EndTime = element.Restrictions.EndTime,
                StartTime = element.Restrictions.StartTime
            } : null
        };

        /// <summary>
        /// Extension to map <see cref="CosmosDb.PriceComponent"/> to <see cref="Response.PriceComponent"/> API response
        /// </summary>
        /// <param name="priceComponent"></param>
        /// <returns></returns>
        private static Response.PriceComponent MapPriceComponent(this CosmosDb.PriceComponent priceComponent) => new()
        {
            Price = priceComponent.Price,
            StepSize = priceComponent.StepSize,
            Type = priceComponent.Type,
            PricePerStep = priceComponent.PricePerStep,
            PricePerStepIncVat = priceComponent.PricePerStepIncVat,
            Vat = priceComponent.Vat
        };
    }
}
