﻿using Microsoft.Azure.Cosmos;
using Microsoft.IdentityModel.Tokens;

namespace Cloud.Services.EV.Api.Extensions
{
    public static class CosmosDbExtensions
    {
        public static QueryDefinition ConstructFullSyncParameterizedQuery()
        {
            QueryDefinition parameterizedQuery;
            parameterizedQuery = new QueryDefinition(
                query: "SELECT * FROM c ORDER BY c._ts DESC");
            return parameterizedQuery;
        }

        public static QueryDefinition ConstructTariffsParameterizedQuery(this int? watermark)
        {
            QueryDefinition parameterizedQuery;
            parameterizedQuery = new QueryDefinition(
                query: "SELECT * FROM c WHERE c._ts > @watermark ORDER BY c._ts DESC")
                .WithParameter("@watermark", watermark);
            return parameterizedQuery;
        }

        public static QueryDefinition ConstructLocationParameterizedQuery(this int? watermark, List<string>? updatedTariffIds)
        {
            if (!updatedTariffIds.IsNullOrEmpty())
            {
                var queryText = "SELECT DISTINCT VALUE c " +
                    "FROM c " +
                    "JOIN e IN c.evses " +
                    "WHERE ARRAY_CONTAINS(@updatedTariffIds, e.connectors[0].tariffId) " +
                    "OR " +
                    "c._ts > @watermark";

                return new QueryDefinition(queryText)
                    .WithParameter("@updatedTariffIds", updatedTariffIds!.ToArray())
                    .WithParameter("@watermark", watermark);
            }
            else
                return new QueryDefinition(query: "SELECT * FROM c WHERE c._ts > @watermark ORDER BY c._ts DESC")
                    .WithParameter("@watermark", watermark);
        }

        public static QueryDefinition ConstructOldTariffsParametrizedQuery(this HashSet<string> oldTariffsIds)
        {
            var queryText = "SELECT * FROM c WHERE ARRAY_CONTAINS(@oldTariffsIds, c.id)";

            return new QueryDefinition(queryText)
                .WithParameter("@oldTariffsIds", oldTariffsIds.ToArray());
        }
    }
}
