﻿namespace Cloud.Services.EV.Api.Models.Response
{
    public class ChargerLocation
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Address { get; set; }
        public OpeningTimes? OpeningTimes { get; set; }
        public string? City { get; set; }
        public string? Postcode { get; set; }
        public string? State { get; set; }
        public Location? Location { get; set; }
        public string? StationTimeZone { get; set; }
        public string? Directions { get; set; }
        public Operator? Operator { get; set; }
        public List<EV>? Evses { get; set; }
        public float? discountValue { get; set; }
        public string? discountType { get; set; }
        public DateTime? LastUpdated { get; set; }
    }

    public class OpeningTimes
    {
        public bool TwentyFourSeven { get; set; }
        public List<RegularHours>? RegularHours { get; set; }
    }

    public class RegularHours
    {
        public int Weekday { get; set; }
        public string? PeriodBegin { get; set; }
        public string? PeriodEnd { get; set; }
    }

    public class Location
    {
        public float Latitude { get; set; }
        public float Longitude { get; set; }
    }

    public class Operator
    {
        public string? Name { get; set; }
        public string? Url { get; set; }
    }

    public class EV
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Status { get; set; }
        public List<Connector>? Connectors { get; set; }
    }

    public class Connector
    {
        public int Id { get; set; }
        public string? Standard { get; set; }
        public string? Format { get; set; } //TODO: Updated this to Enum
        public int MaxElectricPower { get; set; }
        public string? PriceId {  get; set; }
        public Price? Price { get; set; }
    }

    public class Price
    {
        public string? Description { get; set; }
        public List<Element>? Elements { get; set; }
    }

    public class Element
    {
        public List<PriceComponent>? PriceComponents { get; set; }
        public Restrictions? Restrictions { get; set; }
    }
    public class PriceComponent
    {
        public string? Type { get; set; }
        public float Price { get; set; }
        public float PricePerStep { get; set; }
        public float PricePerStepIncVat { get; set; }
        public int StepSize { get; set; }
        public float Vat { get; set; }
    }

    public class Restrictions
    {
        public int? MaxDuration { get; set; }
        public string? StartTime { get; set; }
        public string? EndTime { get; set; }
        public List<string>? DayOfWeek { get; set; }
    }
}
