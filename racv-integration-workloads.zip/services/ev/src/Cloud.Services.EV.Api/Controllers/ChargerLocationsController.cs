﻿using Cloud.Services.Common.Azure.Cosmos.Interfaces;
using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Exceptions;
using Cloud.Services.Common.Models;
using Cloud.Services.EV.Api.Extensions;
using Cloud.Services.EV.Common.Constants;
using Cloud.Services.EV.Common.Settings;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using CosmosDb = Cloud.Services.EV.Common.Models.Connectors.CosmosDb;

namespace Cloud.Services.EV.Api.Controllers
{
    /// <summary>
    /// Controller for get configuration.
    /// </summary>
    [ApiController]
    [Route("v1")]
    public class ChargerLocationsController : ControllerBase
    {
        /// <summary>
        /// This variable is used to log application related logs.
        /// </summary>
        private readonly ILogger<ChargerLocationsController> _logger;

        /// <summary>
        /// Represents the settings for ev.
        /// </summary>
        private readonly EVSettings _evSettings;

        /// <summary>
        /// Represents the service for interacting with the Cosmos DB for charger locations.
        /// </summary>
        private readonly ICosmosDBService _locationsCosmosDbService;

        /// <summary>
        /// Represents the service for interacting with the Cosmos DB for charger tariffs.
        /// </summary>
        private readonly ICosmosDBService _tariffsCosmosDbService;

        /// <summary>
        /// Initializes a new instance of the <see cref="ChargerLocationsController"/> class.
        /// </summary>
        /// <param name="logger">The logger instance used for logging.</param>
        /// <param name="locationsCosmosDbService">The service for interacting with the Cosmos DB for charger locations.</param>
        /// <param name="tariffsCosmosDbService">The service for interacting with the Cosmos DB for charger tariffs.</param>
        /// <exception cref="ArgumentNullException">Thrown when any of the parameters is null.</exception>
        public ChargerLocationsController(
            ILogger<ChargerLocationsController> logger,
            IOptions<EVSettings> evSettings,
            [FromKeyedServices(InternalConstants.LocationsCosmosDbServiceKey)] ICosmosDBService locationsCosmosDbService,
            [FromKeyedServices(InternalConstants.TariffsCosmosDbServiceKey)] ICosmosDBService tariffsCosmosDbService)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _evSettings = evSettings.Value ?? throw new ArgumentNullException(nameof(evSettings));
            _locationsCosmosDbService = locationsCosmosDbService ?? throw new ArgumentNullException(nameof(locationsCosmosDbService));
            _tariffsCosmosDbService = tariffsCosmosDbService ?? throw new ArgumentNullException(nameof(tariffsCosmosDbService));
        }

        /// <summary>
        /// Retrieves the charger locations based on the provided query parameters.
        /// </summary>
        /// <param name="xCorrelationIdentifier">The correlation identifier for the request.</param>
        /// <param name="watermark">The watermark for retrieving updated charger locations.</param>
        /// <returns>The charger locations response.</returns>
        [HttpGet("locations")]
        [Authorize]
        [ProducesResponseType(typeof(OperationSuccessResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(OperationFailureResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(OperationFailureResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public async Task<IActionResult> GetChargerLocations(
            [FromHeader(Name = ServicesConstants.CorrelationIdLogPropertyName)] Guid xCorrelationIdentifier,
            [FromQuery] int? watermark = default)
        {
            _logger.LogInformation("CorrelationId : { " + ServicesConstants.CorrelationIdLogPropertyName + "} Started executing Get Async Method.", xCorrelationIdentifier);

            try
            {
                // Check if the API call is full sync 
                if (!watermark.HasValue)
                {
                    var fullSyncQuery = CosmosDbExtensions.ConstructFullSyncParameterizedQuery();
                    var fullSyncChargerTariffs = await _tariffsCosmosDbService.GetItemsQueryable<CosmosDb.ChargerTariff>(fullSyncQuery);
                    var fullSyncChargerLocations = await _locationsCosmosDbService.GetItemsQueryable<CosmosDb.ChargerLocation>(fullSyncQuery);

                    // Construct API response from ChargerLocations
                    var fullSyncResponse = fullSyncChargerLocations.ConstructChargerLocationsResponse(
                        fullSyncChargerTariffs,
                        _evSettings);
                    return Ok(new OperationSuccessResponse { Data = fullSyncResponse });
                }

                // Get updated tariffs from db
                var tariffsQuery = watermark.ConstructTariffsParameterizedQuery();
                var cosmosDbChargerTariffs = await _tariffsCosmosDbService.GetItemsQueryable<CosmosDb.ChargerTariff>(tariffsQuery);

                // Construct tariffIds list
                var updatedTariffIds = cosmosDbChargerTariffs.Select(ct => ct.Id).ToList();

                // Construct location query with updated tariff ids
                var locationsQuery = watermark.ConstructLocationParameterizedQuery(updatedTariffIds);
                var cosmosDbChargerLocations = await _locationsCosmosDbService.GetItemsQueryable<CosmosDb.ChargerLocation>(locationsQuery);

                // Construct old tariffs Ids
                var oldTariffsIds = cosmosDbChargerLocations.GetOldChargerTariffIds(updatedTariffIds);

                // Get location Ids where old tariffs apply 
                if (!oldTariffsIds.IsNullOrEmpty())
                {
                    var oldTariffsQuery = oldTariffsIds.ConstructOldTariffsParametrizedQuery();
                    var cosmosDbOldChargerTariffs = await _tariffsCosmosDbService.GetItemsQueryable<CosmosDb.ChargerTariff>(oldTariffsQuery);
                    cosmosDbChargerTariffs.AddRange(cosmosDbOldChargerTariffs);
                }

                // Construct API response from ChargerLocations
                var response = cosmosDbChargerLocations.ConstructChargerLocationsResponse(
                    cosmosDbChargerTariffs,
                    _evSettings);

                return Ok(new OperationSuccessResponse { Data = response });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "} Get Charger Locations request failed with error: {message}",
                    xCorrelationIdentifier,
                    ex.InnerException);

                return StatusCode(
                    StatusCodes.Status500InternalServerError,
                    new OperationFailureResponse("Error occurred while retrieving charger locations.", null, xCorrelationIdentifier.ToString()));
            }
        }
    }
}

