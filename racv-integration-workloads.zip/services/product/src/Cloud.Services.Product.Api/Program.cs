﻿using Cloud.Services.Common.Startup;
using Cloud.Services.Common.Utility.Handlers.Interfaces;
using Cloud.Services.Common.Utility.Wrapper.Implementation;
using Cloud.Services.Common.Utility.Wrapper.Interfaces;
using Cloud.Services.Product.Common.Constants;
using Cloud.Services.Product.Common.Settings;
using Cloud.Services.Product.Connector.Salesforce.Implementations;
using Cloud.Services.Product.Connector.Salesforce.Interfaces;

namespace Cloud.Services.Product.Api;

internal class Program
{
    private Program()
    {
    }

    private static void Main(string[] args)
    {
        // Create the web application builder.
        var builder = WebApplication.CreateBuilder(args);

        // Add common services
        ConfigureServices(builder);

        // Build the app
        var app = builder.Build();

        // Configure app
        ApiBaseStartup.Configure(app, app.Environment, builder.Logging);

        // Map controllers
        app.MapControllers();

        // Configure the HTTP request pipeline.
        app.Run();
    }

    private static void ConfigureServices(WebApplicationBuilder builder)
    {
        // Add common services
        ApiBaseStartup.ConfigureServices<Program>(builder);

        // Retrieve the SalesforceSettings from the application configuration.
        var salesforceSettings = new SalesforceSettings();
        builder.Configuration.Bind(SalesforceSettings.ConfigurationSectionName, salesforceSettings);

        // Add HTTP Client
        builder.Services.AddHttpClient(InternalConstants.SalesforceHttpClient,
            client => { client.BaseAddress = new Uri(salesforceSettings.BaseUrl ?? string.Empty); });

        // Add HttpWrapper
        builder.Services.AddSingleton<IHttpWrapper<HttpRequestMessage, HttpResponseMessage>, HttpWrapper>(
            provider =>
            {
                var httpClientFactory = provider.GetRequiredService<IHttpClientFactory>();
                var messageTrackerHandler =
                    provider.GetRequiredService<IMessageTrackerHandler<HttpRequestMessage, HttpResponseMessage>>();
                var wrapper = new HttpWrapper(httpClientFactory, messageTrackerHandler.LogRequestResponse);
                return wrapper;
            });

        // Add AEM Connector
        builder.Services.AddTransient<ISalesforceProductDetails, SalesforceProductDetails>();
    }
}
