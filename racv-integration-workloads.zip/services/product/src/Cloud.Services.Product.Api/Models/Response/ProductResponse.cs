using System.Text.Json.Serialization;
using Cloud.Services.Product.Common.Utilities;

namespace Cloud.Services.Product.Api.Models.Response;

/// <summary>
///     Response payload from Microservice representing Product details
/// </summary>
public class ProductsResponse
{
    [JsonPropertyName("message")]
    public string? Message { get; set; }

    [JsonPropertyName("data")]
    public List<Product> Data { get; set; } = [];

    [JsonPropertyName("tradesJobList")]
    public List<TradesJob> TradesJobs { get; set; } = [];

}

public class Product
{
    [JsonPropertyName("Id")]
    public string? Id { get; set; }

    [JsonPropertyName("status")]
    public string? Status { get; set; }

    [JsonPropertyName("productName")]
    public string? ProductName { get; set; }

    [JsonPropertyName("productCode")]
    public string? ProductCode { get; set; }

    [JsonPropertyName("assetDescription")]
    public string? AssetDescription { get; set; }

    [JsonPropertyName("actualStatus")]
    public string? ActualStatus { get; set; }

    [JsonPropertyName("policyNumber")]
    public string? PolicyNumber { get; set; }

    [JsonPropertyName("paymentPreference")]
    public string? PaymentPreference { get; set; }

    [JsonPropertyName("expiryDate")]
    [JsonConverter(typeof(DateFormatConverter))]
    public DateTime? ExpiryDate { get; set; }

    [JsonPropertyName("displayPolicyNumber")]
    public bool DisplayPolicyNumber {get; set;}

    [JsonPropertyName("displayMakePayment")]
    public bool DisplayMakePayment {get; set;}

    [JsonPropertyName("displayExpiryDate")]
    public bool DisplayExpiryDate {get; set;}

    [JsonPropertyName("canManageClaim")]
    public bool CanManageClaim {get; set;}

    [JsonPropertyName("canViewProductDetails")]
    public bool CanViewProductDetails { get; set; }

    [JsonPropertyName("canViewCancelledProducts")]
    public bool CanViewCancelledProducts { get; set; }

    [JsonPropertyName("canPayBill")]
    public bool CanPayBill { get; set; }

    [JsonPropertyName("canEditAddress")]
    public bool CanEditAddress { get; set; }

    [JsonPropertyName("assetIcon")]
    public Uri? AssetIcon { get; set; }

    [JsonPropertyName("ctaUrl")]
    public Uri? CtaUrl { get; set; }

    [JsonPropertyName("displayPaymentPreference")]
    public bool DisplayPaymentPreference { get; set; }

    [JsonPropertyName("canManageDirectDebit")]
    public bool CanManageDirectDebit { get; set; }

    [JsonPropertyName("canViewClubStatements")]
    public bool CanViewClubStatements { get; set; }

    [JsonPropertyName("canViewPolicyDocuments")]
    public bool CanViewPolicyDocuments { get; set; }

    [JsonPropertyName("viewCancelledProductsUrl")]
    public Uri? ViewCancelledProductsUrl { get; set; }

    [JsonPropertyName("actions")]
    public List<Action> Actions { get; set; } = [];
}

public class Action
{
    [JsonPropertyName("property")]
    public string? Property { get; set; }

    [JsonPropertyName("destination")]
    public Uri? Destination { get; set; }
}

public class TradesJob
{
    [JsonPropertyName("tradeProgress")]
    public string? TradeProgress { get; set; }

    [JsonPropertyName("referenceNumber")]
    public string? ReferenceNumber { get; set; }

    [JsonPropertyName("quoteReviewPaymentLabel")]
    public string? QuoteReviewPaymentLabel { get; set; }

    [JsonPropertyName("propAddress")]
    public string? PropAddress { get; set; }

    [JsonPropertyName("productCode")]
    public string? ProductCode { get; set; }

    [JsonPropertyName("jobStatusDisplay")]
    public string? JobStatusDisplay { get; set; }

    [JsonPropertyName("jobNameDisplay")]
    public string? JobNameDisplay { get; set; }

    [JsonPropertyName("jobIcon")]
    public Uri? JobIcon { get; set; }

    [JsonPropertyName("ctaUrl")]
    public Uri? CtaUrl { get; set; }

    [JsonPropertyName("viewAllJobs")]
    public Uri? ViewAllJobs { get; set; }

    [JsonPropertyName("canViewJobDetails")]
    public bool? CanViewJobDetails { get; set; }

    [JsonPropertyName("canReviewQuote")]
    public bool? CanReviewQuote { get; set; }

    [JsonPropertyName("canMakePayment")]
    public bool? CanMakePayment { get; set; }

    [JsonPropertyName("canPayDeposit")]
    public bool? CanPayDeposit { get; set; }

   [JsonPropertyName("actualStatus")]
    public string? ActualStatus { get; set; }

    [JsonPropertyName("actions")]
    public List<Action> Actions { get; set; } = [];

}

