using ServiceResponse = Cloud.Services.Product.Api.Models.Response;
using SalesforceResponse = Cloud.Services.Product.Common.Models.Salesforce.SObjects;

namespace Cloud.Services.Product.Api.Extensions;

/// <summary>
///     Provides extension methods for product Details responses.
/// </summary>
public static class ProductResponseExtensions
{
    /// <summary>
    ///     Converts Salesforce Product Details to Microservice product Details.
    /// </summary>
    /// <param name="sfProductDetailsResponse">The Salesforce Product Details.</param>
    /// <returns>The Microservice Product Details.</returns>
    public static ServiceResponse.ProductsResponse Convert(
        this SalesforceResponse.ProductDetails sfProductDetailsResponse)
    {
        return new ServiceResponse.ProductsResponse
        {
            Message = "Operation successful.",
            Data = sfProductDetailsResponse.ProductHoldingList.Select(ph => ph.Convert()).ToList(),
            TradesJobs = sfProductDetailsResponse.TradesJobList.Select(tradeJob => tradeJob.Convert()).ToList()
        };
    }

    /// <summary>
    ///     Converts a Salesforce ProductHolding object to a ServiceResponse.Product object.
    /// </summary>
    /// <param name="item">The Salesforce ProductHolding object to convert.</param>
    /// <returns>A ServiceResponse.Product object that represents the converted Salesforce ProductHolding object.</returns>
    private static ServiceResponse.Product Convert(
        this SalesforceResponse.ProductHolding item)
    {
        return new ServiceResponse.Product
        {
            Id = item.Id,
            Status = item.Status,
            ProductName = item.ProductName,
            ProductCode = item.ProductCode,
            AssetDescription = item.AssetDescription,
            ActualStatus = item.ActualStatus,
            PolicyNumber = item.PolicyNumber,
            PaymentPreference = item.PaymentPreference,
            ExpiryDate = item.ExpiryDate,
            DisplayPolicyNumber = item.DisplayPolicyNumber ?? false,
            DisplayMakePayment = item.DisplayMakePayment ?? false,
            DisplayExpiryDate = item.DisplayExpiryDate ?? false,
            CanManageClaim = item.CanManageClaim ?? false,
            CanViewProductDetails = item.CanViewProductDetails ?? false,
            CanViewCancelledProducts = item.CanViewCancelledProducts ?? false,
            CanPayBill = item.CanPayBill ?? false,
            CanEditAddress = item.CanEditAddress ?? false,
            AssetIcon = item.AssetIcon,
            CtaUrl = item.CtaUrl,
            DisplayPaymentPreference = item.DisplayPaymentPreference ?? false,
            CanManageDirectDebit = item.CanManageDirectDebit ?? false,
            CanViewClubStatements = item.CanViewClubStatements ?? false,
            CanViewPolicyDocuments = item.CanViewPolicyDocuments ?? false,
            ViewCancelledProductsUrl = item.ViewCancelledProductsUrl,
            Actions = item.Actions.Select(action => action.Convert()).ToList()
        };
    }

    /// <summary>
    ///     Converts a Salesforce Action object to a ServiceResponse.Action object.
    /// </summary>
    /// <param name="item">The Salesforce Action object to convert.</param>
    /// <returns>A ServiceResponse.Action object that represents the converted Salesforce Action object.</returns>
    private static ServiceResponse.Action Convert(
        this SalesforceResponse.Action item)
    {
        return new ServiceResponse.Action { Property = item.Property, Destination = item.Destination };
    }

     private static ServiceResponse.TradesJob Convert(
        this SalesforceResponse.TradesJob item)
    {
        return new ServiceResponse.TradesJob { 
            TradeProgress = item.TradeProgress, 
            ReferenceNumber = item.ReferenceNumber, 
            QuoteReviewPaymentLabel = item.QuoteReviewPaymentLabel, 
            PropAddress = item.PropAddress, 
            ProductCode = item.ProductCode, 
            JobStatusDisplay = item.JobStatusDisplay, 
            JobNameDisplay = item.JobNameDisplay, 
            JobIcon = item.JobIcon,
            CtaUrl = item.CtaUrl,
            ViewAllJobs = item.ViewAllJobs, 
            CanViewJobDetails = item.CanViewJobDetails ?? false, 
            CanReviewQuote = item.CanReviewQuote ?? false, 
            CanMakePayment = item.CanMakePayment ?? false,
            CanPayDeposit = item.CanPayDeposit ?? false,
            ActualStatus = item.ActualStatus, 
            Actions = item.Actions.Select(action => action.Convert()).ToList()
            };
    }
}
