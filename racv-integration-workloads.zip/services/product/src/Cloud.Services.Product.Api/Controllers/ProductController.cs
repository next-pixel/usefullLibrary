using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Exceptions;
using Cloud.Services.Product.Api.Extensions;
using Cloud.Services.Product.Api.Models.Response;
using Cloud.Services.Product.Connector.Salesforce.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace Cloud.Services.Product.Api.Controllers;

/// <summary>
///     Controller for handling requests related to Product details.
/// </summary>
[ApiController]
[Route("v1")]
public class ProductController : ControllerBase
{
    private readonly ILogger<ProductController> _logger;
    private readonly ISalesforceProductDetails _salesforceProductDetails;

    /// <summary>
    ///     Initializes a new instance of the <see cref="ProductController" /> class.
    /// </summary>
    /// <param name="logger">The logger.</param>
    /// <param name="salesforceProductDetails">The Salesforce Product Details service.</param>
    public ProductController(ILogger<ProductController> logger,
        ISalesforceProductDetails salesforceProductDetails)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _salesforceProductDetails = salesforceProductDetails;
    }

    /// <summary>
    ///     Gets the Product details.
    /// </summary>
    /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
    /// <param name="authorization">JWT Bearer</param>
    /// <returns>The action result.</returns>
    [HttpGet("products")]
    [Authorize]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Produces("application/json")]
    public async Task<ActionResult<ProductsResponse>> GetAsync(
        [FromHeader(Name = ServicesConstants.CorrelationIdLogPropertyName)]
        Guid xCorrelationIdentifier,
        [FromHeader(Name = "Authorization")] string authorization
    )
    {
        _logger.LogInformation(
            "CorrelationId : { "
            + ServicesConstants.CorrelationIdLogPropertyName
            + "} Started executing Get Async Method.",
            xCorrelationIdentifier
        );

        try
        {
            var response =
                await _salesforceProductDetails.GetProductDetails(xCorrelationIdentifier, authorization);

            return Ok(response.Convert());
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                "} Retrieving Product Details failed with Http error: {message}", xCorrelationIdentifier, ex.Message);

            return StatusCode(ex.StatusCode != null ? (int)ex.StatusCode : StatusCodes.Status500InternalServerError,
                new OperationFailureResponse("Http error occurred while retrieving Product Details.", null,
                    xCorrelationIdentifier.ToString()));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                "} Retrieving Product Details failed with error: {message}", xCorrelationIdentifier, ex.Message);

            return StatusCode(StatusCodes.Status500InternalServerError,
                new OperationFailureResponse("Error occurred while retrieving Product Details.", null,
                    xCorrelationIdentifier.ToString()));
        }
    }
}
