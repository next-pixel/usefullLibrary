using Cloud.Services.Benefit.Api.Controllers;
using Cloud.Services.Benefit.Connector.AEM.Interfaces;
using Cloud.Services.Benefit.Controller.Tests.Unit.Infrastructure;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using ServiceBenefitsResponse = Cloud.Services.Benefit.Api.Models.Response.BenefitsResponse;

namespace Cloud.Services.Benefit.Controller.Tests.Unit.UnitTests;

/// <summary>
///     This class contains unit tests for the <see cref="GeneralController" />.
/// </summary>
public class GeneralControllerTest
{
    private const string Authorization = "Bearer valid_token";
    private const string UserAgent = "TestRACVAppUser";
    private readonly GeneralController _generalController;
    private readonly Mock<IAemGeneralBenefits> _mockGeneralBenefitsService;
    private readonly Mock<ILogger<GeneralController>> _mockLogger;
    private readonly Guid _xCorrelationIdentifier;

    /// <summary>
    ///     Initializes a new instance of the GeneralControllerTest class.
    /// </summary>
    public GeneralControllerTest()
    {
        _mockLogger = LoggerHelper.GetLogger<GeneralController>();
        _mockGeneralBenefitsService = new Mock<IAemGeneralBenefits>();
        _generalController = new GeneralController(_mockLogger.Object, _mockGeneralBenefitsService.Object);
        _xCorrelationIdentifier = Guid.NewGuid();
        

        _mockGeneralBenefitsService
            .Setup(service => service.GetGeneralBenefits(_xCorrelationIdentifier, Authorization, UserAgent))
            .ReturnsAsync(TestDataHelper.GetExpectedAEMResponse);
    }

    /// <summary>
    ///     Test case for GetAsync method in GeneralController.
    ///     This test verifies that the GetAsync method returns the expected result when called with valid parameters.
    /// </summary>
    [Fact]
    public async Task BenefitsController_GetGeneralBenefits_ShouldPass()
    {
        // Arrange

        // Act
        var result = await _generalController.GetAsync(_xCorrelationIdentifier, Authorization, UserAgent);

        // Assert
        result.Should().NotBeNull();

        var okResult = result.Result as OkObjectResult;
        okResult.Should().NotBeNull();
        okResult.Should().BeOfType<OkObjectResult>();
        okResult?.StatusCode.Should().Be(StatusCodes.Status200OK);

        var returnValue = okResult?.Value as ServiceBenefitsResponse;
        returnValue.Should().NotBeNull();
        returnValue.Should().BeOfType<ServiceBenefitsResponse>();
        returnValue.Should().BeEquivalentTo(TestDataHelper.GetExpectedServiceResponse());

        _mockGeneralBenefitsService.Verify(
            service => service.GetGeneralBenefits(_xCorrelationIdentifier, Authorization, UserAgent),
            Times.Once);
    }
}
