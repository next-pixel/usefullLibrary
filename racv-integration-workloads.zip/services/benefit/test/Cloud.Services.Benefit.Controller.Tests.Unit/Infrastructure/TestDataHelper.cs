using System.Globalization;
using ServiceResponse = Cloud.Services.Benefit.Api.Models.Response;
using AEMResponse = Cloud.Services.Benefit.Common.Models.AEM.Response;

namespace Cloud.Services.Benefit.Controller.Tests.Unit.Infrastructure;

/// <summary>
///     Helps to generate test data.
/// </summary>
public static class TestDataHelper
{
    /// <summary>
    ///     Generates a mock AEM response for testing.
    /// </summary>
    /// <returns>A mock service response.</returns>
    public static AEMResponse.BenefitsResponse GetExpectedAEMResponse()
    {
        return new AEMResponse.BenefitsResponse
        {
            Data = new List<AEMResponse.Data>
            {
                new()
                {
                    Offers = new List<AEMResponse.Offer>
                    {
                        new()
                        {
                            OfferId = "38541",
                            Category =
                                new List<AEMResponse.OfferCategory>
                                {
                                    new() { CategoryId = "racv:discount-categories/featured", Label = "Featured" },
                                    new() { CategoryId = "racv:discount-categories/popular", Label = "Popular" }
                                },
                            Title = "Competitions",
                            VendorIdentifier = null,
                            StartDate = null,
                            EndDate = null,
                            LastModifiedDate =
                                DateTime.Parse("2024-04-08T00:49:34.460Z",
                                    CultureInfo.InvariantCulture),
                            AppDescription = null,
                            Image =
                                new Uri(
                                    "https://www.racv.com.au/content/dam/racv/images/legacy/compeitions-page-thumbnail-600x400.jpg"),
                            Description =
                                "Find out more about the competitions RACV has on offer and enter for your chance to win some exciting prizes.",
                            Url =
                                new Uri(
                                    "https://www.racv.com.au/utility/competitions.appview.html"),
                            Tag = "Save 10%"
                        }
                    },
                    Categories = new List<AEMResponse.Category>
                    {
                        new()
                        {
                            CategoryUrl =
                                new Uri(
                                    "https://staging-cloudfront.racv.com.au/membership/member-discounts.html#Featured"),
                            Label = "Featured",
                            CategoryId = "racv:discount-categories/featured"
                        },
                        new()
                        {
                            CategoryUrl =
                                new Uri(
                                    "https://staging-cloudfront.racv.com.au/membership/member-discounts.html#Popular"),
                            Label = "Popular",
                            CategoryId = "racv:discount-categories/popular"
                        }
                    },
                    ViewAllUrl =
                        new Uri(
                            "https://www.racv.com.au/..."),
                    CompetitionUrl = 
                        new Uri(
                            "https://www.racv.com.au/..."),
                    FeaturedOffersTitle = "Featured Offers",
                    MostPopularTitle = "Browse by most popular",
                    BrowseByCategoryTitle = "Browse by category",
                    SeeAllNumber = "3000"
                }
            }
        };
    }

    /// <summary>
    ///     Generates a mock service response for testing.
    /// </summary>
    /// <returns>A mock api response.</returns>
    public static ServiceResponse.BenefitsResponse GetExpectedServiceResponse()
    {
        return new ServiceResponse.BenefitsResponse
        {
            Data = new List<ServiceResponse.Data>
            {
                new()
                {
                    Offers = new List<ServiceResponse.Offer>
                    {
                        new()
                        {
                            OfferId = "38541",
                            Category =
                                new List<ServiceResponse.OfferCategory>
                                {
                                    new() { CategoryId = "racv:discount-categories/featured", Label = "Featured" },
                                    new() { CategoryId = "racv:discount-categories/popular", Label = "Popular" }
                                },
                            Title = "Competitions",
                            VendorIdentifier = null,
                            StartDate = null,
                            EndDate = null,
                            LastModifiedDate =
                                DateTime.Parse("2024-04-08T00:49:34.460Z",
                                    CultureInfo.InvariantCulture),
                            AppDescription = null,
                            Image =
                                new Uri(
                                    "https://www.racv.com.au/content/dam/racv/images/legacy/compeitions-page-thumbnail-600x400.jpg"),
                            Description =
                                "Find out more about the competitions RACV has on offer and enter for your chance to win some exciting prizes.",
                            Url =
                                new Uri(
                                    "https://www.racv.com.au/utility/competitions.appview.html"),
                            Tag = "Save 10%"
                        }
                    },
                    Categories = new List<ServiceResponse.Category>
                    {
                        new()
                        {
                            CategoryUrl =
                                new Uri(
                                    "https://staging-cloudfront.racv.com.au/membership/member-discounts.html#Featured"),
                            Label = "Featured",
                            CategoryId = "racv:discount-categories/featured"
                        },
                        new()
                        {
                            CategoryUrl =
                                new Uri(
                                    "https://staging-cloudfront.racv.com.au/membership/member-discounts.html#Popular"),
                            Label = "Popular",
                            CategoryId = "racv:discount-categories/popular"
                        }
                    },
                    ViewAllUrl =
                        new Uri(
                            "https://www.racv.com.au/..."),
                    CompetitionUrl = 
                        new Uri(
                            "https://www.racv.com.au/..."),
                    FeaturedOffersTitle = "Featured Offers",
                    MostPopularTitle = "Browse by most popular",
                    BrowseByCategoryTitle = "Browse by category",
                    SeeAllNumber = "3000"
                }
            }
        };
    }
}
