using Cloud.Services.Benefit.Common.Constants;
using Cloud.Services.Benefit.Common.Settings;
using Cloud.Services.Benefit.Connector.AEM.Implementations;
using Cloud.Services.Benefit.Connector.AEM.Interfaces;
using Cloud.Services.Common.Startup;
using Cloud.Services.Common.Utility.Handlers.Interfaces;
using Cloud.Services.Common.Utility.Wrapper.Implementation;
using Cloud.Services.Common.Utility.Wrapper.Interfaces;

namespace Cloud.Services.Benefit.Api;

internal class Program
{
    private Program()
    {
    }

    private static void Main(string[] args)
    {
        // Create the web application builder.
        var builder = WebApplication.CreateBuilder(args);

        // Add common services
        ConfigureServices(builder);

        // Build the app
        var app = builder.Build();

        // Configure app
        ApiBaseStartup.Configure(app, app.Environment, builder.Logging);

        // Map controllers
        app.MapControllers();

        // Configure the HTTP request pipeline.
        app.Run();
    }

    private static void ConfigureServices(WebApplicationBuilder builder)
    {
        // Add common services
        ApiBaseStartup.ConfigureServices<Program>(builder);

        // Retrieve the AEMSettings from the application configuration.
        var aemSettings = new AemSettings();
        builder.Configuration.Bind(AemSettings.ConfigurationSectionName, aemSettings);

        // Add HTTP Client
        builder.Services.AddHttpClient(InternalConstants.AEMHttpClient,
            client => { client.BaseAddress = new Uri(aemSettings.BaseUrl); });

        // Add HttpWrapper
        builder.Services.AddSingleton<IHttpWrapper<HttpRequestMessage, HttpResponseMessage>, HttpWrapper>(
            provider =>
            {
                var httpClientFactory = provider.GetRequiredService<IHttpClientFactory>();
                var messageTrackerHandler =
                    provider.GetRequiredService<IMessageTrackerHandler<HttpRequestMessage, HttpResponseMessage>>();
                var wrapper = new HttpWrapper(httpClientFactory, messageTrackerHandler.LogRequestResponse);
                return wrapper;
            });

        // Add AEM Connector
        builder.Services.AddTransient<IAemGeneralBenefits, AemGeneralBenefits>();
    }
}
