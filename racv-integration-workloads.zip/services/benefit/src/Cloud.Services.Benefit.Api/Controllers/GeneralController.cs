using Cloud.Services.Benefit.Api.Extensions;
using Cloud.Services.Benefit.Api.Models.Response;
using Cloud.Services.Benefit.Connector.AEM.Interfaces;
using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Cloud.Services.Benefit.Api.Controllers;

/// <summary>
///     Controller for handling requests related to general benefits..
/// </summary>
[ApiController]
[Route("v1")]
public class GeneralController : ControllerBase
{
    private readonly IAemGeneralBenefits _aemGeneralBenefits;
    private readonly ILogger<GeneralController> _logger;

    /// <summary>
    ///     Initializes a new instance of the <see cref="GeneralController" /> class.
    /// </summary>
    /// <param name="logger">The logger.</param>
    /// <param name="aemGeneralBenefits">The AEM general benefits service.</param>
    public GeneralController(ILogger<GeneralController> logger,
        IAemGeneralBenefits aemGeneralBenefits)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _aemGeneralBenefits = aemGeneralBenefits;
    }

    /// <summary>
    ///     Gets the general benefits.
    /// </summary>
    /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
    /// <param name="authorization">JWT Bearer</param>
    /// <returns>The action result.</returns>
    [HttpGet("general")]
    [Authorize]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Produces("application/json")]
    public async Task<ActionResult<BenefitsResponse>> GetAsync(
        [FromHeader(Name = ServicesConstants.CorrelationIdLogPropertyName)]
        Guid xCorrelationIdentifier,
        [FromHeader(Name = "Authorization")] string authorization, 
        [FromHeader(Name = "User-Agent")] string? userAgent = null
    )
    {
        _logger.LogInformation(
            "CorrelationId : { "
            + ServicesConstants.CorrelationIdLogPropertyName
            + "} Started executing Get Async Method.",
            xCorrelationIdentifier
        );
        try
        {
            var response =
                await _aemGeneralBenefits.GetGeneralBenefits(xCorrelationIdentifier, authorization, userAgent);

            return Ok(response.Convert());
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                "} Retrieving General Benefits failed with error: {message}", xCorrelationIdentifier, ex.Message);

            return StatusCode(StatusCodes.Status500InternalServerError,
                new OperationFailureResponse("Error occured while retrieving General Benefits.", null,
                    xCorrelationIdentifier.ToString()));
        }
    }
}
