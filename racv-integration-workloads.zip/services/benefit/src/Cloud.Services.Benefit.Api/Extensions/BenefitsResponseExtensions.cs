using ServiceResponse = Cloud.Services.Benefit.Api.Models.Response;
using AEMResponse = Cloud.Services.Benefit.Common.Models.AEM.Response;

namespace Cloud.Services.Benefit.Api.Extensions;

/// <summary>
///     Provides extension methods for converting AEMBenefitsResponse to ServiceBenefitsResponse.
/// </summary>
public static class BenefitsResponseExtensions
{
    /// <summary>
    ///     Converts AEMBenefitsResponse to ServiceBenefitsResponse.
    /// </summary>
    /// <param name="aemBenefitsResponse">The AEMBenefitsResponse to convert.</param>
    /// <returns>The converted ServiceBenefitsResponse.</returns>
    public static ServiceResponse.BenefitsResponse Convert(this AEMResponse.BenefitsResponse aemBenefitsResponse)
    {
        return new ServiceResponse.BenefitsResponse
        {
            Data = aemBenefitsResponse.Data?.Select(data => data.Convert()).ToList()
        };
    }

    /// <summary>
    ///     Converts AEMBenefitsResponse.DataObj to ServiceBenefitsResponse.DataObj.
    /// </summary>
    /// <param name="aemBenefits">The AEMBenefitsResponse.DataObj to convert.</param>
    /// <returns>The converted ServiceBenefitsResponse.DataObj.</returns>
    private static ServiceResponse.Data Convert(this AEMResponse.Data aemBenefits)
    {
        return new ServiceResponse.Data
        {
            Offers = aemBenefits.Offers?.Select(offer => offer.Convert()).ToList(),
            Categories = aemBenefits.Categories?.Select(category => category.Convert()).ToList(),
            ViewAllUrl = aemBenefits.ViewAllUrl,
            CompetitionUrl = aemBenefits.CompetitionUrl,
            FeaturedOffersTitle = aemBenefits.FeaturedOffersTitle,
            MostPopularTitle = aemBenefits.MostPopularTitle,
            BrowseByCategoryTitle = aemBenefits.BrowseByCategoryTitle,
            SeeAllNumber = aemBenefits.SeeAllNumber
        };
    }

    /// <summary>
    ///     Converts AEMBenefitsResponse.DataObj.Offer to ServiceBenefitsResponse.DataObj.Offer.
    /// </summary>
    /// <param name="aemOffer">The AEMBenefitsResponse.DataObj.Offer to convert.</param>
    /// <returns>The converted ServiceBenefitsResponse.DataObj.Offer.</returns>
    private static ServiceResponse.Offer Convert(this AEMResponse.Offer aemOffer)
    {
        return new ServiceResponse.Offer
        {
            OfferId = aemOffer.OfferId,
            Category = aemOffer.Category?.Select(category => category.Convert()).ToList(),
            Title = aemOffer.Title,
            VendorIdentifier = aemOffer.VendorIdentifier,
            StartDate = aemOffer.StartDate,
            EndDate = aemOffer.EndDate,
            LastModifiedDate = aemOffer.LastModifiedDate,
            AppDescription = aemOffer.AppDescription,
            Image = aemOffer.Image,
            Description = aemOffer.Description,
            Url = aemOffer.Url,
            Tag = aemOffer.Tag
        };
    }

    /// <summary>
    ///     Converts AEMBenefitsResponse.DataObj.Offer.OfferCategory to ServiceBenefitsResponse.DataObj.Offer.OfferCategory.
    /// </summary>
    /// <param name="aemOffer">The AEMBenefitsResponse.DataObj.Offer.OfferCategory to convert.</param>
    /// <returns>The converted ServiceBenefitsResponse.DataObj.Offer.OfferCategory.</returns>
    private static ServiceResponse.OfferCategory Convert(
        this AEMResponse.OfferCategory aemOffer)
    {
        return new ServiceResponse.OfferCategory { CategoryId = aemOffer.CategoryId, Label = aemOffer.Label };
    }

    /// <summary>
    ///     Converts AEMBenefitsResponse.DataObj.CategoryObj to ServiceBenefitsResponse.DataObj.CategoryObj.
    /// </summary>
    /// <param name="aemOffer">The AEMBenefitsResponse.DataObj.CategoryObj to convert.</param>
    /// <returns>The converted ServiceBenefitsResponse.DataObj.CategoryObj.</returns>
    private static ServiceResponse.Category Convert(
        this AEMResponse.Category aemOffer)
    {
        return new ServiceResponse.Category
        {
            CategoryId = aemOffer.CategoryId, Label = aemOffer.Label, CategoryUrl = aemOffer.CategoryUrl
        };
    }
}
