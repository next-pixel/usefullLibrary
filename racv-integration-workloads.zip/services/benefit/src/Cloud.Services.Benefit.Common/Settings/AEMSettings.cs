namespace Cloud.Services.Benefit.Common.Settings;

public class AemSettings
{
    public const string ConfigurationSectionName = "AEMSettings";
    public string BaseUrl { get; set; } = string.Empty;
}
