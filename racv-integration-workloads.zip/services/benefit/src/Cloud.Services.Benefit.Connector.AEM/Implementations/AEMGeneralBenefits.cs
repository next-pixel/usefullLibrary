using System.Runtime.Serialization;
using System.Text.Json;
using Cloud.Services.Benefit.Common.Constants;
using Cloud.Services.Benefit.Common.Models.AEM.Response;
using Cloud.Services.Benefit.Connector.AEM.Interfaces;
using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Utility.Wrapper.Interfaces;
using Microsoft.Extensions.Logging;

namespace Cloud.Services.Benefit.Connector.AEM.Implementations;

public class AemGeneralBenefits : IAemGeneralBenefits
{
    private readonly IHttpWrapper<HttpRequestMessage, HttpResponseMessage> _httpWrapper;
    private readonly ILogger<AemGeneralBenefits> _logger;

    /// <summary>
    ///     Initializes a new instance of the <see cref="AemGeneralBenefits" /> class.
    /// </summary>
    /// <param name="logger">The logger.</param>
    /// <param name="httpWrapper">The HTTP wrapper.</param>
    public AemGeneralBenefits(ILogger<AemGeneralBenefits> logger,
        IHttpWrapper<HttpRequestMessage, HttpResponseMessage> httpWrapper)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _httpWrapper = httpWrapper ?? throw new ArgumentNullException(nameof(httpWrapper));
    }

    /// <summary>
    ///     Gets general benefits
    /// </summary>
    /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
    /// <param name="authorization">Bearer token</param>
    /// <returns>The general benefits response.</returns>
    public async Task<BenefitsResponse> GetGeneralBenefits(Guid xCorrelationIdentifier, string authorization, string userAgent)
    {
        HttpResponseMessage? response = null;

        try
        {
            var request = new HttpRequestMessage(HttpMethod.Get, "bin/racv/api/offers");
            if (!string.IsNullOrWhiteSpace(userAgent))
            {
                request.Headers.UserAgent.ParseAdd(userAgent);
            }

            response = await _httpWrapper.SendAsync(
                request,
                InternalConstants.AEMHttpClient,
                xCorrelationIdentifier);

            response.EnsureSuccessStatusCode();

            var responseJson = await response.Content.ReadAsStringAsync();

            return JsonSerializer.Deserialize<BenefitsResponse>(responseJson) ??
                   throw new SerializationException();
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                "} Retrieving General Benefits from AEM failed with Status Code: {statusCode}",
                xCorrelationIdentifier,
                response?.StatusCode);

            throw new HttpRequestException(
                $"Retrieving General Benefits from AEM failed with Status Code: {response?.StatusCode}", ex);
        }
        catch (SerializationException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                "} Deserialization of General Benefits from AEM failed with error: {message}",
                xCorrelationIdentifier, ex.Message);

            throw new SerializationException(
                $"Deserialization of General Benefits from AEM failed with error: {ex.Message}", ex);
        }
    }
}
