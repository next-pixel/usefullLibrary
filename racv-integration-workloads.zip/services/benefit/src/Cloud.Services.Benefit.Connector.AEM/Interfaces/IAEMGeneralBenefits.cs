using Cloud.Services.Benefit.Common.Models.AEM.Response;

namespace Cloud.Services.Benefit.Connector.AEM.Interfaces;

public interface IAemGeneralBenefits
{
    Task<BenefitsResponse> GetGeneralBenefits(Guid xCorrelationIdentifier, string authorization, string userAgent);
}
