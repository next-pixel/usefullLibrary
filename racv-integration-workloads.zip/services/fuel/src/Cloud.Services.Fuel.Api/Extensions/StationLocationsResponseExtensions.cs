using System.Text.RegularExpressions;
using ServiceResponse = Cloud.Services.Fuel.Api.Models.Response;
using Cloud.Services.Fuel.Common.Settings;
using ArevoResponse = Cloud.Services.Fuel.Common.Models.Arevo.Response;

namespace Cloud.Services.Fuel.Api.Extensions;

/// <summary>
///     Provides extension methods for converting Arevo response objects to API response objects.
/// </summary>
public static partial class StationLocationsResponseExtensions
{
    /// <summary>
    ///     Generates a regular expression that matches a sequence of one or more characters enclosed in curly braces followed
    ///     by an equals sign.
    ///     This is used to format the Facilities property in the Convert method for StationDetail.
    /// </summary>
    /// <returns>A Regex object that matches the specified pattern.</returns>
    [GeneratedRegex(@"\{(.+?)=")]
    private static partial Regex StationFacilitiesRegex();

    /// <summary>
    ///     Generates a regular expression that matches one or more whitespace characters.
    ///     This is used to replace any extra spaces in the result of the StationFacilitiesRegex match in the Convert method
    ///     for StationDetail.
    /// </summary>
    /// <returns>A Regex object that matches the specified pattern.</returns>
    [GeneratedRegex(@"\s+")]
    private static partial Regex ExtraSpacesRegex();




    /// <summary>
    ///     Converts the Arevo station locations response to the service station locations response.
    /// </summary>
    /// <param name="arevoLocationsResponse">The Arevo station locations response.</param>
    /// <returns>The service station locations response.</returns>
    public static ServiceResponse.StationLocationsResponse Convert(
        this ArevoResponse.StationLocationsResponse arevoLocationsResponse, FuelSettings fuelSettings)
    {
        return new ServiceResponse.StationLocationsResponse
        {
            Message = "Operation successful.",
            Data = new ServiceResponse.Location
            {
                StationDetails =
                    arevoLocationsResponse.SyncStationDetails?.Items?.ConvertAll(ssd => ssd.Convert(fuelSettings)) ?? [],
                StationPrices = arevoLocationsResponse.SyncFuelPrices?.Items?.ConvertAll(sfp => sfp.Convert()) ?? [],
                Brands = arevoLocationsResponse.SyncFuelBrands?.Items?.ConvertAll(sfb => sfb.Convert()) ?? []
            }
        };
    }

    /// <summary>
    ///     Converts the Arevo station detail to the service station detail.
    /// </summary>
    /// <param name="arevoStationDetail">The Arevo station detail.</param>
    /// <returns>The service station detail.</returns>
    private static ServiceResponse.StationDetail Convert(this ArevoResponse.StationDetail arevoStationDetail, FuelSettings fuelSettings)
    {
        var formattedFacilities = arevoStationDetail.Facilities
            ?.Select(facility => StationFacilitiesRegex().Match(facility))
            .Where(match => match.Success)
            .Select(match => ExtraSpacesRegex().Replace(match.Groups[1].Value.Trim(), " "))
            .ToList();
        
        var stationResponse = new ServiceResponse.StationDetail
        {
            Address = arevoStationDetail.Address,
            BrandId = arevoStationDetail.BrandId.HasValue ? arevoStationDetail.BrandId.ToString() : null,
            Latitude = arevoStationDetail.Latitude,
            Longitude = arevoStationDetail.Longitude,
            Name = arevoStationDetail.Name,
            Deleted = arevoStationDetail.Deleted ?? false,
            PostCode = arevoStationDetail.PostCode,
            LastChangedAt = arevoStationDetail.LastChangedAt,
            Version = arevoStationDetail.Version,
            CreatedAt = arevoStationDetail.CreatedAt,
            UpdatedAt = arevoStationDetail.UpdatedAt,
            OpeningHours = !string.Equals(arevoStationDetail.OpeningHours, "24/7", StringComparison.OrdinalIgnoreCase)
                ? "Trading Hours"
                : arevoStationDetail.OpeningHours,
                
            LastUpdated = arevoStationDetail.LastUpdated.HasValue ? 
                DateTime.SpecifyKind(arevoStationDetail.LastUpdated.Value, DateTimeKind.Utc) : null,

            Id = arevoStationDetail.Id,
            Facilities = formattedFacilities ?? []
        };
        if (stationResponse.BrandId != null && fuelSettings.MemberDiscounts != null && 
            fuelSettings.MemberDiscounts.ContainsKey(stationResponse.BrandId))
                    {
                        stationResponse.Discount = "ENABLED";
                        stationResponse.DiscountValue  = fuelSettings.MemberDiscounts[stationResponse.BrandId].DiscountValue;
                    }
        return stationResponse;
    }

    /// <summary>
    ///     Converts the Arevo fuel price to the service station price.
    /// </summary>
    /// <param name="arevoFuelPrice">The Arevo fuel price.</param>
    /// <returns>The service station price.</returns>
    private static ServiceResponse.StationPrice Convert(this ArevoResponse.FuelPrice arevoFuelPrice)
    {
        var serviceResponse =  new ServiceResponse.StationPrice
        {
            Deleted = arevoFuelPrice.Deleted ?? false,
            LastChangedAt = arevoFuelPrice.LastChangedAt,
            Version = arevoFuelPrice.Version,
            CreatedAt = arevoFuelPrice.CreatedAt,
            Id = arevoFuelPrice.Id,
            UpdatedAt = arevoFuelPrice.UpdatedAt,
            Fuels = arevoFuelPrice.Fuels?.ConvertAll(f => f.Convert()) ?? []
        };
        if  (arevoFuelPrice.Fuels?.FirstOrDefault()?.TransactionDateUtc is not null )
            serviceResponse.UpdatedAt = arevoFuelPrice.Fuels?.FirstOrDefault()?.TransactionDateUtc!.Value.ToOffset(TimeSpan.Zero);  
        return serviceResponse;
    }

    /// <summary>
    ///     Converts the Arevo fuel to the service fuel.
    /// </summary>
    /// <param name="arevoFuel">The Arevo fuel.</param>
    /// <returns>The service fuel.</returns>
    private static ServiceResponse.Fuel Convert(this ArevoResponse.Fuel arevoFuel)
    {
        return new ServiceResponse.Fuel
        {
            CollectionMethod = arevoFuel.CollectionMethod,
            FuelGroups = arevoFuel.FuelGroups?[0] ?? [],
            FuelId = arevoFuel.FuelId,
            TransactionDateUtc = arevoFuel.TransactionDateUtc,
            Name = arevoFuel.Name,
            Price = arevoFuel.Price
        };
    }

    /// <summary>
    ///     Converts the Arevo fuel brand to the service brand.
    /// </summary>
    /// <param name="arevoFuelBrand">The Arevo fuel brand.</param>
    /// <returns>The service brand.</returns>
    private static ServiceResponse.Brand Convert(this ArevoResponse.FuelBrand arevoFuelBrand)
    {
        var id = arevoFuelBrand.Id?.Split('-')[^1];

        return new ServiceResponse.Brand
        {
            Deleted = arevoFuelBrand.Deleted ?? false,
            LastChangedAt = arevoFuelBrand.LastChangedAt,
            Version = arevoFuelBrand.Version,
            CreatedAt = arevoFuelBrand.CreatedAt,
            Id = id,
            Logo = arevoFuelBrand.Logo != null ? new Uri(arevoFuelBrand.Logo.ToString().Replace("http://", "https://")) : null,
            Name = arevoFuelBrand.Name,
            UpdatedAt = arevoFuelBrand.UpdatedAt
        };
    }

}
