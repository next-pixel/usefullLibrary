using Cloud.Services.Common.Startup;
using Cloud.Services.Common.Utility.Handlers.Interfaces;
using Cloud.Services.Common.Utility.Wrapper.Implementation;
using Cloud.Services.Common.Utility.Wrapper.Interfaces;
using Cloud.Services.Fuel.Common.Settings;
using Cloud.Services.Fuel.Common.Settings.Validators;
using Cloud.Services.Fuel.Connector.Arevo.Implementations;
using Cloud.Services.Fuel.Connector.Arevo.Interfaces;
using GraphQL;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;

namespace Cloud.Services.Fuel.Api;

internal class Program
{
    private Program() { }

    private static void Main(string[] args)
    {
        // Create the web application builder.
        var builder = WebApplication.CreateBuilder(args);

        // Add common services
        ConfigureServices(builder);

        // Build the app
        var app = builder.Build();

        // Configure app
        ApiBaseStartup.Configure(app, app.Environment, builder.Logging);

        // Map controllers
        app.MapControllers();

        // Configure the HTTP request pipeline.
        app.Run();
    }

    private static void ConfigureServices(WebApplicationBuilder builder)
    {
        // Add common services
        ApiBaseStartup.ConfigureServices<Program>(builder);

        // Retrieve the ArevoSettings from the application configuration.
        var arevoSettings = new ArevoSettings();
        builder.Configuration.Bind(ArevoSettings.ConfigurationSectionName, arevoSettings);

        // Register settings as IOptions.
        builder.Services.Configure<ArevoSettings>(builder.Configuration!.GetSection(ArevoSettings.ConfigurationSectionName));

        //Add settings validators
        builder.Services.AddSingleton<IValidateOptions<ArevoSettings>, ArevoSettingsValidator>();

        // Add HttpWrapper
        builder.Services.AddSingleton<IGraphQLHttpWrapper<GraphQLRequest, GraphQLResponse<JObject>>, GraphQLHttpWrapper>(
            provider =>
            {
                var messageTrackerHandler =
                    provider.GetRequiredService<IMessageTrackerHandler<GraphQLRequest, GraphQLResponse<JObject>>>();
                var wrapper = new GraphQLHttpWrapper(new Uri($"{arevoSettings.BaseUrl}/graphql").ToString(),
                    messageTrackerHandler.LogRequestResponse);
                return wrapper;
            });

        // Add Arevo Connector
        builder.Services.AddTransient<IArevoFuelStationLocations, ArevoFuelStationLocations>();
 
        // Add FuelSettings to the service collection
        builder.Services.Configure<FuelSettings>(
            builder.Configuration.GetSection(FuelSettings.ConfigurationSectionName));
    }
}
