using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Exceptions;
using Cloud.Services.Fuel.Api.Extensions;
using Cloud.Services.Fuel.Api.Models.Response;
using Cloud.Services.Fuel.Connector.Arevo.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Cloud.Services.Fuel.Common.Settings;
using Microsoft.Extensions.Options;
namespace Cloud.Services.Fuel.Api.Controllers;

/// <summary>
///     Controller for handling requests related to fuel station location.
/// </summary>
[ApiController]
[Route("v1")]
public class StationLocationsController : ControllerBase
{
    private readonly IArevoFuelStationLocations _arevoFuelStationLocations;
    private readonly ILogger<StationLocationsController> _logger;

    private readonly FuelSettings _fuelSettings;

    /// <summary>
    ///     Initializes a new instance of the <see cref="StationLocationsController" /> class.
    /// </summary>
    /// <param name="logger">The logger.</param>
    /// <param name="arevoFuelStationLocations">The Arevo Fuel Station Locations service.</param>
    public StationLocationsController(ILogger<StationLocationsController> logger,
        IArevoFuelStationLocations arevoFuelStationLocations, IOptions<FuelSettings> fuelSettings)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _arevoFuelStationLocations = arevoFuelStationLocations;
         _fuelSettings = fuelSettings.Value ?? throw new ArgumentNullException(nameof(fuelSettings));        
    }

    /// <summary>
    ///     Gets the fuel station locations.
    /// </summary>
    /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
    /// <param name="watermark">Last successful run epoch timestamp</param>
    /// <returns>The action result.</returns>
    [HttpGet("locations")]
    [Authorize]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Produces("application/json")]
    public async Task<ActionResult<StationLocationsResponse>> GetAsync(
        [FromHeader(Name = ServicesConstants.CorrelationIdLogPropertyName)]
        Guid xCorrelationIdentifier,
        [FromQuery(Name = "watermark")] string watermark
    )
    {
        _logger.LogInformation(
            "CorrelationId : { "
            + ServicesConstants.CorrelationIdLogPropertyName
            + "} Started executing Get Async Method.",
            xCorrelationIdentifier
        );

        try
        {
            // Convert seconds epoch watermark
            if (!long.TryParse(watermark, out var sWatermark))
            {
                _logger.LogError("CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                                 "} Invalid watermark value: {watermark}", xCorrelationIdentifier, watermark);
                throw new ArgumentException("Invalid watermark value.", nameof(watermark));
            }

            var response =
                await _arevoFuelStationLocations.GetFuelStationLocations(xCorrelationIdentifier,
                    sWatermark);
            var convertedResponse = response.Convert(_fuelSettings);
            return Ok(convertedResponse);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                "} Retrieving Fuel Station Locations failed with error: {message}", xCorrelationIdentifier, ex.Message);

            return StatusCode(StatusCodes.Status500InternalServerError,
                new OperationFailureResponse("Error occured while retrieving Fuel Station Locations.", null,
                    xCorrelationIdentifier.ToString()));
        }
    }
}
