using System.Text.Json.Serialization;

namespace Cloud.Services.Fuel.Common.Models.Arevo.Response;

/// <summary>
///     Represents the response from the Arevo service for station locations.
///     This includes details about the stations, fuel prices, and fuel brands.
/// </summary>
public class StationLocationsResponse
{
    [JsonPropertyName("syncStationDetails")]
    public SyncStationDetails? SyncStationDetails { get; set; }

    [JsonPropertyName("syncFuelPrices")]
    public SyncFuelPrices? SyncFuelPrices { get; set; }

    [JsonPropertyName("syncFuelBrands")]
    public SyncFuelBrands? SyncFuelBrands { get; set; }
}

/// <summary>
///     Represents the details of the stations.
///     This includes the next token for pagination, the time the sync started, and a list of station details.
/// </summary>
public class SyncStationDetails
{
    [JsonPropertyName("nextToken")]
    public string? NextToken { get; set; }

    [JsonPropertyName("startedAt")]
    public long? StartedAt { get; set; }

    [JsonPropertyName("items")]
    public List<StationDetail>? Items { get; set; }
}

/// <summary>
///     Represents a detailed information about a station.
///     This includes the address, brand ID, latitude, longitude, name, deletion status, postal code, last changed
///     timestamp, version, creation and update timestamps, opening hours, last updated timestamp, ID, facilities, discount
///     value, and discount.
/// </summary>
public class StationDetail
{
    [JsonPropertyName("Address")]
    public string? Address { get; set; }

    [JsonPropertyName("BrandId")]
    public int? BrandId { get; set; }

    [JsonPropertyName("Latitude")]
    public double? Latitude { get; set; }

    [JsonPropertyName("Longitude")]
    public double? Longitude { get; set; }

    [JsonPropertyName("Name")]
    public string? Name { get; set; }

    [JsonPropertyName("_deleted")]
    public bool? Deleted { get; set; }

    [JsonPropertyName("PostCode")]
    public string? PostCode { get; set; }

    [JsonPropertyName("_lastChangedAt")]
    public long? LastChangedAt { get; set; }

    [JsonPropertyName("_version")]
    public int? Version { get; set; }

    [JsonPropertyName("createdAt")]
    public DateTimeOffset? CreatedAt { get; set; }

    [JsonPropertyName("updatedAt")]
    public DateTimeOffset? UpdatedAt { get; set; }

    [JsonPropertyName("opening_hours")]
    public string? OpeningHours { get; set; }

    [JsonPropertyName("last_updated")]
    public DateTime? LastUpdated { get; set;}

    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("facilities")]
    public List<string>? Facilities { get; set; }

    [JsonPropertyName("discount_value")]
    public int? DiscountValue { get; set; }

    [JsonPropertyName("discount")]
    public string? Discount { get; set; }
}

/// <summary>
///     Represents the fuel prices at different stations.
///     This includes the next token for pagination, the time the sync started, and a list of fuel prices.
/// </summary>
public class SyncFuelPrices
{
    [JsonPropertyName("nextToken")]
    public string? NextToken { get; set; }

    [JsonPropertyName("startedAt")]
    public long? StartedAt { get; set; }

    [JsonPropertyName("items")]
    public List<FuelPrice>? Items { get; set; }
}

/// <summary>
///     Represents the price of a specific type of fuel at a station.
///     This includes the transaction date in UTC, deletion status, last changed timestamp, version, creation and update
///     timestamps, ID, and a list of fuels.
/// </summary>
public class FuelPrice
{
    [JsonPropertyName("_deleted")]
    public bool? Deleted { get; set; }

    [JsonPropertyName("_lastChangedAt")]
    public long? LastChangedAt { get; set; }

    [JsonPropertyName("_version")]
    public int? Version { get; set; }

    [JsonPropertyName("createdAt")]
    public DateTimeOffset? CreatedAt { get; set; }

    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("updatedAt")]
    public DateTimeOffset? UpdatedAt { get; set; }

    [JsonPropertyName("fuels")]
    public List<Fuel>? Fuels { get; set; }
}

/// <summary>
///     Represents a specific type of fuel.
///     This includes the collection method, fuel groups, fuel ID, name, price, transaction date in UTC, and band.
/// </summary>
public class Fuel
{
    [JsonPropertyName("CollectionMethod")]
    public string? CollectionMethod { get; set; }

    [JsonPropertyName("FuelGroups")]
    public List<List<string>>? FuelGroups { get; set; }

    [JsonPropertyName("FuelId")]
    public int? FuelId { get; set; }

    [JsonPropertyName("Name")]
    public string? Name { get; set; }

    [JsonPropertyName("Price")]
    public decimal? Price { get; set; }

    [JsonPropertyName("TransactionDateUtc")]
    public DateTimeOffset? TransactionDateUtc { get; set; }

    [JsonPropertyName("band")]
    public string? Band { get; set; }
}

/// <summary>
///     Represents the fuel brands available at different stations.
///     This includes the next token for pagination, the time the sync started, and a list of fuel brands.
/// </summary>
public class SyncFuelBrands
{
    [JsonPropertyName("nextToken")]
    public string? NextToken { get; set; }

    [JsonPropertyName("startedAt")]
    public long? StartedAt { get; set; }

    [JsonPropertyName("items")]
    public List<FuelBrand>? Items { get; set; }
}

/// <summary>
///     Represents a specific fuel brand.
///     This includes the deletion status, last changed timestamp, version, creation and update timestamps, ID, logo, and
///     name.
/// </summary>
public class FuelBrand
{
    [JsonPropertyName("_deleted")]
    public bool? Deleted { get; set; }

    [JsonPropertyName("_lastChangedAt")]
    public long? LastChangedAt { get; set; }

    [JsonPropertyName("_version")]
    public int? Version { get; set; }

    [JsonPropertyName("createdAt")]
    public DateTimeOffset? CreatedAt { get; set; }

    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("logo")]
    public Uri? Logo { get; set; }

    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("updatedAt")]
    public DateTimeOffset? UpdatedAt { get; set; }
}
