﻿using Microsoft.Extensions.Options;

namespace Cloud.Services.Fuel.Common.Settings.Validators
{
    public class ArevoSettingsValidator : IValidateOptions<ArevoSettings>
    {
        public ValidateOptionsResult Validate(string? name, ArevoSettings options)
        {
            if (options is null)
                return ValidateOptionsResult.Fail(
                    "Arevo settings is null.");

            if (string.IsNullOrWhiteSpace(options.ApiKey))
                return ValidateOptionsResult.Fail(
                    $"Property '{nameof(ArevoSettings.ApiKey)}' cannot be blank.");

            if (string.IsNullOrWhiteSpace(options.BaseUrl))
                return ValidateOptionsResult.Fail(
                    $"Property '{nameof(ArevoSettings.BaseUrl)}' cannot be blank.");

            return ValidateOptionsResult.Success;
        }
    }
}
