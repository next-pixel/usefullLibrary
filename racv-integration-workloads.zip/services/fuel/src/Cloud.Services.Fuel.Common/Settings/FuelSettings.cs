﻿
namespace Cloud.Services.Fuel.Common.Settings
{
    public class FuelSettings
    {
        public const string ConfigurationSectionName = "FuelSettings";
        public Dictionary<string, MemberDiscounts> MemberDiscounts { get; set; }

    }

    public class MemberDiscounts
    {
        public const string ConfigurationSectionName = "MemberDiscounts";

        public int DiscountValue { get; set; }
        public string DiscountType { get; set; }
    }

}
