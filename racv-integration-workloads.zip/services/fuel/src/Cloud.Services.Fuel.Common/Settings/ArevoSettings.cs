namespace Cloud.Services.Fuel.Common.Settings;

public class ArevoSettings
{
    public const string ConfigurationSectionName = "ArevoSettings";
    public string? BaseUrl { get; set; } = null;
    public string? ApiKey { get; set; } = null;
    public int MaxItemsSize { get; set; } = 500;
}
