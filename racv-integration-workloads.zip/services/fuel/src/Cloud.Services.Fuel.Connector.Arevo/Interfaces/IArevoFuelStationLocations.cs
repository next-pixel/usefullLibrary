using Cloud.Services.Fuel.Common.Models.Arevo.Response;

namespace Cloud.Services.Fuel.Connector.Arevo.Interfaces;

public interface IArevoFuelStationLocations
{
    Task<StationLocationsResponse> GetFuelStationLocations(Guid xCorrelationIdentifier, long watermark);
}
