using System.Text;
using GraphQL;

namespace Cloud.Services.Fuel.Connector.Arevo.Utilities;

/// <summary>
///     Contains GraphQL queries used in the ArevoFuelStationLocations class.
/// </summary>
public static class GraphQLQueries
{
    private const string SyncStationDetailsTemplate =
        "  syncStationDetails(filter: {{last_updated: {{gt: $lastUpdated }}}}, limit: $limit, nextToken: \"{0}\") {{\n    nextToken\n    startedAt\n    items {{\n      Address\n      BrandId\n      Latitude\n      Longitude\n      Name\n      _deleted\n      PostCode\n      _lastChangedAt\n      _version\n      createdAt\n      updatedAt\n      opening_hours\n      last_updated\n      id\n      facilities\n      discount_value\n      discount\n    }}\n  }}\n";

    private const string SyncFuelPricesTemplate =
        "  syncFuelPrices(filter: {{TransactionDateUtc: {{gt: $lastUpdated }}}}, limit: $limit, nextToken: \"{0}\") {{\n    nextToken\n    startedAt\n    items {{\n      TransactionDateUtc\n      _deleted\n      _lastChangedAt\n      _version\n      createdAt\n      id\n      updatedAt\n      fuels {{\n        CollectionMethod\n        FuelGroups\n        FuelId\n        Name\n        Price\n        TransactionDateUtc\n        band\n      }}\n    }}\n  }}\n";

    private const string SyncFuelBrandsTemplate =
       "  syncFuelBrands(lastSync:{1}, limit: $limit, nextToken: \"{0}\") {{\n    nextToken\n    startedAt\n    items {{\n      _deleted\n      _lastChangedAt\n      _version\n      createdAt\n      id\n      logo\n      name\n      updatedAt\n    }}\n  }}\n";


    /// <summary>
    ///     Constructs a GraphQL request for fetching fuel station locations from Arevo.
    /// </summary>
    /// <param name="watermark">A timestamp indicating the last time data was fetched.</param>
    /// <param name="maxItemsSize">The maximum number of items to fetch in one request.</param>
    /// <param name="sdNextToken">The next token for station details pagination.</param>
    /// <param name="fpNextToken">The next token for fuel prices pagination.</param>
    /// <param name="fbNextToken">The next token for fuel brands pagination.</param>
    /// <returns>A GraphQLRequest object that can be sent to Arevo.</returns>
    public static GraphQLRequest FuelStationLocations(long watermark, int maxItemsSize, string? sdNextToken,
        string? fpNextToken, string? fbNextToken)
    {
        var stringBuilder = new StringBuilder();

        // Format the watermark
        DateTimeOffset watermarkDTOffset = DateTimeOffset.FromUnixTimeSeconds(watermark);

        string formattedWatermark = watermarkDTOffset.UtcDateTime.ToString("yyyy-MM-ddTHH:mm:ss");

        // Construct the query
        stringBuilder.AppendLine("query GetSyncData($lastUpdated: String!, $limit: Int!) {");

        if (sdNextToken != null)
        {
            stringBuilder.AppendFormat(SyncStationDetailsTemplate, sdNextToken);
        }

        if (fpNextToken != null)
        {
            stringBuilder.AppendFormat(SyncFuelPricesTemplate, fpNextToken);
        }

        if (fbNextToken != null)
        {
            stringBuilder.AppendFormat(SyncFuelBrandsTemplate, fbNextToken, watermark * 1000);
        }

        stringBuilder.AppendLine("}");

        return new GraphQLRequest
        {
            Query = stringBuilder.ToString(),
            Variables = new
            {
                lastUpdated = formattedWatermark,
                limit = maxItemsSize
            }
        };
    }
}
