using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Utility.Wrapper.Interfaces;
using Cloud.Services.Fuel.Common.Models.Arevo.Response;
using Cloud.Services.Fuel.Common.Settings;
using Cloud.Services.Fuel.Connector.Arevo.Interfaces;
using Cloud.Services.Fuel.Connector.Arevo.Utilities;
using GraphQL;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using System.Runtime.Serialization;
using System.Text.Json;

namespace Cloud.Services.Fuel.Connector.Arevo.Implementations;

/// <summary>
///     Responsible for fetching and processing fuel station locations data from Arevo.
///     It implements the IArevoFuelStationLocations interface.
/// </summary>
public class ArevoFuelStationLocations : IArevoFuelStationLocations
{
    private readonly IGraphQLHttpWrapper<GraphQLRequest, GraphQLResponse<JObject>> _graphQLClient;
    private readonly ArevoSettings _arevoSettings;
    private readonly ILogger<ArevoFuelStationLocations> _logger;

    /// <summary>
    ///     Initializes a new instance of the <see cref="ArevoFuelStationLocations" /> class.
    /// </summary>
    /// <param name="logger">The logger.</param>
    /// <param name="configuration"></param>
    public ArevoFuelStationLocations(
        ILogger<ArevoFuelStationLocations> logger,
        IGraphQLHttpWrapper<GraphQLRequest, GraphQLResponse<JObject>> graphQLClient,
        IOptions<ArevoSettings> arevoSettings)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _arevoSettings = arevoSettings.Value ?? throw new ArgumentNullException(nameof(arevoSettings));
        _graphQLClient = graphQLClient ?? throw new ArgumentNullException(nameof(graphQLClient));
    }

    /// <summary>
    ///     Retrieves fuel station locations from Arevo.
    ///     This method fetches data from Arevo using GraphQL, processes the data, and returns a list of fuel station
    ///     locations.
    /// </summary>
    /// <param name="xCorrelationIdentifier">A unique identifier for correlating logs and errors.</param>
    /// <param name="watermark">A timestamp indicating the last time data was fetched.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains the station locations response.</returns>
    public async Task<StationLocationsResponse> GetFuelStationLocations(Guid xCorrelationIdentifier, long watermark)
    {
        // Initialize a list to store fuel station locations
        var fuelStationLocations = new List<StationLocationsResponse>();

        // Initialize tokens for pagination
        var sdNextToken = string.Empty;
        var fpNextToken = string.Empty;
        var fbNextToken = string.Empty;

        try
        {
            // Loop until all pages of data have been fetched from Arevo.
            do
            {
                // Fetch fuel station locations from Arevo using GraphQL.
                var response = await GetGraphQLFuelStationLocations(xCorrelationIdentifier, watermark, sdNextToken,
                    fpNextToken, fbNextToken);

                // If there are any errors in the response, log them and throw an exception.
                HandleGraphQLErrors(response, xCorrelationIdentifier);

                // Deserialize the response data into a StationLocationsResponse object and add it to the list.
                var fuelStationLocation =
                    JsonSerializer.Deserialize<StationLocationsResponse>(response.Data.ToString());
                if (fuelStationLocation != null)
                {
                    fuelStationLocations.Add(fuelStationLocation);

                    // Update the next tokens for pagination.
                    sdNextToken = sdNextToken != null ? fuelStationLocation.SyncStationDetails?.NextToken : null;
                    fpNextToken = fpNextToken != null ? fuelStationLocation.SyncFuelPrices?.NextToken : null;
                    fbNextToken = fbNextToken != null ? fuelStationLocation.SyncFuelBrands?.NextToken : null;
                }
            } while (!(string.IsNullOrWhiteSpace(sdNextToken) && string.IsNullOrWhiteSpace(fpNextToken) &&
                       string.IsNullOrWhiteSpace(fbNextToken)));

            // Flatten the list of fuel station locations into a single StationLocationsResponse object and return it.
            return FlattenFuelStationLocations(fuelStationLocations, sdNextToken, fpNextToken, fbNextToken);
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                "} Retrieving Fuel Station Locations from Arevo failed with error: {message}",
                xCorrelationIdentifier, ex.Message);

            throw new InvalidOperationException(
                $"Retrieving Fuel Station Locations from Arevo failed with error: {ex.Message}", ex);
        }
        catch (SerializationException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                "} Deserialization of Fuel Station Locations from Microservice failed with error: {message}",
                xCorrelationIdentifier, ex.Message);

            throw new SerializationException(
                $"Deserialization of Fuel Station Locations from Arevo failed with error: {ex.Message}", ex);
        }
    }

    /// <summary>
    ///     Retrieves fuel station locations from Arevo using GraphQL.
    ///     This method sends a GraphQL query to Arevo and returns the response.
    /// </summary>
    /// <param name="watermark">A timestamp indicating the last time data was fetched.</param>
    /// <param name="sdNextToken">The next token for station details pagination.</param>
    /// <param name="fpNextToken">The next token for fuel prices pagination.</param>
    /// <param name="fbNextToken">The next token for fuel brands pagination.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains the GraphQL response.</returns>
    private async Task<GraphQLResponse<JObject>> GetGraphQLFuelStationLocations(Guid xCorrelationIdentifier,
        long watermark, string? sdNextToken,
        string? fpNextToken, string? fbNextToken)
    {
        var query = GraphQLQueries.FuelStationLocations(watermark, _arevoSettings.MaxItemsSize, sdNextToken, fpNextToken,
            fbNextToken);
        return await _graphQLClient.SendAsync(query, xCorrelationIdentifier, _arevoSettings.ApiKey!);
    }

    /// <summary>
    ///     Handles any errors that may occur during the execution of a GraphQL query.
    /// </summary>
    /// <param name="response">The response from the GraphQL query.</param>
    /// <param name="xCorrelationIdentifier">A unique identifier for correlating logs and errors.</param>
    /// <exception cref="InvalidOperationException">Thrown when there are errors in the GraphQL response.</exception>
    private void HandleGraphQLErrors(GraphQLResponse<JObject> response, Guid xCorrelationIdentifier)
    {
        if (response.Errors is null)
        {
            return;
        }

        var errorMessage = string.Join(", ", response.Errors.Select(e => e.Message));
        _logger.LogError("CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                         "} GraphQL query failed with errors: {message}", xCorrelationIdentifier,
            errorMessage);
        throw new InvalidOperationException($"GraphQL query failed with errors: {errorMessage}");
    }

    /// <summary>
    ///     Flattens the fuel station locations data.
    ///     This method takes a list of fuel station locations and combines them into a single StationLocationsResponse object.
    /// </summary>
    /// <param name="fuelStationLocations">The list of fuel station locations.</param>
    /// <param name="sdNextToken">The next token for station details pagination.</param>
    /// <param name="fpNextToken">The next token for fuel prices pagination.</param>
    /// <param name="fbNextToken">The next token for fuel brands pagination.</param>
    /// <returns>The flattened station locations response.</returns>
    private StationLocationsResponse FlattenFuelStationLocations(List<StationLocationsResponse> fuelStationLocations,
        string? sdNextToken, string? fpNextToken, string? fbNextToken)
    {
        var firstStationLocation = fuelStationLocations.FirstOrDefault();

        var stationDetailsItems = fuelStationLocations
            .SelectMany(f => f.SyncStationDetails?.Items ?? [])
            .ToList();

        var fuelPricesItems = fuelStationLocations
            .SelectMany(f => f.SyncFuelPrices?.Items ?? [])
            .ToList();

        var fuelBrandsItems = fuelStationLocations
            .SelectMany(f => f.SyncFuelBrands?.Items ?? [])
            .ToList();

        return new StationLocationsResponse
        {
            SyncStationDetails =
                new SyncStationDetails
                {
                    NextToken = sdNextToken,
                    StartedAt = firstStationLocation?.SyncStationDetails?.StartedAt,
                    Items = stationDetailsItems
                },
            SyncFuelPrices =
                new SyncFuelPrices
                {
                    NextToken = fpNextToken,
                    StartedAt = firstStationLocation?.SyncFuelPrices?.StartedAt,
                    Items = fuelPricesItems
                },
            SyncFuelBrands = new SyncFuelBrands
            {
                NextToken = fbNextToken,
                StartedAt = firstStationLocation?.SyncFuelBrands?.StartedAt,
                Items = fuelBrandsItems
            }
        };
    }
}
