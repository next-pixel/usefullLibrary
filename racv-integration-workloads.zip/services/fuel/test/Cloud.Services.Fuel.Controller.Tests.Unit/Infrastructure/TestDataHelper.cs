using System.Globalization;
using ServiceResponse = Cloud.Services.Fuel.Api.Models.Response;
using ArevoResponse = Cloud.Services.Fuel.Common.Models.Arevo.Response;

namespace Cloud.Services.Fuel.Controller.Tests.Unit.Infrastructure;

public static class TestDataHelper
{
    /// <summary>
    ///     Generates a mock Arevo response for testing.
    /// </summary>
    /// <returns>A mock Arevo response.</returns>
    public static ArevoResponse.StationLocationsResponse GetExpectedArevoResponse()
    {
        return new ArevoResponse.StationLocationsResponse
        {
            SyncStationDetails =
                new ArevoResponse.SyncStationDetails
                {
                    NextToken = null,
                    StartedAt = 1714918949451,
                    Items =
                    [
                        new ArevoResponse.StationDetail
                        {
                            Address = "1 Example Valley Highway",
                            BrandId = 3421073,
                            Latitude = -37.254435,
                            Longitude = 145.798177,
                            Name = "Example Valley Service Station",
                            Deleted = null,
                            PostCode = "3712",
                            LastChangedAt = 1714913439,
                            Version = 1,
                            CreatedAt =
                                DateTime.Parse("2024-05-05T12:50:39.754818Z",
                                    CultureInfo.InvariantCulture),
                            UpdatedAt =
                                DateTime.Parse("2024-05-05T12:50:39.754818Z",
                                    CultureInfo.InvariantCulture),
                            OpeningHours = "Trading Hours",
                            LastUpdated = DateTimeOffset.Parse("2023-03-08T02:23:01.913 +11:00", 
                                CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal).UtcDateTime,

                            Id = "ISS-61291528",
                            Facilities =
                            [
                                "{Shop On Site=Yes}",
                                "{Gas Bottles=Yes}",
                                "{Car Wash on Site=Yes}",
                                "{Car Wash types -  Rollover (automatic) =Yes}",
                                "{Coin Operated Vacuum=Yes}"
                            ],
                            DiscountValue = 5,
                            Discount = "ENABLED"
                        }
                    ]
                },
            SyncFuelPrices = new ArevoResponse.SyncFuelPrices
            {
                NextToken = null,
                StartedAt = 1714918949451,
                Items =
                [
                    new ArevoResponse.FuelPrice
                    {
                        Deleted = null,
                        LastChangedAt = 1714854018,
                        Version = 92,
                        CreatedAt = DateTime.Parse("2024-05-04T20:20:18.839426Z", CultureInfo.InvariantCulture),
                        Id = "ISS-61301403",
                        UpdatedAt = DateTimeOffset.Parse("2024-05-04T20:20:18.839426Z", 
                                CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal).UtcDateTime,

                        Fuels =
                        [
                            new ArevoResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups =
                                    [["Unleaded 91", "e10"]],
                                FuelId = 2,
                                Name = "Unleaded",
                                Price = 1987,
                                TransactionDateUtc =
                                    DateTime.Parse("2024-05-03T20:22:00.000Z",
                                        CultureInfo.InvariantCulture),
                                Band = "1983.3992994746059,2163.774418604651"
                            },
                            new ArevoResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups =
                                    [["Diesel", "Premium Diesel"]],
                                FuelId = 3,
                                Name = "Diesel",
                                Price = 1887,
                                TransactionDateUtc =
                                    DateTime.Parse("2024-05-03T20:22:00.000Z",
                                        CultureInfo.InvariantCulture),
                                Band = "1981.2326530612245,2055.793103448276"
                            },
                            new ArevoResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups = [["LPG"]],
                                FuelId = 4,
                                Name = "LPG",
                                Price = 837,
                                TransactionDateUtc =
                                    DateTime.Parse("2024-05-03T20:22:00.000Z",
                                        CultureInfo.InvariantCulture),
                                Band = "895.3783783783783,1009.2931596091205"
                            },
                            new ArevoResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups = [["e10"]],
                                FuelId = 12,
                                Name = "e10",
                                Price = 1967,
                                TransactionDateUtc =
                                    DateTime.Parse("2024-05-03T20:22:00.000Z",
                                        CultureInfo.InvariantCulture),
                                Band = "1963.3471074380166,2131.037037037037"
                            },
                            new ArevoResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups =
                                    [["Unleaded 91", "e10"]],
                                FuelId = 999,
                                Name = "e10/Unleaded",
                                Price = 1967,
                                TransactionDateUtc =
                                    DateTime.Parse("2024-05-03T20:22:00.000Z",
                                        CultureInfo.InvariantCulture),
                                Band = "1968.361493123772,2146.2926829268295"
                            },
                            new ArevoResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups =
                                    [["Diesel", "Premium Diesel"]],
                                FuelId = 1000,
                                Name = "Diesel/Premium Diesel",
                                Price = 1887,
                                TransactionDateUtc =
                                    DateTime.Parse("2024-05-03T20:22:00.000Z",
                                        CultureInfo.InvariantCulture),
                                Band = "1985.5202702702702,2059.344768439108"
                            }
                        ]
                    }
                ]
            },
            SyncFuelBrands = new ArevoResponse.SyncFuelBrands
            {
                NextToken = null,
                StartedAt = 1714918949451,
                Items =
                [
                    new ArevoResponse.FuelBrand
                    {
                        Deleted = null,
                        LastChangedAt = 1713315040,
                        Version = 1,
                        CreatedAt =
                            DateTime.Parse("2024-04-17T00:50:40.830522Z", CultureInfo.InvariantCulture),
                        Id = "ISB-2459022",
                        Logo =
                            new Uri(
                                "https://arevo.example/fuel/icons/example-fuel-brand.png"),
                        Name = "Example Fuel Brand",
                        UpdatedAt = DateTime.Parse("2024-04-17T00:50:40.830522Z",
                            CultureInfo.InvariantCulture)
                    }
                ]
            }
        };
    }

    /// <summary>
    ///     Generates a mock service response for testing.
    /// </summary>
    /// <returns>A mock service response.</returns>
    public static ServiceResponse.StationLocationsResponse GetExpectedServiceResponse()
    {
        return new ServiceResponse.StationLocationsResponse
        {
            Message = "Operation successful.",
            Data = new ServiceResponse.Location
            {
                StationDetails =
                [
                    new ServiceResponse.StationDetail
                    {
                        Address = "1 Example Valley Highway",
                        BrandId = "3421073",
                        Latitude = -37.254435,
                        Longitude = 145.798177,
                        Name = "Example Valley Service Station",
                        Deleted = false,
                        PostCode = "3712",
                        LastChangedAt = 1714913439,
                        Version = 1,
                        CreatedAt = DateTime.Parse("2024-05-05T12:50:39.754818Z", CultureInfo.InvariantCulture),
                        UpdatedAt = DateTime.Parse("2024-05-05T12:50:39.754818Z", CultureInfo.InvariantCulture),
                        OpeningHours = "Trading Hours",
                        LastUpdated = DateTimeOffset.Parse("2023-03-08T02:23:01.913 +11:00", 
                            CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal).UtcDateTime,

                        Id = "ISS-61291528",
                        Facilities =
                        [
                            "Shop On Site",
                            "Gas Bottles",
                            "Car Wash on Site",
                            "Car Wash types - Rollover (automatic)",
                            "Coin Operated Vacuum"
                        ],
                        DiscountValue = 5,
                        Discount = "ENABLED"
                    }
                ],
                StationPrices =
                [
                    new ServiceResponse.StationPrice
                    {
                        Deleted = false,
                        LastChangedAt = 1714854018,
                        Version = 92,
                        CreatedAt = DateTime.Parse("2024-05-04T20:20:18.839426Z", CultureInfo.InvariantCulture),
                        Id = "ISS-61301403",
                        UpdatedAt = DateTime.Parse("2024-05-03T20:22:00.000Z", CultureInfo.InvariantCulture),
                        Fuels =
                        [
                            new ServiceResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups = ["Unleaded 91", "e10"],
                                FuelId = 2,
                                Name = "Unleaded",
                                Price = 1987,
                                TransactionDateUtc = DateTime.Parse("2024-05-03T20:22:00.000Z", CultureInfo.InvariantCulture),
                                Band = null
                            },
                            new ServiceResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups = ["Diesel", "Premium Diesel"],
                                FuelId = 3,
                                Name = "Diesel",
                                Price = 1887,
                                TransactionDateUtc = DateTime.Parse("2024-05-03T20:22:00.000Z", CultureInfo.InvariantCulture),
                                Band = null
                            },
                            new ServiceResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups = ["LPG"],
                                FuelId = 4,
                                Name = "LPG",
                                Price = 837,
                                TransactionDateUtc = DateTime.Parse("2024-05-03T20:22:00.000Z", CultureInfo.InvariantCulture),
                                Band = null
                            },
                            new ServiceResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups = ["e10"],
                                FuelId = 12,
                                Name = "e10",
                                Price = 1967,
                                TransactionDateUtc = DateTime.Parse("2024-05-03T20:22:00.000Z", CultureInfo.InvariantCulture),
                                Band = null
                            },
                            new ServiceResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups = ["Unleaded 91", "e10"],
                                FuelId = 999,
                                Name = "e10/Unleaded",
                                Price = 1967,
                                TransactionDateUtc = DateTime.Parse("2024-05-03T20:22:00.000Z", CultureInfo.InvariantCulture),
                                Band = null
                            },
                            new ServiceResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups = ["Diesel", "Premium Diesel"],
                                FuelId = 1000,
                                Name = "Diesel/Premium Diesel",
                                Price = 1887,
                                TransactionDateUtc = DateTime.Parse("2024-05-03T20:22:00.000Z", CultureInfo.InvariantCulture),
                                Band = null
                            }
                        ]
                    }
                ],
                Brands =
                [
                    new ServiceResponse.Brand
                    {
                        Deleted = false,
                        LastChangedAt = 1713315040,
                        Version = 1,
                        CreatedAt = DateTime.Parse("2024-04-17T00:50:40.830522Z", CultureInfo.InvariantCulture),
                        Id = "2459022",
                        Logo =
                            new Uri(
                                "https://arevo.example/fuel/icons/example-fuel-brand.png"),
                        Name = "Example Fuel Brand",
                        UpdatedAt = DateTime.Parse("2024-04-17T00:50:40.830522Z", CultureInfo.InvariantCulture)
                    }
                ]
            }
        };
    }
}
