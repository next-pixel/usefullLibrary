using Cloud.Services.Fuel.Api.Controllers;
using Cloud.Services.Fuel.Connector.Arevo.Interfaces;
using Cloud.Services.Fuel.Controller.Tests.Unit.Infrastructure;
using Cloud.Services.Fuel.Common.Settings;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using ServiceResponse = Cloud.Services.Fuel.Api.Models.Response;
using Microsoft.Extensions.Options;

namespace Cloud.Services.Fuel.Controller.Tests.Unit.UnitTests;

/// <summary>
///     This class contains unit tests for the <see cref="StationLocationsController" />.
/// </summary>
public class StationLocationsControllerTest
{
    private const string Watermark = "1714914440";
    private const long MsWatermark = 1714914440;
    private readonly Mock<IArevoFuelStationLocations> _mockArevoFuelStationLocations;
    private readonly Mock<ILogger<StationLocationsController>> _mockLogger;
    private readonly StationLocationsController _stationLocationsController;
    private readonly Guid _xCorrelationIdentifier;

    /// <summary>
    ///     Initializes a new instance of the StationLocationsControllerTest class.
    /// </summary>
    public StationLocationsControllerTest()
    {
        _mockLogger = LoggerHelper.GetLogger<StationLocationsController>();
        _mockArevoFuelStationLocations = new Mock<IArevoFuelStationLocations>();
        var fuelSettings = new FuelSettings
        {
            MemberDiscounts = new Dictionary<string, MemberDiscounts>
            {
                { "3421073", new MemberDiscounts { DiscountValue = 5, DiscountType = "offset" } }
            }
        };

        // Wrap FuelSettings in IOptions<FuelSettings>
        var options = new OptionsWrapper<FuelSettings>(fuelSettings);

        _stationLocationsController =
            new StationLocationsController(_mockLogger.Object, _mockArevoFuelStationLocations.Object, options);
        _xCorrelationIdentifier = Guid.NewGuid();

        _mockArevoFuelStationLocations
            .Setup(service => service.GetFuelStationLocations(_xCorrelationIdentifier, MsWatermark))
            .ReturnsAsync(TestDataHelper.GetExpectedArevoResponse);
    }

    /// <summary>
    ///     Test case for GetAsync method in StationLocationsController.
    ///     This test verifies that the GetAsync method returns the expected result when called with valid parameters.
    /// </summary>
    [Fact]
    public async Task StationLocationsController_GetFuelStationLocations_ShouldPass()
    {
        // Arrange

        // Act
        var result = await _stationLocationsController.GetAsync(_xCorrelationIdentifier, Watermark);

        // Assert
        result.Should().NotBeNull();

        var okResult = result.Result as OkObjectResult;
        okResult.Should().NotBeNull();
        okResult.Should().BeOfType<OkObjectResult>();
        okResult?.StatusCode.Should().Be(StatusCodes.Status200OK);

        var returnValue = okResult?.Value as ServiceResponse.StationLocationsResponse;
        returnValue.Should().NotBeNull();
        returnValue.Should().BeOfType<ServiceResponse.StationLocationsResponse>();
        returnValue.Should().BeEquivalentTo(TestDataHelper.GetExpectedServiceResponse());

        _mockArevoFuelStationLocations.Verify(
            service => service.GetFuelStationLocations(_xCorrelationIdentifier, MsWatermark),
            Times.Once);
    }
}
