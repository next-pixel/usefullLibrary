﻿using Cloud.Services.Fuel.Common.Settings;
using Cloud.Services.Fuel.Common.Settings.Validators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cloud.Services.Fuel.Common.Tests.Settings
{
    public class ArevoSettingsValidatorTests
    {
        private readonly ArevoSettingsValidator _validator;

        public ArevoSettingsValidatorTests()
        {
            _validator = new ArevoSettingsValidator();
        }

        [Fact]
        public void Validate_WithNullOptions_ReturnsFailResult()
        {
            // Arrange
            ArevoSettings? options = null;

            // Act
            var result = _validator.Validate(null, options!);

            // Assert
            Assert.False(result.Succeeded);
            Assert.Equal("Arevo settings is null.", result.FailureMessage);
        }

        [Fact]
        public void Validate_WithBlankApiKey_ReturnsFailResult()
        {
            // Arrange
            var options = new ArevoSettings
            {
                ApiKey = "",
                BaseUrl = "https://example.com"
            };

            // Act
            var result = _validator.Validate(null, options);

            // Assert
            Assert.False(result.Succeeded);
            Assert.Equal("Property 'ApiKey' cannot be blank.", result.FailureMessage);
        }

        [Fact]
        public void Validate_WithBlankBaseUrl_ReturnsFailResult()
        {
            // Arrange
            var options = new ArevoSettings
            {
                ApiKey = "valid_api_key",
                BaseUrl = ""
            };

            // Act
            var result = _validator.Validate(null, options);

            // Assert
            Assert.False(result.Succeeded);
            Assert.Equal("Property 'BaseUrl' cannot be blank.", result.FailureMessage);
        }

        [Fact]
        public void Validate_WithValidOptions_ReturnsSuccessResult()
        {
            // Arrange
            var options = new ArevoSettings
            {
                ApiKey = "valid_api_key",
                BaseUrl = "https://example.com"
            };

            // Act
            var result = _validator.Validate(null, options);

            // Assert
            Assert.True(result.Succeeded);
        }
    }
}
