using System.Security.Cryptography;
using System.Text;
using Cloud.Services.Cryptography.Api.Implementations;
using Microsoft.Extensions.Logging;
using Moq;

namespace Cloud.Services.Cryptography.Controller.Tests.Unit.Implementations
{
    public class CryptographyHandlerTests
    {
        private readonly CryptographyHandler _handler;
        private readonly Guid _guid;

        public CryptographyHandlerTests()
        {
            Mock<ILogger<CryptographyHandler>> logger = new();
            _handler = new CryptographyHandler(logger.Object);
            _guid = Guid.NewGuid();
        }

        [Fact]
        public void GetAesEncryptedData_WithValidPlainTextAndEncryptionKey_ReturnsEncryptedString()
        {
            // Arrange
            var plainText = "Mock payload to be encrypted";
            var encryptionKey = "ThisIsAMockEncryptionKey";

            // Act
            var encryptedString = _handler.GetAesEncryptedData(plainText, encryptionKey, _guid);
            
            var encryptedDataWithIv = Convert.FromBase64String(encryptedString);
            var iv = new byte[16]; 
            Array.Copy(encryptedDataWithIv, 0, iv, 0, iv.Length);
            
            var decryptedValue = Decrypt(encryptedDataWithIv, Encoding.ASCII.GetBytes(encryptionKey), iv);

            // Assert
            Assert.NotNull(encryptedString);
            Assert.NotEmpty(encryptedString);
            Assert.Contains(plainText, decryptedValue);
        }
        
        [Fact]
        public void GetAesEncryptedData_WithEmptyPlainText_ThrowsArgumentException()
        {
            // Arrange
            
            var plainText = string.Empty;
            var encryptionKey = "ThisIsAMockEncryptionKey";
        
            // Act & Assert
            Assert.Throws<ArgumentException>(() => _handler.GetAesEncryptedData(plainText, encryptionKey, _guid));
        }

        [Fact]
        public void GetAesEncryptedData_WithEmptyEncryptionKey_ThrowsArgumentException()
        {
            // Arrange
            var plainText = "Mock payload to be encrypted";
            var encryptionKey = string.Empty;

            // Act & Assert
            Assert.Throws<ArgumentException>(() => _handler.GetAesEncryptedData(plainText, encryptionKey, _guid));
        }
        
        [Fact]
        public void GetAesEncryptedData_InvalidEncryptionKey_ThrowsCryptographicException()
        {
            // Arrange
            var plainText = "Mock payload to be encrypted";
            var encryptionKey = "WrongLength";

            // Act & Assert
            Assert.Throws<CryptographicException>(() => _handler.GetAesEncryptedData(plainText, encryptionKey, _guid));
        }

        [Fact]
        public void GetHashedValue_WithValidDataStringAndEncryptionKey_ReturnsHashedString()
        {
            // Arrange
            var dataString = "Mock data string";
            var encryptionKey = "mockEncryptionKey";
            var expected = "DF8CFB39E2DBBB80E5E5EFC303985200A32CDB1685A57B8EF26DF15A12E3C893";

            // Act
            var hashedString = _handler.GetHashedValue(dataString, encryptionKey, _guid);

            // Assert
            Assert.NotNull(hashedString);
            Assert.NotEmpty(hashedString);
            Assert.Equal(expected.ToLower(), hashedString);
        }

        [Fact]
        public void GetHashedValue_WithEmptyEncryptionKey_ThrowsArgumentException()
        {
            // Arrange
            var dataString = "Mock data to be hashed";
            var encryptionKey = string.Empty;
            
            // Act & Assert
            Assert.Throws<ArgumentException>(() => _handler.GetHashedValue(dataString, encryptionKey, _guid));
        }

        /// <summary>
        ///     AES Decrypts AES/CBC/PKCS7Padding encrypted string and returns decrypted string.
        /// </summary>
        /// <param name="ciphertext"></param>
        /// <param name="key"></param>
        /// <param name="iv"></param>
        /// <returns>The Hashed string.</returns>
        /// <exception cref="Exception">Thrown when an error occurs during hashing.</exception>
        private static string Decrypt(byte[] ciphertext, byte[]  key, byte[] iv)
        {
            using Aes aesAlg = Aes.Create();
            aesAlg.Mode = CipherMode.CBC;
            aesAlg.Padding = PaddingMode.PKCS7;
            aesAlg.Key = key;
            aesAlg.IV = iv;
            var decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
            byte[] decryptedBytes;
            using (var msDecrypt = new MemoryStream(ciphertext))
            {
                using (var csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                {
                    using (var msPlain = new MemoryStream())
                    {
                        csDecrypt.CopyTo(msPlain);
                        decryptedBytes = msPlain.ToArray();
                    }
                }
            }
            return Encoding.UTF8.GetString(decryptedBytes);
        }
    }
}