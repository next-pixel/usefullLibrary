using Cloud.Services.Cryptography.Api.Extensions;
using Cloud.Services.Cryptography.Api.Models.Request;
using Cloud.Services.Cryptography.Controller.Tests.Unit.UnitTests.TestData;

namespace Cloud.Services.Cryptography.Controller.Tests.Unit.ExtensionTests
{
    public class NeatIdeasRequestExtensionsTests
    {
        [Fact]
        public void IsRequestValid_WithValidRequest_ReturnsTrue()
        {
            // Arrange
            var request = new NeatIdeasRequest
            {
                LastName = "testLastname", MemberNumber = "12345"
            };

            // Act
            var isValid = request.IsRequestValid(out var failureResponseDetails);

            // Assert
            Assert.True(isValid);
            Assert.Null(failureResponseDetails);
        }

        [Theory]
        [ClassData(typeof(NullAndWhitespaceData))]
        public void IsRequestValid_WithInvalidLastName_ReturnsFalseAndFailureResponseDetails(string lastname)
        {
            // Arrange
            var request = new NeatIdeasRequest
            {
                LastName = lastname,
                MemberNumber = "12345"
            };

            // Act
            var isValid = request.IsRequestValid(out var failureResponseDetails);

            // Assert
            Assert.False(isValid);
            Assert.NotNull(failureResponseDetails);
        }
        
        [Theory]
        [ClassData(typeof(NullAndWhitespaceData))]
        public void IsRequestValid_WithInvalidMemberNumber_ReturnsFalseAndFailureResponseDetails(string memberNumber)
        {
            // Arrange
            var request = new NeatIdeasRequest
            {
                LastName = "testLastname",
                MemberNumber = memberNumber
            };

            // Act
            var isValid = request.IsRequestValid(out var failureResponseDetails);

            // Assert
            Assert.False(isValid);
            Assert.NotNull(failureResponseDetails);
        }
    }
}