using Cloud.Services.Cryptography.Api.Extensions;
using Cloud.Services.Cryptography.Controller.Tests.Unit.UnitTests.TestData;

namespace Cloud.Services.Cryptography.Controller.Tests.Unit.ExtensionTests
{
    public class NeatIdeasResponseExtensionsTests
    {
        private const string EncryptedData = "encryptedData"; 
        private const string HashedData = "hashedData";
        private const string? Timestamp = "2022-01-01";
        private const string Url = "https://example.com/neatideas";
        
        [Fact]
        public void Convert_WithValidData_ReturnsNeatIdeasResponse()
        {
            // Act
            var result = EncryptedData.Convert(HashedData, Timestamp, Url);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("Operation successful.", result.Message);
            Assert.NotNull(result.Data);
            Assert.Equal($"{Url}?aes_data={EncryptedData}&hash={HashedData}&timeStamp={Timestamp}", result.Data.AccessUrl);
        }

        [Theory]
        [ClassData(typeof(NullAndWhitespaceData))]
        public void Convert_WithNullEncryptedData_ThrowsArgumentException(string? encryptedData)
        {
            // Act & Assert
            if(encryptedData is null)
                Assert.Throws<ArgumentNullException>(() => encryptedData!.Convert(HashedData, Timestamp, Url));
            else
                Assert.Throws<ArgumentException>(() => encryptedData!.Convert(HashedData, Timestamp, Url));
        }

        [Theory]
        [ClassData(typeof(NullAndWhitespaceData))]
        public void Convert_WithNullHashedData_ThrowsArgumentException(string? hashedData)
        {
            // Act & Assert
            if(hashedData == null) 
                Assert.Throws<ArgumentNullException>(() => EncryptedData.Convert(hashedData, Timestamp, Url));
            else
                Assert.Throws<ArgumentException>(() => EncryptedData.Convert(hashedData, Timestamp, Url));
        }

        [Theory]
        [ClassData(typeof(NullAndWhitespaceData))]
        public void Convert_WithNullUrl_ThrowsArgumentException(string? url)
        {
            // Act & Assert
            if (url == null) 
                Assert.Throws<ArgumentNullException>(() => EncryptedData.Convert(HashedData, Timestamp, url));
            else 
                Assert.Throws<ArgumentException>(() => EncryptedData.Convert(HashedData, Timestamp, url));
        }
    }
}