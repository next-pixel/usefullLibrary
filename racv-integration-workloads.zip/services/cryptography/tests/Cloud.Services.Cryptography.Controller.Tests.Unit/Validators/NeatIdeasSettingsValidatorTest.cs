using Cloud.Services.Cryptography.Api.Constants;
using Cloud.Services.Cryptography.Api.Settings;
using Cloud.Services.Cryptography.Api.Settings.Validators;
using Cloud.Services.Cryptography.Controller.Tests.Unit.UnitTests.TestData;

namespace Cloud.Services.Cryptography.Controller.Tests.Unit.Validators;

public class NeatIdeasSettingsValidatorTests
{
    private readonly NeatIdeasSettingsValidator _validator = new();
    private const string Name = InternalConstants.NeatIdeasSettings;

    [Fact]
    public void Validate_ShouldFail_WhenOptionsIsNull()
    {
        // Arrange
        NeatIdeasSettings options = null;

        // Act
        var result = _validator.Validate(Name, options);

        // Assert
        Assert.False(result.Succeeded);
        Assert.Equal("Configuration object is null.", result.FailureMessage);
    }
    
    [Theory]
    [ClassData(typeof(NullAndWhitespaceData))]
    public void Validate_ShouldFail_WhenBaseUrlIsNull(string url)
    {
        // Arrange
        var options = new NeatIdeasSettings
        {
            BaseUrl = url,
            EncryptionKey = "MockEncryptionKey"
        };

        // Act
        var result = _validator.Validate(Name, options);

        // Assert
        Assert.False(result.Succeeded);
        Assert.Equal("Property 'BaseUrl' cannot be blank.", result.FailureMessage);
    }
    
    [Theory]
    [ClassData(typeof(NullAndWhitespaceData))]
    public void Validate_ShouldFail_WhenEncryptionKeyIsNull(string key)
    {
        // Arrange
        var options = new NeatIdeasSettings
        {
            BaseUrl = "https://example.com",
            EncryptionKey = key
        };

        // Act
        var result = _validator.Validate(Name, options);

        // Assert
        Assert.False(result.Succeeded);
        Assert.Equal("Property 'EncryptionKey' cannot be blank.", result.FailureMessage);
    }

    [Fact]
    public void Validate_ShouldSucceed_WhenOptionsAreValid()
    {
        // Arrange
        var options = new NeatIdeasSettings
        {
            BaseUrl = "https://example.com",
            EncryptionKey = "MockEncryptionKey"
        };

        // Act
        var result = _validator.Validate(Name, options);

        // Assert
        Assert.True(result.Succeeded);
    }
}