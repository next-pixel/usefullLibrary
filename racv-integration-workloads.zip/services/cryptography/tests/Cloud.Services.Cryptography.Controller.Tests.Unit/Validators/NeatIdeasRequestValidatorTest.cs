using Cloud.Services.Cryptography.Api.Models.Request;
using Cloud.Services.Cryptography.Api.Validators;
using Cloud.Services.Cryptography.Controller.Tests.Unit.UnitTests.TestData;
using FluentAssertions;
using FluentValidation.TestHelper;

namespace Cloud.Services.Cryptography.Controller.Tests.Unit.Validators
{
    public class NeatIdeasRequestValidatorTests
    {
        private readonly NeatIdeasRequestValidator _validator = new();

        [Fact]
        public void Validate_WithValidRequest_ShouldNotHaveValidationError()
        {
            // Arrange
            var request = new NeatIdeasRequest
            {
                LastName = "testLastname",
                MemberNumber = "12345"
            };

            // Act
            var result = _validator.TestValidate(request);

            // Assert
            result.IsValid.Should().BeTrue();
            result.ShouldNotHaveAnyValidationErrors();
        }

        [Theory]
        [ClassData(typeof(NullAndWhitespaceData))]
        public void Validate_WithInvalidLastName_ShouldHaveValidationError(string lastName)
        {
            // Arrange
            var request = new NeatIdeasRequest
            {
                LastName = lastName,
                MemberNumber = "12345"
            };

            // Act
            var result = _validator.TestValidate(request);
            
            // Assert
            result.IsValid.Should().BeFalse();
            result.ShouldHaveValidationErrorFor(x => x.LastName);
        }

        [Theory]
        [ClassData(typeof(NullAndWhitespaceData))]
        public void Validate_WithInvalidMemberNumber_ShouldHaveValidationError(string memberNumber)
        {
            // Arrange
            var request = new NeatIdeasRequest
            {
                LastName = "testLastname",
                MemberNumber = memberNumber
            };

            // Act
            var result = _validator.TestValidate(request);
            
            // Assert
            result.IsValid.Should().BeFalse();
            result.ShouldHaveValidationErrorFor(x => x.MemberNumber);
        }
    }
}