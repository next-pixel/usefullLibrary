using System.Security.Cryptography;
using Cloud.Services.Cryptography.Api.Controllers;
using Cloud.Services.Cryptography.Api.Models.Request;
using Cloud.Services.Cryptography.Api.Models.Response;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using Cloud.Services.Common.Exceptions;
using Cloud.Services.Cryptography.Api.Interfaces;
using Cloud.Services.Cryptography.Api.Settings;

namespace Cloud.Services.Cryptography.Controller.Tests.Unit.UnitTests
{
    public class CryptographyControllerTests
    {
        private readonly Mock<ICryptographyHandler> _handler;
        private readonly CryptographyController _controller;
        private readonly IOptions<NeatIdeasSettings> _settings;

        public CryptographyControllerTests()
        {
            Mock<ILogger<CryptographyController>> logger = new();
            _handler = new Mock<ICryptographyHandler>();
            _handler.Setup(x => x.GetAesEncryptedData(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>()))
                .Returns("MockEncryptedData");
            _handler.Setup(x => x.GetHashedValue(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>()))
                .Returns("MockHashedData");
            _settings = Options.Create(new NeatIdeasSettings()
            {
                BaseUrl = "testBaseUrl.com",
                EncryptionKey = "testKey"
            });
            
            _controller = new CryptographyController(logger.Object, _handler.Object, Options.Create(_settings.Value));
        }
        
        [Fact]
        public void PostCryptographyDetails_ValidRequest_ReturnsOkResult()
        {
            // Arrange
            var correlationId = Guid.NewGuid();
            var request = new NeatIdeasRequest
            {
                LastName = "testLastname",
                MemberNumber = "12345"
            };

            // Act
            var result =  _controller.PostCryptographyDetails(correlationId, request);

            // Assert
            Assert.IsType<OkObjectResult>(result.Result);
            var okResult = result.Result as OkObjectResult;
            Assert.IsType<NeatIdeasResponse>(okResult!.Value);
        }

        [Fact]
        public void PostCryptographyDetails_InvalidRequest_ReturnsBadRequest()
        {
            // Arrange
            var correlationId = Guid.NewGuid();
            var request = new NeatIdeasRequest
            {
                LastName = null, // Invalid request
                MemberNumber = "12345"
            };

            // Act
            var result = _controller.PostCryptographyDetails(correlationId, request);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
            var badRequestResult = result.Result as BadRequestObjectResult;
            Assert.IsType<OperationFailureResponse>(badRequestResult!.Value);
        }
        
        [Fact]
        public void PostCryptographyDetails_ValidRequest_AesEncryptionError()
        {
            // Arrange
            _handler.Setup(x => x.GetAesEncryptedData(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>()))
                .Throws(new CryptographicException("An error occurred"));
            
            var correlationId = Guid.NewGuid();
            var request = new NeatIdeasRequest
            {
                LastName = "testLastname",
                MemberNumber = "12345"
            };

            // Act
            var result = _controller.PostCryptographyDetails(correlationId, request);

            // Assert
            Assert.IsType<ObjectResult>(result.Result);
            var failureResult = result.Result as ObjectResult;
            Assert.IsType<OperationFailureResponse>(failureResult!.Value);
        }
        
        [Fact]
        public void PostCryptographyDetailsAsync_ValidRequest_HashError()
        {
            // Arrange
            _handler.Setup(x => x.GetHashedValue(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>()))
                .Throws(new CryptographicException("An error occurred"));
            
            var correlationId = Guid.NewGuid();
            var request = new NeatIdeasRequest
            {
                LastName = "testLastname",
                MemberNumber = "12345"
            };

            // Act
            var result = _controller.PostCryptographyDetails(correlationId, request);

            // Assert
            Assert.IsType<ObjectResult>(result.Result);
            var failureResult = result.Result as ObjectResult;
            Assert.IsType<OperationFailureResponse>(failureResult!.Value);
        }
        
        [Fact]
        public void PostCryptographyDetails_ValidRequest_EncryptionError()
        {
            // Arrange
            _handler.Setup(x => x.GetAesEncryptedData(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>()))
                .Returns(string.Empty);
            
            var correlationId = Guid.NewGuid();
            var request = new NeatIdeasRequest
            {
                LastName = "testLastname",
                MemberNumber = "12345"
            };

            // Act
            var result =  _controller.PostCryptographyDetails(correlationId, request);

            // Assert
            Assert.IsType<ObjectResult>(result.Result);
            var failureResult = result.Result as ObjectResult;
            Assert.IsType<OperationFailureResponse>(failureResult!.Value);
        }
        
        [Fact]
        public void PostCryptographyDetails_ValidRequest_HashError()
        {
            // Arrange
            _handler.Setup(x => x.GetHashedValue(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>()))
                .Returns(string.Empty);
            
            var correlationId = Guid.NewGuid();
            var request = new NeatIdeasRequest
            {
                LastName = "testLastname",
                MemberNumber = "12345"
            };

            // Act
            var result =  _controller.PostCryptographyDetails(correlationId, request);

            // Assert
            Assert.IsType<ObjectResult>(result.Result);
            var failureResult = result.Result as ObjectResult;
            Assert.IsType<OperationFailureResponse>(failureResult!.Value);
        }
        
        [Fact]
        public void PostCryptographyDetails_ValidRequest_UrlError()
        {
            // Arrange
            _settings.Value.BaseUrl = null;
            
            var correlationId = Guid.NewGuid();
            var request = new NeatIdeasRequest
            {
                LastName = "testLastname",
                MemberNumber = "12345"
            };

            // Act
            var result =  _controller.PostCryptographyDetails(correlationId, request);

            // Assert
            Assert.IsType<ObjectResult>(result.Result);
            var failureResult = result.Result as ObjectResult;
            Assert.IsType<OperationFailureResponse>(failureResult!.Value);
        }
    }
}