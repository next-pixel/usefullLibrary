using System.Collections;

namespace Cloud.Services.Cryptography.Controller.Tests.Unit.UnitTests.TestData;

public class NullAndWhitespaceData : IEnumerable<object[]>
{
    public IEnumerator<object[]> GetEnumerator()
    {
        return new List<object[]>
        {
            new object[1],
            new object[1] { "" },
            new object[1] { " " },
            new object[1] { "       " },
            new object[1] { "\n" },
            new object[1] { "\t" },
            new object[1] { Environment.NewLine }
        }.GetEnumerator();
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}