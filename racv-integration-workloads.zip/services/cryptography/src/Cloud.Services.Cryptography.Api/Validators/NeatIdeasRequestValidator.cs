using Cloud.Services.Cryptography.Api.Models.Request;
using FluentValidation;

namespace Cloud.Services.Cryptography.Api.Validators;

public class NeatIdeasRequestValidator: AbstractValidator<NeatIdeasRequest>
{
    public NeatIdeasRequestValidator()
    {
        RuleFor(m => m.MemberNumber).NotEmpty();
        RuleFor(x => x.LastName).NotEmpty();
    }
}