using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Exceptions;
using Cloud.Services.Cryptography.Api.Constants;
using Cloud.Services.Cryptography.Api.Extensions;
using Cloud.Services.Cryptography.Api.Interfaces;
using Cloud.Services.Cryptography.Api.Models.Request;
using Cloud.Services.Cryptography.Api.Models.Response;
using Cloud.Services.Cryptography.Api.Settings;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;


namespace Cloud.Services.Cryptography.Api.Controllers;

/// <summary>
/// Controller for handling requests related to cryptography details.
/// </summary>
[ApiController]
[Route("v1")]
public class CryptographyController: ControllerBase
{
    private readonly ILogger<CryptographyController> _logger;
    private readonly ICryptographyHandler _cryptographyHandler;
    private readonly NeatIdeasSettings _neatIdeasSettings;

    /// <summary>
    /// Initializes a new instance of the <see cref="CryptographyController" /> class.
    /// </summary>
    /// <param name="logger">The logger.</param>
    /// <param name="cryptographyHandler"></param>
    /// <param name="neatIdeasSettings"></param>
    /// <exception cref="ArgumentNullException"></exception>
    public CryptographyController(ILogger<CryptographyController> logger, ICryptographyHandler cryptographyHandler,
        IOptions<NeatIdeasSettings> neatIdeasSettings)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _cryptographyHandler = cryptographyHandler?? throw new ArgumentNullException(nameof(cryptographyHandler));
        _neatIdeasSettings = neatIdeasSettings.Value ?? throw new ArgumentNullException(nameof(neatIdeasSettings));
    }

    /// <summary>
    /// Creates the encrypted and hashed details.
    /// </summary>
    /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
    /// <param name="cryptographyRequest">Request payload</param>
    /// <exception cref="ArgumentNullException"></exception>
    /// <returns>The action result.</returns>
    [HttpPost("neatideas-endpoint")]
    [Authorize]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Produces("application/json")]
    public ActionResult<NeatIdeasResponse> PostCryptographyDetails(
        [FromHeader(Name = ServicesConstants.CorrelationIdLogPropertyName)]
        Guid xCorrelationIdentifier,
        [FromBody] NeatIdeasRequest cryptographyRequest)
    {
        _logger.LogInformation(
            "CorrelationId : { "
            + ServicesConstants.CorrelationIdLogPropertyName
            + "} Started executing Post Method.",
            xCorrelationIdentifier);

        try
        {
            // Validate the request
            if (!cryptographyRequest.IsRequestValid(out var operationFailureResponse))
            {
                _logger.LogError(
                    "CorrelationId : {"
                    + ServicesConstants.CorrelationIdLogPropertyName
                    + "} Payload request is invalid.",
                    xCorrelationIdentifier);

                return new BadRequestObjectResult(
                    new OperationFailureResponse(
                        "One or more validation errors occurred.",
                        operationFailureResponse,
                        xCorrelationIdentifier.ToString()));
            }
            
            // Convert to Request Payload
            var timestamp = DateTime.UtcNow.ToString(InternalConstants.TimestampFormat);
            var payloadAsString = $"{cryptographyRequest.LastName},{cryptographyRequest.MemberNumber},{timestamp}";

            // Encrypted Details 
            var encryptedResponse = _cryptographyHandler.GetAesEncryptedData(payloadAsString, _neatIdeasSettings.EncryptionKey, xCorrelationIdentifier);

            if (string.IsNullOrWhiteSpace(encryptedResponse))
            {
                _logger.LogWarning(
                    "AlertWarning : {" +
                    ServicesConstants.AlertWaring +
                    "} CorrelationId : {" +
                    ServicesConstants.CorrelationIdLogPropertyName +
                    "} Failed to encrypt data.", true, xCorrelationIdentifier);
                
                throw new InvalidOperationException(
                    "Failure to encrypt the payload");
            }

            // Hashed Details 
            var hashedResponse = _cryptographyHandler.GetHashedValue(payloadAsString, _neatIdeasSettings.EncryptionKey, xCorrelationIdentifier);
            
            if (string.IsNullOrWhiteSpace(hashedResponse))
            {
                _logger.LogWarning(
                    "AlertWarning : {" +
                    ServicesConstants.AlertWaring +
                    "} CorrelationId : {" +
                    ServicesConstants.CorrelationIdLogPropertyName +
                    "} Failed to hash data.", true, xCorrelationIdentifier);
                
                throw new InvalidOperationException(
                    "Failure to hash the payload");
            }

            // Create Response
            var result = encryptedResponse.Convert(hashedResponse, timestamp, _neatIdeasSettings.BaseUrl);

            return Ok(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                "} Encrypting and Hashing details failed with error: {message}", xCorrelationIdentifier, ex.Message);

            return StatusCode(StatusCodes.Status500InternalServerError,
                new OperationFailureResponse("Error occurred while encrypting and hashing details.", null,
                    xCorrelationIdentifier.ToString()));
        }
    }
}