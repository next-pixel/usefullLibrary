﻿using Cloud.Services.Common.Startup;
using Cloud.Services.Cryptography.Api.Implementations;
using Cloud.Services.Cryptography.Api.Interfaces;
using Cloud.Services.Cryptography.Api.Settings;
using Cloud.Services.Cryptography.Api.Settings.Validators;
using Microsoft.Extensions.Options;

namespace Cloud.Services.Cryptography.Api;

internal class Program
{
    private Program()
    {
    }

    private static void Main(string[] args)
    {
        // Create the web application builder.
        var builder = WebApplication.CreateBuilder(args);

        // Add common services
        ConfigureServices(builder);

        // Build the app
        var app = builder.Build();

        // Configure app
        ApiBaseStartup.Configure(app, app.Environment, builder.Logging);

        // Map controllers
        app.MapControllers();

        // Configure the HTTP request pipeline.
        app.Run();
    }

    private static void ConfigureServices(WebApplicationBuilder builder)
    {
        // Add common services
        ApiBaseStartup.ConfigureServices<Program>(builder);

        builder.Services.AddTransient<ICryptographyHandler, CryptographyHandler>();
        
        builder.Services.AddSingleton<IValidateOptions<NeatIdeasSettings>, NeatIdeasSettingsValidator>();

        // Register settings as IOptions.
        builder.Services.Configure<NeatIdeasSettings>(builder.Configuration.GetSection(NeatIdeasSettings.ConfigurationSectionName));
    }
}
