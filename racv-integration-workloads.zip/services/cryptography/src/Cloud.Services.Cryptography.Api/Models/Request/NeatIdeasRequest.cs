using System.Text.Json.Serialization;

namespace Cloud.Services.Cryptography.Api.Models.Request;

public class NeatIdeasRequest
{
    [JsonPropertyName("lastName")]
    public string? LastName { get; set; }

    [JsonPropertyName("memberNumber")]
    public string? MemberNumber { get; set; }
}