using System.Text.Json.Serialization;

namespace Cloud.Services.Cryptography.Api.Models.Response;

public class NeatIdeasResponse
{
    [JsonPropertyName("message")]
    public string? Message { get; set; }

    [JsonPropertyName("data")]
    public NeatIdeasData? Data { get; set; }
}

public class NeatIdeasData
{
    [JsonPropertyName("accessUrl")]
    public string? AccessUrl { get; set; }
}