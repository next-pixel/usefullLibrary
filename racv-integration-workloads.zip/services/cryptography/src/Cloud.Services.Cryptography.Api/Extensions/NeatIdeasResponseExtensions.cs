using Cloud.Services.Cryptography.Api.Constants;
using Cloud.Services.Cryptography.Api.Models.Response;

namespace Cloud.Services.Cryptography.Api.Extensions;

public static class NeatIdeasResponseExtensions
{
    /// <summary>
    ///     Converts Member Details to Microservice Neat Ideas Details.
    /// </summary>
    /// <param name="encryptedData"></param>
    /// <param name="hashedData"></param>
    /// <param name="timestamp"></param>
    /// <param name="url"></param>
    /// <returns>The Microservice Neat Ideas Response Details.</returns>
    /// <exception cref="ArgumentException">Thrown when encryptedData or hashedData or url is null or whitespace.</exception>
    public static NeatIdeasResponse Convert(this string? encryptedData, string? hashedData,  string? timestamp, string? url)
    {
        // Check if encrypted and hashed data is null
        ArgumentException.ThrowIfNullOrWhiteSpace(encryptedData);
        ArgumentException.ThrowIfNullOrWhiteSpace(hashedData);
        ArgumentException.ThrowIfNullOrWhiteSpace(url);
        
        return new NeatIdeasResponse
        {
            Message = InternalConstants.OperationSuccessful,
            Data = new NeatIdeasData
            {
                AccessUrl = $"{url}?aes_data={encryptedData}&hash={hashedData}&timeStamp={timestamp}"
            }
        };
    }
}