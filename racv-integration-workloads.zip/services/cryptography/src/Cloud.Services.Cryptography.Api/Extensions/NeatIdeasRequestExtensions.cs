using Cloud.Services.Common.Exceptions;
using Cloud.Services.Cryptography.Api.Models.Request;
using Cloud.Services.Cryptography.Api.Validators;

namespace Cloud.Services.Cryptography.Api.Extensions;

public static class NeatIdeasRequestExtensions
{
    /// <summary>
    ///     Validates Member Details in Neat Ideas Request.
    /// </summary>
    /// <param name="feedbackRequest"></param>
    /// <param name="failureResponseDetails"></param>
    /// <returns>Boolean if request is valid</returns>
    public static bool IsRequestValid(
        this NeatIdeasRequest feedbackRequest,
        out OperationFailureResponseDetail[]? failureResponseDetails)
    {
        failureResponseDetails = null;

        var result = new NeatIdeasRequestValidator().Validate(feedbackRequest);

        if (!result.IsValid)
        {
            failureResponseDetails = result.Errors.Select(e => new OperationFailureResponseDetail
            {
                Message = e.ErrorMessage,
                Entity = e.PropertyName
            }).ToArray();
        }
        return result.IsValid;
    }
}