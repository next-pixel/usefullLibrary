namespace Cloud.Services.Cryptography.Api.Constants;

public static class InternalConstants
{
    public const string TimestampFormat = "yyyyMMddHHmmss";
    public const string NeatIdeasSettings = "NeatIdeasSettings";
    public const string OperationSuccessful = "Operation successful.";
}