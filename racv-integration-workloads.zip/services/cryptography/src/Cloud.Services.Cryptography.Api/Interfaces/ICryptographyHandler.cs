namespace Cloud.Services.Cryptography.Api.Interfaces;

public interface ICryptographyHandler
{
    string GetAesEncryptedData(string plainText, string? encryptionKey, Guid xCorrelationIdentifier);
    string GetHashedValue(string dataString, string? encryptionKey, Guid xCorrelationIdentifier);
}