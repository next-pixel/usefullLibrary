using System.Security.Cryptography;
using System.Text;
using Cloud.Services.Common.Constants;
using Cloud.Services.Cryptography.Api.Interfaces;

namespace Cloud.Services.Cryptography.Api.Implementations;

public class CryptographyHandler: ICryptographyHandler
{
    private readonly ILogger<CryptographyHandler> _logger;

    public CryptographyHandler(ILogger<CryptographyHandler> logger)
    {
        _logger = logger;
    }

    /// <summary>
    ///     AES Encrypts plain string using AES/CBC/PKCS7Padding and returns encrypted string.
    /// </summary>
    /// <param name="plainText"></param>
    /// <param name="encryptionKey"></param>
    /// <param name="xCorrelationIdentifier"></param>
    /// <returns>The Encrypted string.</returns>
    /// <exception cref="Exception">Thrown when an error occurs during encryption.</exception>
    public string GetAesEncryptedData(string plainText, string? encryptionKey, Guid xCorrelationIdentifier)
    {
        // Check arguments
        ArgumentException.ThrowIfNullOrWhiteSpace(plainText);
        ArgumentException.ThrowIfNullOrWhiteSpace(encryptionKey);
        string encryptedString;
        
        try
        {
            //Set variables to byte array
            var key = Encoding.ASCII.GetBytes(encryptionKey!);
            
            // Create an Aes object with the specified key and IV.
            using var aesAlg = Aes.Create();
            aesAlg.Mode = CipherMode.CBC;
            aesAlg.Padding = PaddingMode.PKCS7;
            aesAlg.Key = key;
            aesAlg.GenerateIV();
            var iv = aesAlg.IV;
        
            // // Create an encryptor to perform the stream transform.
            var encryptor = aesAlg.CreateEncryptor(key, iv);

            // Create the streams used for encryption.
            using var msEncrypt = new MemoryStream();
            using var csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write);
            using (var swEncrypt = new StreamWriter(csEncrypt))
            {
                swEncrypt.Write(plainText);
            }
            var array = msEncrypt.ToArray();
        
            // Concatenate byte arrays - IV with encrypted string
            var ivWithEncryptedData = new byte[iv.Length + array.Length];
            Array.Copy(iv, 0, ivWithEncryptedData, 0, iv.Length);
            Array.Copy(array, 0, ivWithEncryptedData, iv.Length, array.Length);
            
            // Convert byte array as a base64 encoded string
            encryptedString = Convert.ToBase64String(ivWithEncryptedData);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                "} Encryption of Neat Ideas Details failed with error: {message}",
                xCorrelationIdentifier, ex.Message);
            
            throw new CryptographicException(
                "An error occurred while encrypting the payload.",
                ex);
        }
        // Return the encrypted string from the memory stream.
        return encryptedString;
    }

    /// <summary>
    ///     Hashes plain string using HMACSHA256 and returns hashed string.
    /// </summary>
    /// <param name="dataString"></param>
    /// <param name="encryptionKey"></param>
    /// <param name="xCorrelationIdentifier"></param>
    /// <returns>The Hashed string.</returns>
    /// <exception cref="Exception">Thrown when an error occurs during hashing.</exception>
    public string GetHashedValue(string dataString, string? encryptionKey, Guid xCorrelationIdentifier)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(encryptionKey);
        string hash;
        try
        {
            var secretKey = Encoding.UTF8.GetBytes(encryptionKey!);
            var hmac = new HMACSHA256(secretKey);
            hmac.Initialize();
            var data = Encoding.UTF8.GetBytes(dataString);
            var rawHmac = hmac.ComputeHash(data);
            hash = Convert.ToHexString(rawHmac);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                "} Hashing of Neat Ideas Details failed with error: {message}",
                xCorrelationIdentifier, ex.Message);
            
            throw new CryptographicException(
                "An error occurred while hashing the payload.",
                ex);
        }
        return hash.ToLower();
    }
}