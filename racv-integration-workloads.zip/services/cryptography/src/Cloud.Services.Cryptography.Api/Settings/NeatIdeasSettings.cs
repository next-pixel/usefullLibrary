using Cloud.Services.Cryptography.Api.Constants;

namespace Cloud.Services.Cryptography.Api.Settings;

public class NeatIdeasSettings
{
    public const string ConfigurationSectionName = InternalConstants.NeatIdeasSettings;
    public string? BaseUrl { get; set; }
    public string? EncryptionKey { get; set; }
}
