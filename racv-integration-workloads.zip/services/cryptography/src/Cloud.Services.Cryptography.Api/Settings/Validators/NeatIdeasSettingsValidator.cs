using Microsoft.Extensions.Options;

namespace Cloud.Services.Cryptography.Api.Settings.Validators;

public class NeatIdeasSettingsValidator: IValidateOptions<NeatIdeasSettings>
{
    public ValidateOptionsResult Validate(string? name, NeatIdeasSettings? options)
    {
        if (options is null)
            return ValidateOptionsResult.Fail(
                "Configuration object is null.");

        if (string.IsNullOrWhiteSpace(options.EncryptionKey))
            return ValidateOptionsResult.Fail(
                $"Property '{nameof(NeatIdeasSettings.EncryptionKey)}' cannot be blank.");
           
        if (string.IsNullOrWhiteSpace(options.BaseUrl))
            return ValidateOptionsResult.Fail(
                $"Property '{nameof(NeatIdeasSettings.BaseUrl)}' cannot be blank.");
        return ValidateOptionsResult.Success;
    }
}
