﻿using System.Net;
using System.Net.Http.Json;
using System.Text;
using Cloud.Services.Common.Connector.Models.Exceptions;
using Cloud.Services.Common.Connector.Models.OCPI;
using Cloud.Services.Common.Settings;
using Cloud.Services.Common.Tracking.Enumerations;
using Cloud.Services.Common.Utility.Wrapper.Implementation;
using Cloud.Services.Common.Utility.Wrapper.Interfaces;
using Cloud.Services.EVFeed.Common.Constants;
using Cloud.Services.EVFeed.Common.Models.Connectors.ChargeFox;
using Cloud.Services.EVFeed.Common.Models.Connectors.OCPI;
using Cloud.Services.EVFeed.Connector.ChargeFox.Implementations;
using FluentAssertions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;

namespace Cloud.Services.EVFeed.Connector.ChargeFox.Tests.Unit.Implementations
{
    public class ChargeFoxServiceTests
    {
        private const string BaseAddress = "http://www.TestUrl.com";
        private readonly IHttpWrapper<HttpRequestMessage, HttpResponseMessage> _httpWrapper;
        private readonly Mock<IHttpClientFactory> _httpClientFactoryMock;
        private readonly Mock<ILogger<ChargeFoxService>> _loggerMock;
        private readonly Mock<IOptionsSnapshot<ChargeFoxSettings>> _chargefoxSettings;
        private readonly IConfiguration _configuration;
        private readonly Mock<IConfigurationRefresherProvider> _configurationRefreshProvider;

        public ChargeFoxServiceTests()
        {
            _httpClientFactoryMock = new Mock<IHttpClientFactory>();
            _httpWrapper = new HttpWrapper(_httpClientFactoryMock.Object, LogRequestResponse);
            _loggerMock = new Mock<ILogger<ChargeFoxService>>();

            var chargefoxSettings = new ChargeFoxSettings()
            {
                BaseUrl = BaseAddress,
                ChargerLocationsLimit = 10,
                ChargerLocationsRequestDelayInMs = 1000,
                ChargerTariffsLimit = 10,
                ChargerTariffsRequestDelayInMs = 1000,
                LatestMutualVersion = "2.2.1",
                OCPIHandshakeCredentialsToken = "CredentialsTokenA",
                OCPISenderCredentialsToken = "CredentialsTokenB",
                OCPIReceiverCredentialsToken = "CredentialsTokenC"
            };
            _chargefoxSettings = new Mock<IOptionsSnapshot<ChargeFoxSettings>>();
            _chargefoxSettings.Setup(s => s.Value).Returns(chargefoxSettings);

            // Create a mock of IConfigurationRefresher
            var mockRefresher = new Mock<IConfigurationRefresher>();

            // Setup RefreshAsync to be verifiable and return Task.CompletedTask
            mockRefresher
                .Setup(r => r.RefreshAsync(It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask)
                .Verifiable();

            // Setup TryRefreshAsync to return a successful task with true
            mockRefresher
                .Setup(r => r.TryRefreshAsync(It.IsAny<CancellationToken>()))
                .Returns(Task.FromResult(true))
                .Verifiable();

            _configuration = new ConfigurationBuilder()
                .AddInMemoryCollection([]).Build();

            // Create a mock of IConfigurationRefresherProvider
            _configurationRefreshProvider = new Mock<IConfigurationRefresherProvider>();

            // Setup the Refreshers property to return a list with the mock refresher
            _configurationRefreshProvider
                .Setup(p => p.Refreshers)
                .Returns(new List<IConfigurationRefresher> { mockRefresher.Object });

        }

        private async Task LogRequestResponse(
            HttpRequestMessage request,
            HttpResponseMessage response,
            Guid correlationIdentifier,
            OperationProtocols protocol)
        {
            await Task.CompletedTask;
        }

        [Fact]
        public async Task GetVersions_ShouldReturnVersionsResponse()
        {
            // Arrange
            var xCorrelationIdentifier = Guid.NewGuid();
            var authorization = "Bearer token";
            var versionsResponse = new VersionsResponse
            {
                StatusCode = 1000,
                StatusMessage = "Success",
                Versions = new List<Services.Common.Connector.Models.OCPI.OCPIVersion>
                {
                    new Services.Common.Connector.Models.OCPI.OCPIVersion { Version = new Version(2, 1) }
                }
            };

            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            var mockResponse = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(versionsResponse))
            };

            mockHandler
              .Protected()
              .Setup<Task<HttpResponseMessage>>(
                  "SendAsync",
                  ItExpr.Is<HttpRequestMessage>(m => m.Method == HttpMethod.Get),
                  ItExpr.IsAny<CancellationToken>())
              .ReturnsAsync(mockResponse);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri("http://www.TestUrl.com");

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var chargeFoxService = new ChargeFoxService(
               _configuration,
               _httpWrapper,
               _chargefoxSettings.Object,
               _loggerMock.Object,
               _configurationRefreshProvider.Object);

            // Act
            var result = await chargeFoxService.GetVersions(xCorrelationIdentifier, authorization);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result.Versions);
            Assert.Equal(new Version(2, 1), result.Versions.First().Version);
        }

        [Fact]
        public async Task GetVersionEndpoints_ShouldReturnVersionEndpointsResponse()
        {
            // Arrange
            var version = "2.1";
            var xCorrelationIdentifier = Guid.NewGuid();
            var authorization = "Bearer token";
            var versionEndpointsResponse = new VersionEndpointsResponse
            {
                StatusCode = 1000,
                StatusMessage = "Success",
                VersionEndpoints = new VersionEndpoints
                {
                    Endpoints = new List<Services.Common.Connector.Models.OCPI.Endpoint> {
                     new Services.Common.Connector.Models.OCPI.Endpoint{
                         Identifier = "locations",
                         URL = "https://api.test.com/locations" }
                    }
                }
            };

            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            var mockResponse = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(System.Text.Json.JsonSerializer.Serialize(versionEndpointsResponse))
            };

            mockHandler
              .Protected()
              .Setup<Task<HttpResponseMessage>>(
                  "SendAsync",
                  ItExpr.Is<HttpRequestMessage>(m => m.Method == HttpMethod.Get),
                  ItExpr.IsAny<CancellationToken>())
              .ReturnsAsync(mockResponse);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri("http://www.TestUrl.com");

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var chargeFoxService = new ChargeFoxService(
               _configuration,
               _httpWrapper,
               _chargefoxSettings.Object,
               _loggerMock.Object,
               _configurationRefreshProvider.Object);

            // Act
            var result = await chargeFoxService.GetVersionEndpoints(version, xCorrelationIdentifier, authorization);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetVersionEndpoints_ShouldThrowExternalApiDependencyException_WhenApiFails()
        {
            // Arrange
            var xCorrelationIdentifier = Guid.NewGuid();
            var version = "2.2.1";
            var credentials = new Credentials();
            var authorization = "mockAuthorization";
            var httpMethod = HttpMethod.Post;

            var submitCredentialsResponse = new SubmitCredentialsResponse
            {
                StatusCode = 2000,
                StatusMessage = "Failed",
            };

            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            var mockResponse = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(submitCredentialsResponse))
            };

            mockHandler
              .Protected()
              .Setup<Task<HttpResponseMessage>>(
                  "SendAsync",
                  ItExpr.Is<HttpRequestMessage>(m => m.Method == HttpMethod.Get),
                  ItExpr.IsAny<CancellationToken>())
              .ReturnsAsync(mockResponse);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri("http://www.TestUrl.com");

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var chargeFoxService = new ChargeFoxService(
               _configuration,
               _httpWrapper,
               _chargefoxSettings.Object,
               _loggerMock.Object,
               _configurationRefreshProvider.Object);

            // Act & Assert
            await Assert.ThrowsAsync<ExternalApiDependencyException>(() => chargeFoxService.GetVersionEndpoints(
                version,
                xCorrelationIdentifier,
                authorization));

            _loggerMock.Verify(logger => logger.Log(
                It.Is<LogLevel>(logLevel => logLevel == LogLevel.Error),
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((@object, @type) => @object.ToString().Contains("Failed to retrieve Chargefox OCPI endpoints with transient API error")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()
            ), Times.AtLeastOnce);

        }

        [Fact]
        public async Task GetVersionEndpoints_ShouldThrowHttpRequestExceptionException_WhenApiFails()
        {
            // Arrange
            var xCorrelationIdentifier = Guid.NewGuid();
            var version = "2.2.1";
            var credentials = new Credentials();
            var authorization = "mockAuthorization";
            var httpMethod = HttpMethod.Post;

            var responseMessage = new HttpResponseMessage(HttpStatusCode.InternalServerError);

            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            mockHandler
              .Protected()
              .Setup<Task<HttpResponseMessage>>(
                  "SendAsync",
                  ItExpr.Is<HttpRequestMessage>(m => m.Method == HttpMethod.Get),
                  ItExpr.IsAny<CancellationToken>())
              .ReturnsAsync(responseMessage);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri("http://www.TestUrl.com");

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var chargeFoxService = new ChargeFoxService(
               _configuration,
               _httpWrapper,
               _chargefoxSettings.Object,
               _loggerMock.Object,
               _configurationRefreshProvider.Object);

            // Act & Assert
            await Assert.ThrowsAsync<HttpRequestException>(() => chargeFoxService.GetVersionEndpoints(
                version,
                xCorrelationIdentifier,
                authorization));

             _loggerMock.Verify(logger => logger.Log(
                It.Is<LogLevel>(logLevel => logLevel == LogLevel.Error),
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((@object, @type) => @object.ToString().Contains("Failed to retrieve Chargefox OCPI endpoints with transient API error")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()
            ), Times.AtLeastOnce);
        }

        [Fact]
        public async Task GetVersionEndpoints_ShouldThrowSerializationException_WhenResponseIsInvalid()
        {
            // Arrange
            var xCorrelationIdentifier = Guid.NewGuid();
            var version = "2.2.1";
            var credentials = new Credentials();
            var authorization = "mockAuthorization";
            var httpMethod = HttpMethod.Post;

            var responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("{ invalid json }", Encoding.UTF8, "application/xml")
            };

            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            mockHandler
              .Protected()
              .Setup<Task<HttpResponseMessage>>(
                  "SendAsync",
                  ItExpr.Is<HttpRequestMessage>(m => m.Method == HttpMethod.Get),
                  ItExpr.IsAny<CancellationToken>())
              .ReturnsAsync(responseMessage);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri("http://www.TestUrl.com");

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var chargeFoxService = new ChargeFoxService(
               _configuration,
               _httpWrapper,
               _chargefoxSettings.Object,
               _loggerMock.Object,
               _configurationRefreshProvider.Object);

            // Act & Assert
            await Assert.ThrowsAsync<System.Text.Json.JsonException>(() => chargeFoxService.GetVersionEndpoints(
                version,
                xCorrelationIdentifier,
                authorization));

             _loggerMock.Verify(logger => logger.Log(
                It.Is<LogLevel>(logLevel => logLevel == LogLevel.Error),
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((@object, @type) => @object.ToString().Contains("failed to parse ChargeFox OCPI endpoints response with error")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()
            ), Times.AtLeastOnce);
        }

        [Fact]
        public async Task GetVersionEndpoints_ShouldThrowException_WhenUnexpectedErrorOccurs()
        {
            // Arrange
            var xCorrelationIdentifier = Guid.NewGuid();
            var version = "2.2.1";
            var credentials = new Credentials();
            var authorization = "mockAuthorization";
            var httpMethod = HttpMethod.Post;

            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            mockHandler
              .Protected()
              .Setup<Task<HttpResponseMessage>>(
                  "SendAsync",
                  ItExpr.Is<HttpRequestMessage>(m => m.Method == HttpMethod.Get),
                  ItExpr.IsAny<CancellationToken>())
              .ThrowsAsync(new Exception("Unexpected error"));

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri("http://www.TestUrl.com");

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var chargeFoxService = new ChargeFoxService(
               _configuration,
               _httpWrapper,
               _chargefoxSettings.Object,
               _loggerMock.Object,
               _configurationRefreshProvider.Object);

            // Act & Assert
            await Assert.ThrowsAsync<Exception>(() => chargeFoxService.GetVersionEndpoints(
                version,
                xCorrelationIdentifier,
                authorization));
        }

        [Fact]
        public async Task SubmitCredentials_ShouldReturnSubmitCredentialsResponse()
        {
            // Arrange
            var xCorrelationIdentifier = Guid.NewGuid();
            var version = "2.1";
            var credentials = new Credentials { Token = "newToken" };
            var authorization = "Bearer token";
            var httpMethod = HttpMethod.Post;
            var submitCredentialsResponse = new SubmitCredentialsResponse
            {
                StatusCode = 1000,
                StatusMessage = "Success",
                credentials = new Credentials { Token = "newToken" }
            };

            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            var mockResponse = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(submitCredentialsResponse))
            };

            mockHandler
              .Protected()
              .Setup<Task<HttpResponseMessage>>(
                  "SendAsync",
                  ItExpr.Is<HttpRequestMessage>(m => m.Method == HttpMethod.Post),
                  ItExpr.IsAny<CancellationToken>())
              .ReturnsAsync(mockResponse);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri("http://www.TestUrl.com");

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var chargeFoxService = new ChargeFoxService(
               _configuration,
               _httpWrapper,
               _chargefoxSettings.Object,
               _loggerMock.Object,
               _configurationRefreshProvider.Object);

            // Act
            var result = await chargeFoxService.SubmitCredentials(
                xCorrelationIdentifier,
                version,
                credentials,
                authorization,
                httpMethod);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("newToken", result!.credentials!.Token);
        }

        [Fact]
        public async Task SubmitCredentials_ShouldThrowExternalApiDependencyException_WhenApiFails()
        {
            // Arrange
            var xCorrelationIdentifier = Guid.NewGuid();
            var version = "2.2.1";
            var credentials = new Credentials();
            var authorization = "mockAuthorization";
            var httpMethod = HttpMethod.Post;

            var submitCredentialsResponse = new SubmitCredentialsResponse
            {
                StatusCode = 2000,
                StatusMessage = "Failed",
            };

            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            var mockResponse = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(submitCredentialsResponse))
            };

            mockHandler
              .Protected()
              .Setup<Task<HttpResponseMessage>>(
                  "SendAsync",
                  ItExpr.Is<HttpRequestMessage>(m => m.Method == HttpMethod.Post),
                  ItExpr.IsAny<CancellationToken>())
              .ReturnsAsync(mockResponse);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri("http://www.TestUrl.com");

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var chargeFoxService = new ChargeFoxService(
               _configuration,
               _httpWrapper,
               _chargefoxSettings.Object,
               _loggerMock.Object,
               _configurationRefreshProvider.Object);

            // Act & Assert
            await Assert.ThrowsAsync<ExternalApiDependencyException>(() => chargeFoxService.SubmitCredentials(
                xCorrelationIdentifier,
                version,
                credentials,
                authorization,
                httpMethod));
        }

        [Fact]
        public async Task SubmitCredentials_ShouldThrowHttpRequestExceptionException_WhenApiFails()
        {
            // Arrange
            var xCorrelationIdentifier = Guid.NewGuid();
            var version = "2.2.1";
            var credentials = new Credentials();
            var authorization = "mockAuthorization";
            var httpMethod = HttpMethod.Post;

            var responseMessage = new HttpResponseMessage(HttpStatusCode.InternalServerError);

            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            mockHandler
              .Protected()
              .Setup<Task<HttpResponseMessage>>(
                  "SendAsync",
                  ItExpr.Is<HttpRequestMessage>(m => m.Method == HttpMethod.Post),
                  ItExpr.IsAny<CancellationToken>())
              .ReturnsAsync(responseMessage);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri("http://www.TestUrl.com");

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var chargeFoxService = new ChargeFoxService(
               _configuration,
               _httpWrapper,
               _chargefoxSettings.Object,
               _loggerMock.Object,
               _configurationRefreshProvider.Object);

            // Act & Assert
            await Assert.ThrowsAsync<HttpRequestException>(() => chargeFoxService.SubmitCredentials(
                xCorrelationIdentifier,
                version,
                credentials,
                authorization,
                httpMethod));
        }

        [Fact]
        public async Task SubmitCredentials_ShouldThrowSerializationException_WhenResponseIsInvalid()
        {
            // Arrange
            var xCorrelationIdentifier = Guid.NewGuid();
            var version = "2.2.1";
            var credentials = new Credentials();
            var authorization = "mockAuthorization";
            var httpMethod = HttpMethod.Post;

            var responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("{ invalid json }", Encoding.UTF8, "application/xml")
            };

            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            mockHandler
              .Protected()
              .Setup<Task<HttpResponseMessage>>(
                  "SendAsync",
                  ItExpr.Is<HttpRequestMessage>(m => m.Method == HttpMethod.Post),
                  ItExpr.IsAny<CancellationToken>())
              .ReturnsAsync(responseMessage);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri("http://www.TestUrl.com");

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var chargeFoxService = new ChargeFoxService(
               _configuration,
               _httpWrapper,
               _chargefoxSettings.Object,
               _loggerMock.Object,
               _configurationRefreshProvider.Object);

            // Act & Assert
            await Assert.ThrowsAsync<JsonReaderException>(() => chargeFoxService.SubmitCredentials(
                xCorrelationIdentifier,
                version,
                credentials,
                authorization,
                httpMethod));
        }

        [Fact]
        public async Task SubmitCredentials_ShouldThrowException_WhenUnexpectedErrorOccurs()
        {
            // Arrange
            var xCorrelationIdentifier = Guid.NewGuid();
            var version = "2.2.1";
            var credentials = new Credentials();
            var authorization = "mockAuthorization";
            var httpMethod = HttpMethod.Post;

            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            mockHandler
              .Protected()
              .Setup<Task<HttpResponseMessage>>(
                  "SendAsync",
                  ItExpr.Is<HttpRequestMessage>(m => m.Method == HttpMethod.Post),
                  ItExpr.IsAny<CancellationToken>())
              .ThrowsAsync(new Exception("Unexpected error"));

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri("http://www.TestUrl.com");

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var chargeFoxService = new ChargeFoxService(
               _configuration,
               _httpWrapper,
               _chargefoxSettings.Object,
               _loggerMock.Object,
               _configurationRefreshProvider.Object);

            // Act & Assert
            await Assert.ThrowsAsync<Exception>(() => chargeFoxService.SubmitCredentials(
                xCorrelationIdentifier,
                version,
                credentials,
                authorization,
                httpMethod));
        }

        [Theory]
        [InlineData(2)]
        [InlineData(3)]
        [InlineData(4)]
        public async Task GetDeltaChargerLocations_ShouldReturnChargerLocationsResponse(int limit)
        {
            // Arrange
            var lastSync = 123456789L;
            var xCorrelationIdentifier = Guid.NewGuid();
            var responseObject = new ChargerLocationsResponse()
            {
                ChargerLocations = new List<ChargerLocation>
                {
                    new ChargerLocation { Id = Guid.NewGuid().ToString(), Name = "Location 1",LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime},
                    new ChargerLocation { Id = Guid.NewGuid().ToString(), Name = "Location 2",LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime},
                    new ChargerLocation { Id = Guid.NewGuid().ToString(), Name = "Location 3",LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime},
                }
            };


            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            var mockResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = JsonContent.Create(responseObject),
            };
            mockResponse.Headers.Add(InternalConstants.TotalCountHeader, "3");

            mockHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.Is<HttpRequestMessage>(m => m.Method == HttpMethod.Get),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(mockResponse);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri(BaseAddress);

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var chargeFoxService = new ChargeFoxService(
                _configuration,
                _httpWrapper,
                _chargefoxSettings.Object,
                _loggerMock.Object,
                _configurationRefreshProvider.Object);

            // Act
            var result = await chargeFoxService.GetDeltaChargerLocations(lastSync, limit, xCorrelationIdentifier);

            // Assert
            result.Should().BeEquivalentTo(responseObject.ChargerLocations);
        }

        [Fact]
        public async Task GetDeltaChargerLocations_ShouldDelay_WhenPaginatedDelayIsGreaterThanZero()
        {
            // Arrange
            var lastSync = 123456789L;
            var xCorrelationIdentifier = Guid.NewGuid();
            var responseObject = new ChargerLocationsResponse()
            {
                ChargerLocations = new List<ChargerLocation>
                {
                    new ChargerLocation { Id = Guid.NewGuid().ToString(), Name = "Location 1",LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime},
                    new ChargerLocation { Id = Guid.NewGuid().ToString(), Name = "Location 2",LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime},
                    new ChargerLocation { Id = Guid.NewGuid().ToString(), Name = "Location 3",LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime},
                }
            };

            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            var mockResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = JsonContent.Create(responseObject),
            };
            mockResponse.Headers.Add(InternalConstants.TotalCountHeader, "3");

            mockHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.Is<HttpRequestMessage>(m => m.Method == HttpMethod.Get),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(mockResponse);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri(BaseAddress);

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var chargeFoxService = new ChargeFoxService(
                _configuration,
                _httpWrapper,
                _chargefoxSettings.Object,
                _loggerMock.Object,
                _configurationRefreshProvider.Object);

            // Act
            var start = DateTime.Now;
            await chargeFoxService.GetDeltaChargerLocations(lastSync, 3, xCorrelationIdentifier, 2000);
            var end = DateTime.Now;

            // Assert
            (end - start).Should().BeGreaterThan(TimeSpan.FromMilliseconds(1000));
        }

        [Fact]
        public async Task GetDeltaChargerLocations_ShouldThrowException_WhenHttpClientThrowsException()
        {
            // Arrange
            var lastSync = 123456789L;
            var xCorrelationIdentifier = Guid.NewGuid();
            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            var mockResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.ServiceUnavailable,
            };

            mockHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.Is<HttpRequestMessage>(m => m.Method == HttpMethod.Get),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(mockResponse);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri(BaseAddress);

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var chargeFoxService = new ChargeFoxService(
                _configuration,
                _httpWrapper,
                _chargefoxSettings.Object,
                _loggerMock.Object,
                _configurationRefreshProvider.Object);

            // Act
            await Assert.ThrowsAsync<HttpRequestException>(() => chargeFoxService.GetDeltaChargerLocations(lastSync, 500, xCorrelationIdentifier));
        }

        [Theory]
        [InlineData(2)]
        [InlineData(3)]
        [InlineData(4)]
        public async Task GetDeltaChargerTariffs_ShouldReturnChargerTariffsResponse(int limit)
        {
            // Arrange
            var lastSync = 123456789L;
            var xCorrelationIdentifier = Guid.NewGuid();
            var responseObject = new ChargerTariffsResponse()
            {
                ChargerTariffs = new List<ChargerTariff>()
                {
                    new ChargerTariff { Id = Guid.NewGuid().ToString(), Type = "Tariff 1", LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime },
                    new ChargerTariff { Id = Guid.NewGuid().ToString(), Type = "Tariff 2", LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime },
                    new ChargerTariff { Id = Guid.NewGuid().ToString(), Type = "Tariff 3", LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime }
                }
            };

            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            var mockResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = JsonContent.Create(responseObject)
            };
            mockResponse.Headers.Add(InternalConstants.TotalCountHeader, "3");

            mockHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.Is<HttpRequestMessage>(m => m.Method == HttpMethod.Get),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(mockResponse);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri("http://www.TestUrl.com");

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var chargeFoxService = new ChargeFoxService(
                _configuration,
                _httpWrapper,
                _chargefoxSettings.Object,
                _loggerMock.Object,
                _configurationRefreshProvider.Object);

            // Act
            var result = await chargeFoxService.GetDeltaChargerTariffs(lastSync, limit, xCorrelationIdentifier);

            // Assert
            result.Should().BeEquivalentTo(responseObject.ChargerTariffs);
        }

        [Fact]
        public async Task GetDeltaChargerTariffs_ShouldDelay_WhenPaginatedDelayIsGreaterThanZero()
        {
            // Arrange
            var lastSync = 123456789L;
            var xCorrelationIdentifier = Guid.NewGuid();
            var responseObject = new ChargerTariffsResponse()
            {
                ChargerTariffs = new List<ChargerTariff>()
                {
                    new ChargerTariff { Id = Guid.NewGuid().ToString(), Type = "Tariff 1", LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime },
                    new ChargerTariff { Id = Guid.NewGuid().ToString(), Type = "Tariff 2", LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime },
                    new ChargerTariff { Id = Guid.NewGuid().ToString(), Type = "Tariff 3", LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime },
                }
            };

            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            var mockResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = JsonContent.Create(responseObject)
            };
            mockResponse.Headers.Add(InternalConstants.TotalCountHeader, "3");

            mockHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.Is<HttpRequestMessage>(m => m.Method == HttpMethod.Get),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(mockResponse);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri("http://www.TestUrl.com");

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var chargeFoxService = new ChargeFoxService(
                _configuration,
                _httpWrapper,
                _chargefoxSettings.Object,
                _loggerMock.Object,
                _configurationRefreshProvider.Object);

            // Act
            var start = DateTime.Now;
            await chargeFoxService.GetDeltaChargerTariffs(lastSync, 3, xCorrelationIdentifier, 2000);
            var end = DateTime.Now;

            // Assert
            (end - start).Should().BeGreaterThan(TimeSpan.FromMilliseconds(1000));
        }

        [Fact]
        public async Task GetDeltaChargerTariffs_ShouldThrowException_WhenHttpClientThrowsException()
        {
            // Arrange
            var lastSync = 123456789L;
            var xCorrelationIdentifier = Guid.NewGuid();
            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            var mockResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.ServiceUnavailable,
            };

            mockHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.Is<HttpRequestMessage>(m => m.Method == HttpMethod.Get),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(mockResponse);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri("http://www.TestUrl.com");

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var chargeFoxService = new ChargeFoxService(
                _configuration,
                _httpWrapper,
                _chargefoxSettings.Object,
                _loggerMock.Object,
                _configurationRefreshProvider.Object);

            // Act
            await Assert.ThrowsAsync<HttpRequestException>(() => chargeFoxService.GetDeltaChargerTariffs(lastSync, 500, xCorrelationIdentifier));
        }
    }
}
