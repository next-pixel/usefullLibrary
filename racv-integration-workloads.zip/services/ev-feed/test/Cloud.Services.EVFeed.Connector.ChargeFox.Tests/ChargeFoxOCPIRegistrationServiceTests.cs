﻿using Azure;
using Azure.Data.AppConfiguration;
using Azure.Security.KeyVault.Secrets;
using Cloud.Services.Common.Settings;
using Cloud.Services.EVFeed.Common.Constants;
using Cloud.Services.EVFeed.Common.Models.Connectors.OCPI;
using Cloud.Services.EVFeed.Connector.ChargeFox.Implementations;
using Cloud.Services.EVFeed.Connector.ChargeFox.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using System.Linq;

namespace Cloud.Services.EVFeed.Connector.ChargeFox.Tests
{

    public class ChargeFoxOCPIRegistrationServiceTest
    {
        private readonly Mock<ILogger<ChargeFoxOCPIRegistrationService>> _loggerMock;
        private readonly Mock<IChargeFoxService> _chargeFoxServiceMock;
        private readonly IConfiguration _configuration;
        private readonly Mock<ConfigurationClient> _configurationClientMock;
        private readonly Mock<SecretClient> _secretClientMock;
        private readonly Mock<IOptions<AppSettings>> _appSettingsMock;
        private readonly Mock<IOptions<OCPISettings>> _ocpiSettingsMock;
        private readonly Mock<IOptions<ChargeFoxSettings>> _chargeFoxSettingsMock;
        private readonly Mock<IConfigurationRefresherProvider> _configurationRefresherProviderMock;
        private readonly Mock<IConfigurationRefresher> _configurationRefresherMock;

        public ChargeFoxOCPIRegistrationServiceTest()
        {
            _loggerMock = new Mock<ILogger<ChargeFoxOCPIRegistrationService>>();
            _chargeFoxServiceMock = new Mock<IChargeFoxService>();
            _configurationClientMock = new Mock<ConfigurationClient>();
            _secretClientMock = new Mock<SecretClient>();
            _appSettingsMock = new Mock<IOptions<AppSettings>>();
            _ocpiSettingsMock = new Mock<IOptions<OCPISettings>>();
            _chargeFoxSettingsMock = new Mock<IOptions<ChargeFoxSettings>>();
            _configurationRefresherProviderMock = new Mock<IConfigurationRefresherProvider>();
            _configurationRefresherMock = new Mock<IConfigurationRefresher>();

            _configurationRefresherProviderMock.Setup(x => x.Refreshers)
                .Returns(new List<IConfigurationRefresher> { _configurationRefresherMock.Object });

            _configuration = new ConfigurationBuilder()
                .AddInMemoryCollection([]).Build();

            var responseMock = new Mock<Response<KeyVaultSecret>>();

            // Set up the response to return a KeyVaultSecret
            var keyVaultSecret = new KeyVaultSecret("chargefox-ocpi-receiver-credentials-token", "secret-value");
            responseMock.Setup(r => r.Value).Returns(keyVaultSecret);

            _secretClientMock
                .Setup(s => s.GetSecretAsync(It.IsAny<string>(), null, CancellationToken.None))
                .Returns(Task.FromResult(responseMock.Object));

        }

        [Fact]
        public async Task RegisterAsync_ShouldLogInformation_WhenSenderCredentialsExist()
        {
            // Arrange
            var correlationId = Guid.NewGuid();
            var chargeFoxSettings = new ChargeFoxSettings
            {
                OCPISenderCredentialsToken = "existingToken"
            };
            _chargeFoxSettingsMock.Setup(x => x.Value).Returns(chargeFoxSettings);

            var ocpiSettings = new OCPISettings
            {
                VersionDetails = new OCPIVersion { Version = new Version(2, 1) }
            };
            _ocpiSettingsMock.Setup(x => x.Value).Returns(ocpiSettings);

            var appSettings = new AppSettings
            {
                ApplicationInsightConnectionString = string.Empty,

            };
            _appSettingsMock.Setup(x => x.Value).Returns(appSettings);

            ChargeFoxOCPIRegistrationService _service = new ChargeFoxOCPIRegistrationService(
                _loggerMock.Object,
                _configuration,
                _chargeFoxServiceMock.Object,
                _configurationClientMock.Object,
                _secretClientMock.Object,
                _appSettingsMock.Object,
                _ocpiSettingsMock.Object,
                _chargeFoxSettingsMock.Object,
                _configurationRefresherProviderMock.Object);

            // Act
            await _service.RegisterAsync(correlationId);

            // Assert
            _loggerMock.Setup(logger => logger.Log(
                It.Is<LogLevel>(logLevel => logLevel == LogLevel.Information),
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((@object, @type) => true),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()
            ));
        }

        [Fact]
        public async Task RegisterAsync_ShouldThrowException_WhenNoCommonVersionsFound()
        {
            // Arrange
            var correlationId = Guid.NewGuid();
            var chargeFoxSettings = new ChargeFoxSettings
            {
                OCPISenderCredentialsToken = null,
                OCPIHandshakeCredentialsToken = "handshakeToken"
            };
            _chargeFoxSettingsMock.Setup(x => x.Value).Returns(chargeFoxSettings);

            var ocpiSettings = new OCPISettings
            {
                VersionDetails = new OCPIVersion { Version = new Version(2, 1) }
            };
            _ocpiSettingsMock.Setup(x => x.Value).Returns(ocpiSettings);

            var appSettings = new AppSettings
            {
                ApplicationInsightConnectionString = string.Empty,

            };
            _appSettingsMock.Setup(x => x.Value).Returns(appSettings);

            var versionsResponse = new Services.Common.Connector.Models.OCPI.VersionsResponse
            {
                Versions = new List<Services.Common.Connector.Models.OCPI.OCPIVersion>
                {
                    new Services.Common.Connector.Models.OCPI.OCPIVersion { Version = new Version(2, 0) }
                }
            };
            _chargeFoxServiceMock.Setup(x => x.GetVersions(It.IsAny<Guid>(), It.IsAny<string>()))
                .ReturnsAsync(versionsResponse);

            ChargeFoxOCPIRegistrationService _service = new ChargeFoxOCPIRegistrationService(
                _loggerMock.Object,
                _configuration,
                _chargeFoxServiceMock.Object,
                _configurationClientMock.Object,
                _secretClientMock.Object,
                _appSettingsMock.Object,
                _ocpiSettingsMock.Object,
                _chargeFoxSettingsMock.Object,
                _configurationRefresherProviderMock.Object);

            // Act & Assert
            await Assert.ThrowsAsync<InvalidOperationException>(() => _service.RegisterAsync(correlationId));

            // Assert: Verify that the logger was called with the specific error message at least once
            _loggerMock.Verify(logger => logger.Log(
                It.Is<LogLevel>(logLevel => logLevel == LogLevel.Error),
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((@object, @type) => @object.ToString().Contains("Could not find any common OCPI versions between Chargefox and Microservice")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()
            ), Times.AtLeastOnce);
        }

        [Fact]
        public async Task RegisterAsync_ShouldUpdateSecretValueAndProperties_WhenCredentialsSubmitted()
        {
            // Arrange
            var correlationId = Guid.NewGuid();
            var chargeFoxSettings = new ChargeFoxSettings
            {
                OCPISenderCredentialsToken = null,
                OCPIHandshakeCredentialsToken = "handshakeToken"
            };
            _chargeFoxSettingsMock.Setup(x => x.Value).Returns(chargeFoxSettings);

            var ocpiSettings = new OCPISettings
            {
                VersionDetails = new OCPIVersion { 
                    Version = new Version(2, 1),
                    Url = "https://example.com/ocpi/1.0"
                 }
            };
            _ocpiSettingsMock.Setup(x => x.Value).Returns(ocpiSettings);

            var versionsResponse = new Services.Common.Connector.Models.OCPI.VersionsResponse
            {
                Versions = new List<Services.Common.Connector.Models.OCPI.OCPIVersion>
                {
                    new Services.Common.Connector.Models.OCPI.OCPIVersion { 
                        Version = new Version(2, 1),
                        URL = "https://example.com/ocpi/1.0"
                    }
                }
            };
            _chargeFoxServiceMock.Setup(x => x.GetVersions(It.IsAny<Guid>(), It.IsAny<string>()))
                .ReturnsAsync(versionsResponse);

            var appSettings = new AppSettings
            {
                ApplicationInsightConnectionString = string.Empty,

            };
            _appSettingsMock.Setup(x => x.Value).Returns(appSettings);

            var credentialsResponse = new SubmitCredentialsResponse
            {
                credentials = new Credentials { Token = "newToken" }
            };
            _chargeFoxServiceMock.Setup(x => x.SubmitCredentials(
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<Credentials>(),
                It.IsAny<string>(),
                It.IsAny<HttpMethod>()))
                .ReturnsAsync(credentialsResponse);

            ChargeFoxOCPIRegistrationService _service = new ChargeFoxOCPIRegistrationService(
                _loggerMock.Object,
                _configuration,
                _chargeFoxServiceMock.Object,
                _configurationClientMock.Object,
                _secretClientMock.Object,
                _appSettingsMock.Object,
                _ocpiSettingsMock.Object,
                _chargeFoxSettingsMock.Object,
                _configurationRefresherProviderMock.Object);

            // Act
            await _service.RegisterAsync(correlationId);

            // Assert
            _secretClientMock.Verify(x => x.SetSecretAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()), Times.Exactly(3));
        }

[Fact]
public async Task RegisterAsync_ShouldLogWarning_WhenHigherChargeFoxVersionIsAvailable()
{
    // Arrange
    var correlationId = Guid.NewGuid();
    var chargeFoxSettings = new ChargeFoxSettings
    {
        OCPISenderCredentialsToken = null,
        OCPIHandshakeCredentialsToken = "handshakeToken"
    };
    _chargeFoxSettingsMock.Setup(x => x.Value).Returns(chargeFoxSettings);

    // Set OCPISettings to a common version (2.2.1) with ChargeFox
    var ocpiSettings = new OCPISettings
    {
        VersionDetails = new OCPIVersion { Version = new Version(2, 2, 1) }  // latestMutualVersion
    };
    _ocpiSettingsMock.Setup(x => x.Value).Returns(ocpiSettings);

    var versionsResponse = new Services.Common.Connector.Models.OCPI.VersionsResponse
    {
        Versions = new List<Services.Common.Connector.Models.OCPI.OCPIVersion>
        {
            new Services.Common.Connector.Models.OCPI.OCPIVersion { Version = new Version(2, 2, 1) },  // Matching version for latestMutualVersion
            new Services.Common.Connector.Models.OCPI.OCPIVersion { Version = new Version(2, 3, 0) }   // highestChargeFoxVersion
        }
    };
    _chargeFoxServiceMock.Setup(x => x.GetVersions(It.IsAny<Guid>(), It.IsAny<string>()))
        .ReturnsAsync(versionsResponse);

    var appSettings = new AppSettings
    {
        ApplicationInsightConnectionString = string.Empty
    };
    _appSettingsMock.Setup(x => x.Value).Returns(appSettings);
         var credentialsResponse = new SubmitCredentialsResponse
            {
                credentials = new Credentials { Token = "newToken" }
            };
    _chargeFoxServiceMock.Setup(x => x.SubmitCredentials(
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<Credentials>(),
                It.IsAny<string>(),
                It.IsAny<HttpMethod>()))
                .ReturnsAsync(credentialsResponse);

    ChargeFoxOCPIRegistrationService _service = new ChargeFoxOCPIRegistrationService(
        _loggerMock.Object,
        _configuration,
        _chargeFoxServiceMock.Object,
        _configurationClientMock.Object,
        _secretClientMock.Object,
        _appSettingsMock.Object,
        _ocpiSettingsMock.Object,
        _chargeFoxSettingsMock.Object,
        _configurationRefresherProviderMock.Object);
 
    // Act
    await _service.RegisterAsync(correlationId, forceRefresh: true);

    // Assert
    _loggerMock.Verify(logger => logger.Log(
        LogLevel.Warning,
        It.IsAny<EventId>(),
        It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("A higher version for Chargefox OCPI version")),
        It.IsAny<Exception>(),
        It.IsAny<Func<It.IsAnyType, Exception?, string>>()
    ), Times.Once);
}


        [Fact]
        public async Task RegisterAsync_ShouldProceed_WhenSenderCredentialsTokenIsEmptyAndForceRefreshIsTrue()
        {
            // Arrange
            var xCorrelationIdentifier = Guid.NewGuid();

            var chargeFoxSettings = new ChargeFoxSettings
            {
                OCPISenderCredentialsToken = string.Empty,
                OCPIHandshakeCredentialsToken = "handshakeToken"
            };
            _chargeFoxSettingsMock.Setup(x => x.Value).Returns(chargeFoxSettings);

            var ocpiSettings = new OCPISettings
            {
                VersionDetails = new OCPIVersion { Version = new Version(2, 1) }
            };
            _ocpiSettingsMock.Setup(x => x.Value).Returns(ocpiSettings);

            var versionsResponse = new Services.Common.Connector.Models.OCPI.VersionsResponse
            {
                Versions = new List<Services.Common.Connector.Models.OCPI.OCPIVersion>
                {
                    new Services.Common.Connector.Models.OCPI.OCPIVersion { Version = new Version(2, 1) }
                }
            };
            _chargeFoxServiceMock.Setup(x => x.GetVersions(It.IsAny<Guid>(), It.IsAny<string>()))
                .ReturnsAsync(versionsResponse);


            // Set up SubmitCredentials to return a valid response
            var submitCredentialsResponse = new SubmitCredentialsResponse
            {
                credentials = new Credentials { Token = "newToken" }
            };
            _chargeFoxServiceMock.Setup(x => x.SubmitCredentials(
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<Credentials>(),
                It.IsAny<string>(),
                It.IsAny<HttpMethod>()))
                .ReturnsAsync(submitCredentialsResponse);

            // Set up appSettings with a valid environment
            var appSettings = new AppSettings
            {
                Environment = "Development"
            };
            _appSettingsMock.Setup(x => x.Value).Returns(appSettings);

            // Initialize the service
            var service = new ChargeFoxOCPIRegistrationService(
                _loggerMock.Object,
                _configuration,
                _chargeFoxServiceMock.Object,
                _configurationClientMock.Object,
                _secretClientMock.Object,
                _appSettingsMock.Object,
                _ocpiSettingsMock.Object,
                _chargeFoxSettingsMock.Object,
                _configurationRefresherProviderMock.Object);

            // Act
            await service.RegisterAsync(xCorrelationIdentifier, forceRefresh: true);

            // Asserts
            _chargeFoxServiceMock.Verify(s => s.SubmitCredentials(
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<Credentials>(),
                It.IsAny<string>(),
                It.IsAny<HttpMethod>()), Times.Once);

            _configurationClientMock.Verify(c => c.SetConfigurationSettingAsync(
                It.IsAny<string>(),         // key
                It.IsAny<string>(),         // value
                It.IsAny<string>(),         // label
                It.IsAny<CancellationToken>()), Times.Once);

            _secretClientMock.Verify(s => s.SetSecretAsync(
                InternalConstants.ChargefoxOCPIReceiverCredentialsTokenKey,
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()), Times.Once);
        }

    }
}