﻿using Azure.Messaging.ServiceBus;
using Cloud.Services.Common.Azure.Cosmos.Interfaces;
using Cloud.Services.EVFeed.Subscriber.ChargeFox.Tests.Infrastructure;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Moq;
using System.Text.Json;
using CosmosDb = Cloud.Services.EVFeed.Common.Models.Connectors.CosmosDb;

namespace Cloud.Services.EVFeed.Subscriber.ChargeFox.Tests
{
    public class EVChargersTariffsSubscriberFunctionTests
    {
        private readonly Mock<ILogger<EVChargersTariffsSubscriberFunction>> _loggerMock;
        private readonly Mock<ICosmosDBService> _tariffsCosmosDbServiceMock;
        private readonly EVChargersTariffsSubscriberFunction _function;

        public EVChargersTariffsSubscriberFunctionTests()
        {
            _loggerMock = new Mock<ILogger<EVChargersTariffsSubscriberFunction>>();
            _tariffsCosmosDbServiceMock = new Mock<ICosmosDBService>();
            _function = new EVChargersTariffsSubscriberFunction(_loggerMock.Object, _tariffsCosmosDbServiceMock.Object);
        }

        [Fact]
        public async Task Run_ValidMessage_ShouldUpsertItemAndCompleteMessage()
        {
            // Arrange
            var tariffId = Guid.NewGuid().ToString();
            var chargerTariff = TestDataHelper.GenerateChargerTariffsResponseMessage(tariffId);
            var sbMessage = ServiceBusModelFactory.ServiceBusReceivedMessage(BinaryData.FromString(JsonSerializer.Serialize(chargerTariff)));
            var sbMessageActionsMock = new Mock<ServiceBusMessageActions>();

            _tariffsCosmosDbServiceMock
                .Setup(x => x.UpsertItemAsync(tariffId, It.IsAny<CosmosDb.ChargerTariff>()))
                .ReturnsAsync(true);

            // Act
            await _function.Run(sbMessage, sbMessageActionsMock.Object);

            // Assert
            _tariffsCosmosDbServiceMock.Verify(x => x.UpsertItemAsync(tariffId, It.IsAny<CosmosDb.ChargerTariff>()), Times.Once);

            sbMessageActionsMock.Verify(x => x.AbandonMessageAsync(sbMessage, It.IsAny<IDictionary<string, object>>(), It.IsAny<CancellationToken>()), Times.Never);
            sbMessageActionsMock.Verify(x => x.DeadLetterMessageAsync(sbMessage, null, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Run_NullChargerTariff_ShouldThrowArgumentNullException()
        {
            // Arrange
            var sbMessage = ServiceBusModelFactory.ServiceBusReceivedMessage(null);
            var sbMessageActionsMock = new Mock<ServiceBusMessageActions>();

            // Act
            await _function.Run(sbMessage, sbMessageActionsMock.Object);

            // Act & Assert
            sbMessageActionsMock.Verify(x => x.DeadLetterMessageAsync(sbMessage, null, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Run_NullChargerTariffId_ShouldThrowArgumentNullException()
        {
            // Arrange
            var chargerTariff = TestDataHelper.GenerateChargerTariffsResponseMessage(null);
            var sbMessage = ServiceBusModelFactory.ServiceBusReceivedMessage(BinaryData.FromString(JsonSerializer.Serialize(chargerTariff)));
            var sbMessageActionsMock = new Mock<ServiceBusMessageActions>();

            // Act
            await _function.Run(sbMessage, sbMessageActionsMock.Object);

            // Assert
            sbMessageActionsMock.Verify(x => x.AbandonMessageAsync(sbMessage, It.IsAny<IDictionary<string, object>>(), It.IsAny<CancellationToken>()), Times.Never);
            sbMessageActionsMock.Verify(x => x.DeadLetterMessageAsync(sbMessage, null, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Run_UpsertItemFailed_ShouldLogErrorAndDeadLetterMessage()
        {
            // Arrange
            var tariffId = Guid.NewGuid().ToString();
            var chargerTariff = TestDataHelper.GenerateChargerTariffsResponseMessage(tariffId);
            var sbMessage = ServiceBusModelFactory.ServiceBusReceivedMessage(BinaryData.FromString(JsonSerializer.Serialize(chargerTariff)));
            var sbMessageActionsMock = new Mock<ServiceBusMessageActions>();

            _tariffsCosmosDbServiceMock
                .Setup(x => x.UpsertItemAsync(tariffId, It.IsAny<CosmosDb.ChargerTariff>()))
                .ReturnsAsync(false);

            _tariffsCosmosDbServiceMock
               .Setup(x => x.UpsertItemAsync(tariffId, It.IsAny<CosmosDb.ChargerTariff>()))
               .Throws(new Exception("Some Error occred"));

            // Act
            await _function.Run(sbMessage, sbMessageActionsMock.Object);

            // Assert
            _tariffsCosmosDbServiceMock.Verify(x => x.UpsertItemAsync(tariffId, It.IsAny<CosmosDb.ChargerTariff>()), Times.Once);

            sbMessageActionsMock.Verify(x => x.AbandonMessageAsync(sbMessage, It.IsAny<IDictionary<string, object>>(), It.IsAny<CancellationToken>()), Times.Never);
            sbMessageActionsMock.Verify(x => x.DeadLetterMessageAsync(sbMessage, null, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Once);
        }
    }
}
