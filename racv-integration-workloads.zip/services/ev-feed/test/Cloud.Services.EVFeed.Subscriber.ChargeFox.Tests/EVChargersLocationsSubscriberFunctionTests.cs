using Azure.Messaging.ServiceBus;
using Cloud.Services.Common.Azure.Cosmos.Interfaces;
using Cloud.Services.EVFeed.Subscriber.ChargeFox.Tests.Infrastructure;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Moq;
using System.Text.Json;
using CosmosDb = Cloud.Services.EVFeed.Common.Models.Connectors.CosmosDb;

namespace Cloud.Services.EVFeed.Subscriber.ChargeFox.Tests
{
    public class EVChargersLocationsSubscriberFunctionTests
    {
        private readonly Mock<ILogger<EVChargersLocationsSubscriberFunction>> _loggerMock;
        private readonly Mock<ICosmosDBService> _locationsCosmosDbServiceMock;
        private readonly EVChargersLocationsSubscriberFunction _function;

        public EVChargersLocationsSubscriberFunctionTests()
        {
            _loggerMock = new Mock<ILogger<EVChargersLocationsSubscriberFunction>>();
            _locationsCosmosDbServiceMock = new Mock<ICosmosDBService>();
            _function = new EVChargersLocationsSubscriberFunction(_loggerMock.Object, _locationsCosmosDbServiceMock.Object);
        }

        [Fact]
        public async Task Run_ValidMessage_ShouldUpsertItemAndCompleteMessage()
        {
            // Arrange
            var locationId = Guid.NewGuid().ToString();
            var chargerLocation = TestDataHelper.GenerateChargerLocationsResponseMessage(locationId);
            var sbMessage = ServiceBusModelFactory.ServiceBusReceivedMessage(BinaryData.FromString(JsonSerializer.Serialize(chargerLocation)));
            var sbMessageActionsMock = new Mock<ServiceBusMessageActions>();

            _locationsCosmosDbServiceMock
                .Setup(x => x.UpsertItemAsync(locationId, It.IsAny<CosmosDb.ChargerLocation>()))
                .ReturnsAsync(true);

            // Act
            await _function.Run(sbMessage, sbMessageActionsMock.Object);

            // Assert
            _locationsCosmosDbServiceMock.Verify(x => x.UpsertItemAsync(locationId, It.IsAny<CosmosDb.ChargerLocation>()), Times.Once);

            sbMessageActionsMock.Verify(x => x.AbandonMessageAsync(sbMessage, It.IsAny<IDictionary<string, object>>(), It.IsAny<CancellationToken>()), Times.Never);
            sbMessageActionsMock.Verify(x => x.DeadLetterMessageAsync(sbMessage, null, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Run_NullChargerLocation_ShouldThrowArgumentNullException()
        {
            // Arrange
            var sbMessage = ServiceBusModelFactory.ServiceBusReceivedMessage(null);
            var sbMessageActionsMock = new Mock<ServiceBusMessageActions>();

            // Act
            await _function.Run(sbMessage, sbMessageActionsMock.Object);

            // Act & Assert
            sbMessageActionsMock.Verify(x => x.DeadLetterMessageAsync(sbMessage, null, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Run_NullChargerLocationId_ShouldThrowArgumentNullException()
        {
            // Arrange
            var chargerLocation = TestDataHelper.GenerateChargerLocationsResponseMessage(null);
            var sbMessage = ServiceBusModelFactory.ServiceBusReceivedMessage(BinaryData.FromString(JsonSerializer.Serialize(chargerLocation)));
            var sbMessageActionsMock = new Mock<ServiceBusMessageActions>();

            // Act
            await _function.Run(sbMessage, sbMessageActionsMock.Object);

            // Assert
            sbMessageActionsMock.Verify(x => x.AbandonMessageAsync(sbMessage, It.IsAny<IDictionary<string, object>>(), It.IsAny<CancellationToken>()), Times.Never);
            sbMessageActionsMock.Verify(x => x.DeadLetterMessageAsync(sbMessage, null, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Run_UpsertItemFailed_ShouldLogErrorAndDeadLetterMessage()
        {
            // Arrange
            var locationId = Guid.NewGuid().ToString();
            var chargerLocation = TestDataHelper.GenerateChargerLocationsResponseMessage(locationId);
            var sbMessage = ServiceBusModelFactory.ServiceBusReceivedMessage(BinaryData.FromString(JsonSerializer.Serialize(chargerLocation)));
            var sbMessageActionsMock = new Mock<ServiceBusMessageActions>();

            _locationsCosmosDbServiceMock
                .Setup(x => x.UpsertItemAsync(locationId, It.IsAny<CosmosDb.ChargerLocation>()))
                .ReturnsAsync(false);

            _locationsCosmosDbServiceMock
               .Setup(x => x.UpsertItemAsync(locationId, It.IsAny<CosmosDb.ChargerLocation>()))
               .Throws(new Exception("Some Error occred"));

            // Act
            await _function.Run(sbMessage, sbMessageActionsMock.Object);

            // Assert
            _locationsCosmosDbServiceMock.Verify(x => x.UpsertItemAsync(locationId, It.IsAny<CosmosDb.ChargerLocation>()), Times.Once);

            sbMessageActionsMock.Verify(x => x.AbandonMessageAsync(sbMessage, It.IsAny<IDictionary<string, object>>(), It.IsAny<CancellationToken>()), Times.Never);
            sbMessageActionsMock.Verify(x => x.DeadLetterMessageAsync(sbMessage, null, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Once);
        }
    }
}