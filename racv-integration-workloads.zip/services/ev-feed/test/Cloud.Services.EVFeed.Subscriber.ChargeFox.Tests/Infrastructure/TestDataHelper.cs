﻿
using Cloud.Services.EVFeed.Common.Models.Connectors.ChargeFox;

namespace Cloud.Services.EVFeed.Subscriber.ChargeFox.Tests.Infrastructure
{
    /// <summary>
    /// Helps to generate test data
    /// </summary>
    public static class TestDataHelper
    {
        public static ChargerLocation GenerateChargerLocationsResponseMessage(string? locationId)
        {
            return new ChargerLocation
            {
                Id = locationId
            };
        }
        public static ChargerTariff GenerateChargerTariffsResponseMessage(string? tariffId)
        {
            return new ChargerTariff
            {
                Id = tariffId
            };
        }
    }
}
