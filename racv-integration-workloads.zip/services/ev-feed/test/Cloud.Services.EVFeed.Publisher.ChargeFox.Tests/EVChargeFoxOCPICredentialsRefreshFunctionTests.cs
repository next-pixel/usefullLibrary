using Cloud.Services.Common.Exceptions;
using Cloud.Services.Common.Models;
using Cloud.Services.EVFeed.Common.Interfaces;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;

namespace Cloud.Services.EVFeed.Publisher.ChargeFox.Tests.Unit
{
    public class ChargeFoxOCPICredentialsRefreshFunctionTest
    {
        private readonly Mock<ILogger<ChargeFoxOCPICredentialsRefreshFunction>> _mockLogger;
        private readonly Mock<IOCPIRegistrationService> _mockOCPIRegistrationService;
        private readonly ChargeFoxOCPICredentialsRefreshFunction _function;

        public ChargeFoxOCPICredentialsRefreshFunctionTest()
        {
            _mockLogger = new Mock<ILogger<ChargeFoxOCPICredentialsRefreshFunction>>();
            _mockOCPIRegistrationService = new Mock<IOCPIRegistrationService>();
            _function = new ChargeFoxOCPICredentialsRefreshFunction(_mockLogger.Object, _mockOCPIRegistrationService.Object);
        }

        [Fact]
        public async Task RunAsync_ShouldReturn200OK_WhenRegistrationSucceeds()
        {
            // Arrange
            var httpRequest = new Mock<HttpRequest>();

            _mockOCPIRegistrationService
                .Setup(service => service.RegisterAsync(It.IsAny<Guid>(), true))
                .Returns(Task.CompletedTask);

            // Act
            var result = await _function.RunAsync(httpRequest.Object);

            // Assert
            result.Should().NotBeNull();
            var okResult = result as ObjectResult;
            okResult.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(StatusCodes.Status200OK);

            var successResponse = okResult?.Value as OperationSuccessResponse;
            successResponse.Should().NotBeNull();
            successResponse?.Data.Should().Be("Successfully refreshed Chargefox OCPI credentials.");

            _mockOCPIRegistrationService.Verify(service => service.RegisterAsync(It.IsAny<Guid>(), true), Times.Once);
        }

        [Fact]
        public async Task RunAsync_ShouldReturn500InternalServerError_WhenRegistrationFails()
        {
            // Arrange
            var httpRequest = new Mock<HttpRequest>();
            var exceptionMessage = "Test exception";

            _mockOCPIRegistrationService
                .Setup(service => service.RegisterAsync(It.IsAny<Guid>(), true))
                .ThrowsAsync(new Exception(exceptionMessage));

            // Act
            var result = await _function.RunAsync(httpRequest.Object);

            // Assert
            result.Should().NotBeNull();
            var objectResult = result as ObjectResult;
            objectResult.Should().NotBeNull();
            objectResult?.StatusCode.Should().Be(StatusCodes.Status500InternalServerError);

            var failureResponse = objectResult?.Value as OperationFailureResponse;
            failureResponse.Should().NotBeNull();
            failureResponse?.ErrorDetails?.FirstOrDefault()?.Message.Should().Be("Error occurred while refreshing Chargefox OCPI Credentials.");

            _mockOCPIRegistrationService.Verify(service => service.RegisterAsync(It.IsAny<Guid>(), true), Times.Once);
        }
    }
}













































































