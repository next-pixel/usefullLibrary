﻿using Azure.Data.Tables;
using Azure.Messaging.ServiceBus;
using Cloud.Services.Common.Azure.ServiceBus.Interfaces;
using Cloud.Services.Common.Azure.TableStorage.Exceptions;
using Cloud.Services.Common.Azure.TableStorage.Interfaces;
using Cloud.Services.Common.Settings;
using Cloud.Services.EVFeed.Common.Constants;
using Cloud.Services.EVFeed.Common.Models.Connectors.ChargeFox;
using Cloud.Services.EVFeed.Connector.ChargeFox.Interfaces;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;

namespace Cloud.Services.EVFeed.Publisher.ChargeFox.Tests.Unit
{
    public class EVChargersLocationsPublisherFunctionTests
    {
        private readonly Mock<ILogger<EVChargersLocationsPublisherFunction>> _loggerMock = new Mock<ILogger<EVChargersLocationsPublisherFunction>>();
        private readonly Mock<IAzureTableStorageService> _azureTableStorageServiceMock = new Mock<IAzureTableStorageService>();
        private readonly Mock<IChargeFoxService> _chargeFoxServiceMock = new Mock<IChargeFoxService>();
        private readonly Mock<IServiceBusClient> _serviceBusClientMock = new Mock<IServiceBusClient>();
        private readonly Mock<IConfiguration> _configurationMock = new Mock<IConfiguration>();
        private readonly Mock<IOptions<ChargeFoxSettings>> _chargeFoxSettingsMock = new Mock<IOptions<ChargeFoxSettings>>();

        public EVChargersLocationsPublisherFunctionTests()
        {
            _chargeFoxSettingsMock
                .Setup(s => s.Value)
                .Returns(new ChargeFoxSettings
                {
                    BaseUrl = "",
                    ChargerLocationsLimit = 200,
                    ChargerTariffsLimit = 200,
                    OCPIReceiverCredentialsToken = "",
                    OCPISenderCredentialsToken = ""
                });
        }

        [Fact]
        public async Task RunAsync_ShouldPublishLocations()
        {
            // Arrange
            var timerInfo = new Mock<TimerInfo>();
            long lastSyncDate = 1717043910;
            var function = new EVChargersLocationsPublisherFunction(
                _loggerMock.Object,
                _serviceBusClientMock.Object,
                _azureTableStorageServiceMock.Object,
                _chargeFoxServiceMock.Object,
                _configurationMock.Object,
                _chargeFoxSettingsMock.Object);


            var locationsResponse = new List<ChargerLocation>
                {
                    new ChargerLocation
                    {
                        Id = Guid.NewGuid().ToString(),
                        Name = "Location 1",
                        LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime
                    },
                    new ChargerLocation
                    {
                        Id = Guid.NewGuid().ToString(),
                        Name = "Location 2",
                        LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime
                    }
                };

            _azureTableStorageServiceMock
                .Setup(s => s.GetTableEntry(nameof(EVChargersLocationsPublisherFunction), InternalConstants.PartitionKey))
                .Returns(Task.FromResult(
                    new TableEntity(
                        new Dictionary<string, object>
                        {
                            {
                                InternalConstants.LastSyncDate, lastSyncDate
                            }
                        })));

            _chargeFoxServiceMock.Setup(s => s.GetDeltaChargerLocations(It.IsAny<long>(), 200, It.IsAny<Guid>(), 0))
                .ReturnsAsync(locationsResponse);

            _serviceBusClientMock.Setup(s => s.SendMessagesAsync(It.IsAny<string>(), It.IsAny<List<ServiceBusMessage>>()))
                .Returns(Task.CompletedTask);

            // Act
            await function.RunAsync(timerInfo.Object);

            // Assert
            _chargeFoxServiceMock.Verify(s => s.GetDeltaChargerLocations(lastSyncDate, 200, It.IsAny<Guid>(), 0));
            _serviceBusClientMock.Verify(s => s.SendMessagesAsync(It.IsAny<string>(), It.IsAny<List<ServiceBusMessage>>()), Times.Once);
            _azureTableStorageServiceMock.Verify(s => s.UpsertEntityAsync(It.IsAny<TableEntity>()), Times.Once);
        }

        [Fact]
        public async Task RunAsync_ShouldRun_WhenLastSyncDateDoesNotExist()
        {
            // Arrange
            var timerInfo = new Mock<TimerInfo>();
            var locationsResponse = new List<ChargerLocation>
                {
                    new ChargerLocation { Id = Guid.NewGuid().ToString(), Name = "Location 1",LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime},
                    new ChargerLocation { Id = Guid.NewGuid().ToString(), Name = "Location 2",LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime},
                };
            var function = new EVChargersLocationsPublisherFunction(
               _loggerMock.Object,
               _serviceBusClientMock.Object,
               _azureTableStorageServiceMock.Object,
               _chargeFoxServiceMock.Object,
               _configurationMock.Object,
               _chargeFoxSettingsMock.Object);

            _azureTableStorageServiceMock
               .Setup(s => s.GetTableEntry(nameof(EVChargersLocationsPublisherFunction), InternalConstants.PartitionKey))
               .Returns(Task.FromResult(new TableEntity(new Dictionary<string, object> { })));

            _chargeFoxServiceMock.Setup(s => s.GetDeltaChargerLocations(0, 200, It.IsAny<Guid>(), 0))
                .ReturnsAsync(locationsResponse);

            _serviceBusClientMock.Setup(s => s.SendMessagesAsync(It.IsAny<string>(), It.IsAny<List<ServiceBusMessage>>()))
                .Returns(Task.CompletedTask);

            // Act
            await function.RunAsync(timerInfo.Object);

            // Assert

            _chargeFoxServiceMock.Verify(s => s.GetDeltaChargerLocations(0, 200, It.IsAny<Guid>(), 0));
            _serviceBusClientMock.Verify(s => s.SendMessagesAsync(It.IsAny<string>(), It.IsAny<List<ServiceBusMessage>>()), Times.Once);
            _azureTableStorageServiceMock.Verify(s => s.UpsertEntityAsync(It.IsAny<TableEntity>()), Times.Once);
        }

        [Fact]
        public async Task RunAsync_ShouldRun_WhenEntryNotFoundInStorageTable()
        {
            // Arrange
            // Arrange
            var timerInfo = new Mock<TimerInfo>();
            var function = new EVChargersLocationsPublisherFunction(
               _loggerMock.Object,
               _serviceBusClientMock.Object,
               _azureTableStorageServiceMock.Object,
               _chargeFoxServiceMock.Object,
               _configurationMock.Object,
               _chargeFoxSettingsMock.Object);

            var locationsResponse = new List<ChargerLocation>
                {
                    new ChargerLocation { Id = Guid.NewGuid().ToString(), Name = "Location 1", LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime},
                    new ChargerLocation { Id = Guid.NewGuid().ToString(), Name = "Location 2", LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime}
                };

            _azureTableStorageServiceMock.Setup(x => x.GetTableEntry(nameof(EVChargersLocationsPublisherFunction), InternalConstants.PartitionKey))
                .Throws<EntryNotFoundException>();

            _chargeFoxServiceMock.Setup(s => s.GetDeltaChargerLocations(0, 200, It.IsAny<Guid>(), 0))
              .ReturnsAsync(locationsResponse);

            _serviceBusClientMock.Setup(s => s.SendMessagesAsync(It.IsAny<string>(), It.IsAny<List<ServiceBusMessage>>()))
                .Returns(Task.CompletedTask);

            // Act
            await function.RunAsync(timerInfo.Object);

            // Assert

            _chargeFoxServiceMock.Verify(s => s.GetDeltaChargerLocations(0, 200, It.IsAny<Guid>(), 0));
            _serviceBusClientMock.Verify(s => s.SendMessagesAsync(It.IsAny<string>(), It.IsAny<List<ServiceBusMessage>>()), Times.Once);
            _azureTableStorageServiceMock.Verify(s => s.UpsertEntityAsync(It.IsAny<TableEntity>()), Times.Once);
        }

        [Fact]
        public async Task RunAsync_ShouldThrowException_WhenAnErrorOccurs()
        {
            // Arrange
            var timerInfo = new Mock<TimerInfo>();
            var exception = new Exception("Test exception");
            var lastSyncDate = "1234567890";
            var function = new EVChargersLocationsPublisherFunction(
               _loggerMock.Object,
               _serviceBusClientMock.Object,
               _azureTableStorageServiceMock.Object,
               _chargeFoxServiceMock.Object,
               _configurationMock.Object,
               _chargeFoxSettingsMock.Object);

            _azureTableStorageServiceMock
                .Setup(s => s.GetTableEntry(nameof(EVChargersLocationsPublisherFunction), InternalConstants.PartitionKey))
                .Returns(Task.FromResult(
                    new TableEntity(
                        new Dictionary<string, object>
                        {
                            {
                                InternalConstants.LastSyncDate, lastSyncDate
                            }
                        })));

            _chargeFoxServiceMock.Setup(x => x.GetDeltaChargerLocations(It.IsAny<long>(), 200, It.IsAny<Guid>(), 0))
                .Throws(exception);

            // Act
            await function.RunAsync(timerInfo.Object);

            // Assert
            _loggerMock.Setup(logger => logger.Log(
                It.Is<LogLevel>(logLevel => logLevel == LogLevel.Error),
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((@object, @type) => true),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()
            ));
        }
    }
}