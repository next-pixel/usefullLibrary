﻿using Azure.Data.Tables;
using Azure.Messaging.ServiceBus;
using Cloud.Services.Common.Azure.ServiceBus.Interfaces;
using Cloud.Services.Common.Azure.TableStorage.Exceptions;
using Cloud.Services.Common.Azure.TableStorage.Interfaces;
using Cloud.Services.Common.Settings;
using Cloud.Services.EVFeed.Common.Constants;
using Cloud.Services.EVFeed.Common.Models.Connectors.ChargeFox;
using Cloud.Services.EVFeed.Common.Settings;
using Cloud.Services.EVFeed.Connector.ChargeFox.Interfaces;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;

namespace Cloud.Services.EVFeed.Publisher.ChargeFox.Tests.Unit
{
    public class EVChargersTariffsPublisherFunctionTests
    {
        private readonly Mock<ILogger<EVChargersTariffsPublisherFunction>> _loggerMock = new Mock<ILogger<EVChargersTariffsPublisherFunction>>();
        private readonly Mock<IAzureTableStorageService> _azureTableStorageServiceMock = new Mock<IAzureTableStorageService>();
        private readonly Mock<IChargeFoxService> _chargeFoxServiceMock = new Mock<IChargeFoxService>();
        private readonly Mock<IServiceBusClient> _serviceBusClientMock = new Mock<IServiceBusClient>();
        private readonly Mock<IConfiguration> _configurationMock = new Mock<IConfiguration>();
        private readonly Mock<IOptions<ChargeFoxSettings>> _chargeFoxSettingsMock = new Mock<IOptions<ChargeFoxSettings>>();

        public EVChargersTariffsPublisherFunctionTests()
        {
            _chargeFoxSettingsMock
                .Setup(s => s.Value)
                .Returns(new ChargeFoxSettings
                {
                    BaseUrl = "",
                    ChargerLocationsLimit = 200,
                    ChargerTariffsLimit = 200,
                    OCPIReceiverCredentialsToken = "",
                    OCPISenderCredentialsToken = ""
                });
        }

        [Fact]
        public async Task RunAsync_ShouldPublishTariffs()
        {
            // Arrange
            var timerInfo = new Mock<TimerInfo>();
            long lastSyncDate = 1717043910;
            var function = new EVChargersTariffsPublisherFunction(
                _loggerMock.Object,
                _serviceBusClientMock.Object,
                _azureTableStorageServiceMock.Object,
                _chargeFoxServiceMock.Object,
                _configurationMock.Object,
                _chargeFoxSettingsMock.Object);

            var tariffsResponse = new List<ChargerTariff>
            {
                new ChargerTariff { Id = Guid.NewGuid().ToString(), Type = "Tariff 1", LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime},
                new ChargerTariff { Id = Guid.NewGuid().ToString(), Type = "Tariff 2", LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime},
            };

            _azureTableStorageServiceMock
                .Setup(s => s.GetTableEntry(nameof(EVChargersTariffsPublisherFunction), InternalConstants.PartitionKey))
                .Returns(Task.FromResult(
                    new TableEntity(
                        new Dictionary<string, object>
                        {
                            {
                                InternalConstants.LastSyncDate, lastSyncDate
                            }
                        })));

            _chargeFoxServiceMock.Setup(s => s.GetDeltaChargerTariffs(It.IsAny<long>(), 200, It.IsAny<Guid>(), 0))
                .ReturnsAsync(tariffsResponse);

            _serviceBusClientMock.Setup(s => s.SendMessagesAsync(It.IsAny<string>(), It.IsAny<List<ServiceBusMessage>>()))
                .Returns(Task.CompletedTask);

            // Act
            await function.RunAsync(timerInfo.Object);

            // Assert
            _chargeFoxServiceMock.Verify(s => s.GetDeltaChargerTariffs(lastSyncDate, 200, It.IsAny<Guid>(), 0));
            _serviceBusClientMock.Verify(s => s.SendMessagesAsync(It.IsAny<string>(), It.IsAny<List<ServiceBusMessage>>()), Times.Once);
            _azureTableStorageServiceMock.Verify(s => s.UpsertEntityAsync(It.IsAny<TableEntity>()), Times.Once);
        }

        [Fact]
        public async Task RunAsync_ShouldRun_WhenLastSyncDateDoesNotExist()
        {
            // Arrange
            var timerInfo = new Mock<TimerInfo>();
            var tariffsResponse = new List<ChargerTariff>
            {
                new ChargerTariff { Id = Guid.NewGuid().ToString(), Type = "Tariff 1", LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime},
                new ChargerTariff { Id = Guid.NewGuid().ToString(), Type = "Tariff 2", LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime},
            };
            var function = new EVChargersTariffsPublisherFunction(
               _loggerMock.Object,
               _serviceBusClientMock.Object,
               _azureTableStorageServiceMock.Object,
               _chargeFoxServiceMock.Object,
               _configurationMock.Object,
               _chargeFoxSettingsMock.Object);

            _azureTableStorageServiceMock
               .Setup(s => s.GetTableEntry(nameof(EVChargersTariffsPublisherFunction), InternalConstants.PartitionKey))
               .Returns(Task.FromResult(new TableEntity(new Dictionary<string, object> { })));

            _chargeFoxServiceMock.Setup(s => s.GetDeltaChargerTariffs(0, 200, It.IsAny<Guid>(), 0))
                .ReturnsAsync(tariffsResponse);

            _serviceBusClientMock.Setup(s => s.SendMessagesAsync(It.IsAny<string>(), It.IsAny<List<ServiceBusMessage>>()))
                .Returns(Task.CompletedTask);

            // Act
            await function.RunAsync(timerInfo.Object);

            // Assert

            _chargeFoxServiceMock.Verify(s => s.GetDeltaChargerTariffs(0, 200, It.IsAny<Guid>(), 0));
            _serviceBusClientMock.Verify(s => s.SendMessagesAsync(It.IsAny<string>(), It.IsAny<List<ServiceBusMessage>>()), Times.Once);
            _azureTableStorageServiceMock.Verify(s => s.UpsertEntityAsync(It.IsAny<TableEntity>()), Times.Once);
        }

        [Fact]
        public async Task RunAsync_ShouldRun_WhenEntryNotFoundInStorageTable()
        {
            // Arrange
            // Arrange
            var timerInfo = new Mock<TimerInfo>();
            var function = new EVChargersTariffsPublisherFunction(
               _loggerMock.Object,
               _serviceBusClientMock.Object,
               _azureTableStorageServiceMock.Object,
               _chargeFoxServiceMock.Object,
               _configurationMock.Object,
               _chargeFoxSettingsMock.Object);


            var tariffsResponse = new List<ChargerTariff>
            {
                new ChargerTariff { Id = Guid.NewGuid().ToString(), Type = "Tariff 1", LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime},
                new ChargerTariff { Id = Guid.NewGuid().ToString(), Type = "Tariff 2", LastUpdated = DateTimeOffset.FromUnixTimeSeconds(1717043920).DateTime}
            };

            _azureTableStorageServiceMock.Setup(x => x.GetTableEntry(nameof(EVChargersTariffsPublisherFunction), InternalConstants.PartitionKey))
                .Throws<EntryNotFoundException>();

            _chargeFoxServiceMock.Setup(s => s.GetDeltaChargerTariffs(0, 200, It.IsAny<Guid>(), 0))
              .ReturnsAsync(tariffsResponse);

            _serviceBusClientMock.Setup(s => s.SendMessagesAsync(It.IsAny<string>(), It.IsAny<List<ServiceBusMessage>>()))
                .Returns(Task.CompletedTask);

            // Act
            await function.RunAsync(timerInfo.Object);

            // Assert
            _chargeFoxServiceMock.Verify(s => s.GetDeltaChargerTariffs(0, 200, It.IsAny<Guid>(), 0));
            _serviceBusClientMock.Verify(s => s.SendMessagesAsync(It.IsAny<string>(), It.IsAny<List<ServiceBusMessage>>()), Times.Once);
            _azureTableStorageServiceMock.Verify(s => s.UpsertEntityAsync(It.IsAny<TableEntity>()), Times.Once);
        }

        [Fact]
        public async Task RunAsync_ShouldThrowException_WhenAnErrorOccurs()
        {
            // Arrange
            var timerInfo = new Mock<TimerInfo>();
            var exception = new Exception("Test exception");
            var lastSyncDate = "1234567890";
            var function = new EVChargersTariffsPublisherFunction(
               _loggerMock.Object,
               _serviceBusClientMock.Object,
               _azureTableStorageServiceMock.Object,
               _chargeFoxServiceMock.Object,
               _configurationMock.Object,
               _chargeFoxSettingsMock.Object);

            _azureTableStorageServiceMock
                .Setup(s => s.GetTableEntry(nameof(EVChargersTariffsPublisherFunction), InternalConstants.PartitionKey))
                .Returns(Task.FromResult(
                    new TableEntity(
                        new Dictionary<string, object>
                        {
                            {
                                InternalConstants.LastSyncDate, lastSyncDate
                            }
                        })));

            _chargeFoxServiceMock.Setup(x => x.GetDeltaChargerTariffs(It.IsAny<long>(), 200, It.IsAny<Guid>(), 0))
                .Throws(exception);

            // Act
            await function.RunAsync(timerInfo.Object);

            // Assert
            _loggerMock.Setup(logger => logger.Log(
                It.Is<LogLevel>(logLevel => logLevel == LogLevel.Error),
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((@object, @type) => true),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()
            ));
        }
    }
}