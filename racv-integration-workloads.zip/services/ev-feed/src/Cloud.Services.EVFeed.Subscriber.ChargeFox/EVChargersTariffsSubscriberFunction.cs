using System.Text.Json;
using Azure.Messaging.ServiceBus;
using Cloud.Services.Common.Constants;
using Cloud.Services.EVFeed.Common.Models.Connectors.ChargeFox;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Cloud.Services.EVFeed.Common.Extensions;
using Cloud.Services.Common.Azure.Cosmos.Interfaces;
using Microsoft.Azure.Cosmos;
using Cloud.Services.Common.Azure.Cosmos.Implementations;
using Cloud.Services.EVFeed.Common.Settings;
using Cloud.Services.Common.Azure.Cosmos.Settings;
using Microsoft.Extensions.Options;
using Cloud.Services.EVFeed.Common.Constants;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Azure.WebJobs;

namespace Cloud.Services.EVFeed.Subscriber.ChargeFox
{
    public class EVChargersTariffsSubscriberFunction
    {
        /// <summary>
        /// This variable is used to log application related logs.
        /// </summary>
        private readonly ILogger<EVChargersTariffsSubscriberFunction> _logger;

        /// <summary>
        /// Represents the service for interacting with the Cosmos DB for charger tariffs.
        /// </summary>
        private readonly ICosmosDBService _tariffsCosmosDbService;


        public EVChargersTariffsSubscriberFunction(
            ILogger<EVChargersTariffsSubscriberFunction> logger,
            [FromKeyedServices(InternalConstants.TariffsCosmosDbServiceKey)] ICosmosDBService tariffsCosmosDbService)

        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _tariffsCosmosDbService = tariffsCosmosDbService ?? throw new ArgumentNullException(nameof(tariffsCosmosDbService));
        }
        
        [Singleton]
        [Function(nameof(EVChargersTariffsSubscriberFunction))]
        public async Task Run(
             [ServiceBusTrigger(
            "%EVTariffsTopicName%",
            "%EVTariffsCosmosDbSubscriptionName%",
            Connection = "ServiceBusConnection")]
            ServiceBusReceivedMessage sbMessage,
            ServiceBusMessageActions messageActions)
        {
            var correlationIdentifier = sbMessage.CorrelationId;
            try
            {
                var chargerTariff = JsonSerializer.Deserialize<ChargerTariff>(sbMessage.Body.ToString());

                if (chargerTariff == null) throw new InvalidOperationException("ChargerTariff cannot be null");
                if (chargerTariff.Id == null) throw new InvalidOperationException("ChargerTariff Id cannot be null");

                _logger.LogInformation("Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "} Starting {FunctionName} for message Id: {MessageId}",
                    correlationIdentifier,
                    nameof(EVChargersTariffsSubscriberFunction),
                    chargerTariff.Id);

                var cosmosDbChargerTariff = chargerTariff.Convert();
                var result = await _tariffsCosmosDbService.UpsertItemAsync(cosmosDbChargerTariff.Id, cosmosDbChargerTariff);
                if (result)
                {
                    _logger.LogInformation("Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "} Record updated/inserted for message Id: {MessageId}",
                       correlationIdentifier,
                       nameof(EVChargersTariffsSubscriberFunction),
                       chargerTariff.Id);
                }

                // Complete the message
                await messageActions.CompleteMessageAsync(sbMessage);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "} Unexpected error occurred; {exception}; {innerException}; {stackTrace}",
                    correlationIdentifier,
                    ex.Message,
                    ex.InnerException?.Message,
                    ex.StackTrace);
                await messageActions.DeadLetterMessageAsync(sbMessage);
            }
        }
    }
}
