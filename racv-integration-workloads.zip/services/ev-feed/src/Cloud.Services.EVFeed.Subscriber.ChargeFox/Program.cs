using Azure.Identity;
using Cloud.Services.Common.Azure.Cosmos.Implementations;
using Cloud.Services.Common.Azure.Cosmos.Interfaces;
using Cloud.Services.Common.Azure.Cosmos.Settings;
using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Extensions;
using Cloud.Services.Common.Settings;
using Cloud.Services.Common.Tracking.Implementations;
using Cloud.Services.Common.Tracking.Interfaces;
using Cloud.Services.EVFeed.Common.Constants;
using Cloud.Services.EVFeed.Common.Settings;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

IConfigurationRoot? configuration = null;
var functionAppSettings = new AppSettings();

var host = new HostBuilder()
    .ConfigureFunctionsWebApplication()
    .ConfigureAppConfiguration(configBuilder =>
    {
        // compile a temporary configuration instance
        configuration = configBuilder.Build();

        // Retrieve the function app settings from the application configuration.
        configuration.Bind(functionAppSettings);

        configBuilder.AddAzureAppConfigurationOptions(
            new Uri(functionAppSettings.AppConfigurationEndPoint),
            functionAppSettings.AzureClientId,
            functionAppSettings.Environment,
            functionAppSettings.Workload,
            ServicesConstants.ConfigurationRefreshKey);

        // compile a temporary configuration instance
        configuration = configBuilder.Build();
    })
    .ConfigureServices(services =>
    {
        // Enable application insights.
        services.AddApplicationInsightsTelemetryWorkerService();
        services.ConfigureFunctionsApplicationInsights();
        services.Configure<LoggerFilterOptions>(options =>
        {
            // The Application Insights SDK adds a default logging filter that instructs ILogger to capture only Warning and more severe logs. Application Insights requires an explicit override.
            LoggerFilterRule toRemove = options.Rules.FirstOrDefault(rule => rule.ProviderName == "Microsoft.Extensions.Logging.ApplicationInsights.ApplicationInsightsLoggerProvider")!;
            if (toRemove is not null)
            {
                options.Rules.Remove(toRemove);
            }
        });

        // EV Feed Settings
        var evFeedSettings = new EVFeedSettings();
        configuration?.Bind(EVFeedSettings.ConfigurationSectionName, evFeedSettings);

        // Cosmos settings
        var CosmosSettings = new CosmosDbBaseSettings();
        configuration?.Bind(CosmosDbBaseSettings.ConfigurationSectionName, CosmosSettings);


        var cosmosClient = new CosmosClient(
            CosmosSettings.Endpoint,
#if DEBUG
            new AzureCliCredential(),
#else
            new ManagedIdentityCredential(functionAppSettings.AzureClientId),
#endif
        new CosmosClientOptions()
        {
            ConnectionMode = ConnectionMode.Gateway,
            SerializerOptions = new CosmosSerializationOptions()
            {
                PropertyNamingPolicy = CosmosPropertyNamingPolicy.CamelCase,
            }
        });

        var locationsContainer = cosmosClient.GetContainer(CosmosSettings.DatabaseId, evFeedSettings.LocationsContainerId);
        var tariffsContainer = cosmosClient.GetContainer(CosmosSettings.DatabaseId, evFeedSettings.TariffsContainerId);

        services.AddKeyedSingleton<ICosmosDBService>(
            InternalConstants.LocationsCosmosDbServiceKey, new CosmosDBService(locationsContainer));
        services.AddKeyedSingleton<ICosmosDBService>(
            InternalConstants.TariffsCosmosDbServiceKey, new CosmosDBService(tariffsContainer));
    })
    .Build();

await host.RunAsync();