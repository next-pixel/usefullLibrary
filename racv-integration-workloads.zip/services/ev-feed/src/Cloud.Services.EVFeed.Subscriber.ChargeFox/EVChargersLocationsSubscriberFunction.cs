using Azure.Messaging.ServiceBus;
using Cloud.Services.Common.Azure.Cosmos.Interfaces;
using Cloud.Services.Common.Constants;
using Cloud.Services.EVFeed.Common.Constants;
using Cloud.Services.EVFeed.Common.Extensions;
using Cloud.Services.EVFeed.Common.Models.Connectors.ChargeFox;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using Microsoft.Azure.WebJobs;

namespace Cloud.Services.EVFeed.Subscriber.ChargeFox
{
    public class EVChargersLocationsSubscriberFunction
    {
        /// <summary>
        /// This variable is used to log application related logs.
        /// </summary>
        private readonly ILogger<EVChargersLocationsSubscriberFunction> _logger;

        /// <summary>
        /// This variable is used as a service to perform operations in Cosmos DB
        /// </summary>
        private readonly ICosmosDBService _locationsCosmosDbService;

        public EVChargersLocationsSubscriberFunction(
            ILogger<EVChargersLocationsSubscriberFunction> logger,
            [FromKeyedServices(InternalConstants.LocationsCosmosDbServiceKey)] ICosmosDBService locationsCosmosDbService)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _locationsCosmosDbService = locationsCosmosDbService ?? throw new ArgumentNullException(nameof(locationsCosmosDbService));

        }

        [Singleton]
        [Function(nameof(EVChargersLocationsSubscriberFunction))]
        public async Task Run(
            [ServiceBusTrigger(
            "%EVLocationsTopicName%",
            "%EVLocationsCosmosDbSubscriptionName%",
            Connection = "ServiceBusConnection")]
            ServiceBusReceivedMessage sbMessage,
            ServiceBusMessageActions messageActions)
        {
            var correlationIdentifier = sbMessage.CorrelationId;
            try
            {
                var chargerLocation = JsonSerializer.Deserialize<ChargerLocation>(sbMessage.Body.ToString());

                if (chargerLocation == null) throw new InvalidOperationException("ChargerLocation cannot be null");
                if (chargerLocation.Id == null) throw new InvalidOperationException("ChargerLocation Id cannot be null");

                _logger.LogInformation("Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "} Starting {FunctionName} for message Id: {MessageId}",
                    correlationIdentifier,
                    nameof(EVChargersLocationsSubscriberFunction),
                    chargerLocation.Id);

                var cosmosDbChargerLocation = chargerLocation.Convert();
                var result = await _locationsCosmosDbService.UpsertItemAsync(cosmosDbChargerLocation.Id, cosmosDbChargerLocation);
                if (result)
                {
                    _logger.LogInformation("Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "} Record updated/inserted for message Id: {MessageId}",
                       correlationIdentifier,
                       nameof(EVChargersLocationsSubscriberFunction),
                       chargerLocation.Id);
                }

                // Complete the message
                await messageActions.CompleteMessageAsync(sbMessage);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "} Unexpected error occurred; {exception}; {innerException}; {stackTrace}",
                    correlationIdentifier,
                    ex.Message,
                    ex.InnerException?.Message,
                    ex.StackTrace);
                await messageActions.DeadLetterMessageAsync(sbMessage);
            }
        }
    }
}
