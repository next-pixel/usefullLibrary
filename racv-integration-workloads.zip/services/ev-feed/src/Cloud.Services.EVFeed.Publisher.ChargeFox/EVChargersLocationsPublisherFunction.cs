using Azure.Data.Tables;
using Azure.Messaging.ServiceBus;
using Cloud.Services.Common.Azure.ServiceBus.Interfaces;
using Cloud.Services.Common.Azure.TableStorage.Exceptions;
using Cloud.Services.Common.Azure.TableStorage.Interfaces;
using Cloud.Services.Common.Constants;
using Cloud.Services.EVFeed.Common.Constants;
using Cloud.Services.EVFeed.Common.Extensions;
using Cloud.Services.EVFeed.Connector.ChargeFox.Interfaces;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.Text.Json;
using Microsoft.Azure.WebJobs;
using Cloud.Services.Common.Settings;

namespace Cloud.Services.EVFeed.Publisher.ChargeFox
{
    /// <summary>
    /// Azure function for the publisher.
    /// </summary>
    public class EVChargersLocationsPublisherFunction
    {
        /// <summary>
        /// Logger.
        /// </summary>
        private readonly ILogger<EVChargersLocationsPublisherFunction> _logger;

        /// <summary>
        /// Interface to publish messages.
        /// </summary>
        private readonly IServiceBusClient _serviceBusClient;

        /// <summary>
        /// Azure Table Storage Connector
        /// </summary>
        private readonly IAzureTableStorageService _azureTableStorageService;

        /// <summary>
        /// ChargeFox Service.
        /// </summary>
        private readonly IChargeFoxService _chargeFoxService;

        /// <summary>
        /// This variable is used to fetch configuration
        /// </summary>
        private readonly IConfiguration _configuration;

        /// <summary>
        /// ChargerFox Settings
        /// </summary>
        private readonly ChargeFoxSettings _settings;

        public EVChargersLocationsPublisherFunction(
            ILogger<EVChargersLocationsPublisherFunction> logger,
            IServiceBusClient serviceBusClient,
            IAzureTableStorageService azureTableStorageService,
            IChargeFoxService chargeFoxService,
            IConfiguration configuration,
            IOptions<ChargeFoxSettings> settings)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _serviceBusClient = serviceBusClient ?? throw new ArgumentNullException(nameof(serviceBusClient));
            _azureTableStorageService = azureTableStorageService ?? throw new ArgumentNullException(nameof(azureTableStorageService));
            _chargeFoxService = chargeFoxService ?? throw new ArgumentNullException(nameof(chargeFoxService));
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            _settings = settings.Value;
        }

        [Singleton]
        [Function("EVChargersLocationsPublisherFunction")]
        public async Task RunAsync([TimerTrigger("%EVLocationsPublisherFunctionTimer%")] TimerInfo myTimer)
        {
            var xCorrelationIdentifier = Guid.NewGuid();
            try
            {
                _logger.LogInformation("CorrelationId : { " + ServicesConstants.CorrelationIdLogPropertyName + "} Started executing {FunctionName}.",
                    xCorrelationIdentifier,
                    nameof(EVChargersLocationsPublisherFunction));

                // Set function start time
                var functionStartTime = DateTime.UtcNow.GetEpoch();
                var entry = new TableEntity(nameof(EVChargersLocationsPublisherFunction), InternalConstants.PartitionKey);

                try
                {
                    // Get last sync date
                    entry = await _azureTableStorageService.GetTableEntry(nameof(EVChargersLocationsPublisherFunction), InternalConstants.PartitionKey);
                }
                catch (EntryNotFoundException)
                {
                    _logger.LogInformation("Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "}, {PartitionKey}(RowKey) not found, adding the corresponding entry to the storage table.",
                        xCorrelationIdentifier,
                        nameof(EVChargersLocationsPublisherFunction),
                        InternalConstants.PartitionKey);
                }

                // Get delta locations with watermark
                var watermark = Convert.ToInt64(entry[InternalConstants.LastSyncDate]);
                var locationsResponse = await _chargeFoxService.GetDeltaChargerLocations(watermark, _settings.ChargerLocationsLimit, xCorrelationIdentifier, _settings.ChargerLocationsRequestDelayInMs);

                // Map each location to service bus message
                var serviceBusMessages = new List<ServiceBusMessage>();
                if (!locationsResponse.IsNullOrEmpty())
                {
                    serviceBusMessages = locationsResponse
                        .Where(chargerLocation => chargerLocation.LastUpdated.GetEpoch() > watermark)
                        .Select(chargerLocation =>
                        {
                            var message = new ServiceBusMessage(JsonSerializer.Serialize(chargerLocation));
                            message.CorrelationId = xCorrelationIdentifier.ToString();
                            return message;
                        })
                        .ToList();
                }

                // Publish locations
                if (!serviceBusMessages.IsNullOrEmpty())
                {
                    await _serviceBusClient.SendMessagesAsync(_configuration[InternalConstants.EVLocationsTopicNameKey], serviceBusMessages);
                }

                // Upsert last sync date to function start time
                entry[InternalConstants.LastSyncDate] = functionStartTime;
                await _azureTableStorageService.UpsertEntityAsync(entry);

                _logger.LogInformation("Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "}, Successful Run for {FunctionName}",
                xCorrelationIdentifier,
                nameof(EVChargersLocationsPublisherFunction));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "} {FunctionName} failed with error: {message}.",
                    xCorrelationIdentifier,
                    nameof(EVChargersLocationsPublisherFunction),
                    ex.Message);
            }
        }
    }
}
