using Azure.Data.Tables;
using Azure.Messaging.ServiceBus;
using Cloud.Services.Common.Azure.ServiceBus.Interfaces;
using Cloud.Services.Common.Azure.TableStorage.Exceptions;
using Cloud.Services.Common.Azure.TableStorage.Interfaces;
using Cloud.Services.Common.Constants;
using Cloud.Services.EVFeed.Common.Constants;
using Cloud.Services.EVFeed.Common.Extensions;
using Cloud.Services.EVFeed.Connector.ChargeFox.Interfaces;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.Text.Json;
using Microsoft.Azure.WebJobs;
using Cloud.Services.Common.Settings;

namespace Cloud.Services.EVFeed.Publisher.ChargeFox
{
    /// <summary>
    /// Azure function for the publisher.
    /// </summary>
    public class EVChargersTariffsPublisherFunction
    {
        /// <summary>
        /// Logger.
        /// </summary>
        private readonly ILogger<EVChargersTariffsPublisherFunction> _logger;

        /// <summary>
        /// Interface to publish messages.
        /// </summary>
        private readonly IServiceBusClient _serviceBusClient;

        /// <summary>
        /// Azure Table Storage Connector
        /// </summary>
        private readonly IAzureTableStorageService _azureTableStorageService;

        /// <summary>
        /// ChargeFox Service.
        /// </summary>
        private readonly IChargeFoxService _chargeFoxService;

        /// <summary>
        /// This variable is used to fetch configuration
        /// </summary>
        private readonly IConfiguration _configuration;

        /// <summary>
        /// ChargerFox Settings
        /// </summary>
        private readonly ChargeFoxSettings _settings;

        public EVChargersTariffsPublisherFunction(
            ILogger<EVChargersTariffsPublisherFunction> logger,
            IServiceBusClient serviceBusClient,
            IAzureTableStorageService azureTableStorageService,
            IChargeFoxService chargeFoxService,
            IConfiguration configuration,
            IOptions<ChargeFoxSettings> settings)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _serviceBusClient = serviceBusClient ?? throw new ArgumentNullException(nameof(serviceBusClient));
            _azureTableStorageService = azureTableStorageService ?? throw new ArgumentNullException(nameof(azureTableStorageService));
            _chargeFoxService = chargeFoxService ?? throw new ArgumentNullException(nameof(chargeFoxService));
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            _settings = settings.Value;
        }

        [Singleton]
        [Function("EVChargersTariffsPublisherFunction")]
        public async Task RunAsync([TimerTrigger("%EVTariffsPublisherFunctionTimer%")] TimerInfo myTimer)
        {
            var xCorrelationIdentifier = Guid.NewGuid();
            try
            {
                _logger.LogInformation("CorrelationId : { " + ServicesConstants.CorrelationIdLogPropertyName + "} Started executing {FunctionName}.",
                    xCorrelationIdentifier,
                    nameof(EVChargersTariffsPublisherFunction));

                // Set function start time
                var functionStartTime = DateTime.UtcNow.GetEpoch();
                var entry = new TableEntity(nameof(EVChargersTariffsPublisherFunction), InternalConstants.PartitionKey);

                try
                {
                    // Get last sync date
                    entry = await _azureTableStorageService.GetTableEntry(nameof(EVChargersTariffsPublisherFunction), InternalConstants.PartitionKey);
                }
                catch (EntryNotFoundException ex)
                {
                    _logger.LogInformation(ex, "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "}, {PartitionKey}(RowKey) not found, adding the corresponding entry to the storage table.",
                        xCorrelationIdentifier,
                        nameof(EVChargersTariffsPublisherFunction),
                        InternalConstants.PartitionKey);
                }

                // Get delta tariffs with watermark
                var watermark = Convert.ToInt64(entry[InternalConstants.LastSyncDate]);
                var tariffsResponse = await _chargeFoxService.GetDeltaChargerTariffs(watermark, _settings.ChargerTariffsLimit, xCorrelationIdentifier, _settings.ChargerTariffsRequestDelayInMs);

                // Map each tariff to service bus message
                var serviceBusMessages = new List<ServiceBusMessage>();
                if (!tariffsResponse.IsNullOrEmpty())
                {
                    serviceBusMessages = tariffsResponse
                        .Where(chargerTariff => chargerTariff.LastUpdated.GetEpoch() > watermark)
                        .Select(chargerTariff =>
                        {
                            var message = new ServiceBusMessage(JsonSerializer.Serialize(chargerTariff));
                            message.CorrelationId = xCorrelationIdentifier.ToString();
                            return message;
                        })
                        .ToList();
                }

                // Publish tariffs
                if (!serviceBusMessages.IsNullOrEmpty())
                {
                    await _serviceBusClient.SendMessagesAsync(_configuration[InternalConstants.EVTariffsTopicNameKey], serviceBusMessages);
                }

                // Upsert last sync date to function start time
                entry[InternalConstants.LastSyncDate] = functionStartTime;
                await _azureTableStorageService.UpsertEntityAsync(entry);

                _logger.LogInformation("Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "}, Successful Run for {FunctionName}",
                xCorrelationIdentifier,
                nameof(EVChargersTariffsPublisherFunction));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "} {FunctionName} failed with error: {message}.",
                    xCorrelationIdentifier,
                    nameof(EVChargersTariffsPublisherFunction),
                    ex.Message);
            }
        }
    }
}
