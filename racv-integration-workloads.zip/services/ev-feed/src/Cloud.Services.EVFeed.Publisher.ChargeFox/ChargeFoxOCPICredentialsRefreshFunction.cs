using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Exceptions;
using Cloud.Services.Common.Models;
using Cloud.Services.EVFeed.Common.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace Cloud.Services.EVFeed.Publisher.ChargeFox
{
    public class ChargeFoxOCPICredentialsRefreshFunction
    {
        private readonly ILogger<ChargeFoxOCPICredentialsRefreshFunction> _logger;
        private readonly IOCPIRegistrationService _OCPIRegistrationService;

        public ChargeFoxOCPICredentialsRefreshFunction(
            ILogger<ChargeFoxOCPICredentialsRefreshFunction> logger,
            IOCPIRegistrationService OCPIRegistrationService)

        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _OCPIRegistrationService = OCPIRegistrationService ?? throw new ArgumentNullException(nameof(OCPIRegistrationService));
        }

        [Function("ChargeFoxOCPICredentialsRefreshFunction")]
        [ProducesResponseType(typeof(OperationSuccessResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(OperationFailureResponse), StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> RunAsync([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequest req)
        {
            var xCorrelationIdentifier = Guid.NewGuid();
            try
            {
                await _OCPIRegistrationService.RegisterAsync(xCorrelationIdentifier, forceRefresh: true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                   "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "} " +
                   "OCPI Credentials Refresh failed with error: {message}.",
                   xCorrelationIdentifier,
                   ex.Message);

                var errorResponse = new OperationFailureResponse(
                    "Error occurred while refreshing Chargefox OCPI Credentials.",
                    null,
                    xCorrelationIdentifier.ToString());

                return new ObjectResult(errorResponse)
                {
                    StatusCode = StatusCodes.Status500InternalServerError
                };
            }
            return new ObjectResult(new OperationSuccessResponse() { Data = "Successfully refreshed Chargefox OCPI credentials." })
            {
                StatusCode = StatusCodes.Status200OK
            };
        }
    }
}
