using Azure.Data.AppConfiguration;
using Azure.Identity;
using Azure.Messaging.ServiceBus;
using Azure.Security.KeyVault.Secrets;
using Cloud.Services.Common.Azure.ServiceBus.Implementations;
using Cloud.Services.Common.Azure.ServiceBus.Interfaces;
using Cloud.Services.Common.Azure.TableStorage.Implementations;
using Cloud.Services.Common.Azure.TableStorage.Settings;
using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Extensions;
using Cloud.Services.Common.Settings;
using Cloud.Services.Common.Tracking.Implementations;
using Cloud.Services.Common.Tracking.Interfaces;
using Cloud.Services.Common.Utility.Handlers.Implementation;
using Cloud.Services.Common.Utility.Handlers.Interfaces;
using Cloud.Services.Common.Utility.Wrapper.Implementation;
using Cloud.Services.Common.Utility.Wrapper.Interfaces;
using Cloud.Services.EVFeed.Common.Constants;
using Cloud.Services.EVFeed.Common.Interfaces;
using Cloud.Services.EVFeed.Common.Settings;
using Cloud.Services.EVFeed.Connector.ChargeFox.Implementations;
using Cloud.Services.EVFeed.Connector.ChargeFox.Interfaces;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

IConfigurationRoot? configuration = null;
IServiceProvider? _serviceProvider = null;
IConfigurationRefresher? configurationRefresher = null;
var functionAppSettings = new AppSettings();
string? workloadLabel = null;

var host = new HostBuilder()
    .ConfigureFunctionsWebApplication()
    .ConfigureAppConfiguration(configBuilder =>
    {
        // compile a temporary configuration instance
        configuration = configBuilder.Build();

        // Retrieve the function app settings from the application configuration.
        configuration.Bind(functionAppSettings);

        // Set the label
        workloadLabel = $"{functionAppSettings.Environment}:{functionAppSettings.Workload}";
        configurationRefresher = configBuilder.AddAzureAppConfigurationOptions(
            new Uri(functionAppSettings.AppConfigurationEndPoint),
            functionAppSettings.AzureClientId,
            functionAppSettings.Environment,
            functionAppSettings.Workload,
            ServicesConstants.ConfigurationRefreshKey);

        // compile a temporary configuration instance
        configuration = configBuilder.Build();
    })
    .ConfigureServices(services =>
    {

        // Define keys used to access values in the configuration manager.
        var _systemName = "FunctionApp";
        var _excludeHeaders = new[] {
            ServicesConstants.Authorization,
            "subscription-key" };
        
        var azureCredentials =
#if DEBUG
            new AzureCliCredential();
#else
            new ManagedIdentityCredential(functionAppSettings.AzureClientId);
#endif

        // Add Azure App Configuration
        services.AddAzureAppConfiguration();

        // Enable application insights.
        services.AddApplicationInsightsTelemetryWorkerService();
        services.ConfigureFunctionsApplicationInsights();
        services.Configure<LoggerFilterOptions>(options =>
        {
            // The Application Insights SDK adds a default logging filter that instructs ILogger to capture only Warning and more severe logs. Application Insights requires an explicit override.
            LoggerFilterRule toRemove = options.Rules.FirstOrDefault(rule => rule.ProviderName == "Microsoft.Extensions.Logging.ApplicationInsights.ApplicationInsightsLoggerProvider")!;
            if (toRemove is not null)
            {
                options.Rules.Remove(toRemove);
            }
        });

        // Add Azure Configuration Client
        var ConfigurationClient = new ConfigurationClient(
            new Uri(configuration[ServicesConstants.AppConfigurationEndPointKey]),
            credential: azureCredentials);
        services.AddSingleton(ConfigurationClient);

        // Add Key Vault Client 
        var keyVaultClient = new SecretClient(
            new Uri(configuration[ServicesConstants.KeyVaultEndPointKey]),
            credential: azureCredentials);

        services.AddSingleton(keyVaultClient);

        // Add Service Bus connector.
        var serviceBusClient = new ServiceBusClient(
            configuration[ServicesConstants.ServiceBusNamespace],
            credential: azureCredentials,
            new ServiceBusClientOptions
            {
                TransportType = ServiceBusTransportType.AmqpWebSockets,
            });
        services.AddSingleton(serviceBusClient);

        // Add Table Storage connector 
        var tableStorageSettings = new TableStorageSettings();
        configuration.Bind(TableStorageSettings.ConfigurationSectionName, tableStorageSettings);
        var azureTableStorageService = new TableStorageClientFactory().CreateClient(
            tableStorageSettings.Endpoint,
            InternalConstants.StorageAccountTableName);
        services.AddSingleton(azureTableStorageService);

        // Add Settings
        services.AddOptions<ChargeFoxSettings>().Configure((settings) =>
        {
            configuration.GetSection(ChargeFoxSettings.ConfigurationSectionName).Bind(settings);
        });

        services.Configure<OCPISettings>(
            configuration.GetSection(OCPISettings.ConfigurationSectionName));

        services.Configure<EVFeedSettings>(
            configuration.GetSection(EVFeedSettings.ConfigurationSectionName));

        services.Configure<AppSettings>(options => configuration.Bind(options));

        // Compile a temporary service provider instance
        _serviceProvider = services.BuildServiceProvider();

        // Add message tracker system.
        services.AddTransient<IMessageTrackerMiddlewareConfiguration, MessageTrackerMiddlewareConfiguration>();
        services.AddMessageTracker(new Uri(functionAppSettings.BlobServiceUri));

        // Add Message Tracker Handler.
        services.AddTransient<IMessageTrackerHandlerConfiguration, MessageTrackerHandlerConfiguration>();
        services
            .AddSingleton<IMessageTrackerHandler<HttpRequestMessage, HttpResponseMessage>, MessageTrackerHandler>(
                provider =>
                {
                    var logger = provider.GetRequiredService<ILogger<MessageTrackerHandler>>();
                    var messageTracker = provider.GetRequiredService<IMessageTracker>();
                    var messageTrackerHandlerConfiguration =
                        provider.GetRequiredService<IMessageTrackerHandlerConfiguration>();
                    return new MessageTrackerHandler(logger, messageTracker, messageTrackerHandlerConfiguration,
                        _systemName, _excludeHeaders);
                });

        // Add Http clients
        services.AddHttpClient(InternalConstants.ChargeFoxClient, httpClient =>
        {
            var chargeFoxSettings = _serviceProvider.GetRequiredService<IOptionsSnapshot<ChargeFoxSettings>>();

            // Configure the primary typed client
            httpClient.BaseAddress = new Uri(chargeFoxSettings.Value.BaseUrl);
        });

        // Add HttpWrapper
        services.AddSingleton<IHttpWrapper<HttpRequestMessage, HttpResponseMessage>, HttpWrapper>(
            provider =>
            {
                var httpClientFactory = provider.GetRequiredService<IHttpClientFactory>();
                var messageTrackerHandler =
                    provider.GetRequiredService<IMessageTrackerHandler<HttpRequestMessage, HttpResponseMessage>>();
                var wrapper = new HttpWrapper(httpClientFactory, messageTrackerHandler.LogRequestResponse);
                return wrapper;
            });

        // Add Services
        services.AddTransient<IChargeFoxService, ChargeFoxService>();
        services.AddTransient<IServiceBusClient, CustomServiceBusClient>();
        services.AddScoped<IOCPIRegistrationService, ChargeFoxOCPIRegistrationService>();
    })
    .Build();

// Resolve and use the service
using (var scope = host.Services.CreateScope())
{
    var xCorrelationIdentifier = Guid.NewGuid();
    var registrationService = scope.ServiceProvider.GetRequiredService<IOCPIRegistrationService>();
    await registrationService.RegisterAsync(xCorrelationIdentifier);
}

await host.RunAsync();