﻿namespace Cloud.Services.EVFeed.Common.Constants
{
    /// <summary>
    /// Contains internal constant values used throughout the EV Feed service.
    /// /// Constants to be used across a specific workload.
    /// </summary>
    public static class InternalConstants
    {
        /// <summary>
        /// Represents the key to register and access Locations Cosmos DB service.
        /// </summary>
        public const string LocationsCosmosDbServiceKey = "LocationsCosmosDbService";

        /// <summary>
        /// Represents the key to register and access Tariffs Cosmos DB service.
        /// </summary>
        public const string TariffsCosmosDbServiceKey = "TariffsCosmosDbService";

        /// <summary>
        /// HttpClient name for ChargeFox service
        /// </summary>
        public const string ChargeFoxClient = "ChargeFoxClient";

        /// <summary>
        /// Used to access the ChargeFox Locations Topic Name
        /// </summary>
        public const string EVLocationsTopicNameKey = "EVLocationsTopicName";

        /// <summary>
        /// Used to access the ChargeFox Locations Topic Name
        /// </summary>
        public const string EVTariffsTopicNameKey = "EVTariffsTopicName";

        /// <summary>
        /// Used to access the Last Sync Date
        /// </summary>
        public const string LastSyncDate = "LastSyncDate";

        /// <summary>
        /// Used for the storage table name
        /// </summary>
        public const string StorageAccountTableName = "watermarks";

        /// <summary>
        /// Used for the storage table partition key
        /// </summary>
        public const string PartitionKey = "watermark";

        /// <summary>
        /// header constant 
        /// </summary>
        public const string TotalCountHeader = "X-Total-Count";

        /// <summary>
        /// Chargefox OCPI Handshake Credentials Token Key (OCPI Credential Token A)
        /// </summary>
        public const string ChargefoxOCPIHandshakeCredentialsTokenKey = "chargefox-ocpi-hanshake-credentials-token";

        /// <summary>
        /// Chargefox OCPI Sender Credentials Token Key (OCPI Credential Token B)
        /// </summary>
        public const string ChargefoxOCPISenderCredentialsTokenKey = "chargefox-ocpi-sender-credentials-token";

        /// <summary>
        /// Chargefox OCPI Receiver Credentials Token Key (OCPI Credential Token C)
        /// </summary>
        public const string ChargefoxOCPIReceiverCredentialsTokenKey = "chargefox-ocpi-receiver-credentials-token";

        /// <summary>
        /// OCPI Reciever Role Name
        /// </summary>
        public const string OCPIRoleName = "NSP";

        /// <summary>
        /// OCPI Reciever Party Id
        /// </summary>
        public const string OCPIPartyId = "RCV";

        /// <summary>
        /// OCPI Reciever Country Code
        /// </summary>
        public const string OCPICountryCode = "AU";

        /// <summary>
        /// OCPI Reciever Business Name
        /// </summary>
        public const string OCPIBusinessName = "RACV";
    }
}
