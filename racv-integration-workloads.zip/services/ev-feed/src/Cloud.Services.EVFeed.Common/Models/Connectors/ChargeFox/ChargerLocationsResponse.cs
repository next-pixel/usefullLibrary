﻿using System.Text.Json.Serialization;

namespace Cloud.Services.EVFeed.Common.Models.Connectors.ChargeFox
{
    public class ChargerLocationsResponse
    {
        [JsonPropertyName("data")]
        public List<ChargerLocation>? ChargerLocations { get; set; }

        [JsonPropertyName("status_code")]
        public int StatusCode { get; set; }

        [JsonPropertyName("status_message")]
        public string? StatusMessage { get; set; }

        [JsonPropertyName("timestamp")]
        public DateTime Timestamp { get; set; }
    }

    public class ChargerLocation
    {
        [JsonPropertyName("id")]
        public string? Id { get; set; }

        [JsonPropertyName("name")]
        public string? Name { get; set; }

        [JsonPropertyName("address")]
        public string? Address { get; set; }

        [JsonPropertyName("city")]
        public string? City { get; set; }

        [JsonPropertyName("postal_code")]
        public string? PostalCode { get; set; }

        [JsonPropertyName("country")]
        public string? Country { get; set; }

        [JsonPropertyName("coordinates")]
        public Coordinates? Coordinates { get; set; }

        [JsonPropertyName("last_updated")]
        public DateTime LastUpdated { get; set; }
        
        [JsonPropertyName("directions")]
        public List<Direction>? Directions { get; set; }

        [JsonPropertyName("opening_times")]
        public OpeningTimes? OpeningTimes { get; set; }

        [JsonPropertyName("country_code")]
        public string? CountryCode { get; set; }

        [JsonPropertyName("party_id")]
        public string? PartyId { get; set; }

        [JsonPropertyName("parking_type")]
        public string? ParkingType { get; set; }

        [JsonPropertyName("state")]
        public string? State { get; set; }

        [JsonPropertyName("publish")]
        public bool Publish { get; set; }

        [JsonPropertyName("operator")]
        public Operator? Operator { get; set; }

        [JsonPropertyName("time_zone")]
        public string? TimeZone { get; set; }

        [JsonPropertyName("evses")]
        public List<EV>? Evses { get; set; }
    }
    public class Direction
    {
        [JsonPropertyName("language")]
        public string? language { get; set; }

        [JsonPropertyName("text")]
        public string? text { get; set; }
    }
    public class Coordinates
    {
        [JsonPropertyName("latitude")]
        public string? Latitude { get; set; }

        [JsonPropertyName("longitude")]
        public string? Longitude { get; set; }
    }

    public class OpeningTimes
    {
        [JsonPropertyName("twentyfourseven")]
        public bool TwentyFourSeven { get; set; }

        [JsonPropertyName("regular_hours")]
        public List<RegularHours>? RegularHours { get; set; }
    }

    public class RegularHours
    {
        [JsonPropertyName("weekday")]
        public int Weekday { get; set; }

        [JsonPropertyName("period_begin")]
        public string? PeriodBegin { get; set; }

        [JsonPropertyName("period_end")]
        public string? PeriodEnd { get; set; }
    }

    public class Operator
    {
        [JsonPropertyName("name")]
        public string? Name { get; set; }

        [JsonPropertyName("website")]
        public string? Website { get; set; }
    }

    public class EV
    {
        [JsonPropertyName("uid")]
        public string? Uid { get; set; }

        [JsonPropertyName("evse_id")]
        public string? EvseId { get; set; }

        [JsonPropertyName("status")]
        public string? Status { get; set; }

        [JsonPropertyName("connectors")]
        public List<Connector>? Connectors { get; set; }

        [JsonPropertyName("physical_reference")]
        public string? PhysicalReference { get; set; }

        [JsonPropertyName("last_updated")]
        public DateTime LastUpdated { get; set; }
    }

    public class Connector
    {
        [JsonPropertyName("id")]
        public string? Id { get; set; }

        [JsonPropertyName("standard")]
        public string? Standard { get; set; }

        [JsonPropertyName("format")]
        public string? Format { get; set; }

        [JsonPropertyName("power_type")]
        public string? PowerType { get; set; }

        [JsonPropertyName("last_updated")]
        public DateTime LastUpdated { get; set; }

        [JsonPropertyName("max_voltage")]
        public int MaxVoltage { get; set; }

        [JsonPropertyName("max_amperage")]
        public int MaxAmperage { get; set; }

        [JsonPropertyName("max_electric_power")]
        public int MaxElectricPower { get; set; }

        [JsonPropertyName("tariff_ids")]
        public List<string>? TariffIds { get; set; }
    }
}