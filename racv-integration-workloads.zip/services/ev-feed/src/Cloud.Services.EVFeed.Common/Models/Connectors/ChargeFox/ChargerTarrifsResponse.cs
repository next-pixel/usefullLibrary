﻿using System.Text.Json.Serialization;

namespace Cloud.Services.EVFeed.Common.Models.Connectors.ChargeFox
{
    public class ChargerTariffsResponse
    {
        [JsonPropertyName("data")]
        public List<ChargerTariff>? ChargerTariffs { get; set; }

        [JsonPropertyName("status_code")]
        public int StatusCode { get; set; }

        [JsonPropertyName("status_message")]
        public string? StatusMessage { get; set; }

        [JsonPropertyName("timestamp")]
        public DateTime Timestamp { get; set; }
    }

    public class ChargerTariff
    {
        [JsonPropertyName("country_code")]
        public string? CountryCode { get; set; }

        [JsonPropertyName("party_id")]
        public string? PartyId { get; set; }

        [JsonPropertyName("id")]
        public string? Id { get; set; }

        [JsonPropertyName("currency")]
        public string? Currency { get; set; }

        [JsonPropertyName("type")]
        public string? Type { get; set; }

        [JsonPropertyName("tariff_alt_text")]
        public List<TariffAltText>? TariffAltTexts { get; set; }

        [JsonPropertyName("elements")]
        public List<Element>? Elements { get; set; }

        [JsonPropertyName("start_date_time")]
        public DateTime? StartDateTime { get; set; }

        [JsonPropertyName("end_date_time")]
        public DateTime? EndDateTime { get; set; }

        [JsonPropertyName("energy_mix")]
        public EnergyMix? EnergyMix { get; set; }

        [JsonPropertyName("last_updated")]
        public DateTime LastUpdated { get; set; }

        [JsonPropertyName("min_price")]
        public MinPrice? MinPrice { get; set; }
    }

    public class EnergyMix
    {
        [JsonPropertyName("is_green_energy")]
        public bool IsGreenEnergy { get; set; }
    }

    public class MinPrice
    {
        [JsonPropertyName("excl_vat")]
        public float ExclusiveVat { get; set; }

        [JsonPropertyName("incl_vat")]
        public float InclusiveVat { get; set; }
    }

    public class TariffAltText
    {
        [JsonPropertyName("language")]
        public string? Language { get; set; }

        [JsonPropertyName("text")]
        public string? Text { get; set; }
    }

    public class Element
    {
        [JsonPropertyName("price_components")]
        public List<PriceComponent>? PriceComponents { get; set; }

        [JsonPropertyName("restrictions")]
        public Restrictions? Restrictions { get; set; }
    }

    public class Restrictions
    {
        [JsonPropertyName("max_duration")]
        public int MaxDuration { get; set; }

        [JsonPropertyName("start_time")]
        public string? StartTime { get; set; }

        [JsonPropertyName("end_time")]
        public string? EndTime { get; set; }

        [JsonPropertyName("day_of_week")]
        public List<string>? DayOfWeek { get; set; }
    }

    public class PriceComponent
    {
        [JsonPropertyName("type")]
        public string? Type { get; set; }

        [JsonPropertyName("price")]
        public float Price { get; set; }

        [JsonPropertyName("step_size")]
        public int StepSize { get; set; }

        [JsonPropertyName("vat")]
        public float Vat { get; set; }
    }
}
