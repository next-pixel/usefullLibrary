﻿using Cloud.Services.Common.Connector.Models.OCPI;
using Newtonsoft.Json;

namespace Cloud.Services.EVFeed.Common.Models.Connectors.OCPI
{
    public class SubmitCredentialsResponse: OCPIResponse
    {
        [JsonProperty("data")]
        public Credentials? credentials { get; set; }
    }
}
