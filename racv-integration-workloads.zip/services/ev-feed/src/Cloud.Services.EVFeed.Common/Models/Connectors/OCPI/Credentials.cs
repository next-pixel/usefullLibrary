﻿using Newtonsoft.Json;

namespace Cloud.Services.EVFeed.Common.Models.Connectors.OCPI
{
    public class Credentials
    {
        [JsonProperty("token")]
        public string? Token { get; set; }

        [JsonProperty("url")]
        public string? Url { get; set; }

        [JsonProperty("roles")]
        public List<Role>? Roles { get; set; }
    }

    public class Role
    {
        [JsonProperty("role")]
        public string? RoleName { get; set; }

        [JsonProperty("party_id")]
        public string? PartyId { get; set; }

        [JsonProperty("country_code")]
        public string? CountryCode { get; set; }

        [JsonProperty("business_details")]
        public BusinessDetails? BusinessDetails { get; set; }
    }

    public class BusinessDetails
    {
        [JsonProperty("name")]
        public string? Name { get; set; }

        [JsonProperty("website")]
        public string? Website { get; set; }
    }
}
