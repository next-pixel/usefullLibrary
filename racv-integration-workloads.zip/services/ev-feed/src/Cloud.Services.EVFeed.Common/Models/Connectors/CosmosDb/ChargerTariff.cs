﻿using System.Text.Json.Serialization;

namespace Cloud.Services.EVFeed.Common.Models.Connectors.CosmosDb
{
    public class ChargerTariff
    {
        public string Id { get; set; }
        public string? CountryCode { get; set; }
        public string? PartyId { get; set; }
        public string? Currency { get; set; }
        public string? Type { get; set; }
        public List<TariffAltText>? TariffAltText { get; set; }
        public List<Element>? Elements { get; set; }
        public DateTime? StartDateTime { get; set; }
        public DateTime? EndDateTime { get; set; }
        public EnergyMix? EnergyMix { get; set; }
        public DateTime? LastUpdated { get; set; }
    }

    public class EnergyMix
    {
        public bool IsGreenEnergy { get; set; }
    }

    public class TariffAltText
    {
        public string? Language { get; set; }
        public string? Text { get; set; }
    }

    public class Element
    {
        public List<PriceComponent>? PriceComponents { get; set; }
        public Restrictions? Restrictions { get; set; }
    }

    public class Restrictions
    {
        public int MaxDuration { get; set; }
        public string? StartTime { get; set; }
        public string? EndTime { get; set; }
        public List<string>? DayOfWeek { get; set; }
    }

    public class PriceComponent
    {
        public string? type { get; set; }
        public float Price { get; set; }
        public float PricePerStep { get; set; }
        public float PricePerStepIncVat { get; set; }
        public int StepSize { get; set; }
        public float Vat { get; set; }
    }
}
