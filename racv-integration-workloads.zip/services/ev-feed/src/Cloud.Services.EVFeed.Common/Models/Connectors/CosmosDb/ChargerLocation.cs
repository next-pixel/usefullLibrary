﻿using System.Text.Json.Serialization;

namespace Cloud.Services.EVFeed.Common.Models.Connectors.CosmosDb
{
    public class ChargerLocation
    {
        public string Id { get; set; }
        public string? Name { get; set; }
        public string? Address { get; set; }
        public OpeningTimes? OpeningTimes { get; set; }
        public string? City { get; set; }
        public string? Postcode { get; set; }
        public string? State { get; set; }
        public Location? Location { get; set; }
        public string? StationTimeZone { get; set; }
        public string? Directions { get; set; }
        public Operator? Operator { get; set; }
        public List<EV>? Evses { get; set; }
        public DateTime LastUpdated { get; set; }
    }

    public class OpeningTimes
    {
        public bool TwentyFourSeven { get; set; }
        public List<RegularHour>? RegularHours { get; set; }
    }

    public class RegularHour
    {
        public int Weekday { get; set; }
        public string? PeriodBegin { get; set; }
        public string? PeriodEnd { get; set; }
    }

    public class Location
    {
        public string? Type { get; set; }
        public List<float?>? Coordinates { get; set; }
    }

    public class Operator
    {      
        public string? Name { get; set; }      
        public string? Url { get; set; }
    }

    public class EV
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Status { get; set; }
        public List<Connector>? Connectors { get; set; }
        public DateTime LastUpdated { get; set; }
    }

    public class Connector
    {
        public int Id { get; set; }
        public string? Standard { get; set; }
        public string? Format { get; set; }
        public int MaxElectricPower { get; set; }
        public string? TariffId { get; set; }
    }
}
