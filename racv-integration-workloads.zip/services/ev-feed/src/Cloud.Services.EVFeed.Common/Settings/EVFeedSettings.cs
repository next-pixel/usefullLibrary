﻿namespace Cloud.Services.EVFeed.Common.Settings
{
    public class EVFeedSettings
    {
        public const string ConfigurationSectionName = "EVFeedSettings";
        public string LocationsContainerId { get; set; } = "EVChargersLocations";
        public string TariffsContainerId { get; set; } = "EVChargersTariffs";
    }
}
