﻿namespace Cloud.Services.EVFeed.Common.Extensions
{
    public static class DateTimeExtensions
    {
        public static long GetEpoch(this DateTime dateTime)
        {
            TimeSpan epochTimeSpan = dateTime - DateTime.UnixEpoch;
            return (long)epochTimeSpan.TotalSeconds;
        }
    }
}
