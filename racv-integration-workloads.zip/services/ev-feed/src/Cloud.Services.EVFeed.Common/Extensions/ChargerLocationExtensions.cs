﻿using ChargeFox = Cloud.Services.EVFeed.Common.Models.Connectors.ChargeFox;
using CosmosDb = Cloud.Services.EVFeed.Common.Models.Connectors.CosmosDb;

namespace Cloud.Services.EVFeed.Common.Extensions
{
    public static class ChargerLocationExtensions
    {
        /// <summary>
        /// Extension to map <see cref="ChargeFox.ChargerLocation"/> to <see cref="CosmosDb.ChargerLocation"/> API response
        /// </summary>
        /// <param name="response"></param>
        /// <returns></returns>
        public static CosmosDb.ChargerLocation? Convert(this ChargeFox.ChargerLocation? chargerLocation)
        {
            if (chargerLocation != null && chargerLocation.Id != null)
            {
                return new CosmosDb.ChargerLocation
                {
                    Id = chargerLocation.Id,
                    Name = chargerLocation.Name,
                    Address = chargerLocation.Address,
                    OpeningTimes = chargerLocation.OpeningTimes?.MapOpeningTimes(),
                    City = chargerLocation.City,
                    Postcode = chargerLocation.PostalCode,
                    State = chargerLocation.State,
                    Location = chargerLocation.Coordinates?.MapLocation(),
                    StationTimeZone = chargerLocation.TimeZone,
                    Directions = chargerLocation.Directions?.FirstOrDefault()?.text,
                    Operator = new CosmosDb.Operator
                    {
                        Name = chargerLocation.Operator?.Name,
                        Url = chargerLocation.Operator?.Website,
                    },
                    Evses = chargerLocation.Evses?.Select(ev => ev.MapEV()).ToList(),
                    LastUpdated = chargerLocation.LastUpdated
                };
            }
            return null;
        }

        /// <summary>
        /// Extension to map <see cref="ChargeFox.Coordinates"/> to <see cref="CosmosDb.Location"/> API response
        /// </summary>
        /// <param name="openingTimes"></param>
        /// <returns></returns>
        private static CosmosDb.Location MapLocation(this ChargeFox.Coordinates coordinates)
        {
            float? latitude = null;
            float? longitude = null;
            if (float.TryParse(coordinates.Latitude, out var latitudeResult))
            {
                latitude = latitudeResult;
            }

            if (float.TryParse(coordinates.Longitude, out var longitudeResult))
            {
                longitude = longitudeResult;
            }

            return new CosmosDb.Location
            {
                Type = "Point",
                Coordinates = new List<float?> { latitude, longitude }
            };
        }

        /// <summary>
        /// Extension to map <see cref="ChargeFox.OpeningTimes"/> to <see cref="CosmosDb.OpeningTimes"/> API response
        /// </summary>
        /// <param name="openingTimes"></param>
        /// <returns></returns>
        private static CosmosDb.OpeningTimes MapOpeningTimes(this ChargeFox.OpeningTimes openingTimes)
        {
            if (openingTimes.TwentyFourSeven)
                return new() { TwentyFourSeven = true, RegularHours = null };

            return new()
            {
                TwentyFourSeven = false,
                RegularHours = openingTimes.RegularHours?.Select(regularHour => new CosmosDb.RegularHour
                {
                    Weekday = regularHour.Weekday,
                    PeriodBegin = regularHour.PeriodBegin,
                    PeriodEnd = regularHour.PeriodEnd
                }).ToList()
            };
        }

        /// <summary>
        /// Extension to map <see cref="ChargeFox.EV"/> to <see cref="CosmosDb.EV"/> API response
        /// </summary>
        /// <param name="ev"></param>
        /// <returns></returns>
        private static CosmosDb.EV MapEV(this ChargeFox.EV ev) => new()
        {
            Id = ev.EvseId,
            Name = ev.PhysicalReference,
            Status = ev.Status,
            Connectors = ev.Connectors?.Select(connector => connector.MapConnector()).ToList(),
            LastUpdated = ev.LastUpdated,
        };

        /// <summary>
        /// Extension to map <see cref="ChargeFox.Connector"/> to <see cref="CosmosDb.Connector"/> API response
        /// </summary>
        /// <param name="connector"></param>
        /// <returns></returns>
        private static CosmosDb.Connector MapConnector(this ChargeFox.Connector connector) => new()
        {
            Id = int.Parse(connector.Id), // TODO: Change the destination to string
            Standard = connector.Standard,
            Format = connector.Format,
            MaxElectricPower = connector.MaxElectricPower,
            TariffId = connector.TariffIds?.FirstOrDefault(),
        };
    }
}
