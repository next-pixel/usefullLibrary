﻿using Cloud.Services.Common.Connector.Models.Exceptions;
using Cloud.Services.Common.Connector.Models.OCPI;

namespace Cloud.Services.EVFeed.Common.Extensions
{
    public static class OCPIResponseExtensions
    {
        public static OCPIResponse EnsureOCPISuccessStatusCode(this OCPIResponse response)
        {
            if (response == null)
                throw new ExternalApiDependencyException($"Chargefox OCPI API responded with null response.");
            if (response.StatusCode == null)
                throw new ExternalApiDependencyException($"Chargefox OCPI API responded with null status code.");
                
            switch (response.StatusCode / 1000)
            {
                case 1:
                    return response;
                case 2:
                    throw new ExternalApiDependencyException(
                        $"Chargefox OCPI API responded with Client Error with Status Code {response.StatusCode}." +
                        $"ERROR DETAILS: {response.StatusMessage}");
                case 3:
                    throw new ExternalApiDependencyException(
                        $"Chargefox OCPI API responded with Server Error with Status Code {response.StatusCode}." +
                        $"ERROR DETAILS: {response.StatusMessage}");
                default:
                    throw new ExternalApiDependencyException(
                        $"Chargefox OCPI API responded with Unknown Response Code {response.StatusCode}." +
                        $"ERROR DETAILS: {response.StatusMessage}");
            }
        }
    }
}
