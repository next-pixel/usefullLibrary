﻿using ChargeFox = Cloud.Services.EVFeed.Common.Models.Connectors.ChargeFox;
using CosmosDb = Cloud.Services.EVFeed.Common.Models.Connectors.CosmosDb;

namespace Cloud.Services.EVFeed.Common.Extensions
{
    public static class ChargerTariffExtensions
    {
        /// <summary>
        /// Extension to map <see cref="ChargeFox.ChargerTariff"/> to <see cref="CosmosDb.ChargerTariff"/> Cosmos db model
        /// </summary>
        /// <param name="chargerTariff"></param>
        /// <returns></returns>
        public static CosmosDb.ChargerTariff Convert(this ChargeFox.ChargerTariff? chargerTariff)
        {
            if (chargerTariff != null && chargerTariff.Id != null)
            {
                return new CosmosDb.ChargerTariff
                {
                    Id = chargerTariff.Id,
                    CountryCode = chargerTariff.CountryCode,
                    PartyId = chargerTariff.PartyId,
                    Currency = chargerTariff.Currency,
                    Type = chargerTariff.Type,
                    TariffAltText = chargerTariff.TariffAltTexts?.Select(TariffAltText => TariffAltText.MapTariffAltText()).ToList(),
                    Elements = chargerTariff.Elements?.Select(element => element.MapElement()).ToList(),
                    StartDateTime = chargerTariff.StartDateTime,
                    EndDateTime = chargerTariff.EndDateTime,
                    EnergyMix = chargerTariff.EnergyMix?.MapEnergyMix(),
                    LastUpdated = chargerTariff.LastUpdated,
                };
            }
            return null;
        }

        /// <summary>
        /// Extension to map <see cref="ChargeFox.TariffAltText"/> to <see cref="CosmosDb.TariffAltText"/> Cosmos db model
        /// </summary>
        /// <param name="tariffAltText"></param>
        /// <returns></returns>
        private static CosmosDb.TariffAltText MapTariffAltText(this ChargeFox.TariffAltText tariffAltText) => new()
        {
            Language = tariffAltText.Language,
            Text = tariffAltText.Text,
        };

        /// <summary>
        /// Extension to map <see cref="ChargeFox.Element"/> to <see cref="CosmosDb.Element"/> Cosmos db model
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        private static CosmosDb.Element MapElement(this ChargeFox.Element element) => new()
        {
            PriceComponents = element.PriceComponents?.Select(priceComponent => priceComponent.MapPriceComponent()).ToList(),
            Restrictions = (element.Restrictions != null) ? new CosmosDb.Restrictions()
            {
                MaxDuration = element.Restrictions.MaxDuration,
                DayOfWeek = element.Restrictions.DayOfWeek,
                EndTime = element.Restrictions.EndTime,
                StartTime = element.Restrictions.StartTime
            } : null
        };

        /// <summary>
        /// Extension to map <see cref="ChargeFox.PriceComponent"/> to <see cref="CosmosDb.PriceComponent"/> Cosmos db model
        /// </summary>
        /// <param name="priceComponent"></param>
        /// <returns></returns>
        private static CosmosDb.PriceComponent MapPriceComponent(this ChargeFox.PriceComponent priceComponent)
        {
            var pricePerStep = priceComponent.Price / priceComponent.StepSize;
            var pricePerStepIncVat = pricePerStep * (1 + priceComponent.Vat / 100);

            return new CosmosDb.PriceComponent()
            {
                Price = priceComponent.Price,
                PricePerStep = pricePerStep,
                PricePerStepIncVat = (float)Math.Ceiling(pricePerStepIncVat * 100 - 0.5) / 100, // Half-Down Round strategy to 2 decimal places
                StepSize = priceComponent.StepSize,
                type = priceComponent.Type,
                Vat = priceComponent.Vat
            };
        }

        /// <summary>
        /// Extension to map <see cref="ChargeFox.EnergyMix"/> to <see cref="CosmosDb.EnergyMix"/> Cosmos db model
        /// </summary>
        /// <param name="energyMix"></param>
        /// <returns></returns>
        private static CosmosDb.EnergyMix MapEnergyMix(this ChargeFox.EnergyMix energyMix) => new()
        {
            IsGreenEnergy = energyMix.IsGreenEnergy,
        };
    }

}
