﻿namespace Cloud.Services.EVFeed.Common.Interfaces
{
    public interface IOCPIRegistrationService
    {
        Task RegisterAsync(Guid xCorrelationIdentifier, bool forceRefresh = false);
    }
}
