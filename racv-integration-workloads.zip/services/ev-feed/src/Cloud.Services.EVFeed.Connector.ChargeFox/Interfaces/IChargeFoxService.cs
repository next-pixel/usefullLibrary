﻿using Cloud.Services.Common.Connector.Models.OCPI;
using Cloud.Services.EVFeed.Common.Models.Connectors.ChargeFox;
using Cloud.Services.EVFeed.Common.Models.Connectors.OCPI;

namespace Cloud.Services.EVFeed.Connector.ChargeFox.Interfaces
{
    public interface IChargeFoxService
    {
        Task<VersionsResponse> GetVersions(Guid xCorrelationIdentifier, string authorization);

        Task<VersionEndpointsResponse> GetVersionEndpoints(string version, Guid xCorrelationIdentifier, string authorization);

        Task<SubmitCredentialsResponse> SubmitCredentials(
            Guid xCorrelationIdentifier,
            string version,
            Credentials credentials,
            string authorization,
            HttpMethod httpMethod);

        Task<List<ChargerLocation>> GetDeltaChargerLocations(long lastSync, int limit, Guid xCorrelationIdentifier, int paginatedDelay = 0);

        Task<List<ChargerTariff>> GetDeltaChargerTariffs(long lastSync, int limit, Guid xCorrelationIdentifier, int paginatedDelay = 0);
    }
}
