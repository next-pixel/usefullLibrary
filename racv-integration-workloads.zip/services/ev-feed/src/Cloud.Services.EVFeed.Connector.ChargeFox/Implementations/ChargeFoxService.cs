﻿using Cloud.Services.Common.Connector.Extensions;
using Cloud.Services.Common.Connector.Models.Exceptions;
using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Utility.Wrapper.Interfaces;
using Cloud.Services.EVFeed.Common.Constants;
using Cloud.Services.EVFeed.Common.Extensions;
using Cloud.Services.EVFeed.Common.Models.Connectors.ChargeFox;
using Cloud.Services.EVFeed.Common.Models.Connectors.OCPI;
using Cloud.Services.EVFeed.Common.Settings;
using Cloud.Services.EVFeed.Connector.ChargeFox.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.Net.Http.Json;
using System.Net.Mime;
using System.Runtime.Serialization;
using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Configuration;
using Cloud.Services.EVFeed.Connector.ChargeFox.Extensions;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Cloud.Services.Common.Connector.Models.OCPI;
using Cloud.Services.Common.Settings;

namespace Cloud.Services.EVFeed.Connector.ChargeFox.Implementations
{
    public class ChargeFoxService : IChargeFoxService
    {
        private readonly IHttpWrapper<HttpRequestMessage, HttpResponseMessage> _httpWrapper;
        private readonly ILogger<ChargeFoxService> _logger;
        private readonly ChargeFoxSettings _chargeFoxSettings;
        private readonly IConfiguration _configuration;
        private readonly IConfigurationRefresher _configurationRefresher;

        /// <summary>
        /// Initializes a new instance of the <see cref="ChargeFoxService" /> class.
        /// </summary>
        /// <param name="clientFactory">The HTTP client factory.</param>
        /// <param name="logger">The logger.</param>
        /// <exception cref="ArgumentNullException"></exception>
        public ChargeFoxService(
            IConfiguration configuration,
            IHttpWrapper<HttpRequestMessage, HttpResponseMessage> httpWrapper,
            IOptionsSnapshot<ChargeFoxSettings> chargeFoxSettings,
            ILogger<ChargeFoxService> logger,
            IConfigurationRefresherProvider configurationRefresherProvider)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _httpWrapper = httpWrapper ?? throw new ArgumentNullException(nameof(httpWrapper));
            _chargeFoxSettings = chargeFoxSettings.Value ?? throw new ArgumentNullException(nameof(_chargeFoxSettings));
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            _configurationRefresher = configurationRefresherProvider.Refreshers.First();
        }

        public async Task<VersionsResponse> GetVersions(
            Guid xCorrelationIdentifier, string authorization)
        {
            try
            {
                // Refresh chargefox settings from app config
                await _chargeFoxSettings.LoadChargeFoxSettingsAsync(_configuration, _configurationRefresher);

                var queryString = "versions";
                var request = new HttpRequestMessage(HttpMethod.Get, queryString);
                using var response = await _httpWrapper.SendAsync(
                    request,
                    InternalConstants.ChargeFoxClient,
                    xCorrelationIdentifier,
                    $"Bearer {authorization}");

                response.EnsureSuccessStatusCode();

                var responseJson = await response.Content.ReadAsStringAsync();

                // Deserialize OCPI versions response
                var ocpiVersions = JsonConvert.DeserializeObject<VersionsResponse>(
                    responseJson, new JsonSerializerSettings
                    {
                        Converters = { new VersionConverter() }
                    }) ?? throw new SerializationException();

                ocpiVersions.EnsureOCPISuccessStatusCode();
                return ocpiVersions;
            }
            catch (ExternalApiDependencyException ex)
            {
                _logger.LogError(ex,
                   "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName +
                   "} Failed to retrieve Chargefox OCPI Versions with transient API error: {message}",
                   xCorrelationIdentifier,
                   ex.ErrorDetails?.Convert());
                throw;
            }
            catch (SerializationException ex)
            {
                _logger.LogError(ex,
                    "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName +
                    "} failed to parse ChargeFox OCPI versions response with error: {message}",
                    xCorrelationIdentifier,
                    ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName +
                    "} failed to fetch ChargeFox OCPI versions response with error: {message}",
                    xCorrelationIdentifier,
                    ex.Message);
                throw;
            }
        }

        public async Task<VersionEndpointsResponse> GetVersionEndpoints(
            string version,
            Guid xCorrelationIdentifier, string authorization)
        {
            try
            {
                var queryString = $"{version}/endpoints";
                var request = new HttpRequestMessage(HttpMethod.Get, queryString);
                using var response = await _httpWrapper.SendAsync(
                    request,
                    InternalConstants.ChargeFoxClient,
                    xCorrelationIdentifier,
                    $"Bearer {authorization}");

                response.EnsureSuccessStatusCode();

                // Deserialize OCPI Endpoints response
                var ocpiEndpoints = await response.Content
                    .ReadFromJsonAsync<VersionEndpointsResponse>() ?? throw new SerializationException();

                ocpiEndpoints.EnsureOCPISuccessStatusCode();
                return ocpiEndpoints;
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex,
                   "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName +
                   "} Failed to retrieve Chargefox OCPI endpoints with transient API error: {message}",
                   xCorrelationIdentifier,
                   ex.Message);
                throw;
            }
            catch (ExternalApiDependencyException ex)
            {
                _logger.LogError(ex,
                   "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName +
                   "} Failed to retrieve Chargefox OCPI endpoints with transient API error: {message}",
                   xCorrelationIdentifier,
                   ex.ErrorDetails?.Convert());
                throw;
            }
            catch (System.Text.Json.JsonException ex)
            {
                _logger.LogError(ex,
                    "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName +
                    "} failed to parse ChargeFox OCPI endpoints response with error: {message}",
                    xCorrelationIdentifier,
                    ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName +
                    "} failed to fetch ChargeFox OCPI endpoints with error: {message}",
                    xCorrelationIdentifier,
                    ex.Message);
                throw;
            }
        }

        public async Task<SubmitCredentialsResponse> SubmitCredentials(
            Guid xCorrelationIdentifier,
            string version,
            Credentials credentials,
            string authorization,
            HttpMethod httpMethod)
        {
            try
            {
                var queryString = $"{version}/credentials";

                using StringContent credentialsRequestStringContent = new(
                    JsonConvert.SerializeObject(credentials),
                    Encoding.UTF8,
                    MediaTypeNames.Application.Json);

                var request = new HttpRequestMessage(httpMethod, queryString)
                {
                    Content = credentialsRequestStringContent
                };

                using var response = await _httpWrapper.SendAsync(
                    request,
                    InternalConstants.ChargeFoxClient,
                    xCorrelationIdentifier,
                    $"Bearer {authorization}");

                response.EnsureSuccessStatusCode();
                var responseJson = await response.Content.ReadAsStringAsync();

                // Deserialize response
                var ocpiSubmitCredentialsResponse = JsonConvert.DeserializeObject<SubmitCredentialsResponse>(
                    responseJson) ?? throw new SerializationException();

                ocpiSubmitCredentialsResponse.EnsureOCPISuccessStatusCode();
                return ocpiSubmitCredentialsResponse;
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex,
                   "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName +
                   "} Failed to submit Chargefox OCPI credentials with transient API error: {message}",
                   xCorrelationIdentifier,
                   ex.Message);
                throw;
            }
            catch (ExternalApiDependencyException ex)
            {
                _logger.LogError(ex,
                   "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName +
                   "} Failed to submit Chargefox OCPI credentials with API error: {message}",
                   xCorrelationIdentifier,
                   ex.ErrorDetails?.Convert());
                throw;
            }
            catch (JsonReaderException ex)
            {
                _logger.LogError(ex,
                    "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName +
                    "} failed to submit Chargefox OCPI credentials request with error: {message}",
                    xCorrelationIdentifier,
                    ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName +
                    "} failed to submit Chargefox OCPI credentials request with error: {message}",
                    xCorrelationIdentifier,
                    ex.Message);
                throw;
            }
        }

        public async Task<List<ChargerLocation>> GetDeltaChargerLocations(
            long lastSync,
            int limit,
            Guid xCorrelationIdentifier,
            int paginatedDelay = 0)
        {
            try
            {

                var offset = 0;
                var totalCount = 0;
                var pageSize = 0;
                List<ChargerLocation> totalChargerLocations = new List<ChargerLocation>();

                do
                {
                    var queryString = $"{_chargeFoxSettings.LatestMutualVersion}/locations?date_from={lastSync}&limit={limit}&offset={offset}";
                    var request = new HttpRequestMessage(HttpMethod.Get, queryString);

                    using (var response = await _httpWrapper.SendAsync(
                        request,
                        InternalConstants.ChargeFoxClient,
                        xCorrelationIdentifier,
                        $"Bearer {_chargeFoxSettings.OCPISenderCredentialsToken}"))
                    {
                        response.EnsureSuccessStatusCode();

                        // Parse response
                        var initialResponseObject = await response.Content.ReadFromJsonAsync<ChargerLocationsResponse>();

                        // Updated charger locations list
                        if (initialResponseObject != null && initialResponseObject.ChargerLocations != null)
                        {
                            totalChargerLocations.AddRange(initialResponseObject.ChargerLocations);
                            pageSize = initialResponseObject.ChargerLocations.Count;
                        }

                        // Extract total count from response header
                        var totalCountValues = response.Headers.GetValues(InternalConstants.TotalCountHeader);
                        totalCount = int.Parse(totalCountValues.First());
                    }

                    // Update offset
                    offset += pageSize;

                    if (paginatedDelay > 0)
                    {
                        await Task.Delay(paginatedDelay);
                    }

                } while (offset < totalCount);

                return totalChargerLocations;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName +
                    "} failed to fetch ChargeFox locations with error: {message}",
                    xCorrelationIdentifier,
                    ex.Message);
                throw;
            }
        }

        public async Task<List<ChargerTariff>> GetDeltaChargerTariffs(
            long lastSync,
            int limit,
            Guid xCorrelationIdentifier,
            int paginatedDelay = 0)
        {
            try
            {
                var offset = 0;
                var totalCount = 0;
                var pageSize = 0;
                List<ChargerTariff> totalChargerTariffs = new List<ChargerTariff>();

                do
                {
                    var queryString = $"{_chargeFoxSettings.LatestMutualVersion}/tariffs?date_from={lastSync}&limit={limit}&offset={offset}";
                    var request = new HttpRequestMessage(HttpMethod.Get, queryString);

                    using (var response = await _httpWrapper.SendAsync(
                        request,
                        InternalConstants.ChargeFoxClient,
                        xCorrelationIdentifier,
                        $"Bearer {_chargeFoxSettings.OCPISenderCredentialsToken}"))
                    {
                        response.EnsureSuccessStatusCode();

                        // Parse response
                        var responseObject = await response.Content.ReadFromJsonAsync<ChargerTariffsResponse>();

                        // Updated charger tariffs list
                        if (responseObject != null && responseObject.ChargerTariffs != null)
                        {
                            totalChargerTariffs.AddRange(responseObject.ChargerTariffs);
                            pageSize = responseObject.ChargerTariffs.Count;
                        }

                        // Extract total count from response header
                        var totalCountValues = response.Headers.GetValues(InternalConstants.TotalCountHeader);
                        totalCount = int.Parse(totalCountValues.First());
                    }

                    // Update offset
                    offset += pageSize;

                    if (paginatedDelay > 0)
                    {
                        await Task.Delay(paginatedDelay);
                    }

                } while (offset < totalCount);

                return totalChargerTariffs;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName +
                    "} failed to fetch ChargeFox tariffs response with error: {message}",
                    xCorrelationIdentifier,
                    ex.Message);
                throw;
            }
        }
    }
}
