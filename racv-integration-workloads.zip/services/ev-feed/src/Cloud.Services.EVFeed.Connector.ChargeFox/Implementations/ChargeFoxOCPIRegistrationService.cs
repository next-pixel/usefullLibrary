﻿using Azure.Data.AppConfiguration;
using Azure.Security.KeyVault.Secrets;
using Cloud.Services.Common.Connector.Models.Exceptions;
using Cloud.Services.Common.Constants;
using Cloud.Services.Common.Settings;
using Cloud.Services.EVFeed.Common.Constants;
using Cloud.Services.EVFeed.Common.Interfaces;
using Cloud.Services.EVFeed.Common.Models.Connectors.OCPI;
using Cloud.Services.EVFeed.Connector.ChargeFox.Extensions;
using Cloud.Services.EVFeed.Connector.ChargeFox.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Text;

namespace Cloud.Services.EVFeed.Connector.ChargeFox.Implementations
{
    /// <summary>
    /// ChargeFox OCPI Registration Service
    /// </summary>
    public class ChargeFoxOCPIRegistrationService : IOCPIRegistrationService
    {
        private readonly ILogger<ChargeFoxOCPIRegistrationService> _logger;
        private readonly IChargeFoxService _chargeFoxService;
        private readonly IConfiguration _configuration;
        private readonly ConfigurationClient _configurationClient;
        private readonly IConfigurationRefresher _configurationRefresher;
        private readonly SecretClient _secretClient;
        private readonly OCPISettings _OCPISettings;
        private readonly AppSettings _appSettings;
        private readonly ChargeFoxSettings _chargeFoxSettings;

        public ChargeFoxOCPIRegistrationService(
            ILogger<ChargeFoxOCPIRegistrationService> logger,
            IConfiguration configuration,
            IChargeFoxService chargeFoxService,
            ConfigurationClient configurationClient,
            SecretClient secretClient,
            IOptions<AppSettings> appSettings,
            IOptions<OCPISettings> oCPISettings,
            IOptions<ChargeFoxSettings> chargeFoxSettings,
            IConfigurationRefresherProvider configurationRefresherProvider)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _chargeFoxService = chargeFoxService ?? throw new ArgumentNullException(nameof(chargeFoxService));
            _OCPISettings = oCPISettings.Value ?? throw new ArgumentNullException(nameof(oCPISettings));
            _configurationClient = configurationClient ?? throw new ArgumentNullException(nameof(configurationClient));
            _secretClient = secretClient ?? throw new ArgumentNullException(nameof(secretClient));
            _appSettings = appSettings.Value ?? throw new ArgumentNullException(nameof(appSettings));
            _configurationRefresher = configurationRefresherProvider.Refreshers.First();
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            _chargeFoxSettings = chargeFoxSettings.Value ?? throw new ArgumentNullException(nameof(chargeFoxSettings));
        }

        public async Task RegisterAsync(
            Guid xCorrelationIdentifier,
            bool forceRefresh = false)
        {
            try
            {
                await _chargeFoxSettings.LoadChargeFoxSettingsAsync(_configuration, _configurationRefresher);
                var checkSenderToken = string.IsNullOrWhiteSpace(_chargeFoxSettings.OCPISenderCredentialsToken);

                if (!forceRefresh && !checkSenderToken)
                {
                    _logger.LogInformation(
                       "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                       "}. Chargefox OCPI Sender Credentials already exist. " +
                       "A force refresh is necessary to update these credentials.",
                       xCorrelationIdentifier);
                    return;
                }

                var authorization = checkSenderToken ?
                    _chargeFoxSettings.OCPIHandshakeCredentialsToken :
                    _chargeFoxSettings.OCPISenderCredentialsToken;

                var chargeFoxOCPIVersionsResponse = await _chargeFoxService.GetVersions(xCorrelationIdentifier, authorization);
                if (chargeFoxOCPIVersionsResponse.Versions != null
                    && chargeFoxOCPIVersionsResponse.Versions.Count == 0)
                {
                    var errMessage = "Could not find any OCPI versions from ChargeFox.";
                    _logger.LogError(
                        "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                        "}.+ {Message}",
                        xCorrelationIdentifier,
                        errMessage);

                    throw new ExternalApiDependencyException(errMessage);
                }
                var chargeFoxVersions = chargeFoxOCPIVersionsResponse.Versions!.Select(x => x.Version).ToList();
                var OCPISettingsVersions = new List<Version>() { _OCPISettings.VersionDetails.Version };

                var commonVersions = chargeFoxVersions.Intersect(OCPISettingsVersions);
                var latestMutualVersion = commonVersions.Any() ? commonVersions.Max() : null;
                if (latestMutualVersion == null)
                {
                    var errMessage = "Could not find any common OCPI versions between Chargefox and Microservice.";
                    _logger.LogError(
                       "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                        "}.+ {Message}",
                       xCorrelationIdentifier,
                       errMessage);

                    throw new InvalidOperationException(errMessage);
                }

                var highestChargeFoxVersion = chargeFoxVersions.Max();
                if (highestChargeFoxVersion!.CompareTo(latestMutualVersion) > 0)
                {
                    _logger.LogWarning(
                    "CorrelationId : {{{CorrelationId}}}. A higher version for Chargefox OCPI version ({HighestVersion}) is available. Currently Microservice OCPI running on latest mutual version ({LatestMutualVersion}).",
                    xCorrelationIdentifier,
                    highestChargeFoxVersion,
                    latestMutualVersion);
                }

                // Update the configuration setting with the new value
                await _configurationClient.SetConfigurationSettingAsync(
                    $"{ChargeFoxSettings.ConfigurationSectionName}:{nameof(_chargeFoxSettings.LatestMutualVersion)}",
                    latestMutualVersion!.ToString(),
                    $"{_appSettings.Environment}");

                // Generate OCPI Credentials Token B
                var credentialsTokenB = GenerateBase64GuidToken();

                // Store the Credential Token B
                await UpdateSecretValueAndProperties(
                    InternalConstants.ChargefoxOCPIReceiverCredentialsTokenKey,
                    credentialsTokenB);

                // Submit Chargefox Credentials
                var submitCredentialsResponse = await _chargeFoxService.SubmitCredentials(
                    xCorrelationIdentifier,
                    latestMutualVersion.ToString(),
                    CreateOCPICredentialsRequest(credentialsTokenB, _OCPISettings.VersionsEndpoint),
                    authorization,
                    forceRefresh ? HttpMethod.Put : HttpMethod.Post);

                if (submitCredentialsResponse.credentials == null
                && string.IsNullOrWhiteSpace(submitCredentialsResponse.credentials!.Token))
                {
                    var errMessage = "No Credentials token  found from ChargeFox OCPI API response.";
                    _logger.LogError(
                       "CorrelationId : {" + ServicesConstants.CorrelationIdLogPropertyName +
                        "}.+ {Message}",
                       xCorrelationIdentifier);
                    throw new ExternalApiDependencyException(errMessage);
                }

                // Store the Credential Token C
                await UpdateSecretValueAndProperties(
                    InternalConstants.ChargefoxOCPISenderCredentialsTokenKey,
                    submitCredentialsResponse.credentials!.Token!);

                // Set empty value in Credential Token A if force refresh is false
                if (!forceRefresh)
                {
                    await UpdateSecretValueAndProperties(
                    InternalConstants.ChargefoxOCPIHandshakeCredentialsTokenKey,
                    string.Empty);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Correlation Id : {" + ServicesConstants.CorrelationIdLogPropertyName + "} " +
                    "OCPI Registeration failed with error: {message}.",
                    xCorrelationIdentifier,
                    ex.Message);
                throw;
            }
        }

        private static Credentials CreateOCPICredentialsRequest(
            string credentialsTokenB,
            string versionsEndpoint) => new Credentials
            {
                Token = credentialsTokenB,
                Url = versionsEndpoint,
                Roles =
                [
                    new Role
                    {
                        RoleName = InternalConstants.OCPIRoleName,
                        PartyId = InternalConstants.OCPIPartyId,
                        CountryCode = InternalConstants.OCPICountryCode,
                        BusinessDetails = new BusinessDetails
                        {
                            Name = InternalConstants.OCPIBusinessName
                        }
                    }
                ]
            };

        private static string GenerateBase64GuidToken()
        {
            // Generate a new GUID
            string guidString = Guid.NewGuid().ToString();

            // Convert the GUID string to a byte array
            byte[] guidBytes = Encoding.UTF8.GetBytes(guidString);

            // Encode the byte array to Base64
            return Convert.ToBase64String(guidBytes);
        }

        private async Task UpdateSecretValueAndProperties(
            string secretName,
            string secretValue)
        {
            // Step 1: Get the current secret
            var originalSecretResponse = await _secretClient.GetSecretAsync(secretName);
            var originalSecret = originalSecretResponse.Value;

            // Step 2: Disable the old secret
            // Set the old secret to disabled
            originalSecret.Properties.Enabled = false;
            await _secretClient.UpdateSecretPropertiesAsync(originalSecret.Properties);

            // Step 3: Create a new version of the secret
            // Update secret value (create a new version)
            await _secretClient.SetSecretAsync(secretName, secretValue);
        }
    }
}
