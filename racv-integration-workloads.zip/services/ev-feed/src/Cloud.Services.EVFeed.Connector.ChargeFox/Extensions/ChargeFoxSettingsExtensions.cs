﻿using Cloud.Services.Common.Settings;
using Cloud.Services.EVFeed.Common.Settings;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;

namespace Cloud.Services.EVFeed.Connector.ChargeFox.Extensions
{
    public static class ChargeFoxSettingsExtensions
    {
        public static async Task LoadChargeFoxSettingsAsync(
            this ChargeFoxSettings chargeFoxSettings,
            IConfiguration configuration, 
            IConfigurationRefresher configurationRefresher)
        {
            await configurationRefresher.TryRefreshAsync();
            configuration.Bind(ChargeFoxSettings.ConfigurationSectionName, chargeFoxSettings);
        }
    }
}
