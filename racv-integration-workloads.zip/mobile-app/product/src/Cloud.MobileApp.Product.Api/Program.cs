using Cloud.MobileApp.Common.Settings;
using Cloud.MobileApp.Common.Startup;
using Cloud.MobileApp.Common.Utility.Handlers.Interfaces;
using Cloud.MobileApp.Common.Utility.Wrapper.Implementation;
using Cloud.MobileApp.Common.Utility.Wrapper.Interfaces;
using Cloud.MobileApp.Product.Common.Constants;
using Cloud.MobileApp.Product.Common.Settings;
using Cloud.MobileApp.Product.Connector.Service.Implementations;
using Cloud.MobileApp.Product.Connector.Service.Interfaces;

namespace Cloud.MobileApp.Product.Api;

internal class Program
{
    private Program()
    {
    }

    private static void Main(string[] args)
    {
        // Create the web application builder.
        var builder = WebApplication.CreateBuilder(args);

        // Add common services
        ConfigureServices(builder);

        // Build the app
        var app = builder.Build();

        // Configure app
        ApiBaseStartup.Configure(app, app.Environment, builder.Logging);

        // Map controllers
        app.MapControllers();

        // Configure the HTTP request pipeline.
        app.Run();
    }

    private static void ConfigureServices(WebApplicationBuilder builder)
    {
        // Add common services
        ApiBaseStartup.ConfigureServices<Program>(builder);

        // Retrieve the ProductSettings from the application configuration.
        var productSettings = new ProductSettings();
        builder.Configuration.Bind(ProductSettings.ConfigurationSectionName, productSettings);

        // Retrieve the ServiceSettings from the application configuration.
        var serviceSettings = new ServiceSettings();
        builder.Configuration.Bind(ServiceSettings.ConfigurationSectionName, serviceSettings);

        // Add HTTP Client
        builder.Services.AddHttpClient(InternalConstants.ServiceHttpClient,
            client =>
            {
                client.BaseAddress = new Uri(productSettings.ServiceBaseAddress ?? string.Empty);
                client.DefaultRequestHeaders.Add("subscription-key", serviceSettings.SubscriptionKey);
            });

        // Add HttpWrapper
        builder.Services.AddSingleton<IHttpWrapper<HttpRequestMessage, HttpResponseMessage>, HttpWrapper>(
            provider =>
            {
                var httpClientFactory = provider.GetRequiredService<IHttpClientFactory>();
                var messageTrackerHandler =
                    provider.GetRequiredService<IMessageTrackerHandler<HttpRequestMessage, HttpResponseMessage>>();
                var wrapper = new HttpWrapper(httpClientFactory, messageTrackerHandler.LogRequestResponse);
                return wrapper;
            });

        // Add Microservice Connector
        builder.Services.AddTransient<IProductDetailsService, ProductDetailsService>();
    }
}
