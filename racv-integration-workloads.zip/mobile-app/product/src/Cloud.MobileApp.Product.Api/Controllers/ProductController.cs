using Cloud.MobileApp.Common.Constants;
using Cloud.MobileApp.Common.Exceptions;
using Cloud.MobileApp.Product.Api.Extensions;
using Cloud.MobileApp.Product.Connector.Service.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ApiProductResponse = Cloud.MobileApp.Product.Api.Models.Response.ProductResponse;

namespace Cloud.MobileApp.Product.Api.Controllers;

/// <summary>
///     Controller for handling requests related to product details.
/// </summary>
[ApiController]
[Route("v1")]
public class ProductController : ControllerBase
{
    private readonly ILogger<ProductController> _logger;
    private readonly IProductDetailsService _productDetailsService;

    /// <summary>
    ///     Initializes a new instance of the <see cref="ProductController" /> class.
    /// </summary>
    /// <param name="logger">The logger used for logging events in this class.</param>
    /// <param name="productDetailsService">The service that provides product details.</param>
    /// <param name="configuration">The application configuration.</param>
    /// <exception cref="ArgumentNullException">Thrown when the logger is null.</exception>
    public ProductController(ILogger<ProductController> logger,
        IProductDetailsService productDetailsService, IConfiguration configuration)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _productDetailsService = productDetailsService;

        ProductResponseExtensions.SetActionDetails(configuration);
        ProductResponseExtensions.SetTradesJobActionDetails(configuration);
    }

    /// <summary>
    ///     Gets the product details.
    /// </summary>
    /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
    /// <param name="authorization">JWT Bearer</param>
    /// <returns>The action result.</returns>
    [HttpGet("products")]
    [Authorize]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Produces("application/json")]
    public async Task<ActionResult<ApiProductResponse>> GetAsync(
        [FromHeader(Name = MobileAppConstants.CorrelationIdLogPropertyName)]
        Guid xCorrelationIdentifier,
        [FromHeader(Name = "Authorization")] string authorization
    )
    {
        _logger.LogInformation(
            "CorrelationId : { "
            + MobileAppConstants.CorrelationIdLogPropertyName
            + "} Started executing Get Async Method.",
            xCorrelationIdentifier
        );

        try
        {
            var response =
                await _productDetailsService.GetProductDetails(xCorrelationIdentifier, authorization);
            
            return Ok(response.Convert());
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Retrieving Product Details failed with error: {message}", xCorrelationIdentifier, ex.Message);

            return StatusCode(ex.StatusCode != null ? (int)ex.StatusCode : StatusCodes.Status500InternalServerError,
                new OperationFailureResponse("Error occurred while retrieving Product Details.", null,
                    xCorrelationIdentifier.ToString()));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Retrieving Product Details failed with error: {message}", xCorrelationIdentifier, ex.Message);

            return StatusCode(StatusCodes.Status500InternalServerError,
                new OperationFailureResponse("Error occurred while retrieving Product Details.", null,
                    xCorrelationIdentifier.ToString()));
        }
    }
}
