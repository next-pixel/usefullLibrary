using Cloud.MobileApp.Product.Common.Constants;
using Cloud.MobileApp.Product.Common.Settings;
using ApiResponse = Cloud.MobileApp.Product.Api.Models.Response;
using ServiceResponse = Cloud.MobileApp.Product.Common.Models.Service.Response;

namespace Cloud.MobileApp.Product.Api.Extensions;

/// <summary>
///     Provides extension methods for converting Service responses to API responses.
/// </summary>
public static class ProductResponseExtensions
{
    private static Dictionary<string, (int, string, Uri?)> ActionDetails;
    private static Dictionary<string, (int, string, Uri?)> TradesJobActionDetails;

    /// <summary>
    ///     Sets the action details for the product response.
    /// </summary>
    /// <param name="configuration">The application configuration.</param>
    /// <remarks>
    ///     This method initializes the ActionDetails dictionary with the details of each action that can be performed on a product.
    ///     The details include an index, a label, and an optional icon URL. The icon URLs are constructed using the AEM base URL and icon path.
    /// </remarks>
    public static void SetActionDetails(IConfiguration configuration)
    {
        var aemSettings = new AemSettings();
        configuration.Bind(AemSettings.ConfigurationSectionName, aemSettings);

        var aemBaseUrl = aemSettings.BaseUrl;
        const string IconsPath = "/content/dam/racv-assets/images/icons/app";

        ActionDetails = new Dictionary<string, (int, string, Uri?)>
        {
            ["canViewProductDetails"] = (0, "View and manage product",
                aemBaseUrl != null ? new Uri($"{aemBaseUrl}{IconsPath}/paper-lines.svg") : null),
            ["canManageDirectDebit"] = (1, "Manage direct debit",
                aemBaseUrl != null ? new Uri($"{aemBaseUrl}{IconsPath}/credit-card.svg") : null),
            ["canPayBill"] = (2, "Make a payment",
                aemBaseUrl != null ? new Uri($"{aemBaseUrl}{IconsPath}/credit-card.svg") : null),
            ["canViewClubStatements"] = (3, "View club statements",
                aemBaseUrl != null ? new Uri($"{aemBaseUrl}{IconsPath}/folder.svg") : null),
            ["canViewPolicyDocuments"] = (4, "Open policy document",
                aemBaseUrl != null ? new Uri($"{aemBaseUrl}{IconsPath}/folder.svg") : null),
            ["canEditAddress"] = (5, "Update address",
                aemBaseUrl != null ? new Uri($"{aemBaseUrl}{IconsPath}/house.svg") : null)
        };
    }

    public static void SetTradesJobActionDetails(IConfiguration configuration)
    {
        var aemSettings = new AemSettings();
        configuration.Bind(AemSettings.ConfigurationSectionName, aemSettings);

        var aemBaseUrl = aemSettings.BaseUrl;
        const string IconsPath = "/content/dam/racv-assets/images/icons/app";

        TradesJobActionDetails = new Dictionary<string, (int, string, Uri?)>
        {
            ["canViewJobDetails"] = (0, "View job",
                aemBaseUrl != null ? new Uri($"{aemBaseUrl}{IconsPath}/paper-lines.svg") : null),
            ["canReviewQuote"] = (1, "Review quote",
                aemBaseUrl != null ? new Uri($"{aemBaseUrl}{IconsPath}/clipboard.svg") : null),
            ["canPayDeposit"] = (2, "Pay deposit",
                aemBaseUrl != null ? new Uri($"{aemBaseUrl}{IconsPath}/credit-card.svg") : null),
            ["canMakePayment"] = (3, "Make a payment",
                aemBaseUrl != null ? new Uri($"{aemBaseUrl}{IconsPath}/credit-card.svg") : null)
        };
    }

    /// <summary>
    ///     Converts a Service product response to an API product response.
    /// </summary>
    /// <param name="msProductResponse">The Service product response to convert.</param>
    /// <returns>The converted API product response.</returns>
    public static ApiResponse.ProductResponse Convert(this ServiceResponse.ProductsResponse msProductResponse)
    {
        var productsInfo = msProductResponse.Data.Convert();
        productsInfo.ViewAllTradesJobsUrl = msProductResponse.TradesJobList.FirstOrDefault()?.ViewAllJobs;
        productsInfo.TradesJobList = msProductResponse.TradesJobList.Select(tradeJob => tradeJob.Convert()).ToList();
        return new ApiResponse.ProductResponse
        {
            Message = "Operation successful.", 
            ProductsInfo = productsInfo
        };
    }

    /// <summary>
    ///     Converts a list of Service products to an API products info.
    /// </summary>
    /// <param name="msProduct">The list of Service products to convert.</param>
    /// <returns>The converted API products info.</returns>
    private static ApiResponse.ProductsInfo Convert(
        this List<ServiceResponse.Product> msProduct)
    {
        var activeProducts = new List<ServiceResponse.Product>();
        ServiceResponse.Product? cancelledProduct = null;

        foreach (var product in msProduct)
        {
            if (string.IsNullOrWhiteSpace(product.Status))
            {
                continue;
            }

            if (product.Status.Equals(InternalConstants.CancelledProductStatus,
                    StringComparison.InvariantCultureIgnoreCase))
            {
                cancelledProduct = product;
            }
            else
            {
                activeProducts.Add(product);
            }
        }

        return new ApiResponse.ProductsInfo
        {
            ViewCancelledProductsUrl = cancelledProduct?.ViewCancelledProductsUrl,
            ViewAllTradesJobsTitle = InternalConstants.ViewAllTradesJobsTitle,
            ViewCancelledProductsTitle = InternalConstants.ViewCancelledProductsTitle,
            ActiveProducts = activeProducts
                .Select(item => new ApiResponse.ActiveProduct
                {
                    Id = item.Id,
                    Status = item.Status,
                    ProductName = item.ProductName,
                    ProductCode = item.ProductCode,
                    AssetDescription = item.AssetDescription,
                    ActualStatus = item.ActualStatus,
                    PolicyNumber = item.PolicyNumber,
                    PaymentPreference = item.PaymentPreference,
                    ExpiryDate = item.ExpiryDate,
                    DisplayPolicyNumber = item.DisplayPolicyNumber ?? false,
                    DisplayMakePayment = item.DisplayMakePayment ?? false,
                    DisplayExpiryDate = item.DisplayExpiryDate ?? false,
                    CanManageClaim = item.CanManageClaim ?? false,
                    CanViewProductDetails = item.CanViewProductDetails,
                    CanViewCancelledProducts = item.CanViewCancelledProducts,
                    CanPayBill = item.CanPayBill,
                    CanEditAddress = item.CanEditAddress,
                    AssetIcon = item.AssetIcon,
                    CtaUrl = item.CtaUrl,
                    DisplayPaymentPreference = item.DisplayPaymentPreference,
                    MakePaymentLabel = InternalConstants.MakePaymentLabel,
                    CanManageDirectDebit = item.CanManageDirectDebit,
                    CanViewClubStatements = item.CanViewClubStatements,
                    CanViewPolicyDocuments = item.CanViewPolicyDocuments,
                    ViewCancelledProductsUrl = item.ViewCancelledProductsUrl,
                    Actions = item.Actions.Select(action => action.Convert()).OfType<ApiResponse.Action>().OrderBy(action => action.Index).ToList()
                }).ToList(),
                
        };
    }

    /// <summary>
    ///     Converts a Service action to an API action.
    /// </summary>
    /// <param name="action">The Service action to convert.</param>
    /// <returns>The converted API action, or null if the action property is not recognized.</returns>
    private static ApiResponse.Action? Convert(this ServiceResponse.Action action)
    {
        var actionDetail = GetActionDetails(action.Property ?? string.Empty);

        return actionDetail == null
            ? null
            : new ApiResponse.Action
            {
                Index = actionDetail.Value.Item1,
                Label = actionDetail.Value.Item2,
                ActionIcon = actionDetail.Value.Item3,
                Property = action.Property,
                Destination = action.Destination
            };
    }

    private static ApiResponse.Action? ConvertTradesAction(this ServiceResponse.Action action)
    {
        var actionDetail = GetTradesJobActionDetails(action.Property ?? string.Empty);

        return actionDetail == null
            ? null
            : new ApiResponse.Action
            {
                Index = actionDetail.Value.Item1,
                Label = actionDetail.Value.Item2,
                ActionIcon = actionDetail.Value.Item3,
                Property = action.Property,
                Destination = action.Destination
            };
    }
    private static ApiResponse.TradesJob Convert(
        this ServiceResponse.TradesJobResponse item)
    {
        return new ApiResponse.TradesJob { 
            TradeProgress = item.TradeProgress, 
            ReferenceNumber = item.ReferenceNumber, 
            QuoteReviewPaymentLabel = item.QuoteReviewPaymentLabel, 
            PropAddress = item.PropAddress, 
            ProductCode = item.ProductCode, 
            JobStatusDisplay = item.JobStatusDisplay, 
            JobNameDisplay = item.JobNameDisplay, 
            JobIcon = item.JobIcon, 
            ViewAllJobs = item.ViewAllJobs,
            CtaUrl = item.CtaUrl,
            CtaLabel = GetCtaLabel(item),
            CanViewJobDetails = item.CanViewJobDetails, 
            CanReviewQuote = item.CanReviewQuote, 
            CanMakePayment = item.CanMakePayment,
            CanPayDeposit = item.CanPayDeposit,
            ActualStatus = item.ActualStatus, 
            Actions = item.Actions.Select(action => action.ConvertTradesAction()).OfType<ApiResponse.Action>().OrderBy(action => action.Index).ToList()
            };
    }


    /// <summary>
    ///     Gets the action details for a given property.
    /// </summary>
    /// <param name="property">The property to get the action details for.</param>
    /// <returns>The action details, or null if the property is not recognized.</returns>
    private static (int, string, Uri?)? GetActionDetails(string property)
    {
        return ActionDetails.TryGetValue(property, out var value) ? value : null;
    }

    private static (int, string, Uri?)? GetTradesJobActionDetails(string property)
    {
        return TradesJobActionDetails.TryGetValue(property, out var value) ? value : null;
    }

    public static string? GetCtaLabel(this ServiceResponse.TradesJobResponse item)
    {
        if (item.CanReviewQuote)
        {
            return "Review quote";
        }
        else if (item.CanPayDeposit)
        {
            return "Pay deposit";
        }
        else if (item.CanMakePayment)
        {
            return "Make payment";
        }
        return null;
    }   
}
