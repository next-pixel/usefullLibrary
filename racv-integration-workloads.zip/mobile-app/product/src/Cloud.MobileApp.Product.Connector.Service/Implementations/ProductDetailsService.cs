using System.Runtime.Serialization;
using System.Text.Json;
using Cloud.MobileApp.Common.Constants;
using Cloud.MobileApp.Common.Utility.Wrapper.Interfaces;
using Cloud.MobileApp.Product.Common.Constants;
using Cloud.MobileApp.Product.Connector.Service.Interfaces;
using Microsoft.Extensions.Logging;
using ServiceProductsResponse = Cloud.MobileApp.Product.Common.Models.Service.Response.ProductsResponse;

namespace Cloud.MobileApp.Product.Connector.Service.Implementations;

public class ProductDetailsService : IProductDetailsService
{
    private readonly IHttpWrapper<HttpRequestMessage, HttpResponseMessage> _httpWrapper;
    private readonly ILogger<ProductDetailsService> _logger;

    /// <summary>
    ///     Initializes a new instance of the <see cref="ProductDetailsService" /> class.
    /// </summary>
    /// <param name="logger">The logger.</param>
    /// <param name="clientFactory">The HTTP client factory.</param>
    public ProductDetailsService(ILogger<ProductDetailsService> logger,
        IHttpWrapper<HttpRequestMessage, HttpResponseMessage> httpWrapper)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _httpWrapper = httpWrapper ?? throw new ArgumentNullException(nameof(httpWrapper));
    }

    /// <summary>
    ///     Retrieves product details from Salesforce.
    /// </summary>
    /// <param name="xCorrelationIdentifier">The unique identifier for correlating HTTP requests and responses.</param>
    /// <param name="authorization">The JWT Bearer token for authorization.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains the product details response.</returns>
    /// <exception cref="HttpRequestException">Thrown when the HTTP request to Salesforce fails.</exception>
    /// <exception cref="SerializationException">Thrown when deserialization of the Salesforce response fails.</exception>
    public async Task<ServiceProductsResponse> GetProductDetails(Guid xCorrelationIdentifier,
        string authorization)
    {
        HttpResponseMessage? response = null;

        try
        {
            var request = new HttpRequestMessage(HttpMethod.Get, "services/product/v1/products");
            response = await _httpWrapper.SendAsync(
                request,
                InternalConstants.ServiceHttpClient,
                xCorrelationIdentifier,
                authorization);

            response.EnsureSuccessStatusCode();

            var responseJson = await response.Content.ReadAsStringAsync();
            var result = JsonSerializer.Deserialize<ServiceProductsResponse>(responseJson);

            return result ??
                   throw new SerializationException();
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Retrieving Product Details from Microservice failed with Status Code: {statusCode}",
                xCorrelationIdentifier,
                response?.StatusCode);

            throw new HttpRequestException(
                $"Retrieving Product Details from Microservice failed with Status Code: {response?.StatusCode}", ex, response?.StatusCode);
        }
        catch (SerializationException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Deserialization of Product Details from Microservice failed with error: {message}",
                xCorrelationIdentifier, ex.Message);

            throw new SerializationException(
                $"Deserialization of Product Details from Microservice failed with error: {ex.Message}", ex);
        }
    }
}
