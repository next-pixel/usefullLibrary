using Cloud.MobileApp.Product.Common.Models.Service.Response;

namespace Cloud.MobileApp.Product.Connector.Service.Interfaces;

public interface IProductDetailsService
{
    Task<ProductsResponse> GetProductDetails(Guid xCorrelationIdentifier, string authorization);
}
