using System.Text.Json.Serialization;

namespace Cloud.MobileApp.Product.Common.Models.Service.Response;

/// <summary>
///     Response payload from Microservice representing Trades Job details
/// </summary>

public class TradesJobResponse
{
    [JsonPropertyName("tradeProgress")]
    public string? TradeProgress { get; set; }
    
    [JsonPropertyName("referenceNumber")]
    public string? ReferenceNumber { get; set; }
    
    [JsonPropertyName("quoteReviewPaymentLabel")]
    public string? QuoteReviewPaymentLabel { get; set; }

    [JsonPropertyName("propAddress")]
    public string? PropAddress { get; set; }

    [JsonPropertyName("productCode")]
    public string? ProductCode { get; set; }

    [JsonPropertyName("jobStatusDisplay")]
    public string? JobStatusDisplay { get; set; }
    
    [JsonPropertyName("jobNameDisplay")]
    public string? JobNameDisplay { get; set; }

    [JsonPropertyName("jobIcon")]
    public Uri? JobIcon { get; set; }

    [JsonPropertyName("canViewJobDetails")]
    public bool CanViewJobDetails { get; set; }

    [JsonPropertyName("viewAllJobs")]
    public Uri? ViewAllJobs { get; set; }

    [JsonPropertyName("ctaUrl")]
    public Uri? CtaUrl { get; set; }

    [JsonPropertyName("canReviewQuote")]
    public bool CanReviewQuote { get; set; }

    [JsonPropertyName("canMakePayment")]
    public bool CanMakePayment { get; set; }
    
    [JsonPropertyName("canPayDeposit")]
    public bool CanPayDeposit { get; set; }

    [JsonPropertyName("actualStatus")]
    public string? ActualStatus { get; set; }

    [JsonPropertyName("actions")]
    public List<Action> Actions { get; set; } = [];
}

