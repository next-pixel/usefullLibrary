using System.Text.Json.Serialization;

namespace Cloud.MobileApp.Product.Common.Models.Service.Response;

/// <summary>
///     Response payload from Microservice representing Product details
/// </summary>
public class ProductsResponse
{
    [JsonPropertyName("message")]
    public string? Message { get; set; }

    [JsonPropertyName("data")]
    public List<Product> Data { get; set; } = [];

    [JsonPropertyName("tradesJobList")]
    public List<TradesJobResponse> TradesJobList { get; set; } = [];
    
}

public class Product
{
    [JsonPropertyName("Id")]
    public string? Id { get; set; }

    [JsonPropertyName("status")]
    public string? Status { get; set; }

    [JsonPropertyName("productName")]
    public string? ProductName { get; set; }

    [JsonPropertyName("productCode")]
    public string? ProductCode { get; set; }

    [JsonPropertyName("assetDescription")]
    public string? AssetDescription { get; set; }

    [JsonPropertyName("actualStatus")]
    public string? ActualStatus { get; set; }

    [JsonPropertyName("policyNumber")]
    public string? PolicyNumber { get; set; }

    [JsonPropertyName("paymentPreference")]
    public string? PaymentPreference { get; set; }

    [JsonPropertyName("expiryDate")]
    public string? ExpiryDate { get; set; }

    [JsonPropertyName("displayPolicyNumber")]
    public bool? DisplayPolicyNumber {get; set;}

    [JsonPropertyName("displayMakePayment")]
    public bool? DisplayMakePayment {get; set;}

    [JsonPropertyName("displayExpiryDate")]
    public bool? DisplayExpiryDate {get; set;}

    [JsonPropertyName("canManageClaim")]
    public bool? CanManageClaim {get; set;}

    [JsonPropertyName("canViewProductDetails")]
    public bool CanViewProductDetails { get; set; }

    [JsonPropertyName("canViewCancelledProducts")]
    public bool CanViewCancelledProducts { get; set; }

    [JsonPropertyName("canPayBill")]
    public bool CanPayBill { get; set; }

    [JsonPropertyName("canEditAddress")]
    public bool CanEditAddress { get; set; }

    [JsonPropertyName("assetIcon")]
    public Uri? AssetIcon { get; set; }

    [JsonPropertyName("ctaUrl")]
    public Uri? CtaUrl { get; set; }

    [JsonPropertyName("displayPaymentPreference")]
    public bool DisplayPaymentPreference { get; set; }

    [JsonPropertyName("canManageDirectDebit")]
    public bool CanManageDirectDebit { get; set; }

    [JsonPropertyName("canViewClubStatements")]
    public bool CanViewClubStatements { get; set; }

    [JsonPropertyName("canViewPolicyDocuments")]
    public bool CanViewPolicyDocuments { get; set; }

    [JsonPropertyName("viewCancelledProductsUrl")]
    public Uri? ViewCancelledProductsUrl { get; set; }

    [JsonPropertyName("actions")]
    public List<Action> Actions { get; set; } = [];
}

public class Action
{
    [JsonPropertyName("property")]
    public string? Property { get; set; }

    [JsonPropertyName("destination")]
    public Uri? Destination { get; set; }
}
