namespace Cloud.MobileApp.Product.Common.Settings;

public class ProductSettings
{
    public const string ConfigurationSectionName = "ProductSettings";
    public string? ServiceBaseAddress { get; set; } = null;
}
