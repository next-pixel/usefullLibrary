namespace Cloud.MobileApp.Product.Common.Settings;

public class AemSettings
{
    public const string ConfigurationSectionName = "AEMSettings";
    public string? BaseUrl { get; set; } = null;
}
