namespace Cloud.MobileApp.Product.Common.Constants;

/// <summary>
///     Constants to be used across all projects and workloads related to Product.
/// </summary>
public static class InternalConstants
{
    public const string ServiceHttpClient = "ServiceClient";
    public const string CancelledProductStatus = "Cancelled";
    public const string ViewCancelledProductsTitle = "View cancelled products";
    public const string ViewAllTradesJobsTitle = "View all jobs";
    public const string MakePaymentLabel = "Make payment";
}
