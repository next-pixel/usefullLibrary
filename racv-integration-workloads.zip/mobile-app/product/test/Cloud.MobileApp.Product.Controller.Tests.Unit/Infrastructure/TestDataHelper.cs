using ApiResponse = Cloud.MobileApp.Product.Api.Models.Response;
using ServiceResponse = Cloud.MobileApp.Product.Common.Models.Service.Response;

namespace Cloud.MobileApp.Product.Controller.Tests.Unit.Infrastructure;

public static class TestDataHelper
{
    /// <summary>
    ///     Generates a mock service response for testing.
    /// </summary>
    /// <returns>A mock service response.</returns>
    public static ServiceResponse.ProductsResponse GetExpectedServiceResponse()
    {
        return new ServiceResponse.ProductsResponse
        {
            Message = "Operation successful.",
            Data =
            [
                new ServiceResponse.Product
                {
                    Id = "123",
                    Status = "Cancelled",
                    ProductName = "Bike Assist",
                    ProductCode = "ERA-BAS",
                    AssetDescription = "",
                    ActualStatus = "Cancelled",
                    PolicyNumber = "",
                    PaymentPreference = "Annual automatic payment",
                    ExpiryDate = "2024-05-02",
                    DisplayPolicyNumber = null,
                    DisplayMakePayment = null,
                    DisplayExpiryDate = null,
                    CanManageClaim = null,
                    CanViewProductDetails = true,
                    CanViewCancelledProducts = false,
                    CanPayBill = false,
                    CanEditAddress = true,
                    AssetIcon = new Uri("https://example.com.au"),
                    CtaUrl = new Uri("https://racv--uat1.sandbox.my.site.com/s/racv-trades-quote-acceptance?quoteId=2ad9c2aee980"),
                    DisplayPaymentPreference = false,
                    CanManageDirectDebit = false,
                    CanViewClubStatements = false,
                    CanViewPolicyDocuments = false,
                    ViewCancelledProductsUrl = null,
                    Actions =
                    [
                        new ServiceResponse.Action
                        {
                            Property = "canViewProductDetails", Destination = new Uri("https://example.com.au")
                        },

                        new ServiceResponse.Action
                        {
                            Property = "canManageDirectDebit", Destination = new Uri("https://example.com.au")
                        },

                        new ServiceResponse.Action
                        {
                            Property = "canEditAddress", Destination = new Uri("https://example.com.au")
                        }
                    ]
                },
                new ServiceResponse.Product
                {
                    Id = "123",
                    Status = "Current",
                    ProductName = "Total Care",
                    ProductCode = "ERA-TC",
                    AssetDescription = "LTHL 2021 Isuzu MU-X",
                    ActualStatus = "Current",
                    PolicyNumber = "",
                    PaymentPreference = "Annual automatic payment",
                    ExpiryDate = "2025-05-01",
                    DisplayPolicyNumber = null,
                    DisplayMakePayment = null,
                    DisplayExpiryDate = null,
                    CanManageClaim = null,
                    CanViewProductDetails = true,
                    CanViewCancelledProducts = false,
                    CanPayBill = false,
                    CanEditAddress = true,
                    AssetIcon = new Uri("https://example.com.au"),
                    CtaUrl = new Uri("https://racv--uat1.sandbox.my.site.com/s/racv-trades-quote-acceptance?quoteId=2ad9c2aee980"),
                    DisplayPaymentPreference = false,
                    CanManageDirectDebit = false,
                    CanViewClubStatements = false,
                    CanViewPolicyDocuments = false,
                    ViewCancelledProductsUrl = null,
                    Actions =
                    [
                        new ServiceResponse.Action
                        {
                            Property = "canViewProductDetails", Destination = new Uri("https://example.com.au")
                        },

                        new ServiceResponse.Action
                        {
                            Property = "canManageDirectDebit", Destination = new Uri("https://example.com.au")
                        },

                        new ServiceResponse.Action
                        {
                            Property = "canEditAddress", Destination = new Uri("https://example.com.au")
                        }
                    ]
                }
            ],
            TradesJobList = []
        };
    }

    /// <summary>
    ///     Generates a mock api response for testing.
    /// </summary>
    /// <returns>A mock api response.</returns>
    public static ApiResponse.ProductResponse GetExpectedApiResponse()
    {
        return new ApiResponse.ProductResponse
        {
            Message = "Operation successful.",
            ProductsInfo = new ApiResponse.ProductsInfo
            {
                ViewCancelledProductsUrl = null,
                ViewCancelledProductsTitle = "View cancelled products",
                ViewAllTradesJobsTitle = "View all jobs",
                ActiveProducts =
                [
                    new ApiResponse.ActiveProduct
                    {
                        Id = "123",
                        Status = "Current",
                        ProductName = "Total Care",
                        ProductCode = "ERA-TC",
                        AssetDescription = "LTHL 2021 Isuzu MU-X",
                        ActualStatus = "Current",
                        PolicyNumber = "",
                        PaymentPreference = "Annual automatic payment",
                        MakePaymentLabel = "Make payment",
                        ExpiryDate = "2025-05-01",
                        DisplayPolicyNumber = false,
                        DisplayMakePayment = false,
                        DisplayExpiryDate = false,
                        CanManageClaim = false,
                        CanViewProductDetails = true,
                        CanViewCancelledProducts = false,
                        CanPayBill = false,
                        CanEditAddress = true,
                        AssetIcon = new Uri("https://example.com.au"),
                        CtaUrl = new Uri("https://racv--uat1.sandbox.my.site.com/s/racv-trades-quote-acceptance?quoteId=2ad9c2aee980"),
                        DisplayPaymentPreference = false,
                        CanManageDirectDebit = false,
                        CanViewClubStatements = false,
                        CanViewPolicyDocuments = false,
                        ViewCancelledProductsUrl = null,
                        Actions =
                        [
                            new ApiResponse.Action
                            {
                                Index = 0,
                                Label = "View and manage product",
                                ActionIcon = null,
                                Property = "canViewProductDetails",
                                Destination = new Uri("https://example.com.au")
                            },

                            new ApiResponse.Action
                            {
                                Index = 1,
                                Label = "Manage direct debit",
                                ActionIcon = null,
                                Property = "canManageDirectDebit",
                                Destination = new Uri("https://example.com.au")
                            },

                            new ApiResponse.Action
                            {
                                Index = 5,
                                Label = "Update address",
                                ActionIcon = null,
                                Property = "canEditAddress",
                                Destination = new Uri("https://example.com.au")
                            }
                        ]
                    }
                ],
                TradesJobList = []
            },
            
        };
    }
}
