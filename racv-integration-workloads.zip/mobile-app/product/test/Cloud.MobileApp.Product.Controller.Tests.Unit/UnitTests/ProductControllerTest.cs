﻿using Cloud.MobileApp.Product.Api.Controllers;
using Cloud.MobileApp.Product.Connector.Service.Interfaces;
using Cloud.MobileApp.Product.Controller.Tests.Unit.Infrastructure;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using ApiResponse = Cloud.MobileApp.Product.Api.Models.Response;

namespace Cloud.MobileApp.Product.Controller.Tests.Unit.UnitTests;

/// <summary>
///     This class contains unit tests for the <see cref="ProductController" />.
/// </summary>
public class ProductControllerTest
{
    private const string Authorization = "Bearer valid_token";
    private readonly Mock<IConfiguration> _mockConfiguration;
    private readonly Mock<ILogger<ProductController>> _mockLogger;
    private readonly Mock<IProductDetailsService> _mockproductDetailsService;
    private readonly ProductController _productController;
    private readonly Guid _xCorrelationIdentifier;

    /// <summary>
    ///     Initializes a new instance of the DetailsControllerTest class.
    /// </summary>
    public ProductControllerTest()
    {
        _mockLogger = LoggerHelper.GetLogger<ProductController>();
        _mockproductDetailsService = new Mock<IProductDetailsService>();
        _mockConfiguration = new Mock<IConfiguration>();

        // Setup _mockConfiguration to return some value
        _mockConfiguration.Setup(c => c.GetSection(It.IsAny<string>()))
            .Returns(new Mock<IConfigurationSection>().Object);

        _productController = new ProductController(_mockLogger.Object, _mockproductDetailsService.Object,
            _mockConfiguration.Object);
        _xCorrelationIdentifier = Guid.NewGuid();

        _mockproductDetailsService
            .Setup(service => service.GetProductDetails(_xCorrelationIdentifier, Authorization))
            .ReturnsAsync(TestDataHelper.GetExpectedServiceResponse());
    }

    /// <summary>
    ///     Test case for GetAsync method in DetailsController.
    ///     This test verifies that the GetAsync method returns the expected result when called with valid parameters.
    /// </summary>
    [Fact]
    public async Task ProductController_GetProductDetails_ShouldPass()
    {
        // Arrange

        // Act
        var result = await _productController.GetAsync(_xCorrelationIdentifier, Authorization);

        // Assert
        result.Should().NotBeNull();

        var okResult = result.Result as OkObjectResult;
        okResult.Should().NotBeNull();
        okResult.Should().BeOfType<OkObjectResult>();
        okResult?.StatusCode.Should().Be(StatusCodes.Status200OK);

        var returnValue = okResult?.Value as ApiResponse.ProductResponse;
        returnValue.Should().NotBeNull();
        returnValue.Should().BeOfType<ApiResponse.ProductResponse>();
        returnValue.Should().BeEquivalentTo(TestDataHelper.GetExpectedApiResponse());

        _mockproductDetailsService.Verify(
            service => service.GetProductDetails(_xCorrelationIdentifier, Authorization),
            Times.Once);
    }
}
