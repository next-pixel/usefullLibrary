﻿using System.Globalization;
using ApiModels = Cloud.MobileApp.EV.Api.Models;
using ServiceModels = Cloud.MobileApp.EV.Common.Models.Service;

namespace Cloud.MobileApp.EV.Controller.Tests.Infrastructure;

public static class EVHelper
{
    /// <summary>
    /// Generates a mock service response for testing.
    /// </summary>
    /// <returns>A mock service response.</returns>
    public static ServiceModels.Response.ChargerLocationsResponse GetExpectedServiceResponse()
    {
        return new ServiceModels.Response.ChargerLocationsResponse
        {
            Message = "Operation successful",
            Data =
            [
                new ServiceModels.Response.ChargerLocation
                {
                    Id = new Guid("ff33abaf-1b31-4849-ab2c-d35d82b79cec"),
                    Name = "Mcdonald's Kellyville North",
                    Address = "133 Samantha Riley Dr",
                    OpeningTimes =
                        new ServiceModels.Response.OpeningTimes
                        {
                            TwentyFourSeven = false,
                            RegularHours =
                                new
                                    List<ServiceModels.Response.RegularHours>
                                    {
                                        new() { Weekday = 1, PeriodBegin = "07:00", PeriodEnd = "23:00" },
                                        new() { Weekday = 2, PeriodBegin = "07:00", PeriodEnd = "23:00" },
                                        new() { Weekday = 3, PeriodBegin = "07:00", PeriodEnd = "23:00" },
                                        new() { Weekday = 4, PeriodBegin = "07:00", PeriodEnd = "23:00" },
                                        new() { Weekday = 5, PeriodBegin = "07:00", PeriodEnd = "23:00" },
                                        new() { Weekday = 6, PeriodBegin = "07:00", PeriodEnd = "23:00" },
                                        new() { Weekday = 7, PeriodBegin = "07:00", PeriodEnd = "23:00" }
                                    }
                        },
                    City = "Kellyville",
                    Postcode = "2155",
                    State = "NSW",
                    Location =
                        new ServiceModels.Response.Coordinates
                        {
                            Latitude = -37.8136, Longitude = 144.9631
                        },
                    StationTimeZone = "Australia/Sydney",
                    Directions =
                        "Go east on Bell Street, and turn left up the narrow one-way laneway after Elm Grove. The charger is in the laneway to the east of the Coburg Civic Centre",
                    Operator =
                        new ServiceModels.Response.Operator
                        {
                            Name = "ChargeFox", Url = new Uri("https://www.chargefox.com")
                        },
                    Evses =
                    [
                        new ServiceModels.Response.Evse
                        {
                            Id = new Guid("f72ece86-a47e-46f2-8baf-011791388375"),
                            Name = "Station 1021 - A",
                            Status = "AVAILABLE",
                            Connectors =
                            [
                                new ServiceModels.Response.Connector
                                {
                                    Id = 1,
                                    Standard = "TYPE-1",
                                    Format =
                                        ServiceModels.Response.FormatTypes.Cable,
                                    MaxElectricPower = 22000,
                                    Price =
                                        new
                                            ServiceModels.Response.Price
                                            {
                                                Description =
                                                    "Free for the first hour, 20c/kWh for every additional hour.",
                                                Elements =
                                                [
                                                    new
                                                        ServiceModels.Response.Element
                                                        {
                                                            PriceComponents =
                                                            [
                                                                new
                                                                    ServiceModels.Response.PriceComponent
                                                                    {
                                                                        Type = "ENERGY",
                                                                        Price = 0.0,
                                                                        PricePerStepIncVat = 0.0,
                                                                        StepSize = 1,
                                                                        Vat = 10.0
                                                                    }
                                                            ],
                                                            Restrictions = new ServiceModels.Response.Restrictions
                                                                    {
                                                                        MaxDuration = 3780
                                                                    }
                                                        },
                                                    new
                                                        ServiceModels.Response.Element
                                                        {
                                                            PriceComponents =
                                                            [
                                                                new
                                                                    ServiceModels.Response.PriceComponent
                                                                    {
                                                                        Type = "ENERGY",
                                                                        Price = 0.18,
                                                                        PricePerStepIncVat = 0.18,
                                                                        StepSize = 1,
                                                                        Vat = 10.0
                                                                    }
                                                            ],
                                                            Restrictions =
                                                                new
                                                                    ServiceModels.Response.Restrictions
                                                                    {
                                                                        StartTime = "06:00",
                                                                        EndTime = "18:00",
                                                                        DayOfWeek = new List<string>
                                                                        {
                                                                            "MONDAY",
                                                                            "TUESDAY",
                                                                            "WEDNESDAY",
                                                                            "THURSDAY",
                                                                            "FRIDAY"
                                                                        }
                                                                    }
                                                        },
                                                    new
                                                        ServiceModels.Response.Element
                                                        {
                                                            PriceComponents =
                                                            [
                                                                new
                                                                    ServiceModels.Response.PriceComponent
                                                                    {
                                                                        Type = "ENERGY",
                                                                        Price = 0.09,
                                                                        PricePerStepIncVat = 0.09,
                                                                        StepSize = 1,
                                                                        Vat = 10.0
                                                                    }
                                                            ]
                                                        }
                                                ]
                                            }
                                }
                            ]
                        }
                    ],
                    DiscountValue = 5,
                    DiscountType = "percent",
                    LastUpdated = DateTimeOffset.Parse("2018-02-15T13:00:00Z",CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal)
                }
            ]
        };
    }

    /// <summary>
    /// Generates a mock api response for testing.
    /// </summary>
    /// <returns>A mock api response.</returns>
    public static ApiModels.Response.ChargerLocationsResponse GetExpectedApiResponse()
    {
        return new ApiModels.Response.ChargerLocationsResponse
        {
            Message = "Operation successful",
            Data =
            [
                new ApiModels.Response.ChargerLocation
                {
                    Id = new Guid("ff33abaf-1b31-4849-ab2c-d35d82b79cec"),
                    Name = "Mcdonald's Kellyville North",
                    Address = "133 Samantha Riley Dr",
                    OpeningTimes =
                        new ApiModels.Response.OpeningTimes
                        {
                            TwentyFourSeven = false,
                            RegularHours =
                                new
                                    List<ApiModels.Response.RegularHours>
                                    {
                                        new() { Weekday = 1, PeriodBegin = "07:00", PeriodEnd = "23:00" },
                                        new() { Weekday = 2, PeriodBegin = "07:00", PeriodEnd = "23:00" },
                                        new() { Weekday = 3, PeriodBegin = "07:00", PeriodEnd = "23:00" },
                                        new() { Weekday = 4, PeriodBegin = "07:00", PeriodEnd = "23:00" },
                                        new() { Weekday = 5, PeriodBegin = "07:00", PeriodEnd = "23:00" },
                                        new() { Weekday = 6, PeriodBegin = "07:00", PeriodEnd = "23:00" },
                                        new() { Weekday = 7, PeriodBegin = "07:00", PeriodEnd = "23:00" }
                                    }
                        },
                    City = "Kellyville",
                    Postcode = "2155",
                    State = "NSW",
                    Location =
                        new ApiModels.Response.Coordinates
                        {
                            Latitude = -37.8136, Longitude = 144.9631
                        },
                    Directions =
                        "Go east on Bell Street, and turn left up the narrow one-way laneway after Elm Grove. The charger is in the laneway to the east of the Coburg Civic Centre",
                    Operator =
                        new ApiModels.Response.Operator
                        {
                            Name = "ChargeFox", Url = new Uri("https://www.chargefox.com")
                        },
                    Evses =
                    [
                        new ApiModels.Response.Evse
                        {
                            Id = new Guid("f72ece86-a47e-46f2-8baf-011791388375"),
                            Name = "Station 1021 - A",
                            Status = "AVAILABLE",
                            Connector =
                                new ApiModels.Response.Connector
                                {
                                    Id = 1,
                                    Standard = "TYPE-1",
                                    Format = "Cable",
                                    MaxElectricPower = 22000,
                                    PriceRange =
                                        new ApiModels.Response.PriceRange
                                        {
                                            From = 0, To = 0.18
                                        },
                                    PriceDescription = "Free for the first hour, 20c/kWh for every additional hour."
                                }
                        }
                    ],
                    DiscountValue = 5,
                    DiscountType = "percent",
                    LastUpdated = DateTimeOffset.Parse("2018-02-15T13:00:00Z",CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal)
                }
            ]
        };
    }
}
