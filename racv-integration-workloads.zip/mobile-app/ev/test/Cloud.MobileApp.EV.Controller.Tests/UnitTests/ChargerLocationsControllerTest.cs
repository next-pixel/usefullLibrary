﻿using Cloud.MobileApp.EV.Api.Controllers;
using Cloud.MobileApp.EV.Connector.Service.Interfaces;
using Cloud.MobileApp.EV.Controller.Tests.Infrastructure;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;
using ApiChargerLocationResponse = Cloud.MobileApp.EV.Api.Models.Response.ChargerLocationsResponse;

namespace Cloud.MobileApp.EV.Controller.Tests.UnitTests
{
    /// <summary>
    /// This class contains unit tests for the <see cref="ChargerLocationsController" />.
    /// </summary>
    public class ChargerLocationsControllerTest
    {
        private const string Authorization = "Bearer valid_token";
        private readonly ChargerLocationsController _chargerLocationsController;
        private readonly Mock<IEVChargerLocationsService> _mockEVChargerLocationsService;
        private readonly Mock<ILogger<ChargerLocationsController>> _mockLogger;
        private readonly Guid _xCorrelationIdentifier;

        /// <summary>
        /// Initializes a new instance of the ChargerLocationsControllerTest class.
        /// </summary>
        public ChargerLocationsControllerTest()
        {
            _mockLogger = LoggerHelper.GetLogger<ChargerLocationsController>();
            _mockEVChargerLocationsService = new Mock<IEVChargerLocationsService>();
            _chargerLocationsController =
                new ChargerLocationsController(_mockLogger.Object, _mockEVChargerLocationsService.Object);
            _xCorrelationIdentifier = Guid.NewGuid();

            _mockEVChargerLocationsService
                .Setup(service => service.GetChargerLocations(_xCorrelationIdentifier, Authorization, string.Empty))
                .ReturnsAsync(EVHelper.GetExpectedServiceResponse());
        }

        /// <summary>
        /// Test case for GetAsync method in ChargerLocationsController.
        /// This test verifies that the GetAsync method returns the expected result when called with valid parameters.
        /// </summary>
        [Fact]
        public async Task ChargerLocationsController_GetChargerLocations_ShouldPass()
        {
            // Arrange
            var expectedResponse = EVHelper.GetExpectedApiResponse();

            // Act
            var result = await _chargerLocationsController.GetAsync(_xCorrelationIdentifier, Authorization, string.Empty);

            // Assert
            result.Should().NotBeNull();

            var okResult = result.Result as OkObjectResult;
            okResult.Should().NotBeNull().And.BeOfType<OkObjectResult>();

            var returnValue = okResult?.Value as ApiChargerLocationResponse;
            returnValue.Should().NotBeNull().And.BeOfType<ApiChargerLocationResponse>().And
                .BeEquivalentTo(expectedResponse);

            _mockEVChargerLocationsService.Verify(
                service => service.GetChargerLocations(_xCorrelationIdentifier, Authorization, string.Empty),
                Times.Once);
        }
    }
}
