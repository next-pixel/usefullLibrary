namespace Cloud.MobileApp.EV.Common.Settings;

public class EVSettings
{
    public const string ConfigurationSectionName = "EVSettings";
    public string ServiceBaseAddress { get; set; } = "ServiceBaseAddress";
}
