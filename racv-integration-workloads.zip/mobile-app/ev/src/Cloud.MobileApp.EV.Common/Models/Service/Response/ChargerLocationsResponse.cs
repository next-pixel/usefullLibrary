using System.Text.Json.Serialization;

namespace Cloud.MobileApp.EV.Common.Models.Service.Response
{
    /// <summary>
    /// Response payload representing a charger location which has a collection of chargers and additional metadata
    /// </summary>
    public class ChargerLocationsResponse
    {
        [JsonPropertyName("message")]
        public string? Message { get; set; }

        [JsonPropertyName("data")]
        public List<ChargerLocation>? Data { get; set; }
    }

    /// <summary>
    /// Represents a charger location for electric vehicles
    /// </summary>
    public class ChargerLocation
    {
        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [JsonPropertyName("name")]
        public string? Name { get; set; }

        [JsonPropertyName("address")]
        public string? Address { get; set; }

        [JsonPropertyName("openingTimes")]
        public OpeningTimes? OpeningTimes { get; set; }

        [JsonPropertyName("city")]
        public string? City { get; set; }

        [JsonPropertyName("postcode")]
        public string? Postcode { get; set; }

        [JsonPropertyName("state")]
        public string? State { get; set; }

        [JsonPropertyName("location")]
        public Coordinates? Location { get; set; }

        [JsonPropertyName("stationTimeZone")]
        public string? StationTimeZone { get; set; }

        [JsonPropertyName("directions")]
        public string? Directions { get; set; }

        [JsonPropertyName("operator")]
        public Operator? Operator { get; set; }

        [JsonPropertyName("evses")]
        public List<Evse>? Evses { get; set; }

        [JsonPropertyName("discountValue")]
        public float? DiscountValue { get; set; }

        [JsonPropertyName("discountType")]
        public string? DiscountType { get; set; }

        [JsonPropertyName("lastUpdated")]
        public DateTimeOffset? LastUpdated { get; set; }
    }

    /// <summary>
    /// Represents the opening times, including regular hours and 24/7 status for a charger location
    /// </summary>
    public class OpeningTimes
    {
        [JsonPropertyName("twentyFourSeven")]
        public bool TwentyFourSeven { get; set; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        [JsonPropertyName("regularHours")]
        public List<RegularHours>? RegularHours { get; set; }
    }

    /// <summary>
    /// Represents the regular hours of operation for a specific weekday for a charger location
    /// </summary>
    public class RegularHours
    {
        [JsonPropertyName("weekday")]
        public int Weekday { get; set; }

        [JsonPropertyName("periodBegin")]
        public string? PeriodBegin { get; set; }

        [JsonPropertyName("periodEnd")]
        public string? PeriodEnd { get; set; }
    }

    /// <summary>
    /// Represents a geographical location with latitude and longitude
    /// </summary>
    public class Coordinates
    {
        [JsonPropertyName("latitude")]
        public double Latitude { get; set; }

        [JsonPropertyName("longitude")]
        public double Longitude { get; set; }
    }

    /// <summary>
    /// Represents the operator of a charger location
    /// </summary>
    public class Operator
    {
        [JsonPropertyName("name")]
        public string? Name { get; set; }

        [JsonPropertyName("url")]
        public Uri? Url { get; set; }
    }

    /// <summary>
    /// Represents an EVSE (Electric Vehicle Supply Equipment)
    /// </summary>
    public class Evse
    {
        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [JsonPropertyName("name")]
        public string? Name { get; set; }

        [JsonPropertyName("status")]
        public string? Status { get; set; }

        [JsonPropertyName("connectors")]
        public List<Connector>? Connectors { get; set; }
    }

    /// <summary>
    /// Represents the format type of a connector for an EVSE (Electric Vehicle Supply Equipment).
    /// </summary>
    public enum FormatTypes
    {
        Socket,
        Cable
    }

    /// <summary>
    /// Represents a connector of an EVSE
    /// </summary>
    public class Connector
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("standard")]
        public string? Standard { get; set; }

        [JsonConverter(typeof(JsonStringEnumConverter))]
        [JsonPropertyName("format")]
        public FormatTypes Format { get; set; }

        [JsonPropertyName("maxElectricPower")]
        public int MaxElectricPower { get; set; }

        [JsonPropertyName("price")]
        public Price? Price { get; set; }
    }

    /// <summary>
    /// Represents the price for a specific connector
    /// </summary>
    public class Price
    {
        [JsonPropertyName("description")]
        public string? Description { get; set; }

        [JsonPropertyName("elements")]
        public List<Element>? Elements { get; set; }
    }

    /// <summary>
    /// Represents an element in the Price for a specific connector
    /// </summary>
    public class Element
    {
        [JsonPropertyName("priceComponents")]
        public List<PriceComponent>? PriceComponents { get; set; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        [JsonPropertyName("restrictions")]
        public Restrictions? Restrictions { get; set; }
    }

    /// <summary>
    /// Represents a price component
    /// </summary>
    public class PriceComponent
    {
        [JsonPropertyName("type")]
        public string? Type { get; set; }

        [JsonPropertyName("price")]
        public double Price { get; set; }

        [JsonPropertyName("pricePerStep")]
        public double PricePerStep { get; set; }

        [JsonPropertyName("pricePerStepIncVat")]
        public double PricePerStepIncVat { get; set; }

        [JsonPropertyName("stepSize")]
        public int StepSize { get; set; }

        [JsonPropertyName("vat")]
        public double Vat { get; set; }
    }

    /// <summary>
    /// Represents restrictions for a price element
    /// </summary>
    public class Restrictions
    {
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        [JsonPropertyName("maxDuration")]
        public int? MaxDuration { get; set; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        [JsonPropertyName("startTime")]
        public string? StartTime { get; set; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        [JsonPropertyName("endTime")]
        public string? EndTime { get; set; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        [JsonPropertyName("dayOfWeek")]
        public List<string>? DayOfWeek { get; set; }
    }
}
