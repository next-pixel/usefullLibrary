﻿namespace Cloud.MobileApp.EV.Common.Constants;

/// <summary>
/// Constants to be used across all projects and workloads related to EV.
/// </summary>
public static class InternalConstants
{
    public const string ServiceHttpClient = "ServiceClient";
}
