using System.Runtime.Serialization;
using System.Text.Json;
using Cloud.MobileApp.Common.Constants;
using Cloud.MobileApp.Common.Utility.Wrapper.Interfaces;
using Cloud.MobileApp.EV.Common.Constants;
using Cloud.MobileApp.EV.Connector.Service.Interfaces;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using ServiceChargerLocationsResponse = Cloud.MobileApp.EV.Common.Models.Service.Response.ChargerLocationsResponse;

namespace Cloud.MobileApp.EV.Connector.Service.Implementations;

/// <summary>
/// Implementation for retrieving EV charger locations from Microservice.
/// </summary>
public class EVChargerLocationsService : IEVChargerLocationsService
{
    private readonly IHttpWrapper<HttpRequestMessage, HttpResponseMessage> _httpWrapper;
    private readonly ILogger<EVChargerLocationsService> _logger;

    /// <summary>
    /// Initializes a new instance of the <see cref="EVChargerLocationsService" /> class.
    /// </summary>
    /// <param name="logger">The logger.</param>
    /// <param name="httpWrapper">The HTTP wrapper.</param>
    public EVChargerLocationsService(
        ILogger<EVChargerLocationsService> logger,
        IHttpWrapper<HttpRequestMessage, HttpResponseMessage> httpWrapper)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _httpWrapper = httpWrapper ?? throw new ArgumentNullException(nameof(httpWrapper));
    }

    /// <summary>
    /// Gets the charger locations based on the provided request.
    /// </summary>
    /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
    /// <param name="authorization">Bearer token</param>
    /// <returns>The charger locations response.</returns>
    public async Task<ServiceChargerLocationsResponse> GetChargerLocations(
        Guid xCorrelationIdentifier,
        string authorization,
        string? watermark)
    {
        if (xCorrelationIdentifier == Guid.Empty) throw new ArgumentException(null, nameof(xCorrelationIdentifier));
        ArgumentNullException.ThrowIfNull(authorization);

        HttpResponseMessage? response = null;
        try
        {
            var query = !watermark.IsNullOrEmpty() ? $"services/ev/v1/locations?watermark={watermark}" : $"services/ev/v1/locations";
            var request = new HttpRequestMessage(HttpMethod.Get, query);
            response = await _httpWrapper.SendAsync(
                request,
                InternalConstants.ServiceHttpClient,
                xCorrelationIdentifier,
                authorization);

            response.EnsureSuccessStatusCode();

            var responseJson = await response.Content.ReadAsStringAsync();

            return JsonSerializer.Deserialize<ServiceChargerLocationsResponse>(responseJson) ??
                   throw new SerializationException();
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Retrieving Charger Locations from Microservice failed with Status Code: {statusCode}",
                xCorrelationIdentifier,
                response?.StatusCode);

            throw;
        }
        catch (SerializationException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Deserialization of Charger Locations from Microservice failed with error: {message}",
                xCorrelationIdentifier, ex.Message);

            throw;
        }
    }
}
