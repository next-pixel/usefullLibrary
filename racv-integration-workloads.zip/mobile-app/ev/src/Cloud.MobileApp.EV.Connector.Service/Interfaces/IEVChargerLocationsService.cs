using Cloud.MobileApp.EV.Common.Models.Service.Response;

namespace Cloud.MobileApp.EV.Connector.Service.Interfaces;

/// <summary>
/// Interface for the implementation that handles retrieving EV charger locations from Microservice.
/// </summary>
public interface IEVChargerLocationsService
{
    /// <summary>
    /// Gets the charger locations based on the provided request.
    /// </summary>
    /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
    /// <param name="authorization">Bearer token</param>
    /// <returns>The charger locations response.</returns>
    Task<ChargerLocationsResponse> GetChargerLocations(
        Guid xCorrelationIdentifier, string authorization, string? watermark);
}
