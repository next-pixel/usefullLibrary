using System.Globalization;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Cloud.MobileApp.EV.Api.Models.Response
{
    /// <summary>
    /// Response payload representing a charger location which has a collection of chargers and additional metadata
    /// </summary>
    public class ChargerLocationsResponse
    {
        [JsonPropertyName("message")]
        public string? Message { get; set; }

        [JsonPropertyName("data")]
        public List<ChargerLocation>? Data { get; set; }
    }

    /// <summary>
    /// Represents a charger location for electric vehicles
    /// </summary>
    public class ChargerLocation
    {
        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [JsonPropertyName("name")]
        public string? Name { get; set; }

        [JsonPropertyName("address")]
        public string? Address { get; set; }

        [JsonPropertyName("openingTimes")]
        public OpeningTimes? OpeningTimes { get; set; }

        [JsonPropertyName("city")]
        public string? City { get; set; }

        [JsonPropertyName("postcode")]
        public string? Postcode { get; set; }

        [JsonPropertyName("state")]
        public string? State { get; set; }

        [JsonPropertyName("location")]
        public Coordinates? Location { get; set; }

        [JsonPropertyName("directions")]
        public string? Directions { get; set; }

        [JsonPropertyName("operator")]
        public Operator? Operator { get; set; }

        [JsonPropertyName("evses")]
        public List<Evse?>? Evses { get; set; }

        [JsonPropertyName("discountValue")]
        public float? DiscountValue { get; set; }

        [JsonPropertyName("discountType")]
        public string? DiscountType { get; set; }

        [JsonPropertyName("lastUpdated")]
        public DateTimeOffset? LastUpdated { get; set; }
    }

    /// <summary>
    /// Represents the opening times, including regular hours and 24/7 status for a charger location
    /// </summary>
    public class OpeningTimes
    {
        [JsonPropertyName("twentyFourSeven")]
        public bool TwentyFourSeven { get; set; }

        [JsonPropertyName("regularHours")]
        public List<RegularHours>? RegularHours { get; set; }
    }

    /// <summary>
    /// Represents the regular hours of operation for a specific weekday for a charger location
    /// </summary>
    public class RegularHours
    {
        [JsonPropertyName("weekday")]
        public int Weekday { get; set; }

        [JsonPropertyName("periodBegin")]
        public string? PeriodBegin { get; set; }

        [JsonPropertyName("periodEnd")]
        public string? PeriodEnd { get; set; }
    }

    /// <summary>
    /// Represents a geographical location with latitude and longitude
    /// </summary>
    public class Coordinates
    {
        [JsonPropertyName("latitude")]
        public double Latitude { get; set; }

        [JsonPropertyName("longitude")]
        public double Longitude { get; set; }
    }

    /// <summary>
    /// Represents the operator of a charger location
    /// </summary>
    public class Operator
    {
        [JsonPropertyName("name")]
        public string? Name { get; set; }

        [JsonPropertyName("url")]
        public Uri? Url { get; set; }
    }

    /// <summary>
    /// Represents an EVSE (Electric Vehicle Supply Equipment)
    /// </summary>
    public class Evse
    {
        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [JsonPropertyName("name")]
        public string? Name { get; set; }

        [JsonPropertyName("status")]
        public string? Status { get; set; }

        [JsonPropertyName("connector")]
        public Connector? Connector { get; set; }
    }

    /// <summary>
    /// Represents a connector of an EVSE
    /// </summary>
    public class Connector
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("standard")]
        public string? Standard { get; set; }

        [JsonPropertyName("format")]
        public string? Format { get; set; }

        [JsonPropertyName("maxElectricPower")]
        public int MaxElectricPower { get; set; }

        [JsonPropertyName("priceRange")]
        public PriceRange? PriceRange { get; set; }

        [JsonPropertyName("priceDescription")]
        public string? PriceDescription { get; set; }
    }

    /// <summary>
    /// Represents the price range for a specific connector
    /// </summary>
    public class PriceRange
    {
        [JsonPropertyName("from")]
        [JsonConverter(typeof(PriceConverter))]
        public double From { get; set; }

        [JsonPropertyName("to")]
        [JsonConverter(typeof(PriceConverter))]
        public double To { get; set; }
    }

    /// <summary>
    /// Converts a double value to a JSON string with two decimal places.
    /// </summary>
    public class PriceConverter : JsonConverter<double>
    {
        public override double Read(ref Utf8JsonReader reader, Type typeToConvert,
            JsonSerializerOptions options)
        {
            return reader.GetDouble();
        }

        public override void
            Write(Utf8JsonWriter writer, double value, JsonSerializerOptions options)
        {
            writer.WriteStringValue(value.ToString("F2", CultureInfo.InvariantCulture));
        }
    }
}