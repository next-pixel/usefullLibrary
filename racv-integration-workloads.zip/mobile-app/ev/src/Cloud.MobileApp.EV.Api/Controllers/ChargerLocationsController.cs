using Cloud.MobileApp.Common.Constants;
using Cloud.MobileApp.Common.Exceptions;
using Cloud.MobileApp.EV.Api.Extensions;
using Cloud.MobileApp.EV.Connector.Service.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ApiChargerLocationsResponse = Cloud.MobileApp.EV.Api.Models.Response.ChargerLocationsResponse;

namespace Cloud.MobileApp.EV.Api.Controllers;

/// <summary>
/// Controller for handling requests related to charger locations.
/// </summary>
[ApiController]
[Route("v1")]
public class ChargerLocationsController : ControllerBase
{
    private readonly IEVChargerLocationsService _evChargerLocationService;
    private readonly ILogger<ChargerLocationsController> _logger;

    /// <summary>
    /// Initializes a new instance of the <see cref="ChargerLocationsController" /> class.
    /// </summary>
    /// <param name="logger">The logger.</param>
    /// <param name="evChargerLocationService">The EV charger location service.</param>
    public ChargerLocationsController(ILogger<ChargerLocationsController> logger,
        IEVChargerLocationsService evChargerLocationService)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _evChargerLocationService = evChargerLocationService;
    }

    /// <summary>
    /// Gets the charger locations.
    /// </summary>
    /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
    /// <param name="authorization">JWT Bearer</param>
    /// <returns>The action result.</returns>
    [HttpGet("locations")]
    [Authorize]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Produces("application/json")]
    public async Task<ActionResult<ApiChargerLocationsResponse>> GetAsync(
        [FromHeader(Name = MobileAppConstants.CorrelationIdLogPropertyName)] Guid xCorrelationIdentifier,
        [FromHeader(Name = "Authorization")] string authorization,
        [FromQuery] string? watermark)
    {
        _logger.LogInformation(
            "CorrelationId : { "
            + MobileAppConstants.CorrelationIdLogPropertyName
            + "} Started executing Get Async Method.",
            xCorrelationIdentifier
        );

        try
        {
            var response =
                await _evChargerLocationService.GetChargerLocations(xCorrelationIdentifier, authorization, watermark);

            return Ok(response.Convert());
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Retrieving Charger Locations failed with error: {message}", xCorrelationIdentifier, ex.Message);

            return StatusCode(StatusCodes.Status500InternalServerError,
                new OperationFailureResponse(
                    "Error occurred while retriving charger locations.", null, xCorrelationIdentifier.ToString()));
        }
    }
}
