using ApiModels = Cloud.MobileApp.EV.Api.Models;
using ServiceModels = Cloud.MobileApp.EV.Common.Models.Service;

namespace Cloud.MobileApp.EV.Api.Extensions;

/// <summary>
/// Provides extension methods for converting ChargerLocationsResponse objects.
/// </summary>
public static class ChargerLocationsResponseExtensions
{
    /// <summary>
    /// Maps a Microservice Charger Locations Response to a Mobile API Charger Locations Response.
    /// </summary>
    /// <param name="serviceChargerLocationsResponse">The Microservice Charger Locations Response to map.</param>
    /// <returns>A Mobile Api Charger Locations Response with data from the provided Microservice charger location.</returns>
    public static ApiModels.Response.ChargerLocationsResponse? Convert(
        this ServiceModels.Response.ChargerLocationsResponse serviceChargerLocationsResponse
    )
    {
        if (serviceChargerLocationsResponse.Data != null)
        {
            return new ApiModels.Response.ChargerLocationsResponse
            {
                Message = serviceChargerLocationsResponse.Message,
                Data = serviceChargerLocationsResponse.Data.Select(chargingLocation => new ApiModels.Response.ChargerLocation
                {
                    Id = chargingLocation.Id,
                    Name = chargingLocation.Name,
                    Address = chargingLocation.Address,
                    OpeningTimes = chargingLocation.OpeningTimes?.MapOpeningTimes(),
                    City = chargingLocation.City,
                    Postcode = chargingLocation.Postcode,
                    State = chargingLocation.State,
                    Location = chargingLocation.Location?.MapLocation(),
                    Directions = chargingLocation.Directions,
                    Operator = chargingLocation.Operator?.MapOperator(),
                    Evses = chargingLocation.Evses?.Select(evse => evse.MapEvse(chargingLocation.StationTimeZone)).ToList(),
                    DiscountValue = chargingLocation.DiscountValue,
                    DiscountType = chargingLocation.DiscountType,
                    LastUpdated = chargingLocation.LastUpdated,
                }).ToList()
            };
        }

        return null;
    }

    /// <summary>
    /// Maps Microservice opening times to the Mobile API's OpeningTimesObj model.
    /// </summary>
    /// <param name="msOpeningTimes">The Microservice opening times to map.</param>
    /// <returns>An OpeningTimesObj with data from the provided Microservice opening times.</returns>
    private static ApiModels.Response.OpeningTimes MapOpeningTimes(
        this ServiceModels.Response.OpeningTimes msOpeningTimes)
    {
        return new ApiModels.Response.OpeningTimes
        {
            TwentyFourSeven = msOpeningTimes.TwentyFourSeven,
            RegularHours = msOpeningTimes.RegularHours?.Select(regularHour => new ApiModels.Response.RegularHours
            {
                Weekday = regularHour.Weekday,
                PeriodBegin = regularHour.PeriodBegin,
                PeriodEnd = regularHour.PeriodEnd
            }).OrderBy(rh => rh.Weekday).ToList()
        };
    }

    /// <summary>
    /// Maps Microservice coordinates to the Mobile API's LocationObj model.
    /// </summary>
    /// <param name="msCoordinates">The Microservice coordinates to map.</param>
    /// <returns>A LocationObj with data from the provided Microservice coordinates.</returns>
    private static ApiModels.Response.Coordinates MapLocation(
        this ServiceModels.Response.Coordinates msCoordinates)
    {
        return new ApiModels.Response.Coordinates
        {
            Latitude = msCoordinates.Latitude,
            Longitude = msCoordinates.Longitude
        };
    }

    /// <summary>
    /// Maps a Microservice operator to the Mobile API's OperatorObj model.
    /// </summary>
    /// <param name="msOperator">The Microservice operator to map.</param>
    /// <returns>An OperatorObj with data from the provided Microservice operator.</returns>
    private static ApiModels.Response.Operator MapOperator(
        this ServiceModels.Response.Operator msOperator)
    {
        return new ApiModels.Response.Operator
        {
            Name = msOperator.Name,
            Url = msOperator.Url // TODO: If configured otherwise pass configuration value (Mobile may want to add a configurable deep-link to the app)
        };
    }

    /// <summary>
    /// Maps a Microservice EVSE to the Mobile API's Evse model.
    /// </summary>
    /// <param name="msEvse">The Microservice EVSE to map.</param>
    /// <param name="msStationTimeZone">The time zone of the station.</param>
    /// <returns>An Evse with data from the provided Microservice EVSE.</returns>
    private static ApiModels.Response.Evse? MapEvse(
        this ServiceModels.Response.Evse msEvse,
        string? msStationTimeZone)
    {
        return new ApiModels.Response.Evse
        {
            Id = msEvse.Id,
            Name = msEvse.Name,
            Status = msEvse.Status,
            Connector = msEvse.Connectors?.FirstOrDefault()?.MapConnector(msStationTimeZone)
        };
    }

    /// <summary>
    /// Maps a Microservice Connector to the Mobile API's Connector model.
    /// </summary>
    /// <param name="msConnector">The Microservice Connector to map.</param>
    /// <param name="msStationTimeZone">The time zone of the station.</param>
    /// <returns>A ConnectorObj with data from the provided Microservice Connector.</returns>
    private static ApiModels.Response.Connector? MapConnector(
        this ServiceModels.Response.Connector msConnector, string? msStationTimeZone)
    {
        return new ApiModels.Response.Connector
        {
            Id = msConnector.Id,
            Standard = msConnector.Standard,
            Format = msConnector.Format.ToString(),
            MaxElectricPower = msConnector.MaxElectricPower,
            PriceDescription = msConnector.Price?.Description,
            PriceRange = CalculatePriceRange(msConnector, msStationTimeZone)
        };
    }

    /// <summary>
    /// Calculates the price range for a given connector.
    /// </summary>
    /// <param name="msConnector">The Microservice Connector to calculate the price range for.</param>
    /// <param name="msStationTimeZone">The time zone of the station.</param>
    /// <returns>A PriceRangeObj with the calculated price range.</returns>
    private static ApiModels.Response.PriceRange? CalculatePriceRange(ServiceModels.Response.Connector msConnector, string? msStationTimeZone)
    {
        if (!string.IsNullOrWhiteSpace(msStationTimeZone))
        {
            // Call ConvertLocalDateTimeToStationTimeZone to get the current date and time in the station's time zone
            var stationDateTimeOffset = ConvertLocalDateTimeToStationTimeZone(msStationTimeZone!);

            if (stationDateTimeOffset.HasValue)
            {
                // Extract the day of the week from the stationDateTimeOffset
                var currentDayOfWeek = stationDateTimeOffset.Value.DayOfWeek.ToString();

                // Extract the current time in 24 hour format
                var currentTime = stationDateTimeOffset.Value.ToString("HH:mm");

                // Filter the elements based on the following rules
                // 1. If there are no restrictions
                // 2. If there are restrictions, but the current day of the week is not in the list
                // 3. If there are restrictions, the current day of the week is within the list and the current time is within the start and end time
                if (msConnector.Price?.Elements != null)
                {
                    var priceFrom = 0.00;
                    var priceTo = 0.00;

                    var filteredElements = msConnector.Price?.Elements
                        .Where(element => element.Restrictions?.DayOfWeek == null
                            || !element.Restrictions.DayOfWeek.Contains(currentDayOfWeek)
                            || (string.CompareOrdinal(currentTime, element.Restrictions.StartTime) >= 0 && string.CompareOrdinal(currentTime, element.Restrictions.EndTime) <= 0))
                        .Where(element => element.PriceComponents != null)
                        .OrderBy(element => element.PriceComponents?.FirstOrDefault() != null ? element.PriceComponents.FirstOrDefault()?.PricePerStepIncVat : priceFrom)
                        .ToList();

                    // Calculate the price range from and to
                    // If there are no elements, return a default price range
                    if (filteredElements?.Count > 0)
                    {
                        var firstElementPriceComponents = filteredElements[0].PriceComponents;
                        if (firstElementPriceComponents?.Count > 0)
                        {
                            priceFrom = firstElementPriceComponents[0].PricePerStepIncVat;
                        }

                        var lastElementPriceComponents = filteredElements[^1].PriceComponents;
                        if (lastElementPriceComponents?.Count > 0)
                        {
                            priceTo = lastElementPriceComponents[0].PricePerStepIncVat;
                        }
                    }

                    return new ApiModels.Response.PriceRange
                    {
                        From = priceFrom,
                        To = priceTo
                    };
                }
            }
        }

        return null;
    }

    /// <summary>
    /// Converts the current local date and time to the station's time zone.
    /// </summary>
    /// <param name="msStationTimeZone">The time zone of the station.</param>
    /// <returns>A DateTimeOffset representing the current date and time in the station's time zone.</returns>
    private static DateTimeOffset? ConvertLocalDateTimeToStationTimeZone(string msStationTimeZone)
    {
        TimeZoneInfo stationTimeZone;
        try
        {
            // Find the time zone of msChargerLocation.StationTimeZone
            stationTimeZone = TimeZoneInfo.FindSystemTimeZoneById(msStationTimeZone);
        }
        catch (TimeZoneNotFoundException)
        {
            return null;
        }

        // Convert the current local date time to the time zone of msChargerLocation.StationTimeZone
        var stationDateTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, stationTimeZone);

        // Convert DateTime to DateTimeOffset
        DateTimeOffset stationDateTimeOffset = new(stationDateTime,
            stationTimeZone.GetUtcOffset(stationDateTime)
        );

        return stationDateTimeOffset;
    }
}
