using Cloud.MobileApp.Fuel.Api.Controllers;
using Cloud.MobileApp.Fuel.Connector.Service.Interfaces;
using Cloud.MobileApp.Fuel.Controller.Tests.Infrastructure;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using ServiceResponse = Cloud.MobileApp.Fuel.Api.Models.Response;

namespace Cloud.MobileApp.Fuel.Controller.Tests.UnitTests;

/// <summary>
///     This class contains unit tests for the <see cref="StationLocationsController" />.
/// </summary>
public class StationLocationsControllerTest
{
    private const string Authorization = "Bearer valid_token";
    private const string Watermark = "1714914440";
    private readonly Mock<IConfiguration> _mockConfiguration;
    private readonly Mock<IFuelStationLocationsService> _mockFuelStationLocationsService;
    private readonly Mock<ILogger<StationLocationsController>> _mockLogger;
    private readonly StationLocationsController _stationLocationsController;
    private readonly Guid _xCorrelationIdentifier;

    /// <summary>
    ///     Initializes a new instance of the StationLocationsControllerTest class.
    /// </summary>
    public StationLocationsControllerTest()
    {
        _mockLogger = LoggerHelper.GetLogger<StationLocationsController>();
        _mockFuelStationLocationsService = new Mock<IFuelStationLocationsService>();
        _mockConfiguration = new Mock<IConfiguration>();

        // Setup _mockConfiguration to return some value
        _mockConfiguration.Setup(c => c.GetSection(It.IsAny<string>()))
            .Returns(new Mock<IConfigurationSection>().Object);

        _stationLocationsController =
            new StationLocationsController(_mockLogger.Object, _mockFuelStationLocationsService.Object,
                _mockConfiguration.Object);
        _xCorrelationIdentifier = Guid.NewGuid();

        _mockFuelStationLocationsService
            .Setup(service => service.GetFuelLocations(_xCorrelationIdentifier, Authorization, Watermark))
            .ReturnsAsync(TestDataHelper.GetExpectedServiceResponse);
    }

    /// <summary>
    ///     Test case for GetAsync method in StationLocationsController.
    ///     This test verifies that the GetAsync method returns the expected result when called with valid parameters.
    /// </summary>
    [Fact]
    public async Task StationLocationsController_GetFuelStationLocations_ShouldPass()
    {
        // Arrange

        // Act
        var result = await _stationLocationsController.GetAsync(_xCorrelationIdentifier, Authorization, Watermark);

        // Assert
        result.Should().NotBeNull();

        var okResult = result.Result as OkObjectResult;
        okResult.Should().NotBeNull();
        okResult.Should().BeOfType<OkObjectResult>();
        okResult?.StatusCode.Should().Be(StatusCodes.Status200OK);

        var returnValue = okResult?.Value as ServiceResponse.StationLocationsResponse;
        returnValue.Should().NotBeNull();
        returnValue.Should().BeOfType<ServiceResponse.StationLocationsResponse>();
        returnValue.Should().BeEquivalentTo(TestDataHelper.GetExpectedApiResponse());

        _mockFuelStationLocationsService.Verify(
            service => service.GetFuelLocations(_xCorrelationIdentifier, Authorization, Watermark),
            Times.Once);
    }
}
