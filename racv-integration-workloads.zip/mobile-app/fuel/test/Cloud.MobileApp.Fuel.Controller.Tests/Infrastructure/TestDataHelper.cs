using System.Globalization;
using ApiResponse = Cloud.MobileApp.Fuel.Api.Models.Response;
using ServiceResponse = Cloud.MobileApp.Fuel.Common.Models.Service.Response;

namespace Cloud.MobileApp.Fuel.Controller.Tests.Infrastructure;

public static class TestDataHelper
{
    /// <summary>
    ///     Generates a mock service response for testing.
    /// </summary>
    /// <returns>A mock service response.</returns>
    public static ServiceResponse.StationLocationsResponse GetExpectedServiceResponse()
    {
        return new ServiceResponse.StationLocationsResponse
        {
            Message = "Operation successful.",
            Data = new ServiceResponse.Location
            {
                StationDetails =
                [
                    new ServiceResponse.StationDetail
                    {
                        Address = "1 Example Valley Highway",
                        BrandId = "20",
                        Latitude = -37.254435,
                        Longitude = 145.798177,
                        Name = "Example Valley Service Station",
                        Deleted = false,
                        PostCode = "3712",
                        LastChangedAt = 1714913439,
                        Version = 1,
                        CreatedAt = DateTime.Parse("2024-05-05T12:50:39.754818Z", CultureInfo.InvariantCulture),
                        UpdatedAt = DateTime.Parse("2024-05-05T12:50:39.754818Z", CultureInfo.InvariantCulture),
                        OpeningHours = "Trading Hours",
                        LastUpdated = DateTime.Parse("2023-03-08T02:23:01.913", CultureInfo.InvariantCulture),
                        Id = "ISS-61291528",
                        Facilities =
                        [
                            "Shop On Site",
                            "Gas Bottles",
                            "Car Wash on Site",
                            "Car Wash types - Rollover (automatic)",
                            "Coin Operated Vacuum"
                        ],
                        DiscountValue = 4,
                        Discount = "ENABLED"
                    }
                ],
                StationPrices =
                [
                    new ServiceResponse.StationPrice
                    {
                        TransactionDateUtc = null,
                        Deleted = false,
                        LastChangedAt = 1714854018,
                        Version = 92,
                        CreatedAt = DateTime.Parse("2024-05-04T20:20:18.839426Z", CultureInfo.InvariantCulture),
                        Id = "ISS-61301403",
                        UpdatedAt = DateTime.Parse("2024-05-04T20:20:18.839426Z", CultureInfo.InvariantCulture),
                        Fuels =
                        [
                            new ServiceResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups = ["Unleaded 91", "e10"],
                                FuelId = 2,
                                Name = "Unleaded",
                                Price = 1987,
                                TransactionDateUtc = null,
                                Band = null
                            },
                            new ServiceResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups = ["Diesel", "Premium Diesel"],
                                FuelId = 3,
                                Name = "Diesel",
                                Price = 1887,
                                TransactionDateUtc = null,
                                Band = null
                            },
                            new ServiceResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups = ["LPG"],
                                FuelId = 4,
                                Name = "LPG",
                                Price = 837,
                                TransactionDateUtc = null,
                                Band = null
                            },
                            new ServiceResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups = ["e10"],
                                FuelId = 12,
                                Name = "e10",
                                Price = 1967,
                                TransactionDateUtc = null,
                                Band = null
                            },
                            new ServiceResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups = ["Unleaded 91", "e10"],
                                FuelId = 999,
                                Name = "e10/Unleaded",
                                Price = 1967,
                                TransactionDateUtc = null,
                                Band = null
                            },
                            new ServiceResponse.Fuel
                            {
                                CollectionMethod = "M",
                                FuelGroups = ["Diesel", "Premium Diesel"],
                                FuelId = 1000,
                                Name = "Diesel/Premium Diesel",
                                Price = 1887,
                                TransactionDateUtc = null,
                                Band = null
                            }
                        ]
                    }
                ],
                Brands =
                [
                    new ServiceResponse.Brand
                    {
                        Deleted = false,
                        LastChangedAt = 1713315040,
                        Version = 1,
                        CreatedAt = DateTime.Parse("2024-04-17T00:50:40.830522Z", CultureInfo.InvariantCulture),
                        Id = "2459022",
                        Logo =
                            new Uri(
                                "https://arevo.example/fuel/icons/example-fuel-brand.png"),
                        Name = "Example Fuel Brand",
                        UpdatedAt = DateTime.Parse("2024-04-17T00:50:40.830522Z", CultureInfo.InvariantCulture)
                    }
                ]
            }
        };
    }

    /// <summary>
    ///     Generates a mock api response for testing.
    /// </summary>
    /// <returns>A mock api response.</returns>
    public static ApiResponse.StationLocationsResponse GetExpectedApiResponse()
    {
        return new ApiResponse.StationLocationsResponse
        {
            Message = "Operation successful.",
            Data = new ApiResponse.Location
            {
                StationDetails =
                [
                    new ApiResponse.StationDetail
                    {
                        Address = "1 Example Valley Highway",
                        BrandId = "20",
                        Latitude = -37.254435,
                        Longitude = 145.798177,
                        Name = "Example Valley Service Station",
                        Deleted = false,
                        PostCode = "3712",
                        OpeningHours = "7am - 7pm",
                        LastUpdated =
                            DateTime.Parse("2023-03-08T02:23:01.913", CultureInfo.InvariantCulture),
                        StationId = "ISS-61291528",
                        Facilities =
                        [
                            "Shop On Site",
                            "Gas Bottles",
                            "Car Wash on Site",
                            "Car Wash types - Rollover (automatic)",
                            "Coin Operated Vacuum"
                        ],
                        DiscountValue = 4,
                        Discount = "ENABLED"
                    }
                ],
                StationPrices =
                [
                    new ApiResponse.StationPrice
                    {
                        Deleted = false,
                        StationId = "ISS-61301403",
                        UpdatedAt = DateTime.Parse("2024-05-04T20:20:18.839426Z", CultureInfo.InvariantCulture),
                        Fuels =
                        [
                            new ApiResponse.Fuel
                            {
                                CollectionMethod = "M", FuelId = 2, Name = "Unleaded", Price = 1987
                            },

                            new ApiResponse.Fuel { CollectionMethod = "M", FuelId = 3, Name = "Diesel", Price = 1887 },

                            new ApiResponse.Fuel { CollectionMethod = "M", FuelId = 4, Name = "LPG", Price = 837 },

                            new ApiResponse.Fuel { CollectionMethod = "M", FuelId = 12, Name = "e10", Price = 1967 },

                            new ApiResponse.Fuel
                            {
                                CollectionMethod = "M", FuelId = 999, Name = "e10/Unleaded", Price = 1967
                            },

                            new ApiResponse.Fuel
                            {
                                CollectionMethod = "M", FuelId = 1000, Name = "Diesel/Premium Diesel", Price = 1887
                            }
                        ]
                    }
                ],
                Brands =
                [
                    new ApiResponse.Brand
                    {
                        Deleted = false,
                        BrandId = "2459022",
                        Logo =
                            new Uri(
                                "https://arevo.example/fuel/icons/example-fuel-brand.png"),
                        Name = "Example Fuel Brand"
                    }
                ]
            }
        };
    }
}
