using System.Runtime.Serialization;
using System.Text.Json;
using Cloud.MobileApp.Common.Constants;
using Cloud.MobileApp.Common.Utility.Wrapper.Interfaces;
using Cloud.MobileApp.Fuel.Common.Constants;
using Cloud.MobileApp.Fuel.Common.Models.Service.Response;
using Cloud.MobileApp.Fuel.Connector.Service.Interfaces;
using Microsoft.Extensions.Logging;

namespace Cloud.MobileApp.Fuel.Connector.Service.Implementations;

public class FuelStationLocationsService : IFuelStationLocationsService
{
    private readonly IHttpWrapper<HttpRequestMessage, HttpResponseMessage> _httpWrapper;
    private readonly ILogger<FuelStationLocationsService> _logger;

    /// <summary>
    ///     Initializes a new instance of the <see cref="FuelStationLocationsService" /> class.
    /// </summary>
    /// <param name="logger">The logger.</param>
    /// <param name="httpWrapper">The HTTP wrapper.</param>
    public FuelStationLocationsService(ILogger<FuelStationLocationsService> logger,
        IHttpWrapper<HttpRequestMessage, HttpResponseMessage> httpWrapper)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _httpWrapper = httpWrapper ?? throw new ArgumentNullException(nameof(httpWrapper));
    }

    /// <summary>
    ///     Gets fuel station locations based on the provided watermark.
    /// </summary>
    /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
    /// ///
    /// <param name="authorization">Bearer token</param>
    /// <param name="watermark">Last successful run epoch timestamp</param>
    /// <returns>The fuel station locations response.</returns>
    public async Task<StationLocationsResponse> GetFuelLocations(Guid xCorrelationIdentifier, string authorization
        , string watermark)
    {
        HttpResponseMessage? response = null;

        try
        {
            var request = new HttpRequestMessage(HttpMethod.Get, $"services/fuel/v1/locations?watermark={watermark}");
            response = await _httpWrapper.SendAsync(
                request,
                InternalConstants.ServiceHttpClient,
                xCorrelationIdentifier,
                authorization);

            response.EnsureSuccessStatusCode();

            var responseJson = await response.Content.ReadAsStringAsync();

            return JsonSerializer.Deserialize<StationLocationsResponse>(responseJson) ??
                   throw new SerializationException();
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Retrieving Fuel Station Locations from Microservice failed with Status Code: {statusCode}",
                xCorrelationIdentifier,
                response?.StatusCode);

            throw new HttpRequestException(
                $"Retrieving Fuel Station Locations from Microservice failed with Status Code: {response?.StatusCode}",
                ex);
        }
        catch (SerializationException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Deserialization of Fuel Station Locations from Microservice failed with error: {message}",
                xCorrelationIdentifier, ex.Message);

            throw new SerializationException(
                $"Deserialization of Fuel Station Locations from Microservice failed with error: {ex.Message}", ex);
        }
    }
}
