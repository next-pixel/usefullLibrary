using Cloud.MobileApp.Fuel.Common.Models.Service.Response;

namespace Cloud.MobileApp.Fuel.Connector.Service.Interfaces;

public interface IFuelStationLocationsService
{
    Task<StationLocationsResponse> GetFuelLocations(Guid xCorrelationIdentifier, string authorization, string watermark);
}
