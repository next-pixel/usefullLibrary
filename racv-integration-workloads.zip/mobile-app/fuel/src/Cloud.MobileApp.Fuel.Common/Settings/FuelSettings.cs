namespace Cloud.MobileApp.Fuel.Common.Settings;

public class FuelSettings
{
    public const string ConfigurationSectionName = "FuelSettings";
    public string? ServiceBaseAddress { get; set; } = null;
    public string? FuelGroups { get; set; } = null;
}
