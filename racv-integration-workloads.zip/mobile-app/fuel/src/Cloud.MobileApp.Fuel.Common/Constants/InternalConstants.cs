namespace Cloud.MobileApp.Fuel.Common.Constants;

/// <summary>
///     Constants to be used across all projects and workloads related to Account.
/// </summary>
public static class InternalConstants
{
    public const string ServiceHttpClient = "ServiceClient";
}
