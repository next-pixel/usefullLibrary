using Cloud.MobileApp.Common.Settings;
using Cloud.MobileApp.Common.Startup;
using Cloud.MobileApp.Common.Utility.Handlers.Interfaces;
using Cloud.MobileApp.Common.Utility.Wrapper.Implementation;
using Cloud.MobileApp.Common.Utility.Wrapper.Interfaces;
using Cloud.MobileApp.Fuel.Common.Constants;
using Cloud.MobileApp.Fuel.Common.Settings;
using Cloud.MobileApp.Fuel.Connector.Service.Implementations;
using Cloud.MobileApp.Fuel.Connector.Service.Interfaces;
using System.Net;

namespace Cloud.MobileApp.Fuel.Api;

internal class Program
{
    private Program()
    {
    }

    private static void Main(string[] args)
    {
        // Create the web application builder.
        var builder = WebApplication.CreateBuilder(args);

        // Add common services
        ConfigureServices(builder);

        // Build the app
        var app = builder.Build();

        // Configure app
        ApiBaseStartup.Configure(app, app.Environment, builder.Logging);

        // Map controllers
        app.MapControllers();

        // Configure the HTTP request pipeline.
        app.Run();
    }

    private static void ConfigureServices(WebApplicationBuilder builder)
    {
        // Add common services
        ApiBaseStartup.ConfigureServices<Program>(builder);

        // Retrieve the FuelSettings from the application configuration.
        var fuelSettings = new FuelSettings();
        builder.Configuration.Bind(FuelSettings.ConfigurationSectionName, fuelSettings);

        // Retrieve the ServiceSettings from the application configuration.
        var serviceSettings = new ServiceSettings();
        builder.Configuration.Bind(ServiceSettings.ConfigurationSectionName, serviceSettings);

        // Add HTTP Client
        builder.Services.AddHttpClient(InternalConstants.ServiceHttpClient,
            client =>
            {
                client.BaseAddress = new Uri(fuelSettings.ServiceBaseAddress ?? string.Empty);
                client.DefaultRequestHeaders.Add("subscription-key", serviceSettings.SubscriptionKey);
            })
            .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
            {
                AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate | DecompressionMethods.Brotli
            });

        // Add HttpWrapper
        builder.Services.AddSingleton<IHttpWrapper<HttpRequestMessage, HttpResponseMessage>, HttpWrapper>(
            provider =>
            {
                var httpClientFactory = provider.GetRequiredService<IHttpClientFactory>();
                var messageTrackerHandler =
                    provider.GetRequiredService<IMessageTrackerHandler<HttpRequestMessage, HttpResponseMessage>>();
                var wrapper = new HttpWrapper(httpClientFactory, messageTrackerHandler.LogRequestResponse);
                return wrapper;
            });

        // Add Microservice Connector
        builder.Services.AddTransient<IFuelStationLocationsService, FuelStationLocationsService>();
    }
}
