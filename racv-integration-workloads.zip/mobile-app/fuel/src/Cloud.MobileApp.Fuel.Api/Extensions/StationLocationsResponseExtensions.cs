using System.Text.Json;
using Cloud.MobileApp.Fuel.Common.Settings;
using ApiResponse = Cloud.MobileApp.Fuel.Api.Models.Response;
using ServiceResponse = Cloud.MobileApp.Fuel.Common.Models.Service.Response;

namespace Cloud.MobileApp.Fuel.Api.Extensions;

/// <summary>
///     Provides extension methods for converting service response objects to API response objects.
/// </summary>
public static class StationLocationsResponseExtensions
{
    private static List<ApiResponse.FuelGroup> FuelGroupsConfig = [];

    public static void SetFuelGroups(IConfiguration configuration)
    {
        // Retrieve the FuelSettings from the application configuration.
        var fuelSettings = new FuelSettings();
        configuration.Bind(FuelSettings.ConfigurationSectionName, fuelSettings);

        if (fuelSettings.FuelGroups != null)
        {
            FuelGroupsConfig = JsonSerializer.Deserialize<List<ApiResponse.FuelGroup>>(fuelSettings.FuelGroups) ?? [];
        }
    }

    /// <summary>
    ///     Converts a service response to an API response.
    /// </summary>
    /// <param name="msLocationsResponse">The service response to convert.</param>
    /// <returns>The converted API response.</returns>
    public static ApiResponse.StationLocationsResponse Convert(
        this ServiceResponse.StationLocationsResponse msLocationsResponse)
    {
        return new ApiResponse.StationLocationsResponse
        {
            Message = "Operation successful.", Data = msLocationsResponse.Data?.Convert()
        };
    }

    /// <summary>
    ///     Converts a service response location object to an API response location object.
    /// </summary>
    /// <param name="msLocation">The service response location object to convert.</param>
    /// <returns>The converted API response location object.</returns>
    private static ApiResponse.Location Convert(this ServiceResponse.Location msLocation)
    {
        return new ApiResponse.Location
        {
            StationDetails = msLocation.StationDetails.ConvertAll(sd => sd.Convert()),
            StationPrices = msLocation.StationPrices.ConvertAll(sp => sp.Convert()),
            Brands = msLocation.Brands.ConvertAll(b => b.Convert()),
            FuelGroups = FuelGroupsConfig
        };
    }

    /// <summary>
    ///     Converts a service response station detail object to an API response station detail object.
    /// </summary>
    /// <param name="msStationDetail">The service response station detail object to convert.</param>
    /// <returns>The converted API response station detail object.</returns>
    private static ApiResponse.StationDetail Convert(this ServiceResponse.StationDetail msStationDetail)
    {
        return new ApiResponse.StationDetail
        {
            Address = msStationDetail.Address,
            BrandId = msStationDetail.BrandId,
            Latitude = msStationDetail.Latitude,
            Longitude = msStationDetail.Longitude,
            Name = msStationDetail.Name,
            Deleted = msStationDetail.Deleted,
            PostCode = msStationDetail.PostCode,
            OpeningHours = string.Equals(msStationDetail.OpeningHours, "Trading Hours",
                StringComparison.OrdinalIgnoreCase)
                ? "7am - 7pm"
                : msStationDetail.OpeningHours,
            LastUpdated = msStationDetail.LastUpdated,
            StationId = msStationDetail.Id,
            Facilities = msStationDetail.Facilities,
            DiscountValue = msStationDetail.DiscountValue,
            Discount = msStationDetail.Discount
        };
    }

    /// <summary>
    ///     Converts a service response station price object to an API response station price object.
    /// </summary>
    /// <param name="msStationPrice">The service response station price object to convert.</param>
    /// <returns>The converted API response station price object.</returns>
    private static ApiResponse.StationPrice Convert(this ServiceResponse.StationPrice msStationPrice)
    {
        return new ApiResponse.StationPrice
        {
            Deleted = msStationPrice.Deleted,
            StationId = msStationPrice.Id,
            UpdatedAt = msStationPrice.UpdatedAt,
            Fuels = msStationPrice.Fuels.ConvertAll(f => f.Convert())
        };
    }

    /// <summary>
    ///     Converts a service response fuel object to an API response fuel object.
    /// </summary>
    /// <param name="msFuel">The service response fuel object to convert.</param>
    /// <returns>The converted API response fuel object.</returns>
    private static ApiResponse.Fuel Convert(this ServiceResponse.Fuel msFuel)
    {
        return new ApiResponse.Fuel
        {
            CollectionMethod = msFuel.CollectionMethod,
            FuelId = msFuel.FuelId,
            Name = msFuel.Name,
            Price = msFuel.Price
        };
    }

    /// <summary>
    ///     Converts a service response brand object to an API response brand object.
    /// </summary>
    /// <param name="msBrand">The service response brand object to convert.</param>
    /// <returns>The converted API response brand object.</returns>
    private static ApiResponse.Brand Convert(this ServiceResponse.Brand msBrand)
    {
        return new ApiResponse.Brand
        {
            Deleted = msBrand.Deleted, BrandId = msBrand.Id, Logo = msBrand.Logo, Name = msBrand.Name
        };
    }
}
