using System.Text.Json.Serialization;

namespace Cloud.MobileApp.Fuel.Api.Models.Response;

/// <summary>
///     Represents the response from the Fuel Station Locations Mobile API.
/// </summary>
public class StationLocationsResponse
{
    [JsonPropertyName("message")]
    public string? Message { get; set; }

    [JsonPropertyName("data")]
    public Location? Data { get; set; }
}

/// <summary>
///     Represents a petrol station, including details about the station, their prices, and associated brands.
/// </summary>
public class Location
{
    [JsonPropertyName("stationDetails")]
    public List<StationDetail> StationDetails { get; set; } = [];

    [JsonPropertyName("stationPrices")]
    public List<StationPrice> StationPrices { get; set; } = [];

    [JsonPropertyName("brands")]
    public List<Brand> Brands { get; set; } = [];

    [JsonPropertyName("fuelGroups")]
    public List<FuelGroup> FuelGroups { get; set; } = [];
}

/// <summary>
///     Represents the details of a station, including information such as the station's address, brand ID, geographical
///     coordinates, name, and more.
/// </summary>
public class StationDetail
{
    [JsonPropertyName("address")]
    public string? Address { get; set; }

    [JsonPropertyName("brandId")]
    public string? BrandId { get; set; }

    [JsonPropertyName("latitude")]
    public double? Latitude { get; set; }

    [JsonPropertyName("longitude")]
    public double? Longitude { get; set; }

    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("deleted")]
    public bool Deleted { get; set; }

    [JsonPropertyName("postCode")]
    public string? PostCode { get; set; }

    [JsonPropertyName("openingHours")]
    public string? OpeningHours { get; set; }

    [JsonPropertyName("lastUpdated")]
    public DateTime? LastUpdated { get; set; }

    [JsonPropertyName("stationId")]
    public string? StationId { get; set; }

    [JsonPropertyName("facilities")]
    public List<string> Facilities { get; set; } = [];

    [JsonPropertyName("discountValue")]
    public int? DiscountValue { get; set; }

    [JsonPropertyName("discount")]
    public string? Discount { get; set; }
}

/// <summary>
///     Represents the price information of a station, including information such as whether the station is deleted, the
///     station ID, the time it was last updated, and the fuels available.
/// </summary>
public class StationPrice
{
    [JsonPropertyName("deleted")]
    public bool Deleted { get; set; }

    [JsonPropertyName("stationId")]
    public string? StationId { get; set; }

    [JsonPropertyName("updatedAt")]
    public DateTime? UpdatedAt { get; set; }

    [JsonPropertyName("fuels")]
    public List<Fuel> Fuels { get; set; } = [];
}

/// <summary>
///     Represents a fuel type, including information such as the collection method, fuel groups, fuel ID, name, and price.
/// </summary>
public class Fuel
{
    [JsonPropertyName("collectionMethod")]
    public string? CollectionMethod { get; set; }

    [JsonPropertyName("fuelId")]
    public int? FuelId { get; set; }

    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("price")]
    public decimal? Price { get; set; }
}

/// <summary>
///     Represents a brand, including information such as whether the brand is deleted, the brand ID, the logo, and the
///     name.
/// </summary>
public class Brand
{
    [JsonPropertyName("deleted")]
    public bool Deleted { get; set; }

    [JsonPropertyName("brandId")]
    public string? BrandId { get; set; }

    [JsonPropertyName("logo")]
    public Uri? Logo { get; set; }

    [JsonPropertyName("name")]
    public string? Name { get; set; }
}

public class FuelGroup
{
    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("fuelTypes")]
    public List<int> FuelTypes { get; set; } = [];
}
