using Cloud.MobileApp.Common.Constants;
using Cloud.MobileApp.Common.Exceptions;
using Cloud.MobileApp.Fuel.Api.Extensions;
using Cloud.MobileApp.Fuel.Api.Models.Response;
using Cloud.MobileApp.Fuel.Connector.Service.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Cloud.MobileApp.Fuel.Api.Controllers;

/// <summary>
///     Controller for handling requests related to fuel station locations.
/// </summary>
[ApiController]
[Route("v1")]
public class StationLocationsController : ControllerBase
{
    private readonly IFuelStationLocationsService _fuelStationLocationsService;
    private readonly ILogger<StationLocationsController> _logger;

    /// <summary>
    ///     Initializes a new instance of the <see cref="StationLocationsController" /> class.
    /// </summary>
    /// <param name="logger">The logger.</param>
    /// <param name="fuelStationLocationsService">The Fuel Station Locations service.</param>
    /// <param name="configuration">The application configuration</param>
    public StationLocationsController(ILogger<StationLocationsController> logger,
        IFuelStationLocationsService fuelStationLocationsService, IConfiguration configuration)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _fuelStationLocationsService = fuelStationLocationsService;

        // Set FuelGroups in StationLocationsResponseExtensions
        StationLocationsResponseExtensions.SetFuelGroups(configuration);
    }

    /// <summary>
    ///     Gets the fuel station locations.
    /// </summary>
    /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
    /// <param name="authorization">JWT Bearer</param>
    /// <param name="watermark">Last successful run epoch timestamp</param>
    /// <returns>The action result.</returns>
    [HttpGet("locations")]
    [Authorize]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Produces("application/json")]
    public async Task<ActionResult<StationLocationsResponse>> GetAsync(
        [FromHeader(Name = MobileAppConstants.CorrelationIdLogPropertyName)]
        Guid xCorrelationIdentifier,
        [FromHeader(Name = "Authorization")] string authorization,
        [FromQuery(Name = "watermark")] string watermark
    )
    {
        _logger.LogInformation(
            "CorrelationId : { "
            + MobileAppConstants.CorrelationIdLogPropertyName
            + "} Started executing Get Async Method.",
            xCorrelationIdentifier
        );

        try
        {
            // Convert watermark to DateTime
            if (!long.TryParse(watermark, out var _watermark))
            {
                _logger.LogError("CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                                 "} Invalid watermark value. Watermark: {watermark}", xCorrelationIdentifier,
                    watermark);

                throw new ArgumentException("Invalid watermark value.", nameof(watermark));
            }

            // Check if watermark is in the future
            if (DateTime.UnixEpoch.AddSeconds(_watermark) > DateTime.UtcNow)
            {
                _logger.LogError("CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                                 "} Watermark cannot be greater than the current time. Watermark: {watermark}",
                    xCorrelationIdentifier, watermark);

                throw new ArgumentException("Watermark cannot be greater than the current time.", nameof(watermark));
            }

            var response =
                await _fuelStationLocationsService.GetFuelLocations(xCorrelationIdentifier, authorization, watermark);

            return Ok(response.Convert());
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Retrieving Fuel Station Locations failed with error: {message}", xCorrelationIdentifier, ex.Message);

            return StatusCode(StatusCodes.Status500InternalServerError,
                new OperationFailureResponse("Error occured while retrieving Fuel Station Locations.", null,
                    xCorrelationIdentifier.ToString()));
        }
    }
}
