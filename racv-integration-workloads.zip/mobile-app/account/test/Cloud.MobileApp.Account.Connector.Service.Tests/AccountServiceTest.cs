﻿using Cloud.MobileApp.Account.Connector.Service.Implementations;
using Moq;
using System.Net;
using System.Runtime.Serialization;
using Microsoft.Extensions.Logging;
using FluentAssertions;
using Moq.Protected;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using Cloud.MobileApp.Account.Common.Models.Service.Response;
using Azure;
using Cloud.MobileApp.Account.Common.Models.Service.Request;
using Cloud.MobileApp.Common.Tracking.Enumerations;
using Cloud.MobileApp.Common.Utility.Wrapper.Implementation;
using Cloud.MobileApp.Common.Utility.Wrapper.Interfaces;

namespace Cloud.MobileApp.Account.Connector.Service.Tests
{
    public class AccountServiceTest
    {
        private const string Authorization = "Bearer valid_token";
        private const string BaseAddress = "http://www.TestUrl.com";
        private readonly Mock<IHttpClientFactory> _httpClientFactoryMock;
        private readonly IHttpWrapper<HttpRequestMessage, HttpResponseMessage> _httpWrapper;
        private readonly Mock<ILogger<AccountService>> _loggerMock;

        public AccountServiceTest()
        {
            _httpClientFactoryMock = new Mock<IHttpClientFactory>();
            _httpWrapper = new HttpWrapper(_httpClientFactoryMock.Object, LogRequestResponse);
            _loggerMock = new Mock<ILogger<AccountService>>();
        }

        private async Task LogRequestResponse(HttpRequestMessage request, HttpResponseMessage response,
            Guid correlationIdentifier, OperationProtocols protocol)
        {
            await Task.CompletedTask;
        }

        [Fact]
        public async Task GetAccountDetailsAsync_ShouldReturnServiceDetailsResponse()
        {
            // Arrange
            var correlationId = Guid.NewGuid();
            var response = new DetailsResponse
            {
                Data = new()
                {
                    FirstName = "FirstName",
                    LastName = "LastName",
                    MembershipCardType = "MembershipCardType",
                    MembershipStatus = "MembershipStatus",
                    MemberNumber = "MemberNumber",
                    Name = "Name",
                    ContactId = "ContactId",
                    PersonBirthdate = "PersonBirthdate",
                    MemberStartDate = "MemberStartDate",
                    MembershipCardNumber = "MembershipCardNumber",
                    MembershipCardBarcode = "MembershipCardBarcode",
                    FuelVoucherNumber = "FuelVoucherNumber",
                    FuelVoucherBarcode = "FuelVoucherBarcode"
                }
            };
            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            var mockResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = JsonContent.Create(response)
            };

            mockHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.Is<HttpRequestMessage>(
                        m => m.Method == HttpMethod.Get &&
                             m.RequestUri == new Uri(BaseAddress + "/services/account/v1/details")),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(mockResponse);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri(BaseAddress);

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var accountService = new AccountService(_loggerMock.Object, _httpWrapper);

            // Act
            var result = await accountService.GetAccountDetailsAsync(correlationId, Authorization);

            // Assert
            result.Should().NotBeNull();
            result.Should().BeEquivalentTo(response);
            mockHandler.Protected().Verify<Task<HttpResponseMessage>>(
                "SendAsync",
                Times.Once(),
                ItExpr.Is<HttpRequestMessage>(
                    m => m.Method == HttpMethod.Get &&
                         m.RequestUri == new Uri(BaseAddress + "/services/account/v1/details")),
                ItExpr.IsAny<CancellationToken>());
        }

        [Fact]
        public async Task GetAccountDetailsAsync_ShouldThrowHttpRequestException_WhenHttpClientThrows()
        {
            // Arrange
            var correlationId = Guid.NewGuid();
            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            mockHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.Is<HttpRequestMessage>(
                        m => m.Method == HttpMethod.Get &&
                             m.RequestUri == new Uri(BaseAddress + "/services/account/v1/details")),
                    ItExpr.IsAny<CancellationToken>())
                .ThrowsAsync(new HttpRequestException());

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri(BaseAddress);

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);
            var accountService = new AccountService(_loggerMock.Object, _httpWrapper);

            // Act & Assert
            await Assert.ThrowsAsync<HttpRequestException>(() =>
                accountService.GetAccountDetailsAsync(correlationId, Authorization));
        }

        [Fact]
        public async Task GetAccountDetailsAsync_ShouldThrowSerializationException_WhenResponseJsonIsInvalid()
        {
            // Arrange
            var correlationId = Guid.NewGuid();
            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            mockHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.Is<HttpRequestMessage>(
                        m => m.Method == HttpMethod.Get &&
                             m.RequestUri == new Uri(BaseAddress + "/services/account/v1/details")),
                    ItExpr.IsAny<CancellationToken>())
                .ThrowsAsync(new SerializationException());

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri(BaseAddress);

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);
            var accountService = new AccountService(_loggerMock.Object, _httpWrapper);

            // Act & Assert
            await Assert.ThrowsAsync<SerializationException>(() =>
                accountService.GetAccountDetailsAsync(correlationId, Authorization));
        }

        [Fact]
        public async Task SubmitFeedbackAsync_ShouldPostFeedbackAndEnsureSuccessStatusCode()
        {
            // Arrange
            var correlationId = Guid.NewGuid();
            var authorization = "Bearer valid_token";
            var feedbackRequest = new Common.Models.Service.Request.FeedbackRequest
            {
                Description = "This is a description for the app.",
                Rating = 2
            };

            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            var mockResponse = new HttpResponseMessage { StatusCode = HttpStatusCode.OK };

            mockHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.Is<HttpRequestMessage>(
                        m => m.Method == HttpMethod.Post &&
                             m.RequestUri == new Uri(BaseAddress + "/services/account/v1/feedback")),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(mockResponse);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri(BaseAddress);

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);
            var accountService = new AccountService(_loggerMock.Object, _httpWrapper);

            // Act
            await accountService.SubmitFeedbackAsync(correlationId, authorization, feedbackRequest);

            // Assert
            mockHandler.Protected().Verify<Task<HttpResponseMessage>>(
                "SendAsync",
                Times.Once(),
                ItExpr.Is<HttpRequestMessage>(
                    m => m.Method == HttpMethod.Post &&
                         m.RequestUri == new Uri(BaseAddress + "/services/account/v1/feedback")),
                ItExpr.IsAny<CancellationToken>());
        }

        [Fact]
        public async Task SubmitFeedbackAsync_ShouldThrowHttpRequestException_WhenHttpClientThrows()
        {
            // Arrange
            var correlationId = Guid.NewGuid();
            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            mockHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.Is<HttpRequestMessage>(
                        m => m.Method == HttpMethod.Post &&
                             m.RequestUri == new Uri(BaseAddress + "/services/account/v1/feedback")),
                    ItExpr.IsAny<CancellationToken>())
                .ThrowsAsync(new HttpRequestException());

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri(BaseAddress);

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);
            var accountService = new AccountService(_loggerMock.Object, _httpWrapper);

            // Act & Assert
            await Assert.ThrowsAsync<HttpRequestException>(() =>
                accountService.SubmitFeedbackAsync(correlationId, Authorization, new FeedbackRequest()));
        }
    }
}
