using System.Globalization;
using ApiResponse = Cloud.MobileApp.Account.Api.Models.Response;
using ServiceResponse = Cloud.MobileApp.Account.Common.Models.Service.Response;

namespace Cloud.MobileApp.Account.Api.Tests.Infrastructure;
public static class TestDataHelper
{
    /// <summary>
    ///     Generates a mock service response for testing.
    /// </summary>
    /// <returns>A mock service response.</returns>
    public static ServiceResponse.DetailsResponse GetExpectedServiceResponse()
    {
        return new ServiceResponse.DetailsResponse
        {
            Message = "Operation successful.",
            Data = new ServiceResponse.Details
            {
                PersonEmail = "johndoe@email.com",
                FirstName = "John",
                LastName = "Doe",
                MembershipCardType = null,
                MembershipStatus = null,
                MemberNumber = null,
                Name = "John Doe",
                ContactId = "123contactId123",
                PersonBirthdate = "1987-01-01",
                MemberStartDate = null,
                MembershipCardNumber = "1234567890123459",
                MembershipCardBarcode =
                    "iVBORw0KGgoAAAANSUhEUgAAAVcAAABICAYAAABCxrbiAAAABHNCSVQICAgIfAhkiAAAAVtJREFUeJzt1EEKgzAUQMG2h/D+5/MSdtWFAbEWH0WZ2SkxP6i857Isy+PCpmlaXc/zvLr/ud5aPz43rhv321t/dN/R0blH5x+d8+38vX333tfWvNG35737dxvX7b33s85z9j6//mdX8Pr3AQDuSFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgCBNzewaoylKOvhAAAAAElFTkSuQmCC",
                FuelVoucherNumber = "1234567890123450",
                FuelVoucherBarcode =
                    "iVBORw0KGgoAAAANSUhEUgAAAVcAAABICAYAAABCxrbiAAAABHNCSVQICAgIfAhkiAAAAVxJREFUeJzt1FEKgkAUQNFqEe5/fW7CvvpwQEaDSxjn/Bnje0PFfW7btj1ubFmW3fO6rrvPP89H58f3xnPjvNn5q3NHV/de3X91z9n9s7mz7+to3+jsfe/6u307f3x/dt+z+6v/47dz7+T16wsA/CNxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBN4zkGqMC63iZAAAAABJRU5ErkJggg=="
            }
        };
    }

    /// <summary>
    ///     Generates a mock api response for testing.
    /// </summary>
    /// <returns>A mock api response.</returns>
    public static ApiResponse.DetailsResponse GetExpectedApiResponse()
    {
        return new ApiResponse.DetailsResponse
        {
            Message = "Operation successful.",
            Data = new ApiResponse.Details
            {
                PersonEmail = "johndoe@email.com",
                FirstName = "John",
                LastName = "Doe",
                MembershipCardType = null,
                MembershipStatus = null,
                MemberNumber = null,
                Name = "John Doe",
                ContactId = "123contactId123",
                PersonBirthdate = "1987-01-01",
                MemberStartDate = null,
                MembershipCardNumber = "1234567890123459",
                MembershipCardBarcode =
                    "iVBORw0KGgoAAAANSUhEUgAAAVcAAABICAYAAABCxrbiAAAABHNCSVQICAgIfAhkiAAAAVtJREFUeJzt1EEKgzAUQMG2h/D+5/MSdtWFAbEWH0WZ2SkxP6i857Isy+PCpmlaXc/zvLr/ud5aPz43rhv321t/dN/R0blH5x+d8+38vX333tfWvNG35737dxvX7b33s85z9j6//mdX8Pr3AQDuSFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgABcQUIiCtAQFwBAuIKEBBXgIC4AgTEFSAgrgCBNzewaoylKOvhAAAAAElFTkSuQmCC",
                FuelVoucherNumber = "1234567890123450",
                FuelVoucherBarcode =
                    "iVBORw0KGgoAAAANSUhEUgAAAVcAAABICAYAAABCxrbiAAAABHNCSVQICAgIfAhkiAAAAVxJREFUeJzt1FEKgkAUQNFqEe5/fW7CvvpwQEaDSxjn/Bnje0PFfW7btj1ubFmW3fO6rrvPP89H58f3xnPjvNn5q3NHV/de3X91z9n9s7mz7+to3+jsfe/6u307f3x/dt+z+6v/47dz7+T16wsA/CNxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBMQVICCuAAFxBQiIK0BAXAEC4goQEFeAgLgCBN4zkGqMC63iZAAAAABJRU5ErkJggg=="
            }
        };
    }
}
