﻿using Cloud.MobileApp.Account.Api.Controllers;
using Cloud.MobileApp.Account.Connector.Service.Interfaces;
using Cloud.MobileApp.Account.Api.Tests.Infrastructure;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using ApiRequest = Cloud.MobileApp.Account.Api.Models.Request;
using SericeRequest = Cloud.MobileApp.Account.Common.Models.Service.Request;
using ApiResponse = Cloud.MobileApp.Account.Api.Models.Response;

namespace Cloud.MobileApp.Account.Api.Tests.UnitTests;

/// <summary>
///     This class contains unit tests for the <see cref="AccountController" />.
/// </summary>
public class AccountControllerTest
{
    private const string Authorization = "Bearer valid_token";
    private readonly AccountController _accountController;
    private readonly Mock<IAccountService> _mockAccountService;
    private readonly Mock<ILogger<AccountController>> _mockLogger;
    private readonly Guid _xCorrelationIdentifier;

    /// <summary>
    ///     Initializes a new instance of the AccountControllerTest class.
    /// </summary>
    public AccountControllerTest()
    {
        _mockLogger = LoggerHelper.GetLogger<AccountController>();
        _mockAccountService = new Mock<IAccountService>();
        _accountController = new AccountController(_mockLogger.Object, _mockAccountService.Object);
        _xCorrelationIdentifier = Guid.NewGuid();

        _mockAccountService
            .Setup(service => service.GetAccountDetailsAsync(_xCorrelationIdentifier, Authorization))
            .ReturnsAsync(TestDataHelper.GetExpectedServiceResponse());

        _mockAccountService
            .Setup(service => service.SubmitFeedbackAsync(
                _xCorrelationIdentifier,
                Authorization,
                It.Is<SericeRequest.FeedbackRequest>(
                    s => s.Description == "This is a error")
                )).Throws(new Exception());

        _mockAccountService
           .Setup(service => service.SubmitFeedbackAsync(
               _xCorrelationIdentifier,
               Authorization,
               It.Is<SericeRequest.FeedbackRequest>(
                   s => s.Description == "Love this app")
               ));
    }

    /// <summary>
    ///     Test case for GetAsync method in AccountController.
    ///     This test verifies that the GetAsync method returns the expected result when called with valid parameters.
    /// </summary>
    [Fact]
    public async Task AccountController_GetAccountDetails_ShouldPass()
    {
        // Arrange
        var expectedResponse = TestDataHelper.GetExpectedApiResponse();

        // Act
        var result = await _accountController.GetAccountDetailsAsync(_xCorrelationIdentifier, Authorization);

        // Assert
        result.Should().NotBeNull();

        var okResult = result.Result as OkObjectResult;
        okResult.Should().NotBeNull();
        okResult.Should().BeOfType<OkObjectResult>();
        okResult?.StatusCode.Should().Be(StatusCodes.Status200OK);

        var returnValue = okResult?.Value as ApiResponse.DetailsResponse;
        returnValue.Should().NotBeNull();
        returnValue.Should().BeOfType<ApiResponse.DetailsResponse>();
        returnValue.Should().BeEquivalentTo(expectedResponse);

        _mockAccountService.Verify(
            service => service.GetAccountDetailsAsync(_xCorrelationIdentifier, Authorization),
            Times.Once);
    }

    [Fact]
    public async Task AccountController_SubmitFeedbackAsync_ShouldReturnCreated()
    {
        // Arrange
        var requestFeedback = new ApiRequest.FeedbackRequest
        {
            Description = "Love this app",
            Rating = 3
        };

        // Act
        var result = await _accountController.SubmitAccountFeedbackAsync(_xCorrelationIdentifier, Authorization, requestFeedback);

        // Assert
        result.Should().NotBeNull();
        var returnValue = result as StatusCodeResult;
        returnValue?.StatusCode.Should().Be(StatusCodes.Status201Created);

        _mockAccountService.Verify(
            service => service.SubmitFeedbackAsync(
                _xCorrelationIdentifier,
                Authorization,
                It.IsAny<SericeRequest.FeedbackRequest>()),
            Times.Once);
    }

    [Fact]
    public async Task AccountController_SubmitFeedbackAsync_ShouldReturnInternalServerError()
    {
        // Arrange
        var requestFeedback = new ApiRequest.FeedbackRequest
        {
            Description = "This is a error",
            Rating = 3
        };

        // Act
        var result = await _accountController.SubmitAccountFeedbackAsync(_xCorrelationIdentifier, Authorization, requestFeedback);

        // Assert
        result.Should().NotBeNull();
        result.Should().BeOfType<ObjectResult>();

        var returnValue = result as ObjectResult;
        returnValue?.StatusCode.Should().Be(StatusCodes.Status500InternalServerError);

        _mockAccountService.Verify(
            service => service.SubmitFeedbackAsync(
                _xCorrelationIdentifier,
                Authorization,
                It.IsAny<SericeRequest.FeedbackRequest>()),
            Times.Once);
    }

    [Theory]
    [InlineData(null, 0)]
    [InlineData(null, 100)]
    public async Task AccountController_SubmitFeedbackAsync_ShouldReturnBadRequest(string? description, int rating)
    {
        // Arrange
        var xCorrelationIdentifier = Guid.NewGuid();
        var authorization = "Bearer valid_token";
        var requestFeedback = new ApiRequest.FeedbackRequest
        {
            Description = description,
            Rating = rating
        };

        // Act
        var result = await _accountController.SubmitAccountFeedbackAsync(xCorrelationIdentifier, authorization, requestFeedback);

        // Assert
        result.Should().NotBeNull();
        result.Should().BeOfType<BadRequestObjectResult>();

        _mockAccountService.Verify(
            service => service.SubmitFeedbackAsync(
                xCorrelationIdentifier,
                authorization,
                It.IsAny<SericeRequest.FeedbackRequest>()),
            Times.Never);
    }
}
