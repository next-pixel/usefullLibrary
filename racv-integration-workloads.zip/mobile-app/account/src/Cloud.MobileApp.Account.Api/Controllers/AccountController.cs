using Cloud.MobileApp.Account.Api.Extensions;
using Cloud.MobileApp.Account.Api.Models.Request;
using Cloud.MobileApp.Account.Connector.Service.Interfaces;
using Cloud.MobileApp.Common.Constants;
using Cloud.MobileApp.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ApiResponse = Cloud.MobileApp.Account.Api.Models.Response;

namespace Cloud.MobileApp.Account.Api.Controllers
{
    /// <summary>
    /// Controller for handling requests related to account details.
    /// </summary>
    [ApiController]
    [Route("v1")]
    public class AccountController : ControllerBase
    {
        private readonly IAccountService _accountService;
        private readonly ILogger<AccountController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="AccountController" /> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="accountService">The Account Details service.</param>
        public AccountController(ILogger<AccountController> logger,
            IAccountService accountService)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _accountService = accountService;
        }

        /// <summary>
        /// Gets the account details.
        /// </summary>
        /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
        /// <param name="authorization">JWT Bearer</param>
        /// <returns>The action result.</returns>
        [HttpGet("details")]
        [Authorize]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public async Task<ActionResult<ApiResponse.DetailsResponse>> GetAccountDetailsAsync(
            [FromHeader(Name = MobileAppConstants.CorrelationIdLogPropertyName)] Guid xCorrelationIdentifier,
            [FromHeader(Name = "Authorization")] string authorization)
        {
            _logger.LogInformation(
                "CorrelationId : { "
                + MobileAppConstants.CorrelationIdLogPropertyName
                + "} Started executing Get Async Method.",
                xCorrelationIdentifier);

            try
            {
                var response = await _accountService.GetAccountDetailsAsync(xCorrelationIdentifier, authorization);
                return Ok(response.Convert());
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex,
                    "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                    "} Retrieving Account Details failed with error: {message}",
                    xCorrelationIdentifier,
                    ex.Message);

                return StatusCode(ex.StatusCode != null ? (int)ex.StatusCode : StatusCodes.Status500InternalServerError,
                        new OperationFailureResponse("Error occurred while retrieving Account Details.", null, xCorrelationIdentifier.ToString()));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                    "} Retrieving Account Details failed with error: {message}",
                    xCorrelationIdentifier,
                    ex.Message);

                return StatusCode(StatusCodes.Status500InternalServerError,
                    new OperationFailureResponse("Error occurred while retrieving Account Details.", null, xCorrelationIdentifier.ToString()));
            }
        }

        /// <summary>
        /// Post the user feedback.
        /// </summary>
        /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
        /// <param name="authorization">JWT Bearer</param
        /// <param name="feedbackRequest">User feedback request body</param>
        /// <returns>The action result.</returns>
        [HttpPost("feedback")]
        [Authorize]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public async Task<ActionResult> SubmitAccountFeedbackAsync(
            [FromHeader(Name = MobileAppConstants.CorrelationIdLogPropertyName)] Guid xCorrelationIdentifier,
            [FromHeader(Name = "Authorization")] string authorization,
            [FromBody] FeedbackRequest feedbackRequest)
        {
            _logger.LogInformation(
                "CorrelationId : { "
                + MobileAppConstants.CorrelationIdLogPropertyName
                + "} Started executing Post Async Method.",
                xCorrelationIdentifier);

            try
            {
                // validate the request
                if (!feedbackRequest.IsRequestValid(out var operationFailureResponse))
                {
                    _logger.LogError(
                       "CorrelationId : {"
                       + MobileAppConstants.CorrelationIdLogPropertyName
                       + "} Submit feedback request is invalid.",
                       xCorrelationIdentifier);

                    return new BadRequestObjectResult(
                        new OperationFailureResponse(
                            "One or more validation errors occurred.",
                            operationFailureResponse,
                            xCorrelationIdentifier.ToString()));
                }

                var feedbackServiceRequest = feedbackRequest.Convert();
                await _accountService.SubmitFeedbackAsync(xCorrelationIdentifier, authorization, feedbackServiceRequest);
                return StatusCode(StatusCodes.Status201Created);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "CorrelationId : {"
                    + MobileAppConstants.CorrelationIdLogPropertyName
                    + "} Submitting user feedback failed with error: {message}",
                    xCorrelationIdentifier,
                    ex.Message);

                return StatusCode(StatusCodes.Status500InternalServerError,
                    new OperationFailureResponse(
                        "Error occurred while submitting user feedback", null, xCorrelationIdentifier.ToString()));
            }
        }
    }
}
