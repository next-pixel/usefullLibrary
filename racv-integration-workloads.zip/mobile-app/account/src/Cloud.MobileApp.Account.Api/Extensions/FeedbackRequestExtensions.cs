﻿using Cloud.MobileApp.Account.Api.Validators;
using Cloud.MobileApp.Common.Exceptions;
using System.Text;
using ApiRequest = Cloud.MobileApp.Account.Api.Models.Request;
using ServiceRequest = Cloud.MobileApp.Account.Common.Models.Service.Request;

namespace Cloud.MobileApp.Account.Api.Extensions
{
    public static class FeedbackRequestExtensions
    {
        public static bool IsRequestValid(
            this ApiRequest.FeedbackRequest feedbackRequest,
            out OperationFailureResponseDetail[]? failureResponseDetails)
        {
            failureResponseDetails = null;

            var result = new SubmitFeedbackValidator().Validate(feedbackRequest);

            if (!result.IsValid)
            {
                failureResponseDetails = result.Errors.Select(e =>
                {
                    return new OperationFailureResponseDetail
                    {
                        Message = e.ErrorMessage,
                        Entity = e.PropertyName
                    };
                }).ToArray();
            }
            return result.IsValid;
        }

        public static ServiceRequest.FeedbackRequest Convert(this ApiRequest.FeedbackRequest feedbackRequest)
        {
            return new ServiceRequest.FeedbackRequest
            {
                Description = feedbackRequest.Description?.RemoveSpecialCharacters(),
                Rating = feedbackRequest.Rating,
            };
        }
        public static string RemoveSpecialCharacters(this string str)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in str)
            {
                if ((c >= '0' && c <= '9') ||
                    (c >= 'A' && c <= 'Z') ||
                    (c >= 'a' && c <= 'z') ||
                    c == ' ' ||
                    c == ',' || c == '.' ||
                    c == '!' || c == '?')
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }
    }
}