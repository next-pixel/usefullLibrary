using ApiResponse = Cloud.MobileApp.Account.Api.Models.Response;
using ServiceResponse = Cloud.MobileApp.Account.Common.Models.Service.Response;

namespace Cloud.MobileApp.Account.Api.Extensions;

public static class DetailsResponseExtensions
{
    public static ApiResponse.DetailsResponse Convert(this ServiceResponse.DetailsResponse msDetailsResponse)
    {
        return new ApiResponse.DetailsResponse
        {
            Message = msDetailsResponse.Message,
            Data = msDetailsResponse.Data?.Convert()
        };
    }

    private static ApiResponse.Details? Convert(this ServiceResponse.Details? msDetails)
    {
        if (msDetails == null)
        {
            return null;
        }

        return new ApiResponse.Details
        {
            PersonEmail = msDetails.PersonEmail,
            FirstName = msDetails.FirstName,
            LastName = msDetails.LastName,
            MembershipCardType = msDetails.MembershipCardType,
            MembershipStatus = msDetails.MembershipStatus,
            MemberNumber = msDetails.MemberNumber,
            Name = msDetails.Name,
            ContactId = msDetails.ContactId,
            PersonBirthdate = msDetails.PersonBirthdate,
            MemberStartDate = msDetails.MemberStartDate,
            MembershipCardNumber = msDetails.MembershipCardNumber,
            MembershipCardBarcode = msDetails.MembershipCardBarcode,
            FuelVoucherNumber = msDetails.FuelVoucherNumber,
            FuelVoucherBarcode = msDetails.FuelVoucherBarcode
        };
    }
}
