using Cloud.MobileApp.Account.Common.Models.Service.Request;
using Cloud.MobileApp.Account.Common.Models.Service.Response;

namespace Cloud.MobileApp.Account.Connector.Service.Interfaces;

public interface IAccountService
{
    Task<DetailsResponse> GetAccountDetailsAsync(Guid xCorrelationIdentifier, string authorization);

    Task SubmitFeedbackAsync(Guid xCorrelationIdentifier, string authorization, FeedbackRequest feedbackRequest);
}
