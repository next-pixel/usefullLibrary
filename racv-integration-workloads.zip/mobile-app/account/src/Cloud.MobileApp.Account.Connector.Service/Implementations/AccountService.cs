using System.Net.Mime;
using System.Runtime.Serialization;
using System.Text;
using System.Text.Json;
using Cloud.MobileApp.Account.Common.Constants;
using Cloud.MobileApp.Account.Common.Models.Service.Request;
using Cloud.MobileApp.Account.Connector.Service.Interfaces;
using Cloud.MobileApp.Common.Constants;
using Cloud.MobileApp.Common.Utility.Wrapper.Interfaces;
using Microsoft.Extensions.Logging;
using ServiceDetailsResponse = Cloud.MobileApp.Account.Common.Models.Service.Response.DetailsResponse;

namespace Cloud.MobileApp.Account.Connector.Service.Implementations;

public class AccountService : IAccountService
{
    private readonly IHttpWrapper<HttpRequestMessage, HttpResponseMessage> _httpWrapper;
    private readonly ILogger<AccountService> _logger;

    /// <summary>
    ///     Initializes a new instance of the <see cref="AccountService" /> class.
    /// </summary>
    /// <param name="logger">The logger.</param>
    /// <param name="clientFactory">The HTTP wrapper.</param>
    public AccountService(ILogger<AccountService> logger,
        IHttpWrapper<HttpRequestMessage, HttpResponseMessage> httpWrapper)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _httpWrapper = httpWrapper ?? throw new ArgumentNullException(nameof(httpWrapper));
    }

    /// <summary>
    ///  Gets account details based on the provided Salesforce Account Id.
    /// </summary>
    /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
    /// <param name="authorization">Bearer token</param>
    /// <returns></returns>
    /// <exception cref="HttpRequestException"></exception>
    /// <exception cref="SerializationException"></exception>
    public async Task<ServiceDetailsResponse> GetAccountDetailsAsync(
        Guid xCorrelationIdentifier,
        string authorization)
    {
        HttpResponseMessage? response = null;

        try
        {
            var request = new HttpRequestMessage(HttpMethod.Get, "services/account/v1/details");
            response = await _httpWrapper.SendAsync(
                request,
                InternalConstants.AccountServiceHttpClient,
                xCorrelationIdentifier,
                authorization);

            response.EnsureSuccessStatusCode();

            var responseJson = await response.Content.ReadAsStringAsync();

            return JsonSerializer.Deserialize<ServiceDetailsResponse>(responseJson) ??
                   throw new SerializationException();
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Retrieving Account Details from Microservice failed with Status Code: {statusCode}",
                xCorrelationIdentifier,
                response?.StatusCode);

            throw new HttpRequestException(
                $"Retrieving Account Details from Microservice failed with Status Code: {response?.StatusCode}", ex, response?.StatusCode);
        }
        catch (SerializationException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Deserialization of Account Details from Microservice failed with error: {message}",
                xCorrelationIdentifier, ex.Message);

            throw new SerializationException(
                $"Deserialization of Account Details from Microservice failed with error: {ex.Message}", ex);
        }
    }

    /// <summary>
    /// Submits user feedback based on the provided Salesforce Account Id.
    /// </summary>
    /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
    /// <param name="authorization">Bearer token</param>
    /// <param name="feedbackRequest"> User feedback</param>
    /// <returns></returns>
    /// <exception cref="HttpRequestException"></exception>
    /// <exception cref="SerializationException"></exception>
    public async Task SubmitFeedbackAsync(
        Guid xCorrelationIdentifier,
        string authorization,
        FeedbackRequest feedbackRequest)
    {
        HttpResponseMessage? response = null;
        try
        {
            using StringContent feedbackRequestStringContent = new(
                JsonSerializer.Serialize(feedbackRequest),
                Encoding.UTF8,
                MediaTypeNames.Application.Json);

            var request = new HttpRequestMessage(HttpMethod.Post, "services/account/v1/feedback")
            {
                Content = feedbackRequestStringContent
            };
            response = await _httpWrapper.SendAsync(
                request,
                InternalConstants.AccountServiceHttpClient,
                xCorrelationIdentifier,
                authorization);

            response.EnsureSuccessStatusCode();
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Submitting user feedback from Microservice failed with Status Code: {statusCode}",
                xCorrelationIdentifier,
                response?.StatusCode);

            throw new HttpRequestException(
                $"Retrieving user feedback failed with Status Code: {response?.StatusCode}", ex);
        }
    }
}
