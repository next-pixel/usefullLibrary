namespace Cloud.MobileApp.Account.Common.Settings;

public class AccountSettings
{
    public const string ConfigurationSectionName = "AccountSettings";
    public string ServiceBaseAddress { get; set; } = string.Empty;
}
