﻿namespace Cloud.MobileApp.Account.Common.Models.Service.Request
{
    public class FeedbackRequest
    {
        public string? Description { get; set; }
        public int? Rating { get; set; }
    }
}
