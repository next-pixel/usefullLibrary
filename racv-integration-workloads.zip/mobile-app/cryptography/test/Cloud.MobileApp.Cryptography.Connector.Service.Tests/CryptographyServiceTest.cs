using System.Net;
using System.Net.Http.Json;
using System.Runtime.Serialization;
using Cloud.MobileApp.Common.Tracking.Enumerations;
using Cloud.MobileApp.Common.Utility.Wrapper.Implementation;
using Cloud.MobileApp.Common.Utility.Wrapper.Interfaces;
using Cloud.MobileApp.Cryptography.Common.Constants;
using Cloud.MobileApp.Cryptography.Common.Models.Service.Response;
using Cloud.MobileApp.Cryptography.Connector.Service.Implementations;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using ServiceResponse = Cloud.MobileApp.Cryptography.Common.Models.Service.Response;
using ServiceRequest = Cloud.MobileApp.Cryptography.Common.Models.Service.Request;

namespace Cloud.MobileApp.Cryptography.Connector.Service.Tests
{
    public class CryptographyServiceTest
    {
        private const string Authorization = "Bearer valid_token";
        private const string BaseAddress = "http://www.TestUrl.com";
        private readonly Mock<IHttpClientFactory> _httpClientFactoryMock;
        private readonly IHttpWrapper<HttpRequestMessage, HttpResponseMessage> _httpWrapper;
        private readonly Mock<ILogger<CryptographyService>> _loggerMock;

        public CryptographyServiceTest()
        {
            _httpClientFactoryMock = new Mock<IHttpClientFactory>();
            _httpWrapper = new HttpWrapper(_httpClientFactoryMock.Object, LogRequestResponse);
            _loggerMock = new Mock<ILogger<CryptographyService>>();
        }

        private static async Task LogRequestResponse(HttpRequestMessage request, HttpResponseMessage response,
            Guid correlationIdentifier, OperationProtocols protocol)
        {
            await Task.CompletedTask;
        }

        [Fact]
        public async Task PostNeatIdeasDetailsAsync_ShouldReturnServiceDetailsResponse()
        {
            // Arrange
            var correlationId = Guid.NewGuid();
            
            var response= new ServiceResponse.NeatIdeasResponse()
            {
                Message = InternalConstants.OperationSuccessful,
                Data = new NeatIdeasData
                {
                    AccessUrl = "www.exampleUrl.com/thisIsAMock"
                }
            };
            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            var mockResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = JsonContent.Create(response)
            };

            mockHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.Is<HttpRequestMessage>(
                        m => m.Method == HttpMethod.Post &&
                             m.RequestUri == new Uri(BaseAddress + "/services/cryptography/v1/neatideas-endpoint")),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(mockResponse);

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri(BaseAddress);

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);

            var cryptographyService = new CryptographyService(_loggerMock.Object, _httpWrapper);

            // Act
            var result = await cryptographyService.PostCryptographyDetailsAsync(correlationId, Authorization, GetExpectedServiceRequest());

            // Assert
            result.Should().NotBeNull();
            result.Should().BeEquivalentTo(response);
            mockHandler.Protected().Verify<Task<HttpResponseMessage>>(
                "SendAsync",
                Times.Once(),
                ItExpr.Is<HttpRequestMessage>(
                    m => m.Method == HttpMethod.Post &&
                         m.RequestUri == new Uri(BaseAddress + "/services/cryptography/v1/neatideas-endpoint")),
                ItExpr.IsAny<CancellationToken>());
        }

        [Fact]
        public async Task PostNeatIdeasDetailsAsync_ShouldThrowHttpRequestException_WhenHttpClientThrows()
        {
            // Arrange
            var correlationId = Guid.NewGuid();
            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            mockHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.Is<HttpRequestMessage>(
                        m => m.Method == HttpMethod.Post &&
                             m.RequestUri == new Uri(BaseAddress + "/services/cryptography/v1/neatideas-endpoint")),
                    ItExpr.IsAny<CancellationToken>())
                .ThrowsAsync(new HttpRequestException());

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri(BaseAddress);

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);
            var cryptographyService = new CryptographyService(_loggerMock.Object, _httpWrapper);

            // Act & Assert
            await Assert.ThrowsAsync<HttpRequestException>(() =>
                cryptographyService.PostCryptographyDetailsAsync(correlationId, Authorization, GetExpectedServiceRequest()));
        }

        [Fact]
        public async Task PostNeatIdeasDetailsAsync_ShouldThrowSerializationException_WhenResponseJsonIsInvalid()
        {
            // Arrange
            var correlationId = Guid.NewGuid();
            var mockHandler = new Mock<HttpMessageHandler>(MockBehavior.Loose);
            mockHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.Is<HttpRequestMessage>(
                        m => m.Method == HttpMethod.Post &&
                             m.RequestUri == new Uri(BaseAddress + "/services/cryptography/v1/neatideas-endpoint")),
                    ItExpr.IsAny<CancellationToken>())
                .ThrowsAsync(new SerializationException());

            var httpClient = new HttpClient(mockHandler.Object);
            httpClient.BaseAddress = new Uri(BaseAddress);

            _httpClientFactoryMock
                .Setup(ht => ht.CreateClient(It.IsAny<string>()))
                .Returns(httpClient);
            var cryptographyService = new CryptographyService(_loggerMock.Object, _httpWrapper);

            // Act & Assert
            await Assert.ThrowsAsync<SerializationException>(() =>
                cryptographyService.PostCryptographyDetailsAsync(correlationId, Authorization, GetExpectedServiceRequest()));
        }
        
        /// <summary>
        ///     Generates a mock service request for testing.
        /// </summary>
        /// <returns>A mock api response.</returns>
        private static ServiceRequest.NeatIdeasRequest GetExpectedServiceRequest()
        {
            return new ServiceRequest.NeatIdeasRequest()
            {
                LastName = "Appleseed",
                MemberNumber = "123456789"
            };
        }
    }
}
