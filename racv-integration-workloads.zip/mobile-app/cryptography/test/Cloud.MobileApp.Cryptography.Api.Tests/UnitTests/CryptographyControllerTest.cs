﻿using Cloud.MobileApp.Common.Exceptions;
using Cloud.MobileApp.Cryptography.Api.Controllers;
using Cloud.MobileApp.Cryptography.Api.Tests.Infrastructure;
using Cloud.MobileApp.Cryptography.Connector.Service.Interfaces;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ServiceRequest = Cloud.MobileApp.Cryptography.Common.Models.Service.Request;
using ServiceResponse = Cloud.MobileApp.Cryptography.Common.Models.Service.Response;
using ApiResponse = Cloud.MobileApp.Cryptography.Api.Models.Response;


namespace Cloud.MobileApp.Cryptography.Api.Tests.UnitTests;

/// <summary>
///     This class contains unit tests for the <see cref="CryptographyController" />.
/// </summary>
public class CryptographyControllerTest
{
    private const string Authorization = "Bearer valid_token";
    private readonly CryptographyController _cryptographyController;
    private readonly Mock<ICryptographyService> _mockCryptographyService;
    private readonly Guid _xCorrelationIdentifier;

    /// <summary>
    ///     Initializes a new instance of the CryptographyControllerTest class.
    /// </summary>
    public CryptographyControllerTest()
    {
        var mockLogger = LoggerHelper.GetLogger<CryptographyController>();
        _mockCryptographyService = new Mock<ICryptographyService>();
        _cryptographyController = new CryptographyController(mockLogger.Object, _mockCryptographyService.Object);
        _xCorrelationIdentifier = Guid.NewGuid();

        _mockCryptographyService
            .Setup(service => service.PostCryptographyDetailsAsync(_xCorrelationIdentifier, Authorization, It.IsAny<ServiceRequest.NeatIdeasRequest>()))
            .ReturnsAsync(TestDataHelper.GetExpectedServiceResponse());
    }

    /// <summary>
    ///     Test case for Post method in CryptographyController.
    ///     This test verifies that the Post method returns the expected result when called with valid parameters.
    /// </summary>
    [Fact]
    public async Task CryptographyController_PostCryptographyDetails_ShouldPass()
    {
        // Arrange
        var expectedResponse = TestDataHelper.GetExpectedApiResponse();

        // Act
        var result = await _cryptographyController.PostCryptographyDetailsAsync(_xCorrelationIdentifier, Authorization, TestDataHelper.GetExpectedApiRequest());

        // Assert
        result.Should().NotBeNull();

        var okResult = result.Result as OkObjectResult;
        okResult.Should().NotBeNull();
        okResult.Should().BeOfType<OkObjectResult>();
        okResult?.StatusCode.Should().Be(StatusCodes.Status200OK);

        var returnValue = okResult?.Value as ApiResponse.NeatIdeasResponse;
        returnValue.Should().NotBeNull();
        returnValue.Should().BeOfType<ApiResponse.NeatIdeasResponse>();
        returnValue.Should().BeEquivalentTo(expectedResponse);

        _mockCryptographyService.Verify(
            service => service.PostCryptographyDetailsAsync(_xCorrelationIdentifier, Authorization, It.IsAny<ServiceRequest.NeatIdeasRequest>()),
            Times.Once);
    }
    
    [Fact]
    public async Task CryptographyController_PostCryptographyDetails_BadRequestShouldFail()
    {
        // Arrange
        var failRequest = TestDataHelper.GetExpectedApiRequest();
        failRequest.MemberNumber = null;
        
        _mockCryptographyService
            .Setup(service => service.PostCryptographyDetailsAsync(
                _xCorrelationIdentifier,
                Authorization,
                It.Is<ServiceRequest.NeatIdeasRequest>(
                    s => s.MemberNumber == null)
            )).Throws(new Exception());

        // Act
        var result = await _cryptographyController.PostCryptographyDetailsAsync(_xCorrelationIdentifier, Authorization, failRequest);

        // Assert
        result.Should().NotBeNull();

        var badResult = result.Result as BadRequestObjectResult;
        badResult?.StatusCode.Should().Be(StatusCodes.Status400BadRequest);
        Assert.IsType<OperationFailureResponse>(badResult!.Value);
        var returnValue = badResult.Value as OperationFailureResponse;
        Assert.Equivalent(returnValue?.ErrorDetails?.FirstOrDefault()?.Message, "'Member Number' must not be empty.");
        _mockCryptographyService.Verify(
            service => service.PostCryptographyDetailsAsync(_xCorrelationIdentifier, Authorization, It.IsAny<ServiceRequest.NeatIdeasRequest>()),
            Times.Never);
    }
    
    [Fact]
    public async Task CryptographyController_PostCryptographyDetails_ShouldFail_ServiceError()
    {
        // Arrange
        _mockCryptographyService
            .Setup(service => service.PostCryptographyDetailsAsync(_xCorrelationIdentifier, Authorization, It.IsAny<ServiceRequest.NeatIdeasRequest>()))
            .ThrowsAsync(new Exception());

        // Act
        var result = await _cryptographyController.PostCryptographyDetailsAsync(_xCorrelationIdentifier, Authorization, TestDataHelper.GetExpectedApiRequest());

        // Assert
        result.Should().NotBeNull();

        var badResult = result.Result as ObjectResult;
        badResult?.StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
        Assert.IsType<OperationFailureResponse>(badResult!.Value);
        var returnValue = badResult.Value as OperationFailureResponse;
        Assert.Equivalent(returnValue?.ErrorDetails?.FirstOrDefault()?.Message, "Error occurred while creating Neat Ideas cryptographic details.");
        _mockCryptographyService.Verify(
            service => service.PostCryptographyDetailsAsync(_xCorrelationIdentifier, Authorization, It.IsAny<ServiceRequest.NeatIdeasRequest>()),
            Times.Once);
    }
    
    [Fact]
    public async Task CryptographyController_PostCryptographyDetails_ShouldFail_NullServiceResponse()
    {
        // Arrange
        _mockCryptographyService
            .Setup(service => service.PostCryptographyDetailsAsync(_xCorrelationIdentifier, Authorization,
                It.IsAny<ServiceRequest.NeatIdeasRequest>()))
            .ReturnsAsync(new ServiceResponse.NeatIdeasResponse());

        // Act
        var result = await _cryptographyController.PostCryptographyDetailsAsync(_xCorrelationIdentifier, Authorization, TestDataHelper.GetExpectedApiRequest());

        // Assert
        result.Should().NotBeNull();

        var badResult = result.Result as ObjectResult;
        badResult?.StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
        Assert.IsType<OperationFailureResponse>(badResult!.Value);
        var returnValue = badResult.Value as OperationFailureResponse;
        Assert.Equivalent(returnValue?.ErrorDetails?.FirstOrDefault()?.Message, "Error occurred while creating Neat Ideas cryptographic details.");
        _mockCryptographyService.Verify(
            service => service.PostCryptographyDetailsAsync(_xCorrelationIdentifier, Authorization, It.IsAny<ServiceRequest.NeatIdeasRequest>()),
            Times.Once);
    }
}
