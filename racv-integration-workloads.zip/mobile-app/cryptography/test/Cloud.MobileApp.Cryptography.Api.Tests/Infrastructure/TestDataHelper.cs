using ApiResponse = Cloud.MobileApp.Cryptography.Api.Models.Response;
using ServiceResponse = Cloud.MobileApp.Cryptography.Common.Models.Service.Response;
using ApiRequest = Cloud.MobileApp.Cryptography.Api.Models.Request;

namespace Cloud.MobileApp.Cryptography.Api.Tests.Infrastructure;
public static class TestDataHelper
{
    /// <summary>
    ///     Generates a mock service response for testing.
    /// </summary>
    /// <returns>A mock service response.</returns>
    public static ServiceResponse.NeatIdeasResponse GetExpectedServiceResponse()
    {
        return new ServiceResponse.NeatIdeasResponse()
        {
            Message = "Operation successful.",
            Data = new ServiceResponse.NeatIdeasData()
            {
                AccessUrl = "www.example.com/thisIsAMock"
            }
        };
    }

    /// <summary>
    ///     Generates a mock api response for testing.
    /// </summary>
    /// <returns>A mock api response.</returns>
    public static ApiResponse.NeatIdeasResponse GetExpectedApiResponse()
    {
        return new ApiResponse.NeatIdeasResponse
        {
            Message = "Operation successful.",
            Data = new ApiResponse.NeatIdeasData()
            {
                AccessUrl = "www.example.com/thisIsAMock"
            }
        };
    }
    
    /// <summary>
    ///     Generates a mock api request for testing.
    /// </summary>
    /// <returns>A mock api response.</returns>
    public static ApiRequest.NeatIdeasRequest GetExpectedApiRequest()
    {
        return new ApiRequest.NeatIdeasRequest()
        {
            LastName = "Appleseed",
            MemberNumber = "123456789"
        };
    }
}
