using System.Collections;

namespace Cloud.MobileApp.Cryptography.Api.Tests.Infrastructure;

public class NullAndWhitespaceData : IEnumerable<object[]>
{
    public IEnumerator<object[]> GetEnumerator()
    {
        return new List<object[]>
        {
            new object[1],
            new object[1] { "" },
            new object[1] { " " },
            new object[1] { "       " },
            new object[1] { "\n" },
            new object[1] { "\t" },
            new object[1] { Environment.NewLine }
        }.GetEnumerator();
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}