using Cloud.MobileApp.Cryptography.Api.Tests.Infrastructure;
using Cloud.MobileApp.Cryptography.Api.Validators;
using FluentAssertions;
using FluentValidation.TestHelper;
using ApiRequest = Cloud.MobileApp.Cryptography.Api.Models.Request;

namespace Cloud.MobileApp.Cryptography.Api.Tests.Validators
{
    public class NeatIdeasRequestValidatorTests
    {
        private readonly NeatIdeasRequestValidator _validator = new();

        [Fact]
        public void Validate_WithValidRequest_ShouldNotHaveValidationError()
        {
            // Arrange
            var request = new ApiRequest.NeatIdeasRequest()
            {
                LastName = "testLastname",
                MemberNumber = "12345"
            };

            // Act
            var result = _validator.TestValidate(request);

            // Assert
            result.IsValid.Should().BeTrue();
            result.ShouldNotHaveAnyValidationErrors();
        }

        [Theory]
        [ClassData(typeof(NullAndWhitespaceData))]
        public void Validate_WithInvalidLastName_ShouldHaveValidationError(string lastName)
        {
            // Arrange
            var request = new ApiRequest.NeatIdeasRequest()
            {
                LastName = lastName,
                MemberNumber = "12345"
            };

            // Act
            var result = _validator.TestValidate(request);
            
            // Assert
            result.IsValid.Should().BeFalse();
            result.ShouldHaveValidationErrorFor(x => x.LastName);
        }

        [Theory]
        [ClassData(typeof(NullAndWhitespaceData))]
        public void Validate_WithInvalidMemberNumber_ShouldHaveValidationError(string memberNumber)
        {
            // Arrange
            var request = new ApiRequest.NeatIdeasRequest()
            {
                LastName = "testLastname",
                MemberNumber = memberNumber
            };

            // Act
            var result = _validator.TestValidate(request);
            
            // Assert
            result.IsValid.Should().BeFalse();
            result.ShouldHaveValidationErrorFor(x => x.MemberNumber);
        }
    }
}