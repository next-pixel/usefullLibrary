using Cloud.MobileApp.Common.Constants;
using Cloud.MobileApp.Common.Exceptions;
using Cloud.MobileApp.Cryptography.Api.Extensions;
using Cloud.MobileApp.Cryptography.Api.Models.Request;
using Cloud.MobileApp.Cryptography.Connector.Service.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ApiResponse = Cloud.MobileApp.Cryptography.Api.Models.Response.NeatIdeasResponse;

namespace Cloud.MobileApp.Cryptography.Api.Controllers
{
    /// <summary>
    /// Controller for handling requests related to cryptography neat ideas details.
    /// </summary>
    [ApiController]
    [Route("v1")]
    public class CryptographyController : ControllerBase
    {
        private readonly ICryptographyService _cryptographyService;
        private readonly ILogger<CryptographyController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="CryptographyController" /> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="cryptographyService">The Cryptography Neat Ideas service.</param>
        public CryptographyController(ILogger<CryptographyController> logger,
            ICryptographyService cryptographyService)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _cryptographyService = cryptographyService ?? throw new ArgumentNullException(nameof(cryptographyService));
        }

        /// <summary>
        /// Creates the Neat Ideas cryptographic details.
        /// </summary>
        /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
        /// <param name="authorization">JWT Bearer</param>
        /// <param name="neatIdeasRequest"></param>
        /// <returns>The action result.</returns>
        [HttpPost("neatideas-endpoint")]
        [Authorize]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public async Task<ActionResult<ApiResponse>> PostCryptographyDetailsAsync(
            [FromHeader(Name = MobileAppConstants.CorrelationIdLogPropertyName)]
            Guid xCorrelationIdentifier,
            [FromHeader(Name = "Authorization")] string authorization,
            [FromBody] NeatIdeasRequest neatIdeasRequest)
        {
            _logger.LogInformation(
                "CorrelationId : { "
                + MobileAppConstants.CorrelationIdLogPropertyName
                + "} Started executing Post Async Method.",
                xCorrelationIdentifier);

            try
            {
                // validate the request
                if (!neatIdeasRequest.IsRequestValid(out var operationFailureResponse))
                {
                    _logger.LogError(
                        "CorrelationId : {"
                        + MobileAppConstants.CorrelationIdLogPropertyName
                        + "} Neat Ideas request is invalid.",
                        xCorrelationIdentifier);
        
                    return new BadRequestObjectResult(
                        new OperationFailureResponse(
                            "One or more validation errors occurred.",
                            operationFailureResponse,
                            xCorrelationIdentifier.ToString()));
                }
        
                var neatIdeasRequestServiceRequest = neatIdeasRequest.Convert();
                if (neatIdeasRequestServiceRequest is null)
                {
                    _logger.LogError(
                        "CorrelationId : {"
                        + MobileAppConstants.CorrelationIdLogPropertyName
                        + "} Neat Ideas request is invalid.",
                        xCorrelationIdentifier);
        
                    throw new InvalidOperationException(
                        "Failure to map the Neat Ideas request");
                }

                var response = await _cryptographyService.PostCryptographyDetailsAsync(xCorrelationIdentifier, authorization, neatIdeasRequestServiceRequest);
                if (response is { Message: not null, Data.AccessUrl: not null }) 
                    return Ok(response.Convert());
                
                _logger.LogError(
                    "CorrelationId : {"
                    + MobileAppConstants.CorrelationIdLogPropertyName
                    + "} Neat Ideas response is null.",
                    xCorrelationIdentifier);
        
                throw new InvalidOperationException(
                    "Failure to map the Neat Ideas response");

            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                    "} Creating Neat Ideas cryptographic details failed with error: {message}",
                    xCorrelationIdentifier,
                    ex.Message);

                return StatusCode(StatusCodes.Status500InternalServerError,
                    new OperationFailureResponse("Error occurred while creating Neat Ideas cryptographic details.",
                        null, xCorrelationIdentifier.ToString()));
            }
        }
    }
}
