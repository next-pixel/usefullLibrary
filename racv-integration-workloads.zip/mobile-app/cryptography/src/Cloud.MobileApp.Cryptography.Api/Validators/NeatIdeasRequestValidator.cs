using FluentValidation;
using ApiRequest = Cloud.MobileApp.Cryptography.Api.Models.Request;

namespace Cloud.MobileApp.Cryptography.Api.Validators;

public class NeatIdeasRequestValidator : AbstractValidator<ApiRequest.NeatIdeasRequest>
{
    public NeatIdeasRequestValidator()
    {
        RuleFor(x => x.LastName).NotEmpty();
        RuleFor(x => x.MemberNumber).NotEmpty();
    }
}