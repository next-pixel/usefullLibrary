using System.Text.Json.Serialization;

namespace Cloud.MobileApp.Cryptography.Api.Models.Response;

/// <summary>
///     Response payload from Mobile API representing Neat Ideas Cryptography details
/// </summary>
public class NeatIdeasResponse
{
    [JsonPropertyName("message")]
    public string? Message { get; set; }
    [JsonPropertyName("data")]
    public NeatIdeasData? Data { get; set; }
}

public class NeatIdeasData
{
    [JsonPropertyName("accessUrl")]
    public string? AccessUrl { get; set; }
}