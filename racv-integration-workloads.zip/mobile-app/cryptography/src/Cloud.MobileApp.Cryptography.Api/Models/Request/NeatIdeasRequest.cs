using System.Text.Json.Serialization;

namespace Cloud.MobileApp.Cryptography.Api.Models.Request;

/// <summary>
///     Request payload from Mobile API representing Neat Ideas details to be encrypted and hashed
/// </summary>
public class NeatIdeasRequest
{
    [JsonPropertyName("lastName")]
    public string? LastName { get; set; }

    [JsonPropertyName("memberNumber")]
    public string? MemberNumber { get; set; }
}