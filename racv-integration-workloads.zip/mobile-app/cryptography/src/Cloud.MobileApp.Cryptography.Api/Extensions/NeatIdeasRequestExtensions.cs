using Cloud.MobileApp.Common.Exceptions;
using Cloud.MobileApp.Cryptography.Api.Validators;
using ApiRequest = Cloud.MobileApp.Cryptography.Api.Models.Request;
using ServiceRequest = Cloud.MobileApp.Cryptography.Common.Models.Service.Request;

namespace Cloud.MobileApp.Cryptography.Api.Extensions;

public static class NeatIdeasRequestExtensions
{
    /// <summary>
    ///     Validates Member Details in Mobile API Neat Ideas Request.
    /// </summary>
    /// <param name="apiRequest"></param>
    /// <param name="failureResponseDetails"></param>
    /// <returns>Boolean if request is valid</returns>
    public static bool IsRequestValid(
        this ApiRequest.NeatIdeasRequest apiRequest,
        out OperationFailureResponseDetail[]? failureResponseDetails)
    {
        failureResponseDetails = null;

        var result = new NeatIdeasRequestValidator().Validate(apiRequest);

        if (!result.IsValid)
        {
            failureResponseDetails = result.Errors.Select(e => new OperationFailureResponseDetail
            {
                Message = e.ErrorMessage,
                Entity = e.PropertyName
            }).ToArray();
        }
        return result.IsValid;
    }
    
    /// <summary>
    ///     Converts Mobile API Neat Ideas request to Microservice NeatIdeas request.
    /// </summary>
    /// <param name="serviceRequest"></param>
    /// <returns>The Microservice Neat Ideas Request.</returns>
    public static ServiceRequest.NeatIdeasRequest? Convert(this ApiRequest.NeatIdeasRequest? serviceRequest)
    {
        if (serviceRequest is not null)
        {
            return new ServiceRequest.NeatIdeasRequest()
            {
                LastName = serviceRequest.LastName,
                MemberNumber = serviceRequest.MemberNumber
            
            };
        }

        return null;
    }
}