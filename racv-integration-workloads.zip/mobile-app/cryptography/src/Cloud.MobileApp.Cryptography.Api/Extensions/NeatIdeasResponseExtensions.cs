using Cloud.MobileApp.Cryptography.Api.Models.Response;
using ApiResponse = Cloud.MobileApp.Cryptography.Api.Models.Response;
using ServiceDetailsResponse = Cloud.MobileApp.Cryptography.Common.Models.Service.Response;

namespace Cloud.MobileApp.Cryptography.Api.Extensions;

public static class NeatIdeasResponseExtensions
{
    /// <summary>
    ///     Converts Microservice response to Mobile API response.
    /// </summary>
    /// <param name="serviceResponse"></param>
    /// <returns>The Mobile API Neat Ideas Response Details.</returns>
    public static ApiResponse.NeatIdeasResponse? Convert(this ServiceDetailsResponse.NeatIdeasResponse? serviceResponse)
    {
        if (serviceResponse?.Data != null)
        {
            return new ApiResponse.NeatIdeasResponse()
            {
                Message = serviceResponse.Message,
                Data = new NeatIdeasData
                {
                    AccessUrl = serviceResponse.Data.AccessUrl
                }
            };
        }
        return null;
    }
}