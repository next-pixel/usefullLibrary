namespace Cloud.MobileApp.Cryptography.Common.Settings;

public class CryptographySettings
{
    public const string ConfigurationSectionName = "CryptographySettings";
    public string ServiceBaseAddress { get; set; } = string.Empty;
}