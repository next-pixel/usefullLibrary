namespace Cloud.MobileApp.Cryptography.Common.Constants;

public static class InternalConstants
{
    public const string CryptographyServiceHttpClient = "CryptographyServiceClient";
    public const string OperationSuccessful = "OperationSuccessful.";
}