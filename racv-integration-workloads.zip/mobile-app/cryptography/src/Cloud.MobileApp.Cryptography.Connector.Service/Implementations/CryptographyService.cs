﻿using System.Net.Mime;
using System.Runtime.Serialization;
using System.Text;
using System.Text.Json;
using Cloud.MobileApp.Common.Constants;
using Cloud.MobileApp.Common.Utility.Wrapper.Interfaces;
using Cloud.MobileApp.Cryptography.Common.Constants;
using Cloud.MobileApp.Cryptography.Connector.Service.Interfaces;
using Microsoft.Extensions.Logging;
using ServiceDetailsRequest = Cloud.MobileApp.Cryptography.Common.Models.Service.Request.NeatIdeasRequest;
using ServiceDetailsResponse = Cloud.MobileApp.Cryptography.Common.Models.Service.Response.NeatIdeasResponse;

namespace Cloud.MobileApp.Cryptography.Connector.Service.Implementations;

public class CryptographyService : ICryptographyService
{
    private readonly IHttpWrapper<HttpRequestMessage, HttpResponseMessage> _httpWrapper;
    private readonly ILogger<CryptographyService> _logger;

    /// <summary>
    ///     Initializes a new instance of the <see cref="CryptographyService" /> class.
    /// </summary>
    /// <param name="logger">The logger.</param>
    /// <param name="httpWrapper"></param>
    public CryptographyService(ILogger<CryptographyService> logger,
        IHttpWrapper<HttpRequestMessage, HttpResponseMessage> httpWrapper)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _httpWrapper = httpWrapper ?? throw new ArgumentNullException(nameof(httpWrapper));
    }

    /// <summary>
    ///  Creates cryptography details based on the request.
    /// </summary>
    /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
    /// <param name="authorization">Bearer token</param>
    /// <param name="serviceRequest"></param>
    /// <returns></returns>
    /// <exception cref="HttpRequestException"></exception>
    /// <exception cref="SerializationException"></exception>
    public async Task<ServiceDetailsResponse> PostCryptographyDetailsAsync(
        Guid xCorrelationIdentifier,
        string authorization,
        ServiceDetailsRequest serviceRequest)
    {
        HttpResponseMessage? response = null;

        try
        {
            using StringContent serviceRequestStringContent = new(
                JsonSerializer.Serialize(serviceRequest),
                Encoding.UTF8,
                MediaTypeNames.Application.Json);

            var request = new HttpRequestMessage(HttpMethod.Post, "services/cryptography/v1/neatideas-endpoint")
            {
                Content = serviceRequestStringContent
            };
            
            response = await _httpWrapper.SendAsync(
                request,
                InternalConstants.CryptographyServiceHttpClient,
                xCorrelationIdentifier,
                authorization);

            response.EnsureSuccessStatusCode();

            var responseJson = await response.Content.ReadAsStringAsync();

            return JsonSerializer.Deserialize<ServiceDetailsResponse>(responseJson) ??
                    throw new SerializationException();
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Retrieving Cryptography Details from Microservice failed with Status Code: {statusCode}",
                xCorrelationIdentifier,
                response?.StatusCode);

            throw new HttpRequestException(
                $"Retrieving Cryptography Details from Microservice failed with Status Code: {response?.StatusCode}", ex);
        }
        catch (SerializationException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Deserialization of Cryptography Details from Microservice failed with error: {message}",
                xCorrelationIdentifier, ex.Message);

            throw new SerializationException(
                $"Deserialization of Cryptography Details from Microservice failed with error: {ex.Message}", ex);
        }
    }
}