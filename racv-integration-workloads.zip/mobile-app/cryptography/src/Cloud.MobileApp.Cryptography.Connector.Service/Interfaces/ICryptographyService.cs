using ServiceDetailsResponse = Cloud.MobileApp.Cryptography.Common.Models.Service.Response.NeatIdeasResponse;
using ServiceDetailsRequest = Cloud.MobileApp.Cryptography.Common.Models.Service.Request.NeatIdeasRequest;

namespace Cloud.MobileApp.Cryptography.Connector.Service.Interfaces;

public interface ICryptographyService
{
    Task<ServiceDetailsResponse> PostCryptographyDetailsAsync(
        Guid xCorrelationIdentifier,
        string authorization,
        ServiceDetailsRequest serviceRequest);
}