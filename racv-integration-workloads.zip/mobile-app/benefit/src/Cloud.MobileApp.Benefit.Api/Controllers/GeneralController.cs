using Cloud.MobileApp.Benefit.Api.Extensions;
using Cloud.MobileApp.Benefit.Connector.Service.Interfaces;
using Cloud.MobileApp.Common.Constants;
using Cloud.MobileApp.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ApiBenefitsResponse = Cloud.MobileApp.Benefit.Api.Models.Response.BenefitsResponse;

namespace Cloud.MobileApp.Benefit.Api.Controllers;

/// <summary>
///     Controller for handling requests related to general benefits.
/// </summary>
[ApiController]
[Route("v1")]
public class GeneralController : ControllerBase
{
    private readonly IGeneralBenefitsService _generalBenefitsService;
    private readonly ILogger<GeneralController> _logger;

    /// <summary>
    ///     Initializes a new instance of the <see cref="GeneralController" /> class.
    /// </summary>
    /// <param name="logger">The logger.</param>
    /// <param name="generalBenefitsService">The General Benefits service.</param>
    /// <param name="configuration">Benefits app configuration settings</param>
    public GeneralController(ILogger<GeneralController> logger,
        IGeneralBenefitsService generalBenefitsService, IConfiguration configuration)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _generalBenefitsService = generalBenefitsService;

        // Set MaxOffers in BenefitsResponseExtensions
        BenefitsResponseExtensions.SetMaxOffers(configuration);
    }

    /// <summary>
    ///     Gets the general benefits.
    /// </summary>
    /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
    /// <param name="authorization">JWT Bearer</param>
    /// <returns>The action result.</returns>
    [HttpGet("general")]
    [Authorize]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Produces("application/json")]
    public async Task<ActionResult<ApiBenefitsResponse>> GetAsync(
        [FromHeader(Name = MobileAppConstants.CorrelationIdLogPropertyName)]
        Guid xCorrelationIdentifier,
        [FromHeader(Name = "Authorization")] string authorization
    )
    {
        _logger.LogInformation(
            "CorrelationId : { "
            + MobileAppConstants.CorrelationIdLogPropertyName
            + "} Started executing Get Async Method.",
            xCorrelationIdentifier
        );

        try
        {
            var response =
                await _generalBenefitsService.GetGeneralBenefits(xCorrelationIdentifier, authorization);

            return Ok(response.Convert());
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Retrieving General Benefits failed with error: {message}", xCorrelationIdentifier, ex.Message);

            return StatusCode(StatusCodes.Status500InternalServerError,
                new OperationFailureResponse("Error occured while retrieving General Benefits.", null,
                    xCorrelationIdentifier.ToString()));
        }
    }
}
