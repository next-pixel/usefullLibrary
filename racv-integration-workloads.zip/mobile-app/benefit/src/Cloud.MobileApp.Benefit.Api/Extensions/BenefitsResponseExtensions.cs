using System.ComponentModel;
using Cloud.MobileApp.Benefit.Common.Settings;
using ApiResponse = Cloud.MobileApp.Benefit.Api.Models.Response;
using ServiceResponse = Cloud.MobileApp.Benefit.Common.Models.Service.Response;

namespace Cloud.MobileApp.Benefit.Api.Extensions;

/// <summary>
///     Provides extension methods for converting ServiceBenefitsResponse to ApiBenefitsResponse.
/// </summary>
public static class BenefitsResponseExtensions
{
    private const string CategoryBaseId = "racv:app/";
    private const int DefaultMaxOffers = 10;
    private static int HomepageMaxOffers;
    private static int FeaturedMaxOffers;
    private static int PopularMaxOffers;

    /// <summary>
    ///     Sets the maximum number of offers for each category type (Homepage, Featured, Popular)
    ///     by retrieving the values from the application's configuration.
    /// </summary>
    /// <param name="configuration">Benefits app configuration settings.</param>
    public static void SetMaxOffers(IConfiguration configuration)
    {
        var benefitSettings = new BenefitSettings();
        configuration.Bind(BenefitSettings.ConfigurationSectionName, benefitSettings);

        HomepageMaxOffers = GetMaxOffers(benefitSettings.NumberOfHomepageOffers);
        FeaturedMaxOffers = GetMaxOffers(benefitSettings.NumberOfFeaturedOffers);
        PopularMaxOffers = GetMaxOffers(benefitSettings.NumberOfPopularOffers);
    }

    /// <summary>
    ///     Retrieves the maximum number of offers for a specific category type from the application's configuration.
    ///     If the configuration value is not set or cannot be parsed to an integer, it returns a default value.
    /// </summary>
    /// <param name="maxOffersConfig">The configuration of maximum number of offers for the specific category type.</param>
    /// <returns>The maximum number of offers for the specific category type.</returns>
    private static int GetMaxOffers(string maxOffersConfig)
    {
        if (string.IsNullOrWhiteSpace(maxOffersConfig) || !int.TryParse(maxOffersConfig, out var parsedMaxOffers))
        {
            return DefaultMaxOffers; // Default value
        }

        return parsedMaxOffers;
    }


    /// <summary>
    ///     Converts a ServiceBenefitsResponse to an ApiBenefitsResponse.
    /// </summary>
    /// <param name="msBenefitsResponse">The ServiceBenefitsResponse to convert.</param>
    /// <returns>The converted ApiBenefitsResponse.</returns>
    /// <exception cref="ArgumentNullException">Thrown when msBenefitsResponse or its Data property is null.</exception>
    /// <exception cref="InvalidOperationException">Thrown when an error occurs during conversion.</exception>
    public static ApiResponse.BenefitsResponse Convert(this ServiceResponse.BenefitsResponse? msBenefitsResponse)
    {
        if (msBenefitsResponse?.Data == null)
        {
            throw new ArgumentNullException(nameof(msBenefitsResponse),
                "msBenefitsResponse or msBenefitsResponse.Data is null.");
        }

        try
        {
            return new ApiResponse.BenefitsResponse
            {
                Message = "Operation successful.", Data = msBenefitsResponse.Data[0].Convert()
            };
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                "An error occurred while converting the Microservice General Benefits to Api General Benefits.",
                ex);
        }
    }


    /// <summary>
    ///     Converts a list of ServiceBenefitsResponse.DataObj to an ApiBenefitsResponse.DataObj.
    /// </summary>
    /// <param name="msBenefit">The list of ServiceBenefitsResponse.DataObj to convert.</param>
    /// <returns>The converted ApiBenefitsResponse.DataObj.</returns>
    private static ApiResponse.Data Convert(this ServiceResponse.Data msBenefit)
    {
        var offers = msBenefit.Offers ?? [];
        var categories = msBenefit.Categories ?? [];

        return new ApiResponse.Data
        {
            HomepageOffers = offers.MapOffers(CategoryType.Homepage),
            FeaturedOffers = offers.MapOffers(CategoryType.Featured),
            PopularOffers = offers.MapOffers(CategoryType.Popular),
            Categories = categories.Select(category =>
                new ApiResponse.Category
                {
                    CategoryUrl = category.CategoryUrl, Label = category.Label, CategoryId = category.CategoryId
                }).Distinct().ToList(),
            ViewAllUrl = msBenefit.ViewAllUrl,
            CompetitionUrl = msBenefit.CompetitionUrl,
            FeaturedOffersTitle = msBenefit.FeaturedOffersTitle,
            MostPopularTitle = msBenefit.MostPopularTitle,
            BrowseByCategoryTitle = msBenefit.BrowseByCategoryTitle,
            SeeAllNumber = msBenefit.SeeAllNumber
        };
    }

    /// <summary>
    ///     Maps a list of ServiceBenefitsResponse.DataObj.Offer to a list of ApiBenefitsResponse.Offer based on the specified
    ///     category type.
    /// </summary>
    /// <param name="offers">The list of ServiceBenefitsResponse.DataObj.Offer to map.</param>
    /// <param name="categoryType">The category type to use for mapping.</param>
    /// <returns>The mapped list of ApiBenefitsResponse.Offer.</returns>
    private static List<ApiResponse.Offer> MapOffers(this List<ServiceResponse.Offer> offers,
        CategoryType categoryType)
    {
        var categoryId = $"{CategoryBaseId}{categoryType.GetDescription()}";

        var maxOffers = categoryType switch
        {
            CategoryType.Homepage => HomepageMaxOffers,
            CategoryType.Featured => FeaturedMaxOffers,
            CategoryType.Popular => PopularMaxOffers,
            _ => DefaultMaxOffers
        };

        return offers
            .Where(offer => offer.Category?.Exists(category => category.CategoryId == categoryId) == true)
            .OrderByDescending(offer => offer.LastModifiedDate)
            .Take(maxOffers)
            .Select(offer => new ApiResponse.Offer
            {
                OfferId = offer.OfferId,
                Title = offer.Title,
                VendorIdentifier = offer.VendorIdentifier,
                StartDate = offer.StartDate,
                EndDate = offer.EndDate,
                LastModifiedDate = offer.LastModifiedDate,
                AppDescription = offer.AppDescription,
                Image = offer.Image,
                Description = offer.Description,
                Url = offer.Url,
                Tag = offer.Tag
            })
            .ToList();
    }

    /// <summary>
    ///     Gets the description of a CategoryType enum value.
    /// </summary>
    /// <param name="value">The CategoryType enum value.</param>
    /// <returns>
    ///     The description of the CategoryType enum value if it exists,
    ///     otherwise the string representation of the enum value itself.
    /// </returns>
    private static string GetDescription(this CategoryType value)
    {
        var fieldInfo = value.GetType().GetField(value.ToString());
        if (fieldInfo == null)
        {
            return value.ToString().ToLower();
        }

        var attributes = (DescriptionAttribute[])fieldInfo.GetCustomAttributes(typeof(DescriptionAttribute), false);

        return attributes.Length > 0 ? attributes[0].Description : value.ToString();
    }

    /// <summary>
    ///     Enum representing the types of categories for benefits.
    /// </summary>
    private enum CategoryType
    {
        [Description("home-page")]
        Homepage,
        [Description("feature-offer")]
        Featured,
        [Description("popular")]
        Popular
    }
}
