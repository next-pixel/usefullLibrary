using System.Text.Json.Serialization;

namespace Cloud.MobileApp.Benefit.Api.Models.Response;

/// <summary>
///     Represents the response from the Benefits API.
///     This includes a message indicating the status of the request and data containing the details of the benefits.
/// </summary>
public class BenefitsResponse
{
    [JsonPropertyName("message")]
    public string? Message { get; set; }

    [JsonPropertyName("data")]
    public Data? Data { get; set; }
}

/// <summary>
///     The 'data' object in the response - containing various types of offers, categories and additional details.
///     This includes offers that are featured on the homepage, popular offers, featured offers and a list of categories.
/// </summary>
public class Data
{
    [JsonPropertyName("homepageOffers")]
    public List<Offer>? HomepageOffers { get; set; }

    [JsonPropertyName("featuredOffers")]
    public List<Offer>? FeaturedOffers { get; set; }

    [JsonPropertyName("popularOffers")]
    public List<Offer>? PopularOffers { get; set; }

    [JsonPropertyName("categories")]
    public List<Category>? Categories { get; set; }

    [JsonPropertyName("viewAllUrl")]
    public Uri? ViewAllUrl { get; set; }
    
    [JsonPropertyName("competitionUrl")]
    public Uri? CompetitionUrl { get; set; }

    [JsonPropertyName("featuredOffersTitle")]
    public string? FeaturedOffersTitle { get; set; }

    [JsonPropertyName("mostPopularTitle")]
    public string? MostPopularTitle { get; set; }

    [JsonPropertyName("browseByCategoryTitle")]
    public string? BrowseByCategoryTitle { get; set; }

    [JsonPropertyName("seeAllNumber")]
    public string? SeeAllNumber { get; set; }
}

/// <summary>
///     Represents an individual offer - containing details about the offer and its timeframe.
///     This includes the offer ID, title, vendor identifier, start and end dates, and other details.
/// </summary>
public class Offer
{
    [JsonPropertyName("offerid")]
    public string? OfferId { get; set; }

    [JsonPropertyName("title")]
    public string? Title { get; set; }

    [JsonPropertyName("vendorIdentifier")]
    public string? VendorIdentifier { get; set; }

    [JsonPropertyName("startdate")]
    public DateTime? StartDate { get; set; }

    [JsonPropertyName("enddate")]
    public DateTime? EndDate { get; set; }

    [JsonPropertyName("lastmodifieddate")]
    public DateTime? LastModifiedDate { get; set; }

    [JsonPropertyName("appdescription")]
    public string? AppDescription { get; set; }

    [JsonPropertyName("image")]
    public Uri? Image { get; set; }

    [JsonPropertyName("description")]
    public string? Description { get; set; }

    [JsonPropertyName("url")]
    public Uri? Url { get; set; }

    [JsonPropertyName("tag")]
    public string? Tag { get; set; }
}

/// <summary>
///     Represents a category of offers - containing details about the category.
///     This includes the category URL, label, and category ID.
/// </summary>
public class Category
{
    [JsonPropertyName("categoryUrl")]
    public Uri? CategoryUrl { get; set; }

    [JsonPropertyName("label")]
    public string? Label { get; set; }

    [JsonPropertyName("categoryid")]
    public string? CategoryId { get; set; }
}
