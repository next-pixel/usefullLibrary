using System.Runtime.Serialization;
using System.Text.Json;
using Cloud.MobileApp.Benefit.Common.Constants;
using Cloud.MobileApp.Benefit.Connector.Service.Interfaces;
using Cloud.MobileApp.Common.Constants;
using Cloud.MobileApp.Common.Utility.Wrapper.Interfaces;
using Microsoft.Extensions.Logging;
using ServiceBenefitsResponse = Cloud.MobileApp.Benefit.Common.Models.Service.Response.BenefitsResponse;

namespace Cloud.MobileApp.Benefit.Connector.Service.Implementations;

public class GeneralBenefitsService : IGeneralBenefitsService
{
    private readonly IHttpWrapper<HttpRequestMessage, HttpResponseMessage> _httpWrapper;
    private readonly ILogger<GeneralBenefitsService> _logger;

    /// <summary>
    ///     Initializes a new instance of the <see cref="GeneralBenefitsService" /> class.
    /// </summary>
    /// <param name="logger">The logger.</param>
    /// <param name="clientFactory">The HTTP client factory.</param>
    public GeneralBenefitsService(ILogger<GeneralBenefitsService> logger,
        IHttpWrapper<HttpRequestMessage, HttpResponseMessage> httpWrapper)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _httpWrapper = httpWrapper ?? throw new ArgumentNullException(nameof(httpWrapper));
    }

    /// <summary>
    ///     Gets general benefits
    /// </summary>
    /// <param name="xCorrelationIdentifier">The correlation identifier.</param>
    /// <param name="authorization">Bearer token</param>
    /// <returns>The general benefits response.</returns>
    public async Task<ServiceBenefitsResponse> GetGeneralBenefits(Guid xCorrelationIdentifier,
        string authorization)
    {
        HttpResponseMessage? response = null;

        try
        {
            var request = new HttpRequestMessage(HttpMethod.Get, "services/benefit/v1/general");
            
            request.Headers.UserAgent.ParseAdd("RACVApp");
            response = await _httpWrapper.SendAsync(
                request,
                InternalConstants.ServiceHttpClient,
                xCorrelationIdentifier,
                authorization);

            response.EnsureSuccessStatusCode();

            var responseJson = await response.Content.ReadAsStringAsync();

            return JsonSerializer.Deserialize<ServiceBenefitsResponse>(responseJson) ??
                   throw new SerializationException();
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Retrieving General Benefits from Microservice failed with Status Code: {statusCode}",
                xCorrelationIdentifier,
                response?.StatusCode);

            throw new HttpRequestException(
                $"Retrieving General Benefits from Microservice failed with Status Code: {response?.StatusCode}", ex);
        }
        catch (SerializationException ex)
        {
            _logger.LogError(ex,
                "CorrelationId : {" + MobileAppConstants.CorrelationIdLogPropertyName +
                "} Deserialization of General Benefits from Microservice failed with error: {message}",
                xCorrelationIdentifier, ex.Message);

            throw new SerializationException(
                $"Deserialization of General Benefits from Microservice failed with error: {ex.Message}", ex);
        }
    }
}
