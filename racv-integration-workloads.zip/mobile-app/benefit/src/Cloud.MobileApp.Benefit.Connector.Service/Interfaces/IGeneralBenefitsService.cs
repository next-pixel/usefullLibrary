using Cloud.MobileApp.Benefit.Common.Models.Service.Response;

namespace Cloud.MobileApp.Benefit.Connector.Service.Interfaces;

public interface IGeneralBenefitsService
{
    Task<BenefitsResponse> GetGeneralBenefits(Guid xCorrelationIdentifier, string authorization);
}
