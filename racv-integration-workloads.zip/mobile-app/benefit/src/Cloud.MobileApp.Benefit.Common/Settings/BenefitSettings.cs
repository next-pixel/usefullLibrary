namespace Cloud.MobileApp.Benefit.Common.Settings;

public class BenefitSettings
{
    public const string ConfigurationSectionName = "BenefitSettings";
    public string ServiceBaseAddress { get; set; } = string.Empty;
    public string NumberOfHomepageOffers { get; set; } = string.Empty;
    public string NumberOfFeaturedOffers { get; set; } = string.Empty;
    public string NumberOfPopularOffers { get; set; } = string.Empty;
}
