namespace Cloud.MobileApp.Benefit.Common.Constants;

/// <summary>
///     Constants to be used across all projects and workloads related to Benefit.
/// </summary>
public static class InternalConstants
{
    public const string ServiceHttpClient = "ServiceClient";
}
