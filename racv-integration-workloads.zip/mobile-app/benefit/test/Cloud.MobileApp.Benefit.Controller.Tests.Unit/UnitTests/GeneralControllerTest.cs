using Cloud.MobileApp.Benefit.Api.Controllers;
using Cloud.MobileApp.Benefit.Connector.Service.Interfaces;
using Cloud.MobileApp.Benefit.Controller.Tests.Unit.Infrastructure;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using ApiBenefitsResponse = Cloud.MobileApp.Benefit.Api.Models.Response.BenefitsResponse;

namespace Cloud.MobileApp.Benefit.Controller.Tests.Unit.UnitTests;

/// <summary>
///     This class contains unit tests for the <see cref="GeneralController" />.
/// </summary>
public class GeneralControllerTest
{
    private const string Authorization = "Bearer valid_token";
    private readonly GeneralController _generalController;
    private readonly Mock<IConfiguration> _mockConfiguration;
    private readonly Mock<IGeneralBenefitsService> _mockGeneralBenefitsService;
    private readonly Mock<ILogger<GeneralController>> _mockLogger;
    private readonly Guid _xCorrelationIdentifier;

    /// <summary>
    ///     Initializes a new instance of the GeneralControllerTest class.
    /// </summary>
    public GeneralControllerTest()
    {
        _mockLogger = LoggerHelper.GetLogger<GeneralController>();
        _mockGeneralBenefitsService = new Mock<IGeneralBenefitsService>();
        _mockConfiguration = new Mock<IConfiguration>();

        // Setup _mockConfiguration to return some value
        _mockConfiguration.Setup(c => c.GetSection(It.IsAny<string>()))
            .Returns(new Mock<IConfigurationSection>().Object);

        _generalController = new GeneralController(_mockLogger.Object, _mockGeneralBenefitsService.Object,
            _mockConfiguration.Object);
        _xCorrelationIdentifier = Guid.NewGuid();

        _mockGeneralBenefitsService
            .Setup(service => service.GetGeneralBenefits(_xCorrelationIdentifier, Authorization))
            .ReturnsAsync(TestDataHelper.GetExpectedServiceResponse());
    }

    /// <summary>
    ///     Test case for GetAsync method in GeneralController.
    ///     This test verifies that the GetAsync method returns the expected result when called with valid parameters.
    /// </summary>
    [Fact]
    public async Task BenefitsController_GetGeneralBenefits_ShouldPass()
    {
        // Arrange

        // Act
        var result = await _generalController.GetAsync(_xCorrelationIdentifier, Authorization);

        // Assert
        result.Should().NotBeNull();

        var okResult = result.Result as OkObjectResult;
        okResult.Should().NotBeNull();
        okResult.Should().BeOfType<OkObjectResult>();
        okResult?.StatusCode.Should().Be(StatusCodes.Status200OK);

        var returnValue = okResult?.Value as ApiBenefitsResponse;
        returnValue.Should().NotBeNull();
        returnValue.Should().BeOfType<ApiBenefitsResponse>();
        returnValue.Should().BeEquivalentTo(TestDataHelper.GetExpectedApiResponse());

        _mockGeneralBenefitsService.Verify(
            service => service.GetGeneralBenefits(_xCorrelationIdentifier, Authorization),
            Times.Once);
    }
}
