using System.Globalization;
using ApiResponse = Cloud.MobileApp.Benefit.Api.Models.Response;
using ServiceResponse = Cloud.MobileApp.Benefit.Common.Models.Service.Response;

namespace Cloud.MobileApp.Benefit.Controller.Tests.Unit.Infrastructure;

/// <summary>
///     Helps to generate test data.
/// </summary>
public static class TestDataHelper
{
    /// <summary>
    ///     Generates a mock service response for testing.
    /// </summary>
    /// <returns>A mock service response.</returns>
    public static ServiceResponse.BenefitsResponse GetExpectedServiceResponse()
    {
        return new ServiceResponse.BenefitsResponse
        {
            Data = new List<ServiceResponse.Data>
            {
                new()
                {
                    Offers = new List<ServiceResponse.Offer>
                    {
                        new()
                        {
                            OfferId = "38541",
                            Category =
                                new List<ServiceResponse.OfferCategory>
                                {
                                    new() { CategoryId = "racv:app/feature-offer", Label = "Featured" },
                                    new() { CategoryId = "racv:app/popular", Label = "Popular" }
                                },
                            Title = "Competitions",
                            VendorIdentifier = null,
                            StartDate = null,
                            EndDate = null,
                            LastModifiedDate =
                                DateTime.Parse("2024-04-08T00:49:34.460Z",
                                    CultureInfo.InvariantCulture),
                            AppDescription = null,
                            Image =
                                new Uri(
                                    "https://www.racv.com.au/content/dam/racv/images/legacy/compeitions-page-thumbnail-600x400.jpg"),
                            Description =
                                "Find out more about the competitions RACV has on offer and enter for your chance to win some exciting prizes.",
                            Url =
                                new Uri(
                                    "https://www.racv.com.au/utility/competitions.appview.html"),
                            Tag = "Save 10%"
                        }
                    },
                    Categories = new List<ServiceResponse.Category>
                    {
                        new()
                        {
                            CategoryId = "racv:discount-categories/app/feature-offer",
                            CategoryUrl =
                                new Uri(
                                    "https://staging-cloudfront.racv.com.au/membership/member-discounts.html#Featured"),
                            Label = "Featured"
                        },
                        new()
                        {
                            CategoryId = "racv:discount-categories/popular",
                            CategoryUrl =
                                new Uri(
                                    "https://staging-cloudfront.racv.com.au/membership/member-discounts.html#Popular"),
                            Label = "Popular"
                        }
                    },
                    ViewAllUrl =
                        new Uri(
                            "https://www.racv.com.au/..."),
                    CompetitionUrl = 
                        new Uri(
                            "https://www.racv.com.au/..."),
                    FeaturedOffersTitle = "Featured Offers",
                    MostPopularTitle = "Browse by most popular",
                    BrowseByCategoryTitle = "Browse by category",
                    SeeAllNumber = "3000"
                }
            }
        };
    }

    /// <summary>
    ///     Generates a mock api response for testing.
    /// </summary>
    /// <returns>A mock api response.</returns>
    public static ApiResponse.BenefitsResponse GetExpectedApiResponse()
    {
        return new ApiResponse.BenefitsResponse
        {
            Message = "Operation successful.",
            Data = new ApiResponse.Data
            {
                HomepageOffers = new List<ApiResponse.Offer>(),
                FeaturedOffers = new List<ApiResponse.Offer>
                {
                    new()
                    {
                        OfferId = "38541",
                        Title = "Competitions",
                        VendorIdentifier = null,
                        StartDate = null,
                        EndDate = null,
                        LastModifiedDate =
                            DateTime.Parse("2024-04-08T00:49:34.460Z",
                                CultureInfo.InvariantCulture),
                        AppDescription = null,
                        Image =
                            new Uri(
                                "https://www.racv.com.au/content/dam/racv/images/legacy/compeitions-page-thumbnail-600x400.jpg"),
                        Description =
                            "Find out more about the competitions RACV has on offer and enter for your chance to win some exciting prizes.",
                        Url =
                            new Uri(
                                "https://www.racv.com.au/utility/competitions.appview.html"),
                        Tag = "Save 10%"
                    }
                },
                PopularOffers = new List<ApiResponse.Offer>
                {
                    new()
                    {
                        OfferId = "38541",
                        Title = "Competitions",
                        VendorIdentifier = null,
                        StartDate = null,
                        EndDate = null,
                        LastModifiedDate =
                            DateTime.Parse("2024-04-08T00:49:34.460Z",
                                CultureInfo.InvariantCulture),
                        AppDescription = null,
                        Image =
                            new Uri(
                                "https://www.racv.com.au/content/dam/racv/images/legacy/compeitions-page-thumbnail-600x400.jpg"),
                        Description =
                            "Find out more about the competitions RACV has on offer and enter for your chance to win some exciting prizes.",
                        Url =
                            new Uri(
                                "https://www.racv.com.au/utility/competitions.appview.html"),
                        Tag = "Save 10%"
                    }
                },
                Categories = new List<ApiResponse.Category>
                {
                    new()
                    {
                        CategoryId = "racv:discount-categories/app/feature-offer",
                        CategoryUrl =
                            new Uri(
                                "https://staging-cloudfront.racv.com.au/membership/member-discounts.html#Featured"),
                        Label = "Featured"
                    },
                    new()
                    {
                        CategoryId = "racv:discount-categories/popular",
                        CategoryUrl =
                            new Uri(
                                "https://staging-cloudfront.racv.com.au/membership/member-discounts.html#Popular"),
                        Label = "Popular"
                    }
                },
                ViewAllUrl =
                    new Uri(
                        "https://www.racv.com.au/..."),
                CompetitionUrl = 
                    new Uri(
                        "https://www.racv.com.au/..."),
                FeaturedOffersTitle = "Featured Offers",
                MostPopularTitle = "Browse by most popular",
                BrowseByCategoryTitle = "Browse by category",
                SeeAllNumber = "3000"
            }
        };
    }
}
