
###############
#  Imports an environment file into memory, uploads each value into the app config service and sets the sentinel key 
###############

param (
    [Parameter(Mandatory)]
    [string] $ConfigurationFile
)

# Import related helpers.
#Import-Module $PSScriptRoot\scripts\Imports.psm1 -Force

Write-Host "*******************************************"
Write-Host "         Deploying Configuration           "
Write-Host "*******************************************"

Write-Host "Getting configuration keys from '$ConfigurationFile'."

if ($false -eq (Test-Path -Path $ConfigurationFile)) {
    Write-Error "Unable to load file from '$($ConfigurationFile)'"
    exit 1
}
$appConfigFile = Get-Content -Raw -path $ConfigurationFile | ConvertFrom-Json
$appConfigs = $appConfigFile.parameters.appconfigkeysToDeploy.value
$environment = $appConfigFile.parameters.environment.value
Write-Host "Getting Environment to be used for deployment: '$environment'."
$workloadName = $appConfigFile.parameters.workloadName.value
Write-Host "Getting workload to be used for deployment: '$workloadName'."
$appConfigurationName = $appConfigFile.parameters.appconfigName.value
Write-Host "Getting app configuration resource name to be used in the deployment: '$appConfigurationName'."
$appConfigKeySentinel = 'sentinel'
$appConfigSentinelLabel = $environment

$deployAppConfigurationValuesScript = $PSScriptRoot + "\Deploy-App-Configuration-Values.ps1"

& $deployAppConfigurationValuesScript -ConfigurationFile $ConfigurationFile

az appconfig kv set -n $appConfigurationName --key $appConfigKeySentinel --label $appConfigSentinelLabel --value  (Get-Date).Ticks.ToString() --content-type "string"  --yes 

if ($null -ne $errorList) {
    Write-Error $errorList
    exit 1
}

Write-Host "Update Complete"