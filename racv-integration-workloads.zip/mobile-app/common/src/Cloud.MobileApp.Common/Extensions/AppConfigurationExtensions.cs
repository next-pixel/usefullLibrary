﻿using Azure.Identity;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Cloud.MobileApp.Common.Extensions
{
    /// <summary>
    /// Extension class to add Azure App configuration services.
    /// </summary>
    public static class AppConfigurationExtensions
    {
        /// <summary>
        /// Extension method to configure App configuration.
        /// </summary>
        /// <param name="builder">Web application builder</param>
        /// <param name="appConfigurationEndPoint">App configuration url.</param>
        /// <param name="environment">environment variable ed dev, sit, uat and prod.</param>
        /// <param name="workload">workload name like create-limit, update-limits ect.</param>
        /// <param name="configurationRefreshKey">Key name to be watched for the configuration refresh.</param>
        /// <exception cref="ArgumentNullException"></exception>
        public static void ConfigureAppConfiguration<T>(
            this WebApplicationBuilder builder,
            Uri appConfigurationEndPoint,
            string azureClientId,
            string environment,
            string workload,
            string configurationRefreshKey,
            bool includeAllConfiguration)
        {
            ArgumentNullException.ThrowIfNull(appConfigurationEndPoint);
            ArgumentException.ThrowIfNullOrWhiteSpace(environment);
            ArgumentException.ThrowIfNullOrWhiteSpace(workload);
            ArgumentException.ThrowIfNullOrWhiteSpace(configurationRefreshKey);

            var logger = builder.Services.BuildServiceProvider().GetRequiredService<ILogger<T>>();
            IConfigurationRefresher? refresher = null;

            try
            {
#if DEBUG
                logger.LogInformation("Using Azure Cli Credentials");
                var credential = new AzureCliCredential();
#else
                logger.LogInformation("Using Managed Identity Client");
                var credential = new ManagedIdentityCredential(azureClientId);
#endif
                builder.Configuration.AddAzureAppConfiguration(options =>
                {
                    options
                        .Connect(appConfigurationEndPoint, credential)
                        .ConfigureKeyVault(kv =>
                        {
                            kv.SetCredential(credential);
                        });
                    
                    if (includeAllConfiguration)
                    {
                        // Select all keys with global and environment labels
                        options
                            .Select(KeyFilter.Any, LabelFilter.Null)
                            .Select(KeyFilter.Any, environment);
                    }

                    // Select all keys with workload labels
                    options
                        .Select(KeyFilter.Any, $"{environment}:{workload}")
                        .ConfigureRefresh(refreshOptions =>
                        {
                            refreshOptions.Register(configurationRefreshKey, environment, true);
                        });
                    refresher = options.GetRefresher();
                });

                builder.Services.AddSingleton(refresher!);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Configure App Configuration failed with exception: {Exception}", ex.Message);
                throw;
            }

            builder.Services.AddAzureAppConfiguration();
        }
    }
}
