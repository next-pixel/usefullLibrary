﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.ApplicationInsights.AspNetCore.Extensions;

namespace Cloud.MobileApp.Common.Extensions
{
    /// <summary>
    /// Extension class to add App insight services.
    /// </summary>
    public static class ApplicationInsightsExtensions
    {
        /// <summary>
        /// Extension method to add Application Insights telemetry middleware to the container of services.
        /// </summary>
        /// <param name="services"></param>
        /// <param name="appInsightsConnectionString">Application Insights connection string.</param>
        /// <exception cref="ArgumentNullException"></exception>
        public static void AddApplicationInsights(this IServiceCollection services, string appInsightsConnectionString)
        {
            if (string.IsNullOrWhiteSpace(appInsightsConnectionString)) throw new ArgumentNullException(nameof(appInsightsConnectionString));
            var appInsightOptions = new ApplicationInsightsServiceOptions { ConnectionString = appInsightsConnectionString };
            services.AddApplicationInsightsTelemetry(options: appInsightOptions);
        }
    }
}
