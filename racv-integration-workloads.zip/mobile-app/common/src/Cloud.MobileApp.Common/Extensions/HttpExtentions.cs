﻿using Microsoft.AspNetCore.Http;

namespace Cloud.MobileApp.Common.Extensions
{
    /// <summary>
    /// Extension methods relating to <see cref="HttpRequest"/> or <see cref="HttpResponse"/>.
    /// </summary>
    public static class HttpExtentions
    {
        /// <summary>
        /// Read the request body and return the string.
        /// </summary>
        /// <param name="request">The Http Request object.</param>
        /// <returns>Returns the request body in string format.</returns>
        public static async Task<string> GetRequestBodyAsStringAsync(this HttpRequest request)
        {
            request.EnableBuffering();
            request.Body.Seek(0, SeekOrigin.Begin);
            var bodyAsString = await new StreamReader(request.Body).ReadToEndAsync();
            request.Body.Seek(0, SeekOrigin.Begin);
            return bodyAsString;
        }

        /// <summary>
        /// Read the request body and return the string.
        /// </summary>
        /// <param name="response">The Http Response object.</param>
        /// <returns>Returns the response body in string format.</returns>
        public static async Task<string> GetResponseBodyAsStringAsync(this HttpResponse response)
        {
            response.Body.Seek(0, SeekOrigin.Begin);
            var bodyAsString = await new StreamReader(response.Body).ReadToEndAsync();
            response.Body.Seek(0, SeekOrigin.Begin);
            return bodyAsString;
        }
    }
}
