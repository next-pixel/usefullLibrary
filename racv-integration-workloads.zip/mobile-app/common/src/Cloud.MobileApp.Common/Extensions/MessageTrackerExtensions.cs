﻿using Azure.Identity;
using Azure.Storage.Blobs;
using Cloud.MobileApp.Common.Azure.Blob.Implementation;
using Cloud.MobileApp.Common.Tracking.Implementation;
using Cloud.MobileApp.Common.Tracking.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Cloud.MobileApp.Common.Extensions
{
    /// <summary>
    /// Extension methods relating to message tracker setup.
    /// </summary>
    public static class MessageTrackerExtensions
    {
        /// <summary>
        /// Adds the message tracker as a singleton via dependency injection.
        /// </summary>
        /// <param name="services"></param>
        /// <param name="blobServiceUri">URI of the storage container which will hold the tracked messages.</param>
        /// <exception cref="ArgumentNullException"></exception>
        public static void AddMessageTracker(this IServiceCollection services, Uri blobServiceUri)
        {
            ArgumentNullException.ThrowIfNull(blobServiceUri);
            services.AddSingleton<IMessageTracker, AzureStorageMessageTracker>(
                provider =>
                {
                    // initialise blob store
                    var azureBlobStoreLogger = provider.GetService<ILogger<AzureBlobStore>>();
                    var client = new BlobServiceClient(blobServiceUri, new DefaultAzureCredential());
                    var azureBlobStore = new AzureBlobStore(azureBlobStoreLogger!, client);

                    // initialise message tracker
                    var messageTrackerLogger = provider.GetService<ILogger<AzureStorageMessageTracker>>();
                    return new AzureStorageMessageTracker(messageTrackerLogger!, azureBlobStore);
                });
        }
    }
}
