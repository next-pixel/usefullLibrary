﻿using Cloud.MobileApp.Common.Constants;
using Cloud.MobileApp.Common.Exceptions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace Cloud.MobileApp.Common.Middleware
{
    /// <summary>
    /// Validates Correlation Id in REST API services. 
    /// </summary>
    public class ValidateCorrelationMiddleware
    {
        /// <summary>
        /// Processes HTTP requests.
        /// </summary>
        private readonly RequestDelegate _next;

        /// <summary>
        /// Constructor for the <see cref="ValidateCorrelationMiddleware"/> class.
        /// </summary>
        /// <param name="next"></param>
        /// <param name="loggerFactory"></param>
        /// <exception cref="ArgumentNullException"></exception>
        public ValidateCorrelationMiddleware(RequestDelegate next)
        {
            _next = next ?? throw new ArgumentNullException(nameof(next));
        }

        /// <summary>
        /// Invoke the middleware.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InvokeAsync(HttpContext context)
        {
            if (context.Request.Headers.TryGetValue(MobileAppConstants.CorrelationIdLogPropertyName, out var stringValues) &&
                Guid.TryParse(stringValues[0], out Guid correlationId) &&
                correlationId != Guid.Empty)
            {
                context.Response.Headers[MobileAppConstants.CorrelationIdLogPropertyName] = correlationId.ToString();
                await _next(context);
                return;
            }
            var newCorrelationId = Guid.NewGuid().ToString();
            context.Request.Headers[MobileAppConstants.CorrelationIdLogPropertyName] = newCorrelationId;
            context.Response.Headers[MobileAppConstants.CorrelationIdLogPropertyName] = newCorrelationId;
            await _next(context);
        }
    }
}
