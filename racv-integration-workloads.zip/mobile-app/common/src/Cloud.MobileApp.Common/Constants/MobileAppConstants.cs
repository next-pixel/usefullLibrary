﻿namespace Cloud.MobileApp.Common.Constants
{
    /// <summary>
    /// Constants to be used across all projects and workloads.
    /// </summary>
    public static class MobileAppConstants
    {
        /// <summary>
        /// Used to access the workload name across all projects and workloads.
        /// </summary>
        public const string WorkloadKey = "Workload";

        /// <summary>
        /// Used to access the message tracker container uri across all projects and workloads.
        /// </summary>
        public const string MessageTrackerContainerKey = "MessageTrackerContainer";

        /// <summary>
        /// Used to access the log request/response toggle across all projects and workloads.
        /// </summary>
        public const string LogRequestResponseToggleKey = "LogRequestResponseToggle";

        /// <summary>
        /// Correlation id property name. Used to access the correlation id in requests and telemetry logs.
        /// </summary>
        public const string CorrelationIdLogPropertyName = "x-correlation-id";

        /// <summary>
        /// Authorization header key.
        /// </summary>
        public const string Authorization = "Authorization";

        /// <summary>
        /// OpenID configuration URL key.
        /// </summary>
        public const string OpenIdConfigurationUrl = "OpenIdConfigurationUrl";

        /// <summary>
        /// Blob service URI key for the message tracker.
        /// </summary>
        public const string BlobServiceUriKey = "MessageTrackerBlobServiceUri";

        /// <summary>
        /// Application Insights connection string key.
        /// </summary>
        public const string ApplicationInsightConnectionStringKey = "APPLICATIONINSIGHTS_CONNECTION_STRING";

        /// <summary>
        /// App Configuration endpoint key.
        /// </summary>
        public const string AppConfigurationEndPointKey = "AppConfigurationEndPoint";

        /// <summary>
        /// Environment key.
        /// </summary>
        public const string EnvironmentKey = "Environment";

        /// <summary>
        /// Configuration refresh key.
        /// </summary>
        public const string ConfigurationRefreshKey = "sentinel";

        /// <summary>
        /// Azure AD tenant ID key.
        /// </summary>
        public const string TennantIdKey = "AzureAD:TenantId";

        /// <summary>
        /// Azure client ID key.
        /// </summary>
        public const string AzureClientId = "AZURE_CLIENT_ID";
    }
}
