namespace Cloud.MobileApp.Common.Utility.Wrapper.Interfaces
{
    /// <summary>
    /// Wrapper for a HTTP client.
    /// </summary>
    /// <typeparam name="TRequest">Request object type.</typeparam>
    /// <typeparam name="TResponse">Response object type.</typeparam>
    public interface IHttpWrapper<TRequest, TResponse>
    {
        /// <summary>
        /// Executes a HTTP request asynchronously.
        /// </summary>
        /// <param name="restRequest">Request object.</param>
        /// <param name="correlationIdentifier">Request correlation identifier.</param>
        /// <returns></returns>
        public Task<TResponse> SendAsync(TRequest restRequest, string client, Guid correlationIdentifier, string authorization);
    }
}
