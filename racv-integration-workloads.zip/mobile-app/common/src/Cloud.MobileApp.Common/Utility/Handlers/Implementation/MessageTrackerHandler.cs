﻿using System.Globalization;
using Cloud.MobileApp.Common.Constants;
using Cloud.MobileApp.Common.Tracking.Enumerations;
using Cloud.MobileApp.Common.Tracking.Helpers;
using Cloud.MobileApp.Common.Tracking.Interfaces;
using Cloud.MobileApp.Common.Utility.Extensions;
using Cloud.MobileApp.Common.Utility.Handlers.Interfaces;
using Microsoft.Extensions.Logging;

namespace Cloud.MobileApp.Common.Utility.Handlers.Implementation;

/// <summary>
///     Provides a method to log Http requests and response pairs for a given system.
/// </summary>
public class MessageTrackerHandler : IMessageTrackerHandler<HttpRequestMessage, HttpResponseMessage>
{
    /// <summary>
    ///     Application configuration values.
    /// </summary>
    private readonly IMessageTrackerHandlerConfiguration _configuration;

    /// <summary>
    ///     Specifies header values which should not be logged.
    /// </summary>
    private readonly string[] _excludeHeaders;

    /// <summary>
    ///     Logger.
    /// </summary>
    private readonly ILogger _logger;

    /// <summary>
    ///     Message tracker interface.
    /// </summary>
    private readonly IMessageTracker _messageTracker;

    /// <summary>
    ///     The logged requests and responses will be made against this system.
    /// </summary>
    private readonly string _systemName;

    /// <summary>
    ///     Class constructor.
    /// </summary>
    /// <param name="logger">Logger.</param>
    /// <param name="messageTracker">Message tracker interface.</param>
    /// <param name="configuration">Application configuration values.</param>
    /// <param name="systemName">The logged requests and responses will be made against this system.</param>
    /// <param name="excludeHeaders">Specifies header values which should not be logged.</param>
    /// <exception cref="ArgumentNullException"></exception>
    public MessageTrackerHandler(ILogger<MessageTrackerHandler> logger, IMessageTracker messageTracker,
        IMessageTrackerHandlerConfiguration configuration, string systemName, string[] excludeHeaders)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _messageTracker = messageTracker ?? throw new ArgumentNullException(nameof(messageTracker));
        _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        _systemName = systemName ?? throw new ArgumentNullException(nameof(systemName));
        _excludeHeaders = excludeHeaders ?? throw new ArgumentNullException(nameof(excludeHeaders));
    }

    /// <summary>
    ///     Logs a request and response pair to the message tracker system.
    /// </summary>
    /// <param name="request">HttpRequestMessage request.</param>
    /// <param name="response">HttpResponseMessage response.</param>
    /// <param name="correlationIdentifier">Correlation identifier corresponding to the original api call.</param>
    /// <param name="protocol">The protocol used in making the request e.g. HTTP or HTTPS.</param>
    /// <returns></returns>
    /// <exception cref="ArgumentNullException"></exception>
    public async Task LogRequestResponse(HttpRequestMessage request, HttpResponseMessage response,
        Guid correlationIdentifier, OperationProtocols protocol)
    {
        ArgumentNullException.ThrowIfNull(request);
        ArgumentNullException.ThrowIfNull(response);
        if (correlationIdentifier == Guid.Empty)
        {
            throw new ArgumentNullException(nameof(correlationIdentifier));
        }

        if (_configuration.LogRequestResponseToggle)
        {
            var interactionIdentifier = Guid.NewGuid();
            var workloadName = _configuration.WorkloadName;
            var operationName = request.Method.ToString();
            var timestamp = DateTime.Now;

            try
            {
                await LogRequest(request, correlationIdentifier, interactionIdentifier, workloadName, protocol,
                    operationName, timestamp);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    $"Correlation Id : {{{nameof(MobileAppConstants.CorrelationIdLogPropertyName)}}} failed to log {_systemName} request with error: {ex.Message}",
                    correlationIdentifier);
                throw;
            }

            try
            {
                await LogResponse(response, correlationIdentifier, interactionIdentifier, workloadName, protocol,
                    operationName, timestamp);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    $"Correlation Id : {{{nameof(MobileAppConstants.CorrelationIdLogPropertyName)}}} failed to log {_systemName} response with error: {ex.Message}",
                    correlationIdentifier);
                throw;
            }
        }
    }

    /// <summary>
    ///     Logs the request to the message tracker system.
    /// </summary>
    /// <param name="request">The HTTP request message.</param>
    /// <param name="correlationIdentifier">The correlation identifier corresponding to the original API call.</param>
    /// <param name="interactionIdentifier">The unique identifier for the interaction.</param>
    /// <param name="workloadName">The name of the workload.</param>
    /// <param name="protocol">The protocol used in making the request.</param>
    /// <param name="operationName">The name of the operation.</param>
    /// <param name="timestamp">The timestamp when the request was made.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    private async Task LogRequest(HttpRequestMessage request, Guid correlationIdentifier,
        Guid interactionIdentifier, string workloadName, OperationProtocols protocol, string operationName,
        DateTime timestamp)
    {
        var loggedRequest = await request.GetRestRequestMessageAsync(
            correlationIdentifier, interactionIdentifier, workloadName, protocol,
            request.RequestUri?.ToString(), _excludeHeaders, _systemName, operationName, timestamp);
        var filePath = MessageTrackerHelper.FormatFilePath(
            workloadName, timestamp,
            correlationIdentifier.ToString().ToLower(CultureInfo.InvariantCulture),
            _systemName, interactionIdentifier.ToString(), operationName, protocol, OperationTypes.Request);
        await _messageTracker.TrackMessageAsync(loggedRequest, filePath, _configuration.ContainerName);
    }

    /// <summary>
    ///     Logs the response to the message tracker system.
    /// </summary>
    /// <param name="response">The HTTP response message.</param>
    /// <param name="correlationIdentifier">The correlation identifier corresponding to the original API call.</param>
    /// <param name="interactionIdentifier">The unique identifier for the interaction.</param>
    /// <param name="workloadName">The name of the workload.</param>
    /// <param name="protocol">The protocol used in making the request.</param>
    /// <param name="operationName">The name of the operation.</param>
    /// <param name="timestamp">The timestamp when the response was received.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    private async Task LogResponse(HttpResponseMessage response, Guid correlationIdentifier,
        Guid interactionIdentifier, string workloadName, OperationProtocols protocol, string operationName,
        DateTime timestamp)
    {
        var loggedResponse = await response.GetRestResponseMessageAsync(
            correlationIdentifier, interactionIdentifier, workloadName, protocol, _excludeHeaders,
            operationName, _systemName, timestamp);
        var filePath = MessageTrackerHelper.FormatFilePath(
            workloadName, timestamp,
            correlationIdentifier.ToString().ToLower(CultureInfo.InvariantCulture),
            _systemName, interactionIdentifier.ToString(), operationName, protocol,
            OperationTypes.Response);
        await _messageTracker.TrackMessageAsync(loggedResponse, filePath, _configuration.ContainerName);
    }
}
