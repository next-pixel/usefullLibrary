﻿namespace Cloud.MobileApp.Common.Utility.Handlers.Interfaces;

/// <summary>
///     Configuration values required by <see cref="IMessageTrackerHandler{TRequest, TResponse}" />.
/// </summary>
public interface IMessageTrackerHandlerConfiguration
{
    /// <summary>
    ///     Gets the workload name.
    /// </summary>
    public string WorkloadName { get; }

    /// <summary>
    ///     Container name.
    /// </summary>
    public string ContainerName { get; }

    /// <summary>
    ///     Toggles if requests and responses should be logged.
    /// </summary>
    public bool LogRequestResponseToggle { get; }
}
