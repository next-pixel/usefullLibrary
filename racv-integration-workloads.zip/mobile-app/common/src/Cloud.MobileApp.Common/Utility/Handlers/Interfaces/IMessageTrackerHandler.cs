﻿using Cloud.MobileApp.Common.Tracking.Enumerations;

namespace Cloud.MobileApp.Common.Utility.Handlers.Interfaces
{
    /// <summary>
    /// Provides methods to log requests and responses to a message tracker system.
    /// </summary>
    /// <typeparam name="TRequest">Request type.</typeparam>
    /// <typeparam name="TResponse">Response type.</typeparam>
    public interface IMessageTrackerHandler<in TRequest, in TResponse>
    {
        /// <summary>
        /// Logs a request and response pair to the message tracker system.
        /// </summary>
        /// <param name="request">Request object.</param>
        /// <param name="response">Response object.</param>
        /// <param name="correlationIdentifier">Correlation identifier corresponding to the original api call.</param>
        /// <param name="protocol">The protocol used in making the request e.g. HTTP or HTTPS.</param>
        /// <returns></returns>
        public Task LogRequestResponse(TRequest request, TResponse response, Guid correlationIdentifier, OperationProtocols protocol);
    }
}
