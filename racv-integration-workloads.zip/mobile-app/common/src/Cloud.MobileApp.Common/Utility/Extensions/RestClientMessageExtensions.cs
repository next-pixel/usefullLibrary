﻿using Cloud.MobileApp.Common.Constants;
using Cloud.MobileApp.Common.Tracking.Enumerations;
using Cloud.MobileApp.Common.Tracking.Helpers;
using Cloud.MobileApp.Common.Tracking.Interfaces;
using Cloud.MobileApp.Common.Tracking.Models;
using Microsoft.VisualBasic;
using Newtonsoft.Json;
using System.Globalization;

namespace Cloud.MobileApp.Common.Utility.Extensions
{
    /// <summary>
    /// Extension methods for the <see cref="RestRequest"/> and <see cref="RestResponse"/> classes.
    /// </summary>
    public static class RestClientMessageExtensions
    {
        /// <summary>
        /// Converts a <see cref="HttpRequestMessage"/> to a <see cref="TrackerRestRequestMessage"/>
        /// </summary>
        /// <param name="originalRequest"></param>
        /// <param name="correlationIdentifier"></param>
        /// <param name="interactionIdentifier"></param>
        /// <param name="workloadName"></param>
        /// <param name="protocol"></param>
        /// <param name="path"></param>
        /// <param name="excludeHeaders"></param>
        /// <param name="systemIdentifier"></param>
        /// <param name="operationName"></param>
        /// <param name="timestamp"></param>
        /// <param name="baseUrl"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        public static async Task<TrackerRestRequestMessage> GetRestRequestMessageAsync(
            this HttpRequestMessage originalRequest,
            Guid correlationIdentifier,
            Guid interactionIdentifier,
            string workloadName,
            OperationProtocols protocol,
            string? path,
            string[] excludeHeaders,
            string systemIdentifier,
            string operationName,
            DateTime timestamp)
        {
            if (originalRequest is null) throw new ArgumentNullException(nameof(originalRequest));
            if (correlationIdentifier == Guid.Empty) throw new ArgumentNullException(nameof(correlationIdentifier));
            if (interactionIdentifier == Guid.Empty) throw new ArgumentNullException(nameof(interactionIdentifier));
            if (string.IsNullOrWhiteSpace(workloadName)) throw new ArgumentNullException(nameof(workloadName));
            if (string.IsNullOrWhiteSpace(path)) throw new ArgumentNullException(nameof(path));
            if (excludeHeaders is null) throw new ArgumentNullException(nameof(excludeHeaders));
            if (string.IsNullOrWhiteSpace(systemIdentifier)) throw new ArgumentNullException(nameof(systemIdentifier));
            if (string.IsNullOrWhiteSpace(operationName)) throw new ArgumentNullException(nameof(operationName));

            Payload? payload = null;
            if (originalRequest.Content is not null)
            {
                payload = new Payload
                {
                    ContentType = originalRequest.Content.Headers.ContentType?.MediaType,
                    Body = await originalRequest.Content.ReadAsStringAsync()
                };
            }

            string xCorrelationIdentifier = originalRequest.Headers
                .GetValues(MobileAppConstants.CorrelationIdLogPropertyName)
                .First()!
                .ToString().ToLower(CultureInfo.InvariantCulture);

            var headers = originalRequest.Headers
                .Where(a => !excludeHeaders.Contains(a.Key) && a.Value.FirstOrDefault() is not null)
                .ToDictionary(a => a.Key, a => a.Value.First());

            var operationType = OperationTypes.Request;

            return new TrackerRestRequestMessage
            {
                CorrelationId = xCorrelationIdentifier,
                InteractionId = interactionIdentifier,
                ActivityId = Guid.NewGuid(),
                OperationName = operationName,
                WorkloadName = workloadName,
                MessageTimestamp = timestamp,
                OperationType = operationType,
                Protocol = protocol,
                Payload = payload,
                Path = path,
                Verb = operationName,
                QueryString = originalRequest.RequestUri?.ToString(),
                Headers = headers,
                SystemId = systemIdentifier,
                BaseUrl = originalRequest.RequestUri?.GetLeftPart(UriPartial.Authority)
            };
        }

        /// <summary>
        /// Converts a<see cref="HttpResponseMessage"/> to a <see cref = "TrackerRestResponseMessage" />
        /// </summary>
        /// <param name="originalResponse"></param>
        /// <param name="correlationIdentifier"></param>
        /// <param name="interactionIdentifier"></param>
        /// <param name="workloadName"></param>
        /// <param name="protocol"></param>
        /// <param name="excludeHeaders"></param>
        /// <param name="method"></param>
        /// <param name="systemIdentifier"></param>
        /// <param name="timestamp"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        public static async Task<TrackerRestResponseMessage> GetRestResponseMessageAsync(
            this HttpResponseMessage originalResponse,
            Guid correlationIdentifier,
            Guid interactionIdentifier,
            string workloadName,
            OperationProtocols protocol,
            string[] excludeHeaders,
            string method,
            string systemIdentifier,
            DateTime timestamp)
        {
            if (originalResponse is null) throw new ArgumentNullException(nameof(originalResponse));
            if (correlationIdentifier == Guid.Empty) throw new ArgumentNullException(nameof(correlationIdentifier));
            if (interactionIdentifier == Guid.Empty) throw new ArgumentNullException(nameof(interactionIdentifier));
            if (string.IsNullOrWhiteSpace(workloadName)) throw new ArgumentNullException(nameof(workloadName));
            if (string.IsNullOrWhiteSpace(method)) throw new ArgumentNullException(nameof(method));
            if (string.IsNullOrWhiteSpace(systemIdentifier)) throw new ArgumentNullException(nameof(systemIdentifier));

            var payload = new Payload
            {
                ContentType = originalResponse.Content.Headers.ContentType?.MediaType,
                Body = await originalResponse.Content.ReadAsStringAsync()
            };

            var headers = originalResponse.Headers
                .Where(a => !excludeHeaders.Contains(a.Key) && a.Value.FirstOrDefault() is not null)
                .ToDictionary(a => a.Key, a => a.Value.First());

            return new TrackerRestResponseMessage
            {
                CorrelationId = correlationIdentifier.ToString(),
                InteractionId = interactionIdentifier,
                ActivityId = Guid.NewGuid(),
                OperationName = method,
                WorkloadName = workloadName,
                MessageTimestamp = timestamp,
                OperationType = OperationTypes.Response,
                Protocol = protocol,
                Payload = payload,
                StatusCode = ((int)originalResponse.StatusCode),
                Headers = headers,
                SystemId = systemIdentifier
            };
        }
    }
}
