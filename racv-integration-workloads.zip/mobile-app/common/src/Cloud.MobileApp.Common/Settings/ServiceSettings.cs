namespace Cloud.MobileApp.Common.Settings;

public class ServiceSettings
{
    public const string ConfigurationSectionName = "ServiceSettings";
    public string? SubscriptionKey { get; set; } = null;
}