﻿using Cloud.MobileApp.Common.Constants;
using Microsoft.Extensions.Configuration;

namespace Cloud.MobileApp.Common.Settings
{
    public class AppSettings
    {
        [ConfigurationKeyName(MobileAppConstants.ApplicationInsightConnectionStringKey)]
        public string ApplicationInsightConnectionString { get; set; } = string.Empty;

        [ConfigurationKeyName(MobileAppConstants.AppConfigurationEndPointKey)]
        public string AppConfigurationEndPoint { get; set; } = string.Empty;

        [ConfigurationKeyName(MobileAppConstants.AzureClientId)]
        public string AzureClientId { get; set; } = string.Empty;

        [ConfigurationKeyName(MobileAppConstants.EnvironmentKey)]
        public string Environment { get; set; } = string.Empty;

        [ConfigurationKeyName(MobileAppConstants.WorkloadKey)]
        public string Workload { get; set; } = string.Empty;

        [ConfigurationKeyName(MobileAppConstants.BlobServiceUriKey)]
        public string BlobServiceUri { get; set; } = string.Empty;
    }
}
