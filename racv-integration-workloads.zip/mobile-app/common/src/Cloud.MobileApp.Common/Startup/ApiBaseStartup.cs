﻿using Cloud.MobileApp.Common.Constants;
using Cloud.MobileApp.Common.Extensions;
using Cloud.MobileApp.Common.Middleware;
using Cloud.MobileApp.Common.Settings;
using Cloud.MobileApp.Common.Tracking.Implementations;
using Cloud.MobileApp.Common.Tracking.Interfaces;
using Cloud.MobileApp.Common.Utility.Handlers.Implementation;
using Cloud.MobileApp.Common.Utility.Handlers.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using System.IO.Compression;

namespace Cloud.MobileApp.Common.Startup;

/// <summary>
///     Abstracts common steps when starting up an MobileApp api.
/// </summary>
public static class ApiBaseStartup
{
    /// <summary>
    ///     Configure services via dependency injection.
    /// </summary>
    /// <param name="builder">Web application builder.</param>
    /// <exception cref="ArgumentNullException"></exception>
    public static void ConfigureServices<TCaller>(WebApplicationBuilder builder, bool includeAllConfiguration = true)
    {
        ArgumentNullException.ThrowIfNull(builder);

        // Define keys used to access values in the configuration manager.
        var _systemName = "MobileAppApi";
        var _excludeHeaders = new[] { MobileAppConstants.Authorization, "subscription-key" };

        // Use response compression
        builder.Services.AddResponseCompression(options =>
        {
            options.EnableForHttps = true;
            options.Providers.Add<GzipCompressionProvider>();
            options.Providers.Add<BrotliCompressionProvider>();
        });

        builder.Services.Configure<BrotliCompressionProviderOptions>(options =>
        {
            options.Level = CompressionLevel.Fastest;
        });

        builder.Services.Configure<GzipCompressionProviderOptions>(options =>
        {
            options.Level = CompressionLevel.Fastest;
        });

        // Add configuration
        builder.Services.Configure<IConfiguration>(builder.Configuration);

        // Retrieve the app settings from the application configuration.
        var mobileAppSettings = new AppSettings();
        builder.Configuration.Bind(mobileAppSettings);

        // Enable application insights.
        builder.Services.AddApplicationInsights(mobileAppSettings.ApplicationInsightConnectionString);

        // Configure app configuration service in the web host.
        builder.ConfigureAppConfiguration<TCaller>(
            new Uri(mobileAppSettings.AppConfigurationEndPoint),
            mobileAppSettings.AzureClientId,
            mobileAppSettings.Environment,
            mobileAppSettings.Workload,
            MobileAppConstants.ConfigurationRefreshKey,
            includeAllConfiguration);

        builder.AddCustomModelValidationError();

        //Add OpenId authentication
        builder.Services
            .AddAuthentication(opts =>
            {
                opts.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                opts.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(
                opts =>
                {
                    var configManager = new ConfigurationManager<OpenIdConnectConfiguration>(
                        builder.Configuration[MobileAppConstants.OpenIdConfigurationUrl],
                        new OpenIdConnectConfigurationRetriever(),
                        new HttpDocumentRetriever())
                    { AutomaticRefreshInterval = new TimeSpan(1, 0, 0) };

                    var discoveryDocument = configManager.GetConfigurationAsync().GetAwaiter().GetResult();
                    var signingKeys = discoveryDocument.SigningKeys;
                    var issuer = discoveryDocument.Issuer;

                    opts.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidAudience = issuer,
                        ValidIssuer = issuer,
                        ValidateIssuer = true,
                        IssuerSigningKeys = signingKeys,
                        ValidateAudience = true,
                        RequireExpirationTime = true,
                        ValidateLifetime = true,
                        ClockSkew = TimeSpan.Zero
                    };
                });

        // Add message tracker system.
        builder.Services.AddTransient<IMessageTrackerMiddlewareConfiguration, MessageTrackerMiddlewareConfiguration>();
        builder.Services.AddMessageTracker(new Uri(mobileAppSettings.BlobServiceUri));

        // Add Message Tracker Handler.
        builder.Services.AddTransient<IMessageTrackerHandlerConfiguration, MessageTrackerHandlerConfiguration>();
        builder.Services
            .AddSingleton<IMessageTrackerHandler<HttpRequestMessage, HttpResponseMessage>, MessageTrackerHandler>(
                provider =>
                {
                    var logger = provider.GetRequiredService<ILogger<MessageTrackerHandler>>();
                    var messageTracker = provider.GetRequiredService<IMessageTracker>();
                    var messageTrackerHandlerConfiguration =
                        provider.GetRequiredService<IMessageTrackerHandlerConfiguration>();
                    return new MessageTrackerHandler(logger, messageTracker, messageTrackerHandlerConfiguration,
                        _systemName, _excludeHeaders);
                });

        // Default Services
        builder.Services.AddControllers();
        builder.Services.AddEndpointsApiExplorer();
    }

    /// <summary>
    ///     This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
    /// </summary>
    /// <param name="app">Application builder.</param>
    /// <param name="env">Environment.</param>
    /// <param name="logging">Logging builder.</param>
    /// <exception cref="ArgumentNullException"></exception>
    public static void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggingBuilder logging)
    {
        ArgumentNullException.ThrowIfNull(app);
        ArgumentNullException.ThrowIfNull(env);
        ArgumentNullException.ThrowIfNull(logging);

        if (env.IsDevelopment())
        {
            logging.AddDebug();
        }

        app.UseAzureAppConfiguration();
        app.UseMiddleware<ValidateCorrelationMiddleware>();
        app.UseMiddleware<RequestEnrichmentMiddleware>();
        app.UseMiddleware<MessageTrackerMiddleware>();
        app.UseAuthentication();
        app.UseAuthorization();
        app.UseHttpsRedirection();
        app.UseResponseCompression();
    }
}
