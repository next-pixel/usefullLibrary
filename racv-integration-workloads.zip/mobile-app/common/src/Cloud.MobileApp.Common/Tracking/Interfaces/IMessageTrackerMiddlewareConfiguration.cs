﻿namespace Cloud.MobileApp.Common.Tracking.Interfaces;

/// <summary>
///     Configuration values required by <see cref="MessageTrackerMiddleware" />.
/// </summary>
public interface IMessageTrackerMiddlewareConfiguration
{
    /// <summary>
    ///     Workload name.
    /// </summary>
    public string WorkloadName { get; }

    /// <summary>
    ///     Container name.
    /// </summary>
    public string ContainerName { get; }

    /// <summary>
    ///     Toggles if requests and responses should be logged.
    /// </summary>
    public bool LogRequestResponseToggle { get; }
}
