﻿using System.ComponentModel;

namespace Cloud.MobileApp.Common.Tracking.Enumerations
{
    /// <summary>
    /// Enumerates the operation protocols.
    /// </summary>
    public enum OperationProtocols
    {
        [Description("Unknown")]
        Unknown,
        [Description("GRPC")]
        GRPC,
        [Description("HTTP")]
        HTTP,
        [Description("HTTPS")]
        HTTPS,
        [Description("SMB")]
        SMB,
        [Description("SQL")]
        SQL,
        [Description("SOAP")]
        SOAP,
        [Description("XMLRPC")]
        XMLRPC,
        [Description("LDAP")]
        LDAP
    }
}
