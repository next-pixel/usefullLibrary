﻿using System.ComponentModel;

namespace Cloud.MobileApp.Common.Tracking.Enumerations
{
    /// <summary>
    /// Enumerates the operation types.
    /// </summary>
    public enum OperationTypes
    {
        [Description("Unknown")]
        Unknown,
        [Description("Request")]
        Request,
        [Description("Response")]
        Response
    }
}
