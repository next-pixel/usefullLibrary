﻿namespace Cloud.MobileApp.Common.Azure.Blob.Models
{
    /// <summary>
    /// Blob store operation response object.
    /// </summary>
    public class BlobOperationResponse
    {
        /// <summary>
        /// Status of the operation.
        /// </summary>
        public int StatusCode { get; set; }

        /// <summary>
        /// The blob model associated with the operation.
        /// </summary>
        public BlobModel? BlobModel { get; set; }

        public BlobOperationResponse(int statusCode, BlobModel blobModel) 
        {
            this.StatusCode = statusCode;
            this.BlobModel = blobModel;
        }
        public BlobOperationResponse(int statusCode)
        {
            this.StatusCode = statusCode;
        }

    }
}
