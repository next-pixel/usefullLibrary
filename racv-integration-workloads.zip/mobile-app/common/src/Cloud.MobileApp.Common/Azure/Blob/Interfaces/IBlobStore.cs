﻿using Cloud.MobileApp.Common.Azure.Blob.Models;
using System.Net;

namespace Cloud.MobileApp.Common.Azure.Blob.Interfaces
{
    /// <summary>
    /// Interface for Blob Store clients.
    /// </summary>
    public interface IBlobStore
    {
        /// <summary>
        /// Downloads a blob from a Blob Store container.
        /// </summary>
        /// <param name="filePath">Path to the blob in the container.</param>
        /// <param name="containerName">Container name.</param>
        /// <returns>The blob store operation response.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        Task<BlobOperationResponse> Download(string filePath, string containerName);

        /// <summary>
        /// Upload a blob to the Blob Store.
        /// </summary>
        /// <param name="blob">Blob details.</param>
        /// <param name="metadata">Optional metadata relating to the blob.</param>
        /// <returns>The blob store operation response.</returns>
        Task<BlobOperationResponse> Upload(BlobModel blob, Dictionary<string, string>? metadata = null);

        /// <summary>
        /// Deletes a blob from an Azure Blob Store container.
        /// </summary>
        /// <param name="filePath">Path to the blob in the container.</param>
        /// <param name="containerName">Container name.</param>
        /// <returns>The status of the delete request.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        Task<BlobOperationResponse> Delete(string filePath, string containerName);

        /// <summary>
        /// Checks whether a blob exists.
        /// </summary>
        /// <param name="blob">Blob details.</param>
        /// <returns>True with the blob exists within the client and false otherwise.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        Task<bool> Exists(BlobModel blob);

        /// <summary>
        /// Loads metadata for a blob.
        /// </summary>
        /// <param name="blob">Blob details.</param>
        /// <returns>Blob metadata.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        Task<Dictionary<string, string>> LoadMetadata(Uri blob);

        /// <summary>
        /// Gets the number of blobs in a container.
        /// </summary>
        /// <param name="containerName">Name of the container.</param>
        /// <returns>The number of blobs in the given container.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        Task<int> GetBlobCount(string containerName);
    }
}
