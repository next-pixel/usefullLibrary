﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.Runtime.Serialization;

namespace Cloud.MobileApp.Common.Exceptions
{
    /// <summary>
    /// Operation Failure Response message.
    /// </summary>
    [JsonObject]
    public class OperationFailureResponse
    {
        /// <summary>
        /// Gets or sets the Id of the object..
        /// </summary>
        /// <value>The Id.</value>
        public string? Id { get; set; }

        /// <summary>
        /// Gets or sets a global error message 
        /// </summary>
        /// <value>Error Message</value>
        public string? Message { get; set; }

        /// <summary>
        /// Gets or sets the ErrorDetails.
        /// </summary>
        /// <value>The ErrorDetails.</value>
        [DataMember(Name = "errorDetails")]
        [JsonProperty("errorDetails")]
        public OperationFailureResponseDetail[]? ErrorDetails { get; set; }

        public OperationFailureResponse(string message, OperationFailureResponseDetail[]? errorDetails, string? id = "")
        {
            this.Id = id;
            if (errorDetails is null || errorDetails.Length <= 0)
            {
                ErrorDetails =
                [
                    new OperationFailureResponseDetail
                    {
                        Message = message
                    }
                ];
                return;
            }
            Message = message;
            ErrorDetails = errorDetails;
        }
    }
}
