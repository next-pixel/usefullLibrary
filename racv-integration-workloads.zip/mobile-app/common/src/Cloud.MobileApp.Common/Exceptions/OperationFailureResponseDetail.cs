﻿using Newtonsoft.Json;
using System.Globalization;

namespace Cloud.MobileApp.Common.Exceptions
{
    /// <summary>
    /// Operation failure response details.
    /// </summary>
    [JsonObject]
    public class OperationFailureResponseDetail
    {
        /// <summary>
        /// When the error occured.
        /// </summary>
        [JsonProperty("timestamp")]
        public string Timestamp { get; set; } = DateTime.UtcNow.ToString("yyyy-MM-dd-HH:mm:ss.fffzz", CultureInfo.InvariantCulture);

        /// <summary>
        /// Error code.
        /// </summary>
        [JsonProperty("code")]
        public string Code { get; set; } = "";

        /// <summary>
        /// Message of the error.
        /// </summary>
        [JsonProperty("message")]
        public string? Message { get; set; }

        /// <summary>
        /// The entity that the error pertains to.
        /// </summary>
        [JsonProperty("entity")]
        public string? Entity { get; set; }
    }
}
