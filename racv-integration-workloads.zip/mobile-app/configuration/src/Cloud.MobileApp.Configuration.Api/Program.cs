using Cloud.MobileApp.Common.Startup;
using Azure.Identity;
using Azure.Extensions.AspNetCore.Configuration.Secrets;
using Cloud.MobileApp.Common.Constants;

namespace Cloud.MobileApp.Configuration.API;

internal class Program
{
    private Program() { }

    private static void Main(string[] args)
    {
        // Create the web application builder.
        var builder = WebApplication.CreateBuilder(args);

        // Add common services
        ApiBaseStartup.ConfigureServices<Program>(builder);

        // Add supplementary Key Vault reference
        builder.Configuration.AddAzureKeyVault(
            new Uri(builder.Configuration[InternalConstants.MiscKeyVaultBaseUrlKey]),
#if DEBUG
                new AzureCliCredential(),
#else
                new ManagedIdentityCredential(builder.Configuration[MobileAppConstants.AzureClientId]),
#endif
        new AzureKeyVaultConfigurationOptions());

        // Build the app
        var app = builder.Build();

        // Configure app
        ApiBaseStartup.Configure(app, app.Environment, builder.Logging);

        // Map controllers
        app.MapControllers();

        // Configure the HTTP request pipeline.
        app.Run();
    }
}
