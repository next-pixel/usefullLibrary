﻿namespace Cloud.MobileApp.Configuration.API
{
    public static class InternalConstants
    {
        internal const string MobileBaseConfigurationKey = "MobileBase";
        internal const string MobileAnalyticsConfigurationKey = "MobileAnalytics";
        internal const string MobileMiscConfigurationKey = "MobileMisc";

        /// <summary>
        /// Represents the key for the MiscKeyVaultBaseUrl configuration value.
        /// </summary>
        public const string MiscKeyVaultBaseUrlKey = "MiscKeyVaultBaseUrl";
    }
}
