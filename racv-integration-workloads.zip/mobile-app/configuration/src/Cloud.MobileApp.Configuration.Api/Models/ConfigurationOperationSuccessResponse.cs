﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace Cloud.MobileApp.Configuration.API.Models
{
    /// <summary>
    /// Class to return success response data on configuration operations
    /// </summary>
    public class ConfigurationOperationSuccessResponse
    {
        /// <summary>
        /// Successful operation message
        /// </summary>
        [DataMember(Name = "message")]
        [Required]
        public string Message { get; } = "Operation Successful.";

        /// <summary>
        /// Response data
        /// </summary>
        [DataMember(Name = "data")]
        [Required]
        public object? Data { get; set; }
    }
}
