﻿namespace Cloud.MobileApp.Configuration.API.Models
{
    public class MiscValuesResponse
    {
        public string SalesforceMCToken { get; set; } = string.Empty;
        public string SalesforceMCAppId { get; set; } = string.Empty;
        public string placesApiId1 { get; set; } = string.Empty;
        public string placesApiId2 { get; set; } = string.Empty;
        public string mapboxApiId { get; set; } = string.Empty;
    }
}
