﻿using System.Text;
using System.Text.Json;

namespace Cloud.MobileApp.Configuration.API.Extensions
{
    public static class ConfigurationSectionExtensions
    {
        public static async Task<IDictionary<string, object>> ToDictionaryAsync(this IConfigurationSection configurationSection)
        {
            var configSection = new Dictionary<string, object>();

            foreach (var item in configurationSection.GetChildren())
            {
                if (!string.IsNullOrWhiteSpace(item.Value))
                {
                    try
                    {
                        var stream = new MemoryStream(Encoding.UTF8.GetBytes(item.Value));
                        var deserializedObject = await JsonSerializer.DeserializeAsync<dynamic>(stream);
                        configSection.Add(item.Key, deserializedObject!);
                    }
                    catch (Exception)
                    {
                        configSection.Add(item.Key, item.Value);
                    }
                }
                else
                    configSection.Add(item.Key, item.Value!);
            }
            return configSection;
        }
    }
}
