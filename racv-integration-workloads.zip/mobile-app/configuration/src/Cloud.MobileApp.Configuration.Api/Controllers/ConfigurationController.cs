﻿using Cloud.MobileApp.Common.Constants;
using Cloud.MobileApp.Common.Exceptions;
using Cloud.MobileApp.Configuration.API.Extensions;
using Cloud.MobileApp.Configuration.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Cloud.MobileApp.Configuration.API.Controllers;

/// <summary>
///     Controller for get configuration.
/// </summary>
[ApiController]
[Route("v1")]
public class ConfigurationController : ControllerBase
{
    /// <summary>
    ///     This variable is used to fetch configuration
    /// </summary>
    private readonly IConfiguration _configuration;

    /// <summary>
    ///     This variable is used to log application related logs.
    /// </summary>
    private readonly ILogger<ConfigurationController> _logger;

    public ConfigurationController(
        ILogger<ConfigurationController> logger, 
        IConfiguration configuration)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
    }

    [HttpGet("base")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(ConfigurationOperationSuccessResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(OperationFailureResponse), StatusCodes.Status500InternalServerError)]
    [Produces("application/json")]
    public async Task<IActionResult> GetBaseConfigurationsAsyncAsync(
        [FromHeader(Name = MobileAppConstants.CorrelationIdLogPropertyName)]
        Guid xCorrelationIdentifier)
    {
        _logger.LogInformation(
            "CorrelationId : { "
            + MobileAppConstants.CorrelationIdLogPropertyName +
            "} Started executing Get Async Method.",
            xCorrelationIdentifier);

        var result = await _configuration
            .GetSection(InternalConstants.MobileBaseConfigurationKey)
            .ToDictionaryAsync();

        return Ok(new ConfigurationOperationSuccessResponse { Data = result });
    }

    [HttpGet("analytics")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(ConfigurationOperationSuccessResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(OperationFailureResponse), StatusCodes.Status500InternalServerError)]
    [Produces("application/json")]
    public async Task<IActionResult> GetAnalyticsConfigurationsAsyncAsync(
        [FromHeader(Name = MobileAppConstants.CorrelationIdLogPropertyName)]
        Guid xCorrelationIdentifier)
    {
        _logger.LogInformation(
            "CorrelationId : { "
            + MobileAppConstants.CorrelationIdLogPropertyName +
            "} Started executing Get Async Method.",
            xCorrelationIdentifier);

        var result = await _configuration
            .GetSection(InternalConstants.MobileAnalyticsConfigurationKey)
            .ToDictionaryAsync();

        return Ok(new ConfigurationOperationSuccessResponse { Data = result });
    }

    [HttpGet("misc")]
    [Authorize]
    [ProducesResponseType(typeof(ConfigurationOperationSuccessResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(OperationFailureResponse), StatusCodes.Status500InternalServerError)]
    [Produces("application/json")]
    public IActionResult GetMiscConfigurations(
        [FromHeader(Name = MobileAppConstants.CorrelationIdLogPropertyName)]
        Guid xCorrelationIdentifier)
    {
        var miscValuesResponse = new MiscValuesResponse();
        _configuration.Bind(miscValuesResponse);

        _logger.LogInformation(
            "CorrelationId : { "
            + MobileAppConstants.CorrelationIdLogPropertyName
            + "} Started executing Get Async Method.",
            xCorrelationIdentifier);

        return Ok(new ConfigurationOperationSuccessResponse { Data = miscValuesResponse });
    }
}