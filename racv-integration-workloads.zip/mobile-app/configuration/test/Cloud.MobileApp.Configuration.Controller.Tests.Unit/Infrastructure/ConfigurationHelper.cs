﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cloud.MobileApp.Configuration.Controller.Tests.Unit.Infrastructure
{
    public static class ConfigurationHelper
    {
        public static IConfiguration GetConfiguration()
        {
            var config = new ConfigurationBuilder()
                .SetBasePath(AppContext.BaseDirectory)
                .AddJsonFile("appsettings.test.json", false, true)
                .Build();
            return config;
        }
    }
}
