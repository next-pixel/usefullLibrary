﻿using Cloud.MobileApp.Configuration.API.Controllers;
using Cloud.MobileApp.Configuration.Controller.Tests.Unit.Infrastructure;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Cloud.MobileApp.Configuration.Controller.Tests.Unit.UnitTests
{
    /// <summary>
    /// Tests the create Configuration controller methods.
    /// </summary>
    public class ConfigurationTest
    {
        /// <summary>
        /// Gets the controller with mocked dependencies.
        /// </summary>
        /// <param name="service">Mocked service object.</param>
        /// <returns><see cref="ConfigurationController"/> controller.</returns>
        private static ConfigurationController GetController()
        {
            var logger = LoggerHelper.GetLogger<ConfigurationController>();
            return new ConfigurationController(
                logger.Object,
                ConfigurationHelper.GetConfiguration());
        }

        [Fact]
        public async Task ConfigurationController_GetBaseConfiguration_ShouldPass()
        {
            //Arrange
            var controller = GetController();

            //Act
            var result = await controller.GetBaseConfigurationsAsyncAsync(Guid.NewGuid()) as ObjectResult;

            //Assert
            result.Should().NotBeNull();
            result!.Value.Should().NotBeNull();
            result!.StatusCode.Should().Be(StatusCodes.Status200OK);
        }

        [Fact]
        public async Task ConfigurationController_GetAnalyticsConfiguration_ShouldPass()
        {
            //Arrange
            var controller = GetController();

            //Act
            var result = await controller.GetAnalyticsConfigurationsAsyncAsync(Guid.NewGuid()) as ObjectResult;

            //Assert
            result.Should().NotBeNull();
            result!.Value.Should().NotBeNull();
            result!.StatusCode.Should().Be(StatusCodes.Status200OK);
        }

        [Fact]
        public void ConfigurationController_GetMiscConfiguration_ShouldPass()
        {
            //Arrange
            var controller = GetController();

            //Act
            var result = controller.GetMiscConfigurations(Guid.NewGuid()) as ObjectResult;

            //Assert
            result.Should().NotBeNull();
            result!.Value.Should().NotBeNull();
            result!.StatusCode.Should().Be(StatusCodes.Status200OK);
        }
    }
}
